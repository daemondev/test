﻿VSJS_SliderControl.prototype = new VSJS_CBase();

function VSJS_SliderControl(_name) {
    var _this = this;
    VSJS_CBase.call(this);
    _this.CID = "SliderControl";
    _this.InitializeLayer(_name, "SPAN", false);
    _this.input = _this.GetInputElement();
    _this.layer = _this.GetLayerElement();
    _this.input.className = "slider-wrapper theme-default";
    _this.nivoActivated = false;

    _this.ContentListUpdated = function () {
        var list = _this.ContentList();
        if (list == null) {
            return;
        };
        if (list.length == 0) {
            return;
        };
        if (_this.nivoActivated) {
            return;
        };
        if (_this.IsRendered()) {
            if (list.length > 0) {
                _this.nivoActivated = true;
                var sz = _this.Size();
                _this.links = [];
                for (var o in list) {
                    eval("var item = " + list[o] + ";");

                    var aa = document.createElement("A");
                    if (item.targetURL != "" && item.targetURL != "#") {
                        aa.href = item.targetURL;
                        aa.target = "_blank";
                    };
                    aa.style.display = "none";
                    aa.className = "nivo-imageLink";
                    var img = document.createElement("IMG");
                    img.src = item.imageURL;
                    img.title = item.captionText;
                    img.width = sz.w;
                    img.height = sz.h;

                    aa.appendChild(img);
                    _this.links.push(aa);
                    _this.input.appendChild(aa);
                };
                _this.SetClickData(0);
                var ob = { slices: _this.slices, boxCols: _this.boxCols, boxRows: _this.boxRows,
                    startSlide: _this.startSlide, directionNav: _this.directionNav,
                    keyboardNav: false
                , directionNavHide: _this.directionNavHide,
                    afterChange: function () {
                        var act = 0;
                        for (var o in _this.links) {
                            if (_this.links[o].style.display == "block") {
                                act = o;
                                break;
                            };
                        };
                        _this.SetClickData(act);
                    }, pauseTime: _this.pauseTime
                };

                $(_this.input).nivoSlider(ob);
            };
        };
    };

    _this.OnRenderCompleted = function () { 
        _this.ContentListUpdated();
    };

    _this.pauseTime = 4000;
    _this.PauseTime = function (pt) {
        if (pt != _this.pauseTime) {
            _this.pauseTime = pt;
            if (_this._Rendered) {
                _this.ContentListUpdated();
            };
        };
    };

    _this.slices = 5;
    _this.Slices = function (pt) {
        if (pt != _this.slices) {
            _this.slices = pt;
            if (_this._Rendered) {
                _this.ContentListUpdated();
            };
        };
    };

    _this.boxCols = 5;
    _this.BoxCols = function (pt) {
        if (pt != _this.boxCols) {
            _this.boxCols = pt;
            if (_this._Rendered) {
                _this.ContentListUpdated();
            };
        };
    };

    _this.boxRows = 5;
    _this.BoxRows = function (pt) {
        if (pt != _this.boxRows) {
            _this.boxRows = pt;
            if (_this._Rendered) {
                _this.ContentListUpdated();
            };
        };
    };

     _this.startSlide= 0;
     _this.StartSlide = function (pt) {
        if (pt != _this.startSlide) {
            _this.startSlide = pt;
            if (_this._Rendered) {
                _this.ContentListUpdated();
            };
        };
    };

    _this.directionNav = true; 
     _this.DirectionNav = function (pt) {
        if (pt != _this.directionNav) {
            _this.directionNav = pt;
            if (_this._Rendered) {
                _this.ContentListUpdated();
            };
        };
    };

    _this.directionNavHide = true; 
     _this.DirectionNavHide = function (pt) {
        if (pt != _this.directionNavHide) {
            _this.directionNavHide = pt;
            if (_this._Rendered) {
                _this.ContentListUpdated();
            };
        };
    }; 
};