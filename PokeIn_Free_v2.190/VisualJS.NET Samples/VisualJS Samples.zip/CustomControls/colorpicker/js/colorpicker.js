﻿VSJS_ColorPicker.prototype = new VSJS_CBase();

function VSJS_ColorPicker(_name) {
    VSJS_CBase.call(this);
    var _this = this;
    _this.CID = "ColorPicker";
    _this.InitializeLayer(_name, "TEXT", false);
    var _i = _this.GetInputElement();
    VSJS_MaskedTextBox.MaskBinder(_this); 
    _i.className = "VSJS_TextBox";
    var _l = _this.GetLayerElement();

    _this.leaved = function () {
        _this.cShow.style.backgroundColor = _this.Text();
    };

    JTool.AttachElementEvent(_i, "blur", _this.leaved);
    JTool.AttachElementEvent(_i, "keyup", function () {
        if (_this._Rendered && !JTool.Touch) {
            $(_i).ColorPickerSetColor(_this.Text());
        };
    });

    _this.TextUpdated = function (txt) {
        if (_this._Rendered && !JTool.Touch) {
            $(_i).ColorPickerSetColor(txt);
            _this.cShow.style.backgroundColor = txt;
        };
    };

    _l.style.overflow = "hidden";
    _this.cShow = document.createElement("div");
    _this.cShow.style.cssText = "position:absolute;display:block;border:solid 1px #000;width:15px;height:15px;z-index:2;top:2px;right:3px;";
    _l.appendChild(_this.cShow);
    _this.cShow.onmousedown = function () {
        if (_this._Rendered && !JTool.Touch) {
            $(_i).ColorPickerShow();
        };
    };

    _this.bdDiff = -1;
    _this.borderStyle = LayerBase.Border.Fixed3D;

    _this.OnSizeChanged = function (w, h) {
        if (w <= 1 || h <= 1) {
            return;
        };
        if (_this.bdDiff == -1) {
            _this.bdDiff = 4;
        };
        _i.style.width = w - _this.bdDiff + "px";
        _i.style.height = h - _this.bdDiff + "px";
    };

    _this.BorderStyleUpdated = function (s) {
        var oldBd = _this.bdDiff;
        switch (s) {
            case LayerBase.Border.None:
                _this.bdDiff = 0;
                _i.style.boxShadow = "none";
                break;
            case LayerBase.Border.FixedSingle:
            case LayerBase.Border.Fixed3D:
                _this.bdDiff = 4;
                _i.style.boxShadow = "";
                break;
            default:
                _this.bdDiff = 4;
                _i.style.boxShadow = "";
        };
        if (oldBd == -1) {
            oldBd = _this.bdDiff;
        };
        var sz = _this.Size();
        var d = oldBd - _this.bdDiff;
        _this.OnSizeChanged(sz.w - d, sz.h - d);
    };

    _this.OnRenderCompleted = function () {
        _l._frm = _this._Form;
        var txt = _this.Text();
        if (!JTool.Touch) {
            $(_i).ColorPicker({
                onSubmit: function (hsb, hex, rgb, el) {
                    if (hex.length == 0) {
                        return;
                    };
                    var cc = JTool.Trim(hex);
                    if (cc.charAt(0) != '#') {
                        cc = "#" + cc;
                    };
                    $(_i).val(cc);
                    _this.cShow.style.backgroundColor = cc;
                    $(_i).ColorPickerHide();
                    if (_this.OnChanged != null) {
                        _this.OnChanged(_this.Name, null);
                    };
                },
                onCancel: function () {
                    $(_i).ColorPickerHide();
                }
            });

            $(_i).ColorPickerSetColor(txt);
            _this.cShow.style.backgroundColor = txt;
        };

        _this.Mask();

        _this.stChangedIndex = _this._Form.InnerStatusChanged.push(_this.StChanged) - 1;
    };
    _this.clientSize = { w: 0, h: 0 };

    _this.OnControlRemoved = function () {
        if (_this._Rendered) {
            _this.Hide();
        };
        if (_this.stChangedIndex != null) {
            _this._Form.InnerStatusChanged[_this.stChangedIndex] = null;
        };
    };

    _this.Show = function () {
        if (_this._Rendered && !JTool.Touch) {
            $(_i).ColorPickerShow();
        };
    };

    _this.Hide = function () {
        if (_this._Rendered && !JTool.Touch) {
            $(_i).ColorPickerHide();
        };
    }; 

    _this.StChanged = function (name, sta) {
        _this.Hide();
    };

    _this.CharacterCasing("upper");
    _this.Text("FFFFFF");
};