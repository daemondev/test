﻿namespace VisualJS.Kernel
{
    public enum Localization
    {
        Arabic,
        Chinese,
        EnglishGB,
        EnglishUS,
        French,
        German,
        Italian,
        Russian,
        Spanish,
        Turkish
    };
}