﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using VisualJS;
using VisualJS.Kernel;
using VisualJS.Service;

namespace VisualJS.Web.Forms 
{
    [ToolboxItem(true),ToolboxBitmap(typeof(System.Windows.Forms.ToolStripContainer)), Description("VisualJS UserControl")]
    public partial class SliderControl : VisualJS.Web.Forms.ExternalControl
    { 
        public SliderControl():base("SliderControl")
        {
            this.OnCommit = Resources; 
            InitializeComponent();  
        } 

        void Resources()  
        {
            VisualJS.Kernel.Settings.JQuerySupport = true;
                 
            if (ComponentRegister.Register(typeof(SliderControl))) 
            {   
                Assembly appAsm = Assembly.GetExecutingAssembly();
                ComponentRegister.RegisterFolder(appAsm, "WebControls.slider");
                ComponentRegister.Merge(new string[]{
                    "WebControls.slider.js.jquery.nivo.slider.pack.js",
                    "WebControls.slider.js.slider.js"}
                    , "WebControls.slider.js", "js", Encoding.UTF8);
            } 

            this.ClientLoadCheck("WebControls.slider.js", ClientSideDocuments.Script);
            this.ClientLoadCheck("WebControls.slider.css.nivo-slider.css", ClientSideDocuments.CSS);
        } 

        public class SliderItem
        {
            internal string ImageURL = "", TargetURL = "", CaptionText = "";

            public override string ToString()
            {
                return "{" + "imageURL:\"" + ImageURL + "\"," + "targetURL:\"" + TargetURL + "\","
                              + "captionText:\"" + CaptionText + "\"}";
            }

            public override int GetHashCode()
            {
                return ToString().Length + ImageURL.GetHashCode();
            }

            public override bool Equals(object obj)
            {
                SliderItem item = (SliderItem)obj;
                return item.ToString() == this.ToString();
            }

            public SliderItem(string imageURL, string targetURL, string captionText)
            {
                ImageURL = imageURL;
                TargetURL = targetURL;
                CaptionText = captionText;
            }
        }

        internal bool dataSet = false;

        /// <summary>
        /// Add list of slides (you may only call this method one time within object's lifetime)
        /// </summary>
        /// <param name="slides">list of slides</param>
        public void AddSlide(List<SliderItem> slides)
        {
            if (dataSet)
                return;
            dataSet = true;

            ContentCollection.Contents.BeginUpdate();
            foreach (SliderItem slide in slides)
            {
                ContentCollection.Contents.Add(slide.ToString());
            }
            ContentCollection.Contents.EndUpdate();
        } 

        /// <summary>
        /// Client side component doesn't support docking
        /// </summary>
        [Browsable(false), EditorBrowsable(EditorBrowsableState.Never)]
        public new DockStyle Dock
        {
            get { return base.Dock; }
            set { }
        }

        [Browsable(false)]
        public new bool AutoScroll
        {
            get
            {
                return base.AutoScroll;
            }
            set
            {
            }
        }

        internal int slices = 5;
        [Browsable(true), Description("For slice animations")]
        public int Slices 
        {
            get
            {
                return slices;
            }
            set
            {
                if (slices != value)
                    SetProperty("Slices", value);
                slices = value;
            }
        }

        internal int boxCols = 5;
        [Browsable(true), Description("For box animations")]
        public int BoxCols
        {
            get
            {
                return boxCols;
            }
            set
            {
                if (boxCols != value)
                    SetProperty("BoxCols", value);
                boxCols = value;
            }
        }

        internal int boxRows = 5;
        [Browsable(true), Description("For box animations")]
        public int BoxRows
        {
            get
            {
                return boxRows;
            }
            set
            {
                if (boxRows != value)
                    SetProperty("BoxRows", value);
                boxRows = value;
            }
        }

        internal int pauseTime = 4000;
        [Browsable(true), Description("How long each slide will show")]
        public int PauseTime
        {
            get
            {
                return pauseTime;
            }
            set
            {
                if (pauseTime != value)
                    SetProperty("PauseTime", value);
                pauseTime = value;
            }
        }

        internal int startSlide = 0;
        [Browsable(true), Description("Set starting Slide (0 index)")]
        public int StartSlide
        {
            get
            {
                return startSlide;
            }
            set
            {
                if (startSlide != value)
                    SetProperty("StartSlide", value);
                startSlide = value;
            }
        }

        internal bool directNav = true;
        [Browsable(true), Description("Next & Prev navigation")]
        public bool DirectNav
        {
            get
            {
                return directNav;
            }
            set
            {
                if (directNav != value)
                    SetProperty("DirectNav", value);
                directNav = value;
            }
        }

        internal bool directNavHide = true;
        [Browsable(true), Description("Only show on hover")]
        public bool DirectNavHide
        {
            get
            {
                return directNavHide;
            }
            set
            {
                if (directNavHide != value)
                    SetProperty("DirectNavHide", value);
                directNavHide = value;
            }
        }

        [Browsable(false)]
        public new bool ReadOnly
        {
            get
            {
                return base.ReadOnly;
            }
            set
            {
            }
        }

        [Browsable(false)]
        public string ClickInfo
        {
            get
            {
                return base.ClickData;
            }
        }
    }
}
