﻿using System;
using System.ComponentModel;
using System.Drawing;
using VisualJS.Kernel;
using VisualJS.Service;
using System.Reflection;
using System.Text; 
namespace VisualJS.Web.Forms
{
    [ToolboxItem(true), ToolboxBitmap(typeof(System.Windows.Forms.TextBox)),Description("VisualJS ColorPicker Control"), DefaultEvent("TextChanged")]
    public class ColorPicker : MaskedTextBox
    { 
        public ColorPicker():base("ColorPicker")
        {
            this.OnCommit = Resources;
            base.Mask = "#??????";
            base.RegexCheck = "^#?([a-f]|[A-F]|[0-9]){3}(([a-f]|[A-F]|[0-9]){3})?$";
        }

        public override void Extend(ref StringBuilder code)
        {
            //MaskedTextBox reads "Text" value instead "UnMaskedText"
            //We need "UnMaskedText" value for ColorPicker hence the method is overriden
            code.Append("VSJS['~THIS_COMPONENT'].OnChanged = function(sender, ev){");
            code.Append("pCall['~PARENT_COMPONENT'].SStr(VSJS['~THIS_COMPONENT'].UnMaskedText(),\"Text\",\"~THIS_COMPONENT\");};");
        }

        private void Resources()
        {
            VisualJS.Kernel.Settings.JQuerySupport = true;

            if (ComponentRegister.Register(typeof(ColorPicker)))
            {
                Assembly appAsm = Assembly.GetExecutingAssembly();
                ComponentRegister.RegisterFolder(appAsm, "WebControls.colorpicker");  

                ComponentRegister.Merge(new string[]{
                    "WebControls.colorpicker.js.jquery-colorpicker.js",
                    "WebControls.colorpicker.js.colorpicker.js"}, "WebControls.colorpicker.js", "js", Encoding.UTF8);

                string CSS = ComponentRegister.GetText("WebControls.colorpicker.css.colorpicker.css", Encoding.UTF8);
                string[] resNames = appAsm.GetManifestResourceNames();
                foreach (string resName in resNames)
                {
                    if (resName.StartsWith("WebControls.colorpicker.img"))
                    {
                        string fileName = resName.Replace("WebControls.colorpicker.img.", "");
                        CSS = CSS.Replace("img/" + fileName, "[$$VisualJSResourceTarget$$]?name=" + resName + "&type=image");
                    }
                }
                ComponentRegister.SetText("WebControls.colorpicker.css.colorpicker.css", CSS, Encoding.UTF8);
            }

            this.ClientLoadCheck("WebControls.colorpicker.js", ClientSideDocuments.Script);
            this.ClientLoadCheck("WebControls.colorpicker.css.colorpicker.css", ClientSideDocuments.CSS);
        }

        [Browsable(false), EditorBrowsable(EditorBrowsableState.Never)]
        public new string Mask{get{return base.Mask;}set{}}

        [Browsable(false), EditorBrowsable(EditorBrowsableState.Never)]
        public new int MinLength { get { return -1; } set { } }

        [Browsable(false), EditorBrowsable(EditorBrowsableState.Never)]
        public new char PromptChar { get { return base.PromptChar; } set { } }

        [Browsable(false), EditorBrowsable(EditorBrowsableState.Never)]
        public new System.Windows.Forms.CharacterCasing CharacterCasing { get { return base.CharacterCasing; } set { } }

        [Browsable(false), EditorBrowsable(EditorBrowsableState.Never)]
        public new string RegexCheck{get{return base.RegexCheck;}set{}}

        [Browsable(false), EditorBrowsable(EditorBrowsableState.Never)]
        public new bool CheckForEmail{get{return base.CheckForEmail;}set{}}

        [Browsable(false), EditorBrowsable(EditorBrowsableState.Never)]
        public new bool PasswordMode{get{return base.PasswordMode;}set{}}

        internal bool colorInputValidation = true;

        /// <summary>
        /// Client Side Regex Based Color Validation
        /// </summary>
        [Browsable(true), Description("Client Side Regex Based Color Validation")]
        public bool ColorInputValidation 
        {
            get
            {
                return colorInputValidation;
            }
            set
            {
                if (colorInputValidation == value)
                    return;

                colorInputValidation = value;
                if (value)
                    base.RegexCheck = "^#?([a-f]|[A-F]|[0-9]){3}(([a-f]|[A-F]|[0-9]){3})?$";
                else
                    base.RegexCheck = "";
            }
        }

        public Color Color
        {
            get
            {
                return base.Text.ToColor();
            }
            set
            {
                string clr = value.ToWebColor().Replace("#","");
                base.Text = clr;
            }
        }

        public override string Text
        {
            get
            {
                return base.Text;
            }
            set
            {
                if (base.Text == value || value == null)
                    return;

                base.Text = value.Replace("#","");
            }
        }

    }
}