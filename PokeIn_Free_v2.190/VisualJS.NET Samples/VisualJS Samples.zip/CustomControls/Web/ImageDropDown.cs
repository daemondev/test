﻿using System; 
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms; 
using VisualJS.Kernel.Controls;
using VisualJS.Service;
using VisualJS.Kernel; 
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text; 
namespace VisualJS.Web.Forms
{ 
    [ToolboxItem(true)]
    [ToolboxBitmap(typeof(System.Windows.Forms.ComboBox))]
    [Description("VisualJS ImageDropDown Control")]
    public class ImageDropDown : ComboBox
    {
        public ImageDropDown()
            : base("ImageDropDown")
        {
            Items = new ImageDropDownItems(this);
            this.OnCommit = Resources;
        }

        private void Resources()
        {
            VisualJS.Kernel.Settings.ActivateJQuery = true;

            if (ComponentRegister.Register(typeof(ImageDropDown)))
            {
                Assembly appAsm = Assembly.GetExecutingAssembly();
                ComponentRegister.RegisterFolder(appAsm, "WebControls.dropdown");

                ComponentRegister.Merge(
                    new string[] { "WebControls.dropdown.js.jquery.dd.js", "WebControls.dropdown.js.dropdown.js" },
                    "WebControls.dropdown.js",
                    "js",
                    Encoding.UTF8);

                string CSS = ComponentRegister.GetText("WebControls.dropdown.css.dropdown.css", Encoding.UTF8);
                string[] resNames = appAsm.GetManifestResourceNames();
                foreach (string resName in resNames)
                {
                    if (resName.StartsWith("WebControls.dropdown.img"))
                    {
                        string fileName = resName.Replace("WebControls.dropdown.img.", "");
                        CSS = CSS.Replace(
                            "img/" + fileName, "[$$VisualJSResourceTarget$$]?name=" + resName + "&type=image");
                    }
                }
                ComponentRegister.SetText("WebControls.dropdown.css.dropdown.css", CSS, Encoding.UTF8);
            }

            this.ClientLoadCheck("WebControls.dropdown.js", ClientSideDocuments.Script);
            this.ClientLoadCheck("WebControls.dropdown.css.dropdown.css", ClientSideDocuments.CSS);
        }

        [Browsable(false)]
        [EditorBrowsable(EditorBrowsableState.Never)]
        public new ImageDropDownItems Items;

        public class ImageDropDownItems : ObjectCollection, IList
        {
            internal ImageDropDown owner_box;

            internal List<object> items = new List<object>();

            public ImageDropDownItems(ImageDropDown owner)
                : base(owner)
            {
                owner_box = owner;
            }

            internal ImageItem Convert(object item)
            {
                ImageItem iitem;
                if (item.GetType() == typeof(string) || item.GetType() == typeof(double)
                    || item.GetType() == typeof(long) || item.GetType() == typeof(char) || item.GetType() == typeof(int)
                    || item.GetType() == typeof(decimal) || item.GetType() == typeof(bool)
                    || item.GetType() == typeof(float)) iitem = new ImageItem(item.ToString());
                else if (item.GetType() == typeof(ImageItem)) iitem = (ImageItem)item;
                else throw new Exception("This value type is not supported by ImageDropDown component");

                return iitem;
            }

            public new Int32 Add(object item)
            {
                ImageItem iitem = Convert(item);

                return Add(iitem);
            }

            internal void ItemAdding(ref ImageItem item)
            {
                owner_box.SetMethod("AddItem", new object[] { new Kernel.JSON(PokeIn.JSON.ClassTo(item)) });
            }

            public Int32 Add(ImageItem item)
            {
                int index;
                lock (items)
                {
                    items.Add(item);
                    index = items.Count - 1;
                }
                ItemAdding(ref item);
                return index;
            }

            public new void Remove(object item)
            {
                int pos;
                lock (items)
                {
                    pos = items.IndexOf(item);
                    if (pos >= 0) items.RemoveAt(pos);
                }
                if (pos >= 0)
                {
                    owner_box.SetMethod("RemoveAt", new object[] { pos });
                }
            }

            public void Remove(ImageItem item)
            {
                Remove((object)item);
            }

            public new void RemoveAt(int index)
            {
                lock (items)
                {
                    items.RemoveAt(index);
                }
                owner_box.SetMethod("RemoveAt", new object[] { index });
            }

            public new void Clear()
            {
                lock (items)
                {
                    items.Clear();
                }
                owner_box.SetMethod("ClearItems", null);
            }

            public new void AddRange(object[] _items)
            {
                foreach (object item in _items)
                {
                    Add(item);
                }
            }

            public void AddRange(ImageItem[] _items)
            {
                foreach (ImageItem item in _items)
                {
                    Add(item);
                }
            }

            internal new void Insert(Int32 index, object item)
            {
                Insert(index, Convert(item));
            }

            public void Insert(Int32 index, ImageItem item)
            {
                lock (items)
                {
                    items.Insert(index, item);
                }
                owner_box.SetMethod("InsertItem", new object[] { index, new Kernel.JSON(PokeIn.JSON.ClassTo(item)) });
            }

            public new ImageItem this[int index]
            {
                get
                {
                    return (ImageItem)base[index];
                }
            }
        }


        public class ImageItem
        {
            internal string i_text = "", i_image = " ";

            internal bool i_enabled = true;

            public ImageItem(string title, string imageURL, bool enabled)
            {
                i_image = imageURL;
                i_text = title;
                i_enabled = enabled;
            }

            public ImageItem(string title, string imageURL)
            {
                i_image = imageURL;
                i_text = title;
            }

            public ImageItem(string title)
            {
                i_text = title;
            }

            public bool Enabled
            {
                get
                {
                    return i_enabled;
                }
            }

            public string Text
            {
                get
                {
                    return i_text;
                }
            }

            public string ImageURL
            {
                get
                {
                    return i_image;
                }
            }
        }
    }
}
