﻿using System;
using System.ComponentModel;
using System.Drawing;
using VisualJS.Kernel;
using VisualJS.Service;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
namespace VisualJS.Web.Forms
{
    [ToolboxItem(true), ToolboxBitmap(typeof(System.Windows.Forms.RichTextBox)), Description("VisualJS RichTextBox Control")]
    public class RichTextBox : TextBox
    {
        public RichTextBox()
            : base("RichTextBox")
        {
            this.OnCommit = Resources;
            base.Multiline = true;
        }

        internal string buttons = "style,alignment,colors,insert,undoredo";
        [Description("RichTextBox Toolbar Buttons (You cant change the effect on run time)")]
        public string Buttons 
        {
            get
            {
                return buttons;
            }
            set
            {
                if (value == buttons)
                    return;
                string[] vals = value.Split(',');
                string val = "";
                foreach (string v in vals)
                {
                    if (String.IsNullOrEmpty(v.Trim()))
                        continue;
                    if (val.Length > 0)
                        val += ",";
                    val += v;
                }

                if (!DesignMode)
                    SetProperty("Buttons", val);
                buttons = val;
            }
        }

        internal string lang = "en"; 
        [Description("RichTextBox Language (You cant change the effect on run time)"), DefaultValue("en")]
        public string Lang 
        {
            get
            {
                return lang;
            }
            set
            {
                if (value == lang)
                    return;

                if(!DesignMode)
                    SetProperty("Lang", value);

                lang = value;
            }
        }

        private void Resources()
        {
            VisualJS.Kernel.Settings.JQuerySupport = true;

            if (ComponentRegister.Register(typeof(RichTextBox)))
            {  
                Assembly appAsm = Assembly.GetExecutingAssembly();
                ComponentRegister.RegisterFolder(appAsm, "WebControls.elrte");  
                   
                ComponentRegister.Merge(new string[]{
                    "WebControls.elrte.js.elrte.min.vsjs.js", "WebControls.elrte.lang.ar.js", 
                    "WebControls.elrte.lang.ca.js", "WebControls.elrte.lang.cs.js", 
                    "WebControls.elrte.lang.da.js", "WebControls.elrte.lang.de.js", 
                    "WebControls.elrte.lang.es.js", "WebControls.elrte.lang.fa.js", 
                    "WebControls.elrte.lang.fr.js", "WebControls.elrte.lang.hr.js", 
                    "WebControls.elrte.lang.hu.js", "WebControls.elrte.lang.it.js", 
                    "WebControls.elrte.lang.jp.js", "WebControls.elrte.lang.ko.js", 
                    "WebControls.elrte.lang.lv.js", "WebControls.elrte.lang.nl.js", 
                    "WebControls.elrte.lang.pl.js", "WebControls.elrte.lang.pt_BR.js", 
                    "WebControls.elrte.lang.ru.js", "WebControls.elrte.lang.sk.js", 
                    "WebControls.elrte.lang.th.js", "WebControls.elrte.lang.tr.js", 
                    "WebControls.elrte.lang.uk.js", "WebControls.elrte.lang.vi.js", 
                    "WebControls.elrte.lang.zh_CN.js", "WebControls.elrte.lang.zh_TW.js", 
                    "WebControls.elrte.js.RichTextBox.js"}, "WebControls.RichTextBox.js", "js", Encoding.UTF8);

                string CSS = ComponentRegister.GetText("WebControls.elrte.css.elrte.min.css", Encoding.UTF8);
                CSS = CSS.Replace("../images/elrte-toolbar.png", "[$$VisualJSResourceTarget$$]?name=WebControls.elrte.img.elrte-toolbar.png&type=image");
                CSS = CSS.Replace("../images/pixel.gif", "[$$VisualJSResourceTarget$$]?name=WebControls.elrte.img.pixel.gif&type=image");
                ComponentRegister.SetText("WebControls.elrte.css.elrte.min.css", CSS, Encoding.UTF8);
            }

            this.ClientLoadCheck("WebControls.RichTextBox.js", ClientSideDocuments.Script);
            this.ClientLoadCheck("WebControls.elrte.css.elrte.min.css", ClientSideDocuments.CSS); 
        }

        #region Disabled 
        [Browsable(false)]
        public new bool CheckForEmail{get{return base.CheckForEmail;}set{}}

        [Browsable(false)]
        public new Color BackColor { set { } get { return base.BackColor; } }

        [Browsable(false)]
        public new Color ForeColor { set { } get { return base.ForeColor; } }

        [Browsable(false)]
        public new Font Font { set { } get { return base.Font; } }

        [Browsable(false)]
        public new bool ReadOnly { set { } get { return base.ReadOnly; } }

        [Browsable(false)]
        public new Cursor Cursor { set { } get { return base.Cursor; } }

        [Browsable(false)]
        public new TooltipDirections TooltipDirection { get { return base.TooltipDirection; } set { } }

        [Browsable(false)]
        public new string TooltipText { get { return base.TooltipText; } set { } }

        [Browsable(false)]
        public new string CustomFontFamilies { get { return base.CustomFontFamilies; } set { } } 

        [Browsable(false)]
        public new HorizontalAlignment TextAlign { set { } get { return base.TextAlign; } }

        [Browsable(false)]
        public new bool PreventSQLInjection { set { } get { return base.PreventSQLInjection; } }

        [Browsable(false)]
        public new bool WordWrap { set { } get { return base.WordWrap; } }

        [Browsable(false)]
        public new ScrollBars ScrollBars { set { } get { return base.ScrollBars; } }

        [Browsable(false)]
        public new int Opacity { set { } get { return base.Opacity; } }
        
        [Browsable(false)]
        public new int MinLength { set { } get { return base.MinLength; } }

        [Browsable(false)]
        public new BorderStyle BorderStyle { set { } get { return base.BorderStyle; } }

        [Browsable(false)]
        public new string ClassName { set { } get { return base.ClassName; } }

        [Browsable(false)]
        public new CharacterCasing CharacterCasing { set { } get { return base.CharacterCasing; } }

        [Browsable(false)]
        public new VisualJS.Web.Forms.ContextMenu ContextMenu { set { } get { return null; } }

        [Browsable(false)]
        public new bool Multiline { set { } get { return base.Multiline; } }

        [Browsable(false)]
        public new string ValidationMessage { set { } get { return base.ValidationMessage; } }
        #endregion
    }
}