﻿VSJS_RichTextBox.prototype = new VSJS_CBase();

function VSJS_RichTextBox(_name) {
    VSJS_CBase.call(this);
    var _this = this;
    _this.CID = "RichTextBox";
    _this.multiline = true;
    _this.maxLength = 65535;
    if (JTool.Touch) {
        _this.InitializeLayer(_name, "TEXTAREA", false);
    } else {
        _this.InitializeLayer(_name, "DIV", false);
    };

    var _i = _this.GetInputElement();
    var _l = _this.GetLayerElement();

    if (!JTool.Touch) {
        _i.innerHTML = "<p></p>";
    };
    _i.className = "VSJS_TextBox";

    _this.editor = null;
    _this.OnRenderCompleted = function () {
        if (!JTool.Touch) {
            var sz = _this.Size();
            _this.opts.width = sz.w - 4;
            _this.opts.height = sz.h - 4;
            window.elRTE.prototype.options.toolbars['bar' + _this.Name] = _this.buttons;
            _this.editor = $(_i).elrte(_this.opts);

            _this.editorBase = _this.editor[0].elrte;
            _this.editorBase.OnChanged = function (val) {
                try {
                    if (val.length > _this.maxLength) {
                        val = val.substring(0, _this.maxLength - 1);
                        setTimeout(function () { $(_i).elrte('val', val); }, 1);
                    };
                    _this.Text(val);
                    if (_this.OnChanged) {
                        _this.OnChanged(_this.Name, null);
                    };
                } catch (ae) {
                };
            };
            _this.editorBase.Enabled(_this.Enabled());
            _this.OnSizeChanged(sz.w, sz.h);
        };
    };

    _this.OnControlRemoved = function () {
        if (_this.editor != null && !JTool.Touch) {
            $(_i).elrte('destroy');
        };
    };

    _this.TextUpdated = function (txt) {
        if (_this.editor != null && !JTool.Touch) {
            var q = $(_i);
            if (txt == "") {
                txt = " ";
            };
            q.elrte('val', txt);
        };
    };

    _this.EnabledUpdated = function (e) {
        if (_this.editorBase) {
            _this.editorBase.Enabled(e);
        };
    };

    _l.style.overflow = "visible";

    _this.OnSizeChanged = function (w, h) {
        if (w < 4) {
            return;
        };
        _i.style.width = w - 4 + "px";
        _i.style.height = h - 4 + "px";
        if (!JTool.Touch) {
            if (_this.editorBase) {
                var elm = _this.editorBase.editor[0];
                elm.style.width = w + "px";
                elm.style.height = h + "px";
                var tb = _this.editorBase.toolbar[0].offsetHeight;
                _this.editorBase.workzone[0].style.height = (h-tb) + "px";
                _this.editorBase.updateHeight();
            };
        };
    };

    _this.auto = null; 
    _this.AutoCompleteSource = function (o) {
    };

    _this.opts = {
        width: 100,
        height: 100,
       lang : 'en',
       toolbar: 'bar' + _this.Name
    };

   _this.buttons = ['style', 'alignment', 'colors', 'insert', 'undoredo'];
   _this.Buttons = function (list) {
       try {
           eval("_this.buttons =  ['" + list.replace(/,/g, "','") + "'];");
       } catch (e) {
       };
   };

   _this.Lang = function (ln) {
       _this.opts.lang = ln;
   };
};

VSJS_RichTextBox.prototype.MaxLength = function (ml) {
    if (ml == null) {
        return this.maxLength;
    };

    this.maxLength = ml;
    if (this.MaxLengthUpdated != null) { this.MaxLengthUpdated(); };
};

VSJS_RichTextBox.prototype.Multiline = function (enabled) {
    if (this.multiline == enabled) {
        return;
    };
    this.multiline = true;
};

if (!JTool.Touch) {
    VSJS_RichTextBox.prototype.Text = function (_text) {
        var _this = this;
        if (_text == null) {
            return _this.text;
        };

        _text = JTool.Trim(_text);
        _this.text = _text.replace(new RegExp("\n", "g"), "");

        _this.GetInputElement().innerHTML = _this.text;
        if (_this.TextUpdated) {
            _this.TextUpdated(_this.text);
        };
    };
};