﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
    // WindowsImpersonationContext
using FormStartPosition = VisualJS.Web.Forms.FormStartPosition;
using MessageBox = VisualJS.Web.Forms.MessageBox;

// PermissionSetAttribute

namespace TaskManager.VisualJSApp
{
    public partial class Login : VisualJS.Web.Forms.Form
    {

#region Constructors
        public Login()
        {
            InitializeComponent();
            AfterInitialization();
        } 

        //Use the below constructor if you create the instance of this Form object other than the active Thread
        //otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        public Login(string clientId): base(clientId)
        {
            InitializeComponent(); 
            AfterInitialization();
        }
#endregion

        //Use below method for the tasks after the initialization of the Form
        void  AfterInitialization()
        {
            if(this.IsTouchEnabled)//reconfigure dialog to touch compatible look
            {
                //below settings will be re-configuring the form for touch interface
                this.WindowState = FormWindowState.Maximized;
                this.FormBorderStyle = FormBorderStyle.None;
                this.StartPosition = FormStartPosition.Manual;
            }
        }

        /*
         * Feel free to use any of the WinAPI!
         */

        [DllImport("ADVAPI32.DLL")]
        public static extern bool LogonUser(String lpszUsername, String lpszDomain, String lpszPassword,
        int dwLogonType, int dwLogonProvider, out IntPtr phToken);

        [DllImport("kernel32.DLL")]
        static extern bool CloseHandle(IntPtr hObject);
        
        private void button1_Click(object sender, EventArgs e)
        {
            //after 3 miss-type the login form asks for captcha
            if (!captchaPass)//if the captcha process is activated and yet it is not passed
                return;

            if (txtUsername.Text.Length < 3 || txtPassword.Text.Length < 3)//double check for username for password
                return;

            IntPtr token = IntPtr.Zero;

            //try to logon with the user to make the correction for credentials
            bool done = LogonUser(txtUsername.Text, txtDomain.Text, txtPassword.Text, 2, 0,out token);

            txtPassword.Text = "";

            if(!done)
            {
                numberOfTrial++;
                MessageBox.Show("Please check your credentials.", this);

                if(numberOfTrial>3)
                {
                    captchaPass = false;
                    tabControl1.SelectedIndex = 1;
                }

                return;
            }

            try
            {
                CloseHandle(token);
            }
            catch{}

            numberOfTrial = 0;
            this.Hide();
            captchaPass = true;

            MainForm mf = new MainForm();
            mf.loginForm = this;
            if(this.IsTouchEnabled)//reconfigure mainForm to touch enabled
            {
                mf.FormBorderStyle = FormBorderStyle.None;
                mf.WindowState = FormWindowState.Maximized;
                mf.StartPosition = FormStartPosition.Manual;
            }
            mf.Show();
        }

        int numberOfTrial = 0;
        internal static bool captchaPass = true;
        private void button2_Click(object sender, EventArgs e)
        {
            if (txtCaptcha.Text.Length != 6)
                return;
            if(captchaBox1.PassByTextBox(txtCaptcha, true, true))
            {
                captchaPass = true;
                tabControl1.SelectedIndex = 0;
                txtCaptcha.Text = "";
            }
            else
            {
                MessageBox.Show("Incorrect Captcha!", this);
            }
        }
    }
}