Uncomment the below CustomStyle line inside the ASPX page in order to activate CustomStyle file
<!-- <link href='/VisualJSApp/Style/CustomStyle.css' media='screen' rel='stylesheet' type='text/css' /> -->

And comment the below line inside the same file;
    <link href='a.PokeIn?name=VSJS_CSS&type=text' media='screen' rel='stylesheet' type='text/css' />

Also, built-in style packages are available from VisualJS.Kernel.Settings.ActiveTheme property
