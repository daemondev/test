﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using VisualJS;
using System.Linq;
using System.Text;
using VisualJS.Web.Forms;
using ListView = VisualJS.Web.Forms.ListView;
using MessageBox = VisualJS.Web.Forms.MessageBox;

namespace TaskManager.VisualJSApp
{
    public partial class MainForm : VisualJS.Web.Forms.Form
    {
        public Login loginForm = null;

#region Constructors
        public MainForm()
        {
            InitializeComponent();
            AfterInitialization();
        } 

        //Use the below constructor if you create the instance of this Form object other than the active Thread
        //otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        public MainForm(string clientId): base(clientId)
        {
            InitializeComponent(); 
            AfterInitialization();
        }
#endregion

        //Use below method for the tasks after the initialization of the Form
        void  AfterInitialization()
        {
            listView1.Columns.Add("Process name", 160);
            listView1.Columns.Add("PID", 60, HorizontalAlignment.Right);
            listView1.Columns.Add("Status", 100);
            listView1.Columns.Add("Memory", 100, HorizontalAlignment.Right);
            listView1.Columns.Add("Threads", 80, HorizontalAlignment.Right);

            this.Text = "Please wait...";
            Thread.Sleep(1);

            new Thread(delegate(){
               refreshList();
               this.Text = "Task Manager";
            }).Start();
        }

        void refreshList()
        {
            if(listView1.Items.Count>0)
                listView1.Items.Clear();

            Process[] prList = null;
            try
            {
                prList = Process.GetProcesses();
            }
            catch
            {
                MessageBox.Show("Please check your web.config file and update the user credentials for this application", this);
                return;
            }

            List<ListView.ListViewItem> items = new List<ListView.ListViewItem>();
            foreach (Process pr in prList)
            {
                try
                {
                    ListView.ListViewItem item = new ListView.ListViewItem(pr.ProcessName);
                    item.SubItems.Add(pr.Id.ToString());
                    if(pr.Responding)
                        item.SubItems.Add("Running");
                    else
                    {
                        item.SubItems.Add("Suspended");
                    }
                    item.SubItems.Add((pr.WorkingSet64/1024).ToString("#,#"));
                    item.SubItems.Add(pr.Threads.Count.ToString());
                    item.Tag = pr;
                    items.Add(item);

                }
                catch { }
            }

            listView1.Items.AddRange(items.ToArray());
        }


        private void jButton1_Click(object sender, EventArgs e)
        {
            if (!listView1.SelectedItems.Any())
                return;
            ListView.ListViewItem item = listView1.SelectedItems.First();
            MessageBox.Show("Warning!","Are you sure ?\r\n"+item.SubItems[0].Text+" will be killed.",MessageBoxIcons.Warning,this, MessageBoxType.YesNo, delegate (MessageBoxResult res)
                {
                    if(res == MessageBoxResult.Yes)
                    {
                        Process pr = (Process)item.Tag;
                        try
                        {
                            pr.Refresh();
                            pr.Kill();
                        }
                        catch{}
                        refreshList();
                    }
                });
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (this.loginForm != null)
            {
                loginForm.Show();
            }
        }

        private void jButton2_Click(object sender, EventArgs e)
        {
            refreshList();
        }

    }
}