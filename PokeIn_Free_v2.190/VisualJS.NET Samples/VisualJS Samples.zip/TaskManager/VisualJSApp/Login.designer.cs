﻿namespace TaskManager.VisualJSApp
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.label1 = new VisualJS.Web.Forms.Label();
            this.label2 = new VisualJS.Web.Forms.Label();
            this.txtUsername = new VisualJS.Web.Forms.TextBox();
            this.txtPassword = new VisualJS.Web.Forms.MaskedTextBox();
            this.button1 = new VisualJS.Web.Forms.Button();
            this.label3 = new VisualJS.Web.Forms.Label();
            this.txtDomain = new VisualJS.Web.Forms.TextBox();
            this.label4 = new VisualJS.Web.Forms.Label();
            this.tabControl1 = new VisualJS.Web.Forms.TabControl();
            this.tabPage2 = new VisualJS.Web.Forms.TabPage();
            this.tabPage4 = new VisualJS.Web.Forms.TabPage();
            this.button2 = new VisualJS.Web.Forms.Button();
            this.txtCaptcha = new VisualJS.Web.Forms.TextBox();
            this.captchaBox1 = new VisualJS.Web.Forms.CaptchaBox();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.captchaBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 9F);
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(5, 41);
            this.label1.Name = "label1";
            this.label1.Opacity = 100;
            this.label1.Overflow = true;
            this.label1.Size = new System.Drawing.Size(66, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Username";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.WrapText = true;
            this.label1.ZOrder = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9F);
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(5, 90);
            this.label2.Name = "label2";
            this.label2.Opacity = 100;
            this.label2.Overflow = true;
            this.label2.Size = new System.Drawing.Size(63, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Password";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.WrapText = true;
            this.label2.ZOrder = 0;
            // 
            // txtUsername
            // 
            this.txtUsername.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtUsername.CheckForEmail = false;
            this.txtUsername.ClassName = "";
            this.txtUsername.CustomFontFamilies = "";
            this.txtUsername.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsername.GhostColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtUsername.GhostText = "";
            this.txtUsername.Location = new System.Drawing.Point(8, 59);
            this.txtUsername.MaxLength = 65535;
            this.txtUsername.MinLength = 3;
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Opacity = 100;
            this.txtUsername.PreventSQLInjection = false;
            this.txtUsername.RegexCheck = "";
            this.txtUsername.Size = new System.Drawing.Size(246, 22);
            this.txtUsername.SubmitButton = null;
            this.txtUsername.TabIndex = 0;
            this.txtUsername.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.txtUsername.TooltipText = "";
            this.txtUsername.ValidationMessage = "Enter your username";
            this.txtUsername.ZOrder = 0;
            // 
            // txtPassword
            // 
            this.txtPassword.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPassword.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtPassword.CheckForEmail = false;
            this.txtPassword.ClassName = "";
            this.txtPassword.CustomFontFamilies = "";
            this.txtPassword.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(8, 108);
            this.txtPassword.MinLength = 3;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Opacity = 100;
            this.txtPassword.PasswordMode = true;
            this.txtPassword.PreventSQLInjection = false;
            this.txtPassword.RegexCheck = "";
            this.txtPassword.Size = new System.Drawing.Size(246, 22);
            this.txtPassword.SubmitButton = this.button1;
            this.txtPassword.TabIndex = 1;
            this.txtPassword.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.txtPassword.TooltipText = "";
            this.txtPassword.ValidationMessage = "Enter your password";
            this.txtPassword.ZOrder = 0;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackgroundImagePosition = "";
            this.button1.BackgroundImageQuality = ((short)(80));
            this.button1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.button1.ClassName = "";
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.CustomFontFamilies = "";
            this.button1.Font = new System.Drawing.Font("Arial", 9F);
            this.button1.Image = null;
            this.button1.Location = new System.Drawing.Point(160, 192);
            this.button1.Name = "button1";
            this.button1.Opacity = 100;
            this.button1.PreventMultipleClicks = true;
            this.button1.Size = new System.Drawing.Size(94, 29);
            this.button1.TabIndex = 3;
            this.button1.Text = "Login";
            this.button1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.button1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.button1.TooltipText = "";
            this.button1.UseMnemonic = false;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.ValidationFailedMessage = "Fill the inputs";
            this.button1.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnParent;
            this.button1.ZOrder = 0;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ClassName = "";
            this.label3.CustomFontFamilies = "";
            this.label3.Font = new System.Drawing.Font("Arial", 9F);
            this.label3.ForeColor = System.Drawing.Color.Coral;
            this.label3.Image = null;
            this.label3.Location = new System.Drawing.Point(35, 20);
            this.label3.Name = "label3";
            this.label3.Opacity = 100;
            this.label3.Overflow = true;
            this.label3.Size = new System.Drawing.Size(195, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "Enter Windows User Credentials;";
            this.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label3.TooltipText = "";
            this.label3.UseMnemonic = false;
            this.label3.WrapText = true;
            this.label3.ZOrder = 0;
            // 
            // txtDomain
            // 
            this.txtDomain.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDomain.CheckForEmail = false;
            this.txtDomain.ClassName = "";
            this.txtDomain.CustomFontFamilies = "";
            this.txtDomain.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDomain.GhostColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtDomain.GhostText = "";
            this.txtDomain.Location = new System.Drawing.Point(8, 157);
            this.txtDomain.MaxLength = 65535;
            this.txtDomain.MinLength = -1;
            this.txtDomain.Name = "txtDomain";
            this.txtDomain.Opacity = 100;
            this.txtDomain.PreventSQLInjection = false;
            this.txtDomain.RegexCheck = "";
            this.txtDomain.Size = new System.Drawing.Size(246, 22);
            this.txtDomain.SubmitButton = null;
            this.txtDomain.TabIndex = 2;
            this.txtDomain.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.txtDomain.TooltipText = "";
            this.txtDomain.ValidationMessage = "Enter your username";
            this.txtDomain.ZOrder = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ClassName = "";
            this.label4.CustomFontFamilies = "";
            this.label4.Font = new System.Drawing.Font("Arial", 9F);
            this.label4.Image = null;
            this.label4.Location = new System.Drawing.Point(5, 139);
            this.label4.Name = "label4";
            this.label4.Opacity = 100;
            this.label4.Overflow = true;
            this.label4.Size = new System.Drawing.Size(51, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "Domain";
            this.label4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label4.TooltipText = "";
            this.label4.UseMnemonic = false;
            this.label4.WrapText = true;
            this.label4.ZOrder = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.ClassName = "";
            this.tabControl1.ClientID = null;
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.CustomFontFamilies = "";
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Arial", 9F);
            this.tabControl1.HeadersVisible = false;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Opacity = 100;
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.SelectedTab = null;
            this.tabControl1.SelectionHelper = null;
            this.tabControl1.Size = new System.Drawing.Size(270, 252);
            this.tabControl1.SwipeEnabled = false;
            this.tabControl1.TabIcons = null;
            this.tabControl1.TabIndex = 8;
            this.tabControl1.TabPages = false;
            this.tabControl1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.tabControl1.TooltipText = "";
            this.tabControl1.ZOrder = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.ClassName = "";
            this.tabPage2.ClientID = null;
            this.tabPage2.Closable = false;
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.txtDomain);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.txtUsername);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.txtPassword);
            this.tabPage2.CustomFontFamilies = "";
            this.tabPage2.Font = new System.Drawing.Font("Arial", 9F);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(262, 224);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Tab Page";
            this.tabPage2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.tabPage2.TooltipText = "";
            this.tabPage2.Visible = false;
            this.tabPage2.ZOrder = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.ClassName = "";
            this.tabPage4.ClientID = null;
            this.tabPage4.Closable = false;
            this.tabPage4.Controls.Add(this.button2);
            this.tabPage4.Controls.Add(this.txtCaptcha);
            this.tabPage4.Controls.Add(this.captchaBox1);
            this.tabPage4.CustomFontFamilies = "";
            this.tabPage4.Font = new System.Drawing.Font("Arial", 9F);
            this.tabPage4.Location = new System.Drawing.Point(4, 24);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(262, 224);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Tab Page";
            this.tabPage4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.tabPage4.TooltipText = "";
            this.tabPage4.Visible = false;
            this.tabPage4.ZOrder = 0;
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.BackgroundImagePosition = "";
            this.button2.BackgroundImageQuality = ((short)(80));
            this.button2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.button2.ClassName = "";
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.CustomFontFamilies = "";
            this.button2.Font = new System.Drawing.Font("Arial", 9F);
            this.button2.Image = null;
            this.button2.Location = new System.Drawing.Point(183, 161);
            this.button2.Name = "button2";
            this.button2.Opacity = 100;
            this.button2.PreventMultipleClicks = false;
            this.button2.Size = new System.Drawing.Size(111, 33);
            this.button2.TabIndex = 5;
            this.button2.Text = "Submit";
            this.button2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.button2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.button2.TooltipText = "";
            this.button2.UseMnemonic = false;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.ValidationFailedMessage = "Enter captcha text";
            this.button2.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnParent;
            this.button2.ZOrder = 0;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtCaptcha
            // 
            this.txtCaptcha.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCaptcha.CheckForEmail = false;
            this.txtCaptcha.ClassName = "";
            this.txtCaptcha.CustomFontFamilies = "";
            this.txtCaptcha.Font = new System.Drawing.Font("Arial", 9F);
            this.txtCaptcha.GhostColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtCaptcha.GhostText = "";
            this.txtCaptcha.Location = new System.Drawing.Point(8, 136);
            this.txtCaptcha.MaxLength = 6;
            this.txtCaptcha.MinLength = 6;
            this.txtCaptcha.Name = "txtCaptcha";
            this.txtCaptcha.Opacity = 100;
            this.txtCaptcha.PreventSQLInjection = false;
            this.txtCaptcha.RegexCheck = "";
            this.txtCaptcha.Size = new System.Drawing.Size(286, 21);
            this.txtCaptcha.SubmitButton = this.button2;
            this.txtCaptcha.TabIndex = 4;
            this.txtCaptcha.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.txtCaptcha.TooltipText = "";
            this.txtCaptcha.ValidationMessage = "Enter captcha";
            this.txtCaptcha.ZOrder = 0;
            // 
            // captchaBox1
            // 
            this.captchaBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.captchaBox1.BackColor = System.Drawing.Color.Black;
            this.captchaBox1.ClassName = "";
            this.captchaBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("captchaBox1.ErrorImage")));
            this.captchaBox1.Image = null;
            this.captchaBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("captchaBox1.InitialImage")));
            this.captchaBox1.Location = new System.Drawing.Point(8, 13);
            this.captchaBox1.Name = "captchaBox1";
            this.captchaBox1.Opacity = 100;
            this.captchaBox1.Size = new System.Drawing.Size(286, 118);
            this.captchaBox1.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal;
            this.captchaBox1.TabIndex = 0;
            this.captchaBox1.TabStop = false;
            this.captchaBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.captchaBox1.TooltipText = "";
            this.captchaBox1.ZOrder = 0;
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(270, 252);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.FormClosableByUser = false;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Login";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.KeepInCenter;
            this.Text = "Login";
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.captchaBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.Label label2;
        private VisualJS.Web.Forms.TextBox txtUsername;
        private VisualJS.Web.Forms.MaskedTextBox txtPassword;
        private VisualJS.Web.Forms.Button button1;
        private VisualJS.Web.Forms.Label label3;
        private VisualJS.Web.Forms.TextBox txtDomain;
        private VisualJS.Web.Forms.Label label4;
        private VisualJS.Web.Forms.TabControl tabControl1;
        private VisualJS.Web.Forms.TabPage tabPage2;
        private VisualJS.Web.Forms.TabPage tabPage4;
        private VisualJS.Web.Forms.Button button2;
        private VisualJS.Web.Forms.TextBox txtCaptcha;
        private VisualJS.Web.Forms.CaptchaBox captchaBox1;
    }
}