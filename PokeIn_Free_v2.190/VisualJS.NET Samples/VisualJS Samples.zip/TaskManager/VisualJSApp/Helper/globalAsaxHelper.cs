﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using VisualJS;
using VisualJS.Kernel;
using PokeIn.Comet;

#region VisualJS.Kernel.VisualJSProjectKey - Do Not Edit
[assembly:VisualJS.Kernel.VisualJSProjectKey("NONE")]
#endregion 

namespace TaskManager.VisualJSApp.Helper
{
    internal static class globalAsaxHelper
    {
        internal static void Application_Start()
        {
            //Safer & Faster data transfer between the server and client
            CometSettings.Base64EncyrptedTransfers = true;

            //Using chunked mode transfers helps reducing load
            CometSettings.ChunkedMode = true;

            //enable below line in order to use Chart Support (requires Settings.JQuerySupport is enabled)
            //Settings.ChartSupport = true;

            //use below line in order to activate built-in JQuery Support 1.8.3 (default true)
            //Settings.JQuerySupport = false;

            //Update the below parameter with your own copy of JQuery to change the working version of JQuery
            //Settings.JQueryBase = .....

            Settings.ActiveTheme = VisualJS.Kernel.Theme.Modern;

            //Below line will register your main form on VisulJS.NET
            //You don't need to register other forms you are going to use on your application
            try
            {
                VisualJS.Page.CreateApplication(typeof(TaskManager.VisualJSApp.Login));
            }
            catch(VisualJS.Kernel.LicenseFailedException ex)
            {
                //You can read this log under App_Data folder. Do not forget to create App_Data folder under your web application's folder 
                CometWorker.AddLog("License Failed");
                throw;
            }

            //Below event fires when a form open request is received from the client side
            //VisualJS.Page.OnFormOpenRequest += new FormOpenDelegate(Page_OnFormOpenRequest);

            //Use below event listener instead CometWorker.OnClientConnected for your VisualJS.NET applications
            //VisualJS.Page.OnClientConnected += new DefineClassObjects(Page_OnClientConnected);

            //Above rule applies to OnClientDisconnected
            //VisualJS.Page.OnClientDisconnected += new ClientDisconnectedDelegate(Page_OnClientDisconnected);
        }

        internal static void Page_OnFormOpenRequest(ConnectionDetails details, string formName)
        {
            //check our other sample project to see how it works
        } 

        //Adding some custom classes into classList requires additional PokeIn license!
        internal static void Page_OnClientConnected(ConnectionDetails details, ref Dictionary<string, object> classList)
        {
            
        }

        internal static void Page_OnClientDisconnected(string clientId)
        {
            
        }
    }
}