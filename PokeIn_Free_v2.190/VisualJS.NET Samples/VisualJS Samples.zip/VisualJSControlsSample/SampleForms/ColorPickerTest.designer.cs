﻿namespace VisualJSControlsSample.SampleForms
{
    partial class ColorPickerTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ColorPickerTest));
            this.colorPicker1 = new VisualJS.Web.Forms.ColorPicker();
            this.label1 = new VisualJS.Web.Forms.Label();
            this.label2 = new VisualJS.Web.Forms.Label();
            this.colorPicker2 = new VisualJS.Web.Forms.ColorPicker();
            this.panel1 = new VisualJS.Web.Forms.Panel();
            this.checkBox1 = new VisualJS.Web.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // colorPicker1
            // 
            this.colorPicker1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.colorPicker1.CheckForEmail = false;
            this.colorPicker1.ClassName = "";
            this.colorPicker1.Color = System.Drawing.Color.White;
            this.colorPicker1.CustomFontFamilies = "";
            this.colorPicker1.Font = new System.Drawing.Font("Arial", 9F);
            this.colorPicker1.Location = new System.Drawing.Point(91, 12);
            this.colorPicker1.Mask = "#??????";
            this.colorPicker1.MinLength = -1;
            this.colorPicker1.Name = "colorPicker1";
            this.colorPicker1.Opacity = 100;
            this.colorPicker1.PreventSQLInjection = false;
            this.colorPicker1.RegexCheck = "";
            this.colorPicker1.Size = new System.Drawing.Size(93, 21);
            this.colorPicker1.TabIndex = 7;
            this.colorPicker1.Text = "#000000";
            this.colorPicker1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.colorPicker1.TooltipText = "";
            this.colorPicker1.ValidationMessage = "An action is required";
            this.colorPicker1.ZOrder = 0;
            this.colorPicker1.TextChanged += new System.EventHandler(this.colorPicker1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 9F);
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(11, 15);
            this.label1.Name = "label1";
            this.label1.Opacity = 100;
            this.label1.Size = new System.Drawing.Size(41, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Start Color";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.ZOrder = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9F);
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(11, 42);
            this.label2.Name = "label2";
            this.label2.Opacity = 100;
            this.label2.Size = new System.Drawing.Size(41, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "End Color";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.ZOrder = 0;
            // 
            // colorPicker2
            // 
            this.colorPicker2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.colorPicker2.CheckForEmail = false;
            this.colorPicker2.ClassName = "";
            this.colorPicker2.Color = System.Drawing.Color.White;
            this.colorPicker2.CustomFontFamilies = "";
            this.colorPicker2.Font = new System.Drawing.Font("Arial", 9F);
            this.colorPicker2.Location = new System.Drawing.Point(91, 39);
            this.colorPicker2.Mask = "#??????";
            this.colorPicker2.MinLength = -1;
            this.colorPicker2.Name = "colorPicker2";
            this.colorPicker2.Opacity = 100;
            this.colorPicker2.PreventSQLInjection = false;
            this.colorPicker2.RegexCheck = "";
            this.colorPicker2.Size = new System.Drawing.Size(93, 21);
            this.colorPicker2.TabIndex = 4;
            this.colorPicker2.Text = "#FF0000";
            this.colorPicker2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.colorPicker2.TooltipText = "";
            this.colorPicker2.ValidationMessage = "An action is required";
            this.colorPicker2.ZOrder = 0;
            this.colorPicker2.TextChanged += new System.EventHandler(this.colorPicker2_TextChanged);
            // 
            // panel1
            // 
            this.panel1.ApplicationWideResource = true;
            this.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.panel1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.panel1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.BackColorEnd = System.Drawing.Color.Red;
            this.panel1.BackgroundImagePosition = "";
            this.panel1.BackgroundImageQuality = ((short)(80));
            this.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.panel1.ClassName = "";
            this.panel1.ClientID = null;
            this.panel1.CustomFontFamilies = "";
            this.panel1.Font = new System.Drawing.Font("Arial", 9F);
            this.panel1.HTML = "";
            this.panel1.Location = new System.Drawing.Point(14, 91);
            this.panel1.Name = "panel1";
            this.panel1.Opacity = 100;
            this.panel1.Size = new System.Drawing.Size(170, 101);
            this.panel1.TabIndex = 5;
            this.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.panel1.TooltipText = "";
            this.panel1.VerticalGradient = true;
            this.panel1.ZOrder = 0;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackColor = System.Drawing.Color.Transparent;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.ClassName = "";
            this.checkBox1.CustomFontFamilies = "";
            this.checkBox1.Font = new System.Drawing.Font("Arial", 9F);
            this.checkBox1.Image = null;
            this.checkBox1.Location = new System.Drawing.Point(14, 66);
            this.checkBox1.MustBeCheckedBeforeSubmit = false;
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Opacity = 100;
            this.checkBox1.Size = new System.Drawing.Size(85, 19);
            this.checkBox1.TabIndex = 6;
            this.checkBox1.Text = "Vertical Gradient";
            this.checkBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.checkBox1.TooltipText = "";
            this.checkBox1.UseMnemonic = false;
            this.checkBox1.UseVisualStyleBackColor = false;
            this.checkBox1.ValidationMessage = "An action is required";
            this.checkBox1.ZOrder = 0;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // ColorPickerTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(200, 210);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.colorPicker2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.colorPicker1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ColorPickerTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "ColorPicker Demo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private VisualJS.Web.Forms.ColorPicker colorPicker1;
        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.Label label2;
        private VisualJS.Web.Forms.ColorPicker colorPicker2;
        private VisualJS.Web.Forms.Panel panel1;
        private VisualJS.Web.Forms.CheckBox checkBox1;
    }
}