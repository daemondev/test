﻿namespace VisualJSControlsSample.SampleForms
{
    partial class Buttons
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Buttons));
            this.jButton1 = new VisualJS.Web.Forms.JButton();
            this.label1 = new VisualJS.Web.Forms.Label();
            this.jButton6 = new VisualJS.Web.Forms.JButton();
            this.jButton5 = new VisualJS.Web.Forms.JButton();
            this.jButton4 = new VisualJS.Web.Forms.JButton();
            this.jButton3 = new VisualJS.Web.Forms.JButton();
            this.jButton2 = new VisualJS.Web.Forms.JButton();
            this.jButton7 = new VisualJS.Web.Forms.JButton();
            this.jButton8 = new VisualJS.Web.Forms.JButton();
            this.jButton9 = new VisualJS.Web.Forms.JButton();
            this.jButton10 = new VisualJS.Web.Forms.JButton();
            this.jButton11 = new VisualJS.Web.Forms.JButton();
            this.button1 = new VisualJS.Web.Forms.Button();
            this.textBox1 = new VisualJS.Web.Forms.TextBox();
            this.label2 = new VisualJS.Web.Forms.Label();
            this.button2 = new VisualJS.Web.Forms.Button();
            this.jButton12 = new VisualJS.Web.Forms.JButton();
            this.button3 = new VisualJS.Web.Forms.Button();
            this.SuspendLayout();
            // 
            // jButton1
            // 
            this.jButton1.ApplicationWideResource = true;
            this.jButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton1.BackgroundImagePosition = "";
            this.jButton1.BackgroundImageQuality = ((short)(80));
            this.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton1.ClassName = "";
            this.jButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton1.CustomFontFamilies = "";
            this.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton1.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton1.Icon = null;
            this.jButton1.IconURL = "";
            this.jButton1.Image = null;
            this.jButton1.ImageLocation = "";
            this.jButton1.Location = new System.Drawing.Point(12, 12);
            this.jButton1.Name = "jButton1";
            this.jButton1.Opacity = 100;
            this.jButton1.Size = new System.Drawing.Size(145, 23);
            this.jButton1.TabIndex = 7;
            this.jButton1.Text = "Default JButton";
            this.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton1.TooltipText = "";
            this.jButton1.UseVisualStyleBackColor = false;
            this.jButton1.ValidationFailedMessage = "Validation failed!";
            this.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton1.VerticalGradient = true;
            this.jButton1.ZOrder = 0;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(12, 48);
            this.label1.Name = "label1";
            this.label1.Opacity = 100;
            this.label1.Size = new System.Drawing.Size(145, 49);
            this.label1.TabIndex = 5;
            this.label1.Text = "Same Icon Resource Automatically Resizes by Button Size";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.ZOrder = 0;
            // 
            // jButton6
            // 
            this.jButton6.ApplicationWideResource = true;
            this.jButton6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton6.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton6.BackgroundImage = global::VisualJSControlsSample.Properties.Resources.buttonImage;
            this.jButton6.BackgroundImagePosition = "";
            this.jButton6.BackgroundImageQuality = ((short)(80));
            this.jButton6.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton6.ClassName = "";
            this.jButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton6.CustomFontFamilies = "";
            this.jButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton6.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jButton6.ForeColor = System.Drawing.Color.White;
            this.jButton6.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton6.Icon = null;
            this.jButton6.IconURL = "";
            this.jButton6.Image = null;
            this.jButton6.ImageLocation = "";
            this.jButton6.Location = new System.Drawing.Point(173, 12);
            this.jButton6.Name = "jButton6";
            this.jButton6.Opacity = 100;
            this.jButton6.Size = new System.Drawing.Size(145, 85);
            this.jButton6.TabIndex = 8;
            this.jButton6.Text = "JButton with an Image";
            this.jButton6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton6.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton6.TooltipText = "";
            this.jButton6.UseVisualStyleBackColor = false;
            this.jButton6.ValidationFailedMessage = "Validation failed!";
            this.jButton6.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton6.VerticalGradient = true;
            this.jButton6.ZOrder = 0;
            // 
            // jButton5
            // 
            this.jButton5.ApplicationWideResource = true;
            this.jButton5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton5.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton5.BackgroundImagePosition = "";
            this.jButton5.BackgroundImageQuality = ((short)(80));
            this.jButton5.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton5.ClassName = "";
            this.jButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton5.CustomFontFamilies = "";
            this.jButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton5.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton5.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton5.Icon = global::VisualJSControlsSample.Properties.Resources.Windows;
            this.jButton5.IconURL = "";
            this.jButton5.Image = null;
            this.jButton5.ImageLocation = "";
            this.jButton5.Location = new System.Drawing.Point(12, 228);
            this.jButton5.Name = "jButton5";
            this.jButton5.Opacity = 100;
            this.jButton5.Size = new System.Drawing.Size(145, 55);
            this.jButton5.TabIndex = 6;
            this.jButton5.Text = "JButton with Icon";
            this.jButton5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton5.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton5.TooltipText = "";
            this.jButton5.UseVisualStyleBackColor = false;
            this.jButton5.ValidationFailedMessage = "Validation failed!";
            this.jButton5.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton5.VerticalGradient = true;
            this.jButton5.ZOrder = 0;
            // 
            // jButton4
            // 
            this.jButton4.ApplicationWideResource = true;
            this.jButton4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton4.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton4.BackgroundImagePosition = "";
            this.jButton4.BackgroundImageQuality = ((short)(80));
            this.jButton4.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton4.ClassName = "";
            this.jButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton4.CustomFontFamilies = "";
            this.jButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton4.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton4.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton4.Icon = global::VisualJSControlsSample.Properties.Resources.Windows;
            this.jButton4.IconURL = "";
            this.jButton4.Image = null;
            this.jButton4.ImageLocation = "";
            this.jButton4.Location = new System.Drawing.Point(12, 179);
            this.jButton4.Name = "jButton4";
            this.jButton4.Opacity = 100;
            this.jButton4.Size = new System.Drawing.Size(145, 43);
            this.jButton4.TabIndex = 4;
            this.jButton4.Text = "JButton with Icon";
            this.jButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton4.TooltipText = "";
            this.jButton4.UseVisualStyleBackColor = false;
            this.jButton4.ValidationFailedMessage = "Validation failed!";
            this.jButton4.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton4.VerticalGradient = true;
            this.jButton4.ZOrder = 0;
            // 
            // jButton3
            // 
            this.jButton3.ApplicationWideResource = true;
            this.jButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton3.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton3.BackgroundImagePosition = "";
            this.jButton3.BackgroundImageQuality = ((short)(80));
            this.jButton3.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton3.ClassName = "";
            this.jButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton3.CustomFontFamilies = "";
            this.jButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton3.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton3.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton3.Icon = global::VisualJSControlsSample.Properties.Resources.Windows;
            this.jButton3.IconURL = "";
            this.jButton3.Image = null;
            this.jButton3.ImageLocation = "";
            this.jButton3.Location = new System.Drawing.Point(12, 138);
            this.jButton3.Name = "jButton3";
            this.jButton3.Opacity = 100;
            this.jButton3.Size = new System.Drawing.Size(145, 35);
            this.jButton3.TabIndex = 3;
            this.jButton3.Text = "JButton with Icon";
            this.jButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton3.TooltipText = "";
            this.jButton3.UseVisualStyleBackColor = false;
            this.jButton3.ValidationFailedMessage = "Validation failed!";
            this.jButton3.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton3.VerticalGradient = true;
            this.jButton3.ZOrder = 0;
            // 
            // jButton2
            // 
            this.jButton2.ApplicationWideResource = true;
            this.jButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton2.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton2.BackgroundImagePosition = "";
            this.jButton2.BackgroundImageQuality = ((short)(80));
            this.jButton2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton2.ClassName = "";
            this.jButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton2.CustomFontFamilies = "";
            this.jButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton2.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton2.Icon = global::VisualJSControlsSample.Properties.Resources.Windows;
            this.jButton2.IconURL = "";
            this.jButton2.Image = null;
            this.jButton2.ImageLocation = "";
            this.jButton2.Location = new System.Drawing.Point(12, 109);
            this.jButton2.Name = "jButton2";
            this.jButton2.Opacity = 100;
            this.jButton2.Size = new System.Drawing.Size(145, 23);
            this.jButton2.TabIndex = 2;
            this.jButton2.Text = "JButton with Icon";
            this.jButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton2.TooltipText = "";
            this.jButton2.UseVisualStyleBackColor = false;
            this.jButton2.ValidationFailedMessage = "Validation failed!";
            this.jButton2.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton2.VerticalGradient = true;
            this.jButton2.ZOrder = 0;
            // 
            // jButton7
            // 
            this.jButton7.ApplicationWideResource = true;
            this.jButton7.BackColor = System.Drawing.Color.Maroon;
            this.jButton7.BackColorEnd = System.Drawing.Color.Black;
            this.jButton7.BackgroundImagePosition = "";
            this.jButton7.BackgroundImageQuality = ((short)(80));
            this.jButton7.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton7.ClassName = "";
            this.jButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton7.CustomFontFamilies = "";
            this.jButton7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton7.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jButton7.ForeColor = System.Drawing.Color.White;
            this.jButton7.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.jButton7.Icon = null;
            this.jButton7.IconURL = "";
            this.jButton7.Image = null;
            this.jButton7.ImageLocation = "";
            this.jButton7.Location = new System.Drawing.Point(173, 109);
            this.jButton7.Name = "jButton7";
            this.jButton7.Opacity = 100;
            this.jButton7.Size = new System.Drawing.Size(145, 23);
            this.jButton7.TabIndex = 9;
            this.jButton7.Text = "Gradient JButton";
            this.jButton7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton7.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton7.TooltipText = "";
            this.jButton7.UseVisualStyleBackColor = false;
            this.jButton7.ValidationFailedMessage = "Validation failed!";
            this.jButton7.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton7.VerticalGradient = true;
            this.jButton7.ZOrder = 0;
            // 
            // jButton8
            // 
            this.jButton8.ApplicationWideResource = true;
            this.jButton8.BackColor = System.Drawing.Color.Blue;
            this.jButton8.BackColorEnd = System.Drawing.Color.Black;
            this.jButton8.BackgroundImagePosition = "";
            this.jButton8.BackgroundImageQuality = ((short)(80));
            this.jButton8.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton8.ClassName = "";
            this.jButton8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton8.CustomFontFamilies = "";
            this.jButton8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton8.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jButton8.ForeColor = System.Drawing.Color.White;
            this.jButton8.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.jButton8.Icon = null;
            this.jButton8.IconURL = "";
            this.jButton8.Image = null;
            this.jButton8.ImageLocation = "";
            this.jButton8.Location = new System.Drawing.Point(173, 138);
            this.jButton8.Name = "jButton8";
            this.jButton8.Opacity = 100;
            this.jButton8.Size = new System.Drawing.Size(145, 35);
            this.jButton8.TabIndex = 10;
            this.jButton8.Text = "Gradient JButton";
            this.jButton8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton8.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton8.TooltipText = "";
            this.jButton8.UseVisualStyleBackColor = false;
            this.jButton8.ValidationFailedMessage = "Validation failed!";
            this.jButton8.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton8.VerticalGradient = true;
            this.jButton8.ZOrder = 0;
            // 
            // jButton9
            // 
            this.jButton9.ApplicationWideResource = true;
            this.jButton9.BackColor = System.Drawing.Color.Maroon;
            this.jButton9.BackColorEnd = System.Drawing.Color.Green;
            this.jButton9.BackgroundImagePosition = "";
            this.jButton9.BackgroundImageQuality = ((short)(80));
            this.jButton9.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton9.ClassName = "";
            this.jButton9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton9.CustomFontFamilies = "";
            this.jButton9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton9.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jButton9.ForeColor = System.Drawing.Color.White;
            this.jButton9.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.jButton9.Icon = null;
            this.jButton9.IconURL = "";
            this.jButton9.Image = null;
            this.jButton9.ImageLocation = "";
            this.jButton9.Location = new System.Drawing.Point(173, 179);
            this.jButton9.Name = "jButton9";
            this.jButton9.Opacity = 100;
            this.jButton9.Size = new System.Drawing.Size(145, 43);
            this.jButton9.TabIndex = 11;
            this.jButton9.Text = "Gradient JButton";
            this.jButton9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton9.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton9.TooltipText = "";
            this.jButton9.UseVisualStyleBackColor = false;
            this.jButton9.ValidationFailedMessage = "Validation failed!";
            this.jButton9.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton9.VerticalGradient = true;
            this.jButton9.ZOrder = 0;
            // 
            // jButton10
            // 
            this.jButton10.ApplicationWideResource = true;
            this.jButton10.BackColor = System.Drawing.Color.Green;
            this.jButton10.BackColorEnd = System.Drawing.Color.Orange;
            this.jButton10.BackgroundImagePosition = "";
            this.jButton10.BackgroundImageQuality = ((short)(80));
            this.jButton10.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton10.ClassName = "";
            this.jButton10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton10.CustomFontFamilies = "";
            this.jButton10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton10.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jButton10.ForeColor = System.Drawing.Color.Black;
            this.jButton10.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.jButton10.Icon = null;
            this.jButton10.IconURL = "";
            this.jButton10.Image = null;
            this.jButton10.ImageLocation = "";
            this.jButton10.Location = new System.Drawing.Point(173, 228);
            this.jButton10.Name = "jButton10";
            this.jButton10.Opacity = 100;
            this.jButton10.Size = new System.Drawing.Size(145, 55);
            this.jButton10.TabIndex = 12;
            this.jButton10.Text = "Gradient JButton";
            this.jButton10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton10.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton10.TooltipText = "";
            this.jButton10.UseVisualStyleBackColor = false;
            this.jButton10.ValidationFailedMessage = "Validation failed!";
            this.jButton10.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton10.VerticalGradient = true;
            this.jButton10.ZOrder = 0;
            // 
            // jButton11
            // 
            this.jButton11.ApplicationWideResource = true;
            this.jButton11.BackColor = System.Drawing.Color.Black;
            this.jButton11.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.jButton11.BackgroundImagePosition = "";
            this.jButton11.BackgroundImageQuality = ((short)(80));
            this.jButton11.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton11.ClassName = "";
            this.jButton11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton11.CustomFontFamilies = "";
            this.jButton11.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.jButton11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton11.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jButton11.ForeColor = System.Drawing.Color.White;
            this.jButton11.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.jButton11.Icon = null;
            this.jButton11.IconURL = "";
            this.jButton11.Image = null;
            this.jButton11.ImageLocation = "";
            this.jButton11.Location = new System.Drawing.Point(0, 298);
            this.jButton11.Name = "jButton11";
            this.jButton11.Opacity = 100;
            this.jButton11.Size = new System.Drawing.Size(145, 55);
            this.jButton11.TabIndex = 13;
            this.jButton11.Text = "Docked Gradient JButton";
            this.jButton11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton11.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton11.TooltipText = "";
            this.jButton11.UseVisualStyleBackColor = false;
            this.jButton11.ValidationFailedMessage = "Validation failed!";
            this.jButton11.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton11.VerticalGradient = true;
            this.jButton11.ZOrder = 0;
            // 
            // button1
            // 
            this.button1.BackgroundImagePosition = "";
            this.button1.BackgroundImageQuality = ((short)(80));
            this.button1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.button1.ClassName = "";
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.CustomFontFamilies = "";
            this.button1.Font = new System.Drawing.Font("Arial", 9F);
            this.button1.Image = null;
            this.button1.Location = new System.Drawing.Point(333, 12);
            this.button1.Name = "button1";
            this.button1.Opacity = 100;
            this.button1.Size = new System.Drawing.Size(171, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "Normal Button";
            this.button1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.button1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.button1.TooltipText = "";
            this.button1.UseMnemonic = false;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.ValidationFailedMessage = "Validation failed!";
            this.button1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.button1.ZOrder = 0;
            // 
            // textBox1
            // 
            this.textBox1.CheckForEmail = true;
            this.textBox1.ClassName = "";
            this.textBox1.CustomFontFamilies = "";
            this.textBox1.Font = new System.Drawing.Font("Arial", 9F);
            this.textBox1.Location = new System.Drawing.Point(333, 109);
            this.textBox1.MaxLength = 65535;
            this.textBox1.MinLength = -1;
            this.textBox1.Name = "textBox1";
            this.textBox1.Opacity = 100;
            this.textBox1.PreventSQLInjection = false;
            this.textBox1.RegexCheck = "";
            this.textBox1.Size = new System.Drawing.Size(171, 21);
            this.textBox1.TabIndex = 15;
            this.textBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.textBox1.TooltipText = "";
            this.textBox1.ValidationMessage = "Email address is required";
            this.textBox1.ZOrder = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9F);
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(335, 89);
            this.label2.Name = "label2";
            this.label2.Opacity = 100;
            this.label2.Size = new System.Drawing.Size(41, 15);
            this.label2.TabIndex = 16;
            this.label2.Text = "Enter your email";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.ZOrder = 0;
            // 
            // button2
            // 
            this.button2.BackgroundImagePosition = "";
            this.button2.BackgroundImageQuality = ((short)(80));
            this.button2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.button2.ClassName = "";
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.CustomFontFamilies = "";
            this.button2.Font = new System.Drawing.Font("Arial", 9F);
            this.button2.Image = null;
            this.button2.Location = new System.Drawing.Point(333, 139);
            this.button2.Name = "button2";
            this.button2.Opacity = 100;
            this.button2.Size = new System.Drawing.Size(171, 34);
            this.button2.TabIndex = 17;
            this.button2.Text = "Validation Button";
            this.button2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.button2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.button2.TooltipText = "";
            this.button2.UseMnemonic = false;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.ValidationFailedMessage = "Enter your Email Address!";
            this.button2.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnParent;
            this.button2.ZOrder = 0;
            // 
            // jButton12
            // 
            this.jButton12.ApplicationWideResource = true;
            this.jButton12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton12.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton12.BackgroundImagePosition = "";
            this.jButton12.BackgroundImageQuality = ((short)(80));
            this.jButton12.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton12.ClassName = "";
            this.jButton12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton12.CustomFontFamilies = "Times New Roman,Arial";
            this.jButton12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton12.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton12.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton12.Icon = null;
            this.jButton12.IconURL = "";
            this.jButton12.Image = null;
            this.jButton12.ImageLocation = "";
            this.jButton12.Location = new System.Drawing.Point(333, 228);
            this.jButton12.Name = "jButton12";
            this.jButton12.Opacity = 100;
            this.jButton12.Size = new System.Drawing.Size(171, 55);
            this.jButton12.TabIndex = 18;
            this.jButton12.Text = "Custom Font Families";
            this.jButton12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton12.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton12.TooltipText = "";
            this.jButton12.UseVisualStyleBackColor = false;
            this.jButton12.ValidationFailedMessage = "Validation failed!";
            this.jButton12.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton12.VerticalGradient = true;
            this.jButton12.ZOrder = 0;
            // 
            // button3
            // 
            this.button3.BackgroundImagePosition = "";
            this.button3.BackgroundImageQuality = ((short)(80));
            this.button3.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.button3.ClassName = "";
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.CustomFontFamilies = "verdana,tahoma";
            this.button3.Font = new System.Drawing.Font("Arial", 9F);
            this.button3.Image = null;
            this.button3.Location = new System.Drawing.Point(333, 179);
            this.button3.Name = "button3";
            this.button3.Opacity = 100;
            this.button3.Size = new System.Drawing.Size(171, 43);
            this.button3.TabIndex = 19;
            this.button3.Text = "Custom Font Families";
            this.button3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.button3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.button3.TooltipText = "";
            this.button3.UseMnemonic = false;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.ValidationFailedMessage = "Validation failed!";
            this.button3.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.button3.ZOrder = 0;
            // 
            // Buttons
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(516, 353);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.jButton12);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.jButton11);
            this.Controls.Add(this.jButton10);
            this.Controls.Add(this.jButton9);
            this.Controls.Add(this.jButton8);
            this.Controls.Add(this.jButton7);
            this.Controls.Add(this.jButton6);
            this.Controls.Add(this.jButton5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.jButton4);
            this.Controls.Add(this.jButton3);
            this.Controls.Add(this.jButton2);
            this.Controls.Add(this.jButton1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Buttons";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "Buttons Sample";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private VisualJS.Web.Forms.JButton jButton1;
        private VisualJS.Web.Forms.JButton jButton2;
        private VisualJS.Web.Forms.JButton jButton3;
        private VisualJS.Web.Forms.JButton jButton4;
        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.JButton jButton5;
        private VisualJS.Web.Forms.JButton jButton6;
        private VisualJS.Web.Forms.JButton jButton7;
        private VisualJS.Web.Forms.JButton jButton8;
        private VisualJS.Web.Forms.JButton jButton9;
        private VisualJS.Web.Forms.JButton jButton10;
        private VisualJS.Web.Forms.JButton jButton11;
        private VisualJS.Web.Forms.Button button1;
        private VisualJS.Web.Forms.TextBox textBox1;
        private VisualJS.Web.Forms.Label label2;
        private VisualJS.Web.Forms.Button button2;
        private VisualJS.Web.Forms.JButton jButton12;
        private VisualJS.Web.Forms.Button button3;
    }
}