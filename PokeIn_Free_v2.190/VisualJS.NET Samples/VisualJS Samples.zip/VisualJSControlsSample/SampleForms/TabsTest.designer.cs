﻿namespace VisualJSControlsSample.SampleForms
{
    partial class TabsTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TabsTest));
            this.tabControl1 = new VisualJS.Web.Forms.TabControl();
            this.tabPage2 = new VisualJS.Web.Forms.TabPage();
            this.label2 = new VisualJS.Web.Forms.Label();
            this.tabPage4 = new VisualJS.Web.Forms.TabPage();
            this.label3 = new VisualJS.Web.Forms.Label();
            this.tabPage6 = new VisualJS.Web.Forms.TabPage();
            this.label4 = new VisualJS.Web.Forms.Label();
            this.tabPage8 = new VisualJS.Web.Forms.TabPage();
            this.label5 = new VisualJS.Web.Forms.Label();
            this.comboBox1 = new VisualJS.Web.Forms.ComboBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new VisualJS.Web.Forms.Label();
            this.jButton1 = new VisualJS.Web.Forms.JButton();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.ClassName = "";
            this.tabControl1.ClientID = null;
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.CustomFontFamilies = "";
            this.tabControl1.Font = new System.Drawing.Font("Arial", 9F);
            this.tabControl1.HeadersVisible = true;
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Opacity = 100;
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.SelectedTab = null;
            this.tabControl1.SelectionHelper = this.comboBox1;
            this.tabControl1.Size = new System.Drawing.Size(493, 311);
            this.tabControl1.TabIcons = this.imageList1;
            this.tabControl1.TabIndex = 0;
            this.tabControl1.TabPages = false;
            this.tabControl1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.tabControl1.TooltipText = "";
            this.tabControl1.ZOrder = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.DarkKhaki;
            this.tabPage2.ClassName = "";
            this.tabPage2.ClientID = null;
            this.tabPage2.Closable = false;
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.CustomFontFamilies = "";
            this.tabPage2.Font = new System.Drawing.Font("Arial", 9F);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(485, 283);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Customers";
            this.tabPage2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.tabPage2.TooltipText = "";
            this.tabPage2.Visible = false;
            this.tabPage2.ZOrder = 0;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.SlateGray;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(107, 131);
            this.label2.Name = "label2";
            this.label2.Opacity = 100;
            this.label2.Size = new System.Drawing.Size(271, 21);
            this.label2.TabIndex = 3;
            this.label2.Text = "Customers Tab Sample";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.ZOrder = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Salmon;
            this.tabPage4.ClassName = "";
            this.tabPage4.ClientID = null;
            this.tabPage4.Closable = false;
            this.tabPage4.Controls.Add(this.label3);
            this.tabPage4.CustomFontFamilies = "";
            this.tabPage4.Font = new System.Drawing.Font("Arial", 9F);
            this.tabPage4.Location = new System.Drawing.Point(4, 24);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(485, 283);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Contacts";
            this.tabPage4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.tabPage4.TooltipText = "";
            this.tabPage4.Visible = false;
            this.tabPage4.ZOrder = 0;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Brown;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.ClassName = "";
            this.label3.CustomFontFamilies = "";
            this.label3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Image = null;
            this.label3.Location = new System.Drawing.Point(107, 131);
            this.label3.Name = "label3";
            this.label3.Opacity = 100;
            this.label3.Size = new System.Drawing.Size(271, 21);
            this.label3.TabIndex = 4;
            this.label3.Text = "Contacts Tab Sample";
            this.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label3.TooltipText = "";
            this.label3.UseMnemonic = false;
            this.label3.ZOrder = 0;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.Silver;
            this.tabPage6.ClassName = "";
            this.tabPage6.ClientID = null;
            this.tabPage6.Closable = false;
            this.tabPage6.Controls.Add(this.label4);
            this.tabPage6.CustomFontFamilies = "";
            this.tabPage6.Font = new System.Drawing.Font("Arial", 9F);
            this.tabPage6.Location = new System.Drawing.Point(4, 24);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(485, 283);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Money";
            this.tabPage6.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.tabPage6.TooltipText = "";
            this.tabPage6.Visible = false;
            this.tabPage6.ZOrder = 0;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.OrangeRed;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.ClassName = "";
            this.label4.CustomFontFamilies = "";
            this.label4.Font = new System.Drawing.Font("Arial", 9F);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Image = null;
            this.label4.Location = new System.Drawing.Point(107, 131);
            this.label4.Name = "label4";
            this.label4.Opacity = 100;
            this.label4.Size = new System.Drawing.Size(271, 21);
            this.label4.TabIndex = 4;
            this.label4.Text = "Money Tab Sample";
            this.label4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.label4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label4.TooltipText = "";
            this.label4.UseMnemonic = false;
            this.label4.ZOrder = 0;
            // 
            // tabPage8
            // 
            this.tabPage8.ClassName = "";
            this.tabPage8.ClientID = null;
            this.tabPage8.Closable = true;
            this.tabPage8.Controls.Add(this.label5);
            this.tabPage8.CustomFontFamilies = "";
            this.tabPage8.Font = new System.Drawing.Font("Arial", 9F);
            this.tabPage8.Location = new System.Drawing.Point(4, 24);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(485, 283);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "More";
            this.tabPage8.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.tabPage8.TooltipText = "";
            this.tabPage8.Visible = false;
            this.tabPage8.ZOrder = 0;
            this.tabPage8.TabClosed += new System.EventHandler(this.tabPage8_TabClosed);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Brown;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.ClassName = "";
            this.label5.CustomFontFamilies = "";
            this.label5.Font = new System.Drawing.Font("Arial", 9F);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Image = null;
            this.label5.Location = new System.Drawing.Point(107, 131);
            this.label5.Name = "label5";
            this.label5.Opacity = 100;
            this.label5.Size = new System.Drawing.Size(271, 21);
            this.label5.TabIndex = 5;
            this.label5.Text = "Other Tab with Default BackgroundColor";
            this.label5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.label5.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label5.TooltipText = "";
            this.label5.UseMnemonic = false;
            this.label5.ZOrder = 0;
            // 
            // comboBox1
            // 
            this.comboBox1.ClassName = "";
            this.comboBox1.CustomFontFamilies = "";
            this.comboBox1.Font = new System.Drawing.Font("Arial", 9F);
            this.comboBox1.Items.AddRange(new object[] {
            "Customers",
            "Contacts",
            "Money",
            "More"});
            this.comboBox1.Location = new System.Drawing.Point(514, 90);
            this.comboBox1.MinSelectedIndex = -1;
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Opacity = 100;
            this.comboBox1.Size = new System.Drawing.Size(171, 23);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.comboBox1.TooltipText = "";
            this.comboBox1.UpdateTextBySelection = null;
            this.comboBox1.ValidationMessage = "An action is required";
            this.comboBox1.Visible = false;
            this.comboBox1.ZOrder = 0;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.Tag = "TabsDemo";
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Customers.png");
            this.imageList1.Images.SetKeyName(1, "Contacts.png");
            this.imageList1.Images.SetKeyName(2, "Money.png");
            this.imageList1.Images.SetKeyName(3, "more.png");
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Gold;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 9F);
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(511, 38);
            this.label1.Name = "label1";
            this.label1.Opacity = 100;
            this.label1.Size = new System.Drawing.Size(174, 48);
            this.label1.TabIndex = 2;
            this.label1.Text = "You can also use ISelect controls for tab index selection management";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.Visible = false;
            this.label1.ZOrder = 0;
            // 
            // jButton1
            // 
            this.jButton1.ApplicationWideResource = true;
            this.jButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton1.BackgroundImagePosition = "";
            this.jButton1.BackgroundImageQuality = ((short)(80));
            this.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton1.ClassName = "";
            this.jButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton1.CustomFontFamilies = "";
            this.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton1.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton1.Icon = null;
            this.jButton1.IconURL = "";
            this.jButton1.Image = null;
            this.jButton1.ImageLocation = "";
            this.jButton1.Location = new System.Drawing.Point(511, 12);
            this.jButton1.Name = "jButton1";
            this.jButton1.Opacity = 100;
            this.jButton1.PreventMultipleClicks = true;
            this.jButton1.Size = new System.Drawing.Size(174, 23);
            this.jButton1.TabIndex = 0;
            this.jButton1.Text = "Hide Headers";
            this.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton1.TooltipText = "";
            this.jButton1.UseVisualStyleBackColor = false;
            this.jButton1.ValidationFailedMessage = "Validation failed!";
            this.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton1.VerticalGradient = true;
            this.jButton1.ZOrder = 0;
            this.jButton1.Click += new System.EventHandler(this.jButton1_Click);
            // 
            // TabsTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(703, 333);
            this.Controls.Add(this.jButton1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TabsTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tabs Demo";
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage8.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private VisualJS.Web.Forms.TabControl tabControl1;
        private VisualJS.Web.Forms.TabPage tabPage2;
        public VisualJS.Web.Forms.TabPage tabPage4;
        private VisualJS.Web.Forms.TabPage tabPage6;
        private System.Windows.Forms.ImageList imageList1;
        private VisualJS.Web.Forms.ComboBox comboBox1;
        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.JButton jButton1;
        private VisualJS.Web.Forms.Label label2;
        private VisualJS.Web.Forms.Label label3;
        private VisualJS.Web.Forms.Label label4;
        private VisualJS.Web.Forms.TabPage tabPage8;
        private VisualJS.Web.Forms.Label label5;
    }
}