﻿namespace VisualJSControlsSample.SampleForms
{
    partial class PictureBoxTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PictureBoxTest));
            this.pictureBox1 = new VisualJS.Web.Forms.PictureBox();
            this.label1 = new VisualJS.Web.Forms.Label();
            this.label2 = new VisualJS.Web.Forms.Label();
            this.pictureBox2 = new VisualJS.Web.Forms.PictureBox();
            this.label3 = new VisualJS.Web.Forms.Label();
            this.pictureBox3 = new VisualJS.Web.Forms.PictureBox();
            this.label4 = new VisualJS.Web.Forms.Label();
            this.pictureBox4 = new VisualJS.Web.Forms.PictureBox();
            this.label5 = new VisualJS.Web.Forms.Label();
            this.pictureBox5 = new VisualJS.Web.Forms.PictureBox();
            this.label6 = new VisualJS.Web.Forms.Label();
            this.pictureBox6 = new VisualJS.Web.Forms.PictureBox();
            this.jButton1 = new VisualJS.Web.Forms.JButton();
            this.pictureBox7 = new VisualJS.Web.Forms.PictureBox();
            this.clrText = new VisualJS.Web.Forms.ColorPicker();
            this.label7 = new VisualJS.Web.Forms.Label();
            this.label8 = new VisualJS.Web.Forms.Label();
            this.txtImage = new VisualJS.Web.Forms.TextBox();
            this.panel1 = new VisualJS.Web.Forms.Panel();
            this.clrBack = new VisualJS.Web.Forms.ColorPicker();
            this.label9 = new VisualJS.Web.Forms.Label();
            this.jButton2 = new VisualJS.Web.Forms.JButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.ApplicationWideResource = true;
            this.pictureBox1.ClassName = "";
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Font = new System.Drawing.Font("Arial", 9F);
            this.pictureBox1.Image = global::VisualJSControlsSample.Properties.Resources.vsjslogo;
            this.pictureBox1.ImageLocation = "";
            this.pictureBox1.ImageQuality = ((short)(100));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(15, 222);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Opacity = 100;
            this.pictureBox1.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.PNG;
            this.pictureBox1.Size = new System.Drawing.Size(288, 60);
            this.pictureBox1.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.pictureBox1.TooltipText = "25 KB File Size";
            this.pictureBox1.ZOrder = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MintCream;
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(12, 204);
            this.label1.Name = "label1";
            this.label1.Opacity = 100;
            this.label1.Size = new System.Drawing.Size(202, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Normal Image Size, PNG Emulation";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.ZOrder = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.MintCream;
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(12, 293);
            this.label2.Name = "label2";
            this.label2.Opacity = 100;
            this.label2.Size = new System.Drawing.Size(195, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Normal Image Size, GIF Emulation";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.ZOrder = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.ApplicationWideResource = true;
            this.pictureBox2.ClassName = "";
            this.pictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.ErrorImage")));
            this.pictureBox2.Font = new System.Drawing.Font("Arial", 9F);
            this.pictureBox2.Image = global::VisualJSControlsSample.Properties.Resources.vsjslogo;
            this.pictureBox2.ImageLocation = "";
            this.pictureBox2.ImageQuality = ((short)(100));
            this.pictureBox2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.InitialImage")));
            this.pictureBox2.Location = new System.Drawing.Point(15, 311);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Opacity = 100;
            this.pictureBox2.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.GIF;
            this.pictureBox2.Size = new System.Drawing.Size(288, 60);
            this.pictureBox2.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.pictureBox2.TooltipText = "7.3 KB File Size";
            this.pictureBox2.ZOrder = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ClassName = "";
            this.label3.CustomFontFamilies = "";
            this.label3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.MintCream;
            this.label3.Image = null;
            this.label3.Location = new System.Drawing.Point(12, 384);
            this.label3.Name = "label3";
            this.label3.Opacity = 100;
            this.label3.Size = new System.Drawing.Size(278, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Normal Image Size, %100 Quality, JPG Emulation";
            this.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label3.TooltipText = "";
            this.label3.UseMnemonic = false;
            this.label3.ZOrder = 0;
            // 
            // pictureBox3
            // 
            this.pictureBox3.ApplicationWideResource = true;
            this.pictureBox3.ClassName = "";
            this.pictureBox3.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.ErrorImage")));
            this.pictureBox3.Font = new System.Drawing.Font("Arial", 9F);
            this.pictureBox3.Image = global::VisualJSControlsSample.Properties.Resources.vsjslogo;
            this.pictureBox3.ImageLocation = "";
            this.pictureBox3.ImageQuality = ((short)(100));
            this.pictureBox3.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.InitialImage")));
            this.pictureBox3.Location = new System.Drawing.Point(15, 402);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Opacity = 100;
            this.pictureBox3.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.JPG;
            this.pictureBox3.Size = new System.Drawing.Size(288, 60);
            this.pictureBox3.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.pictureBox3.TooltipText = "18.8 KB File Size";
            this.pictureBox3.ZOrder = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ClassName = "";
            this.label4.CustomFontFamilies = "";
            this.label4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.MintCream;
            this.label4.Image = null;
            this.label4.Location = new System.Drawing.Point(317, 384);
            this.label4.Name = "label4";
            this.label4.Opacity = 100;
            this.label4.Size = new System.Drawing.Size(271, 15);
            this.label4.TabIndex = 11;
            this.label4.Text = "Normal Image Size, %10 Quality, JPG Emulation";
            this.label4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label4.TooltipText = "";
            this.label4.UseMnemonic = false;
            this.label4.ZOrder = 0;
            // 
            // pictureBox4
            // 
            this.pictureBox4.ApplicationWideResource = true;
            this.pictureBox4.ClassName = "";
            this.pictureBox4.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.ErrorImage")));
            this.pictureBox4.Font = new System.Drawing.Font("Arial", 9F);
            this.pictureBox4.Image = global::VisualJSControlsSample.Properties.Resources.vsjslogo;
            this.pictureBox4.ImageLocation = "";
            this.pictureBox4.ImageQuality = ((short)(10));
            this.pictureBox4.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.InitialImage")));
            this.pictureBox4.Location = new System.Drawing.Point(320, 402);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Opacity = 100;
            this.pictureBox4.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.JPG;
            this.pictureBox4.Size = new System.Drawing.Size(286, 60);
            this.pictureBox4.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal;
            this.pictureBox4.TabIndex = 10;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.pictureBox4.TooltipText = "1.6 KB File Size";
            this.pictureBox4.ZOrder = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ClassName = "";
            this.label5.CustomFontFamilies = "";
            this.label5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.MintCream;
            this.label5.Image = null;
            this.label5.Location = new System.Drawing.Point(317, 293);
            this.label5.Name = "label5";
            this.label5.Opacity = 100;
            this.label5.Size = new System.Drawing.Size(179, 15);
            this.label5.TabIndex = 9;
            this.label5.Text = "Streched Image, GIF Emulation";
            this.label5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label5.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label5.TooltipText = "";
            this.label5.UseMnemonic = false;
            this.label5.ZOrder = 0;
            // 
            // pictureBox5
            // 
            this.pictureBox5.ApplicationWideResource = true;
            this.pictureBox5.ClassName = "";
            this.pictureBox5.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.ErrorImage")));
            this.pictureBox5.Font = new System.Drawing.Font("Arial", 9F);
            this.pictureBox5.Image = global::VisualJSControlsSample.Properties.Resources.vsjslogo;
            this.pictureBox5.ImageLocation = "";
            this.pictureBox5.ImageQuality = ((short)(100));
            this.pictureBox5.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.InitialImage")));
            this.pictureBox5.Location = new System.Drawing.Point(320, 311);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Opacity = 100;
            this.pictureBox5.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.GIF;
            this.pictureBox5.Size = new System.Drawing.Size(304, 60);
            this.pictureBox5.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.StretchImage;
            this.pictureBox5.TabIndex = 8;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.pictureBox5.TooltipText = "7.3 KB File Size";
            this.pictureBox5.ZOrder = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.ClassName = "";
            this.label6.CustomFontFamilies = "";
            this.label6.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.MintCream;
            this.label6.Image = null;
            this.label6.Location = new System.Drawing.Point(317, 204);
            this.label6.Name = "label6";
            this.label6.Opacity = 100;
            this.label6.Size = new System.Drawing.Size(186, 15);
            this.label6.TabIndex = 7;
            this.label6.Text = "Streched Image, PNG Emulation";
            this.label6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label6.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label6.TooltipText = "";
            this.label6.UseMnemonic = false;
            this.label6.ZOrder = 0;
            // 
            // pictureBox6
            // 
            this.pictureBox6.ApplicationWideResource = true;
            this.pictureBox6.ClassName = "";
            this.pictureBox6.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.ErrorImage")));
            this.pictureBox6.Font = new System.Drawing.Font("Arial", 9F);
            this.pictureBox6.Image = global::VisualJSControlsSample.Properties.Resources.vsjslogo;
            this.pictureBox6.ImageLocation = "";
            this.pictureBox6.ImageQuality = ((short)(10));
            this.pictureBox6.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.InitialImage")));
            this.pictureBox6.Location = new System.Drawing.Point(320, 222);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Opacity = 100;
            this.pictureBox6.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.PNG;
            this.pictureBox6.Size = new System.Drawing.Size(304, 60);
            this.pictureBox6.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.StretchImage;
            this.pictureBox6.TabIndex = 6;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.pictureBox6.TooltipText = "25 KB File Size";
            this.pictureBox6.ZOrder = 0;
            // 
            // jButton1
            // 
            this.jButton1.ApplicationWideResource = true;
            this.jButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton1.BackgroundImagePosition = "";
            this.jButton1.BackgroundImageQuality = ((short)(80));
            this.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton1.ClassName = "";
            this.jButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton1.CustomFontFamilies = "";
            this.jButton1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jButton1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton1.Icon = null;
            this.jButton1.IconURL = "";
            this.jButton1.Image = null;
            this.jButton1.ImageLocation = "";
            this.jButton1.Location = new System.Drawing.Point(0, 479);
            this.jButton1.Name = "jButton1";
            this.jButton1.Opacity = 100;
            this.jButton1.Size = new System.Drawing.Size(645, 34);
            this.jButton1.TabIndex = 0;
            this.jButton1.Text = "More Samples..";
            this.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton1.TooltipText = "";
            this.jButton1.UseVisualStyleBackColor = false;
            this.jButton1.ValidationFailedMessage = "Validation failed!";
            this.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton1.VerticalGradient = true;
            this.jButton1.ZOrder = 0;
            this.jButton1.Click += new System.EventHandler(this.jButton1_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.ApplicationWideResource = false;
            this.pictureBox7.ClassName = "";
            this.pictureBox7.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox7.ErrorImage")));
            this.pictureBox7.Font = new System.Drawing.Font("Arial", 9F);
            this.pictureBox7.Image = null;
            this.pictureBox7.ImageLocation = "";
            this.pictureBox7.ImageQuality = ((short)(100));
            this.pictureBox7.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox7.InitialImage")));
            this.pictureBox7.Location = new System.Drawing.Point(19, 14);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Opacity = 100;
            this.pictureBox7.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.PNG;
            this.pictureBox7.Size = new System.Drawing.Size(288, 140);
            this.pictureBox7.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.StretchImage;
            this.pictureBox7.TabIndex = 13;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.pictureBox7.TooltipText = "";
            this.pictureBox7.ZOrder = 0;
            // 
            // clrText
            // 
            this.clrText.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.clrText.CheckForEmail = false;
            this.clrText.ClassName = "";
            this.clrText.Color = System.Drawing.Color.White;
            this.clrText.ColorInputValidation = true;
            this.clrText.CustomFontFamilies = "";
            this.clrText.Font = new System.Drawing.Font("Arial", 9F);
            this.clrText.Location = new System.Drawing.Point(316, 84);
            this.clrText.Mask = "#??????";
            this.clrText.MinLength = -1;
            this.clrText.Name = "clrText";
            this.clrText.Opacity = 100;
            this.clrText.PreventSQLInjection = false;
            this.clrText.RegexCheck = "^#?([a-f]|[A-F]|[0-9]){3}(([a-f]|[A-F]|[0-9]){3})?$";
            this.clrText.Size = new System.Drawing.Size(103, 21);
            this.clrText.TabIndex = 14;
            this.clrText.Text = "B00000";
            this.clrText.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.clrText.TooltipText = "";
            this.clrText.ValidationMessage = "Enter or Select Valid HTML Color";
            this.clrText.ZOrder = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.ClassName = "";
            this.label7.CustomFontFamilies = "";
            this.label7.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.MintCream;
            this.label7.Image = null;
            this.label7.Location = new System.Drawing.Point(313, 66);
            this.label7.Name = "label7";
            this.label7.Opacity = 100;
            this.label7.Size = new System.Drawing.Size(64, 15);
            this.label7.TabIndex = 15;
            this.label7.Text = "Text Color";
            this.label7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label7.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label7.TooltipText = "";
            this.label7.UseMnemonic = false;
            this.label7.ZOrder = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.ClassName = "";
            this.label8.CustomFontFamilies = "";
            this.label8.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.MintCream;
            this.label8.Image = null;
            this.label8.Location = new System.Drawing.Point(313, 14);
            this.label8.Name = "label8";
            this.label8.Opacity = 100;
            this.label8.Size = new System.Drawing.Size(69, 15);
            this.label8.TabIndex = 16;
            this.label8.Text = "Image Text";
            this.label8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label8.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label8.TooltipText = "";
            this.label8.UseMnemonic = false;
            this.label8.ZOrder = 0;
            // 
            // txtImage
            // 
            this.txtImage.CheckForEmail = false;
            this.txtImage.ClassName = "";
            this.txtImage.CustomFontFamilies = "";
            this.txtImage.Font = new System.Drawing.Font("Arial", 9F);
            this.txtImage.Location = new System.Drawing.Point(316, 32);
            this.txtImage.MaxLength = 65535;
            this.txtImage.MinLength = 4;
            this.txtImage.Name = "txtImage";
            this.txtImage.Opacity = 100;
            this.txtImage.PreventSQLInjection = false;
            this.txtImage.RegexCheck = "";
            this.txtImage.Size = new System.Drawing.Size(275, 21);
            this.txtImage.TabIndex = 17;
            this.txtImage.Text = "Sample Text";
            this.txtImage.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.txtImage.TooltipText = "";
            this.txtImage.ValidationMessage = "Enter Something (Min 3 Chars)";
            this.txtImage.ZOrder = 0;
            // 
            // panel1
            // 
            this.panel1.ApplicationWideResource = true;
            this.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.panel1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.panel1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(153)))));
            this.panel1.BackgroundImagePosition = "";
            this.panel1.BackgroundImageQuality = ((short)(80));
            this.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.panel1.ClassName = "";
            this.panel1.ClientID = null;
            this.panel1.Controls.Add(this.clrBack);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.jButton2);
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Controls.Add(this.txtImage);
            this.panel1.Controls.Add(this.clrText);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.CustomFontFamilies = "";
            this.panel1.Font = new System.Drawing.Font("Arial", 9F);
            this.panel1.HTML = "";
            this.panel1.ImageLocation = "";
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Opacity = 40;
            this.panel1.Size = new System.Drawing.Size(614, 171);
            this.panel1.TabIndex = 18;
            this.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.panel1.TooltipText = "";
            this.panel1.VerticalGradient = true;
            this.panel1.ZOrder = 0;
            // 
            // clrBack
            // 
            this.clrBack.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.clrBack.CheckForEmail = false;
            this.clrBack.ClassName = "";
            this.clrBack.Color = System.Drawing.Color.White;
            this.clrBack.ColorInputValidation = true;
            this.clrBack.CustomFontFamilies = "";
            this.clrBack.Font = new System.Drawing.Font("Arial", 9F);
            this.clrBack.Location = new System.Drawing.Point(316, 133);
            this.clrBack.Mask = "#??????";
            this.clrBack.MinLength = -1;
            this.clrBack.Name = "clrBack";
            this.clrBack.Opacity = 100;
            this.clrBack.PreventSQLInjection = false;
            this.clrBack.RegexCheck = "^#?([a-f]|[A-F]|[0-9]){3}(([a-f]|[A-F]|[0-9]){3})?$";
            this.clrBack.Size = new System.Drawing.Size(103, 21);
            this.clrBack.TabIndex = 20;
            this.clrBack.Text = "FFFFFF";
            this.clrBack.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.clrBack.TooltipText = "";
            this.clrBack.ValidationMessage = "Enter or Select Valid HTML Color";
            this.clrBack.ZOrder = 0;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.ClassName = "";
            this.label9.CustomFontFamilies = "";
            this.label9.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.MintCream;
            this.label9.Image = null;
            this.label9.Location = new System.Drawing.Point(313, 115);
            this.label9.Name = "label9";
            this.label9.Opacity = 100;
            this.label9.Size = new System.Drawing.Size(109, 15);
            this.label9.TabIndex = 21;
            this.label9.Text = "Background Color";
            this.label9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label9.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label9.TooltipText = "";
            this.label9.UseMnemonic = false;
            this.label9.ZOrder = 0;
            // 
            // jButton2
            // 
            this.jButton2.ApplicationWideResource = true;
            this.jButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton2.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton2.BackgroundImagePosition = "";
            this.jButton2.BackgroundImageQuality = ((short)(80));
            this.jButton2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton2.ClassName = "";
            this.jButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton2.CustomFontFamilies = "";
            this.jButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton2.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton2.Icon = null;
            this.jButton2.IconURL = "";
            this.jButton2.Image = null;
            this.jButton2.ImageLocation = "";
            this.jButton2.Location = new System.Drawing.Point(437, 131);
            this.jButton2.Name = "jButton2";
            this.jButton2.Opacity = 100;
            this.jButton2.Size = new System.Drawing.Size(80, 23);
            this.jButton2.TabIndex = 22;
            this.jButton2.Text = "Draw";
            this.jButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton2.TooltipText = "";
            this.jButton2.UseVisualStyleBackColor = false;
            this.jButton2.ValidationFailedMessage = "Check the inputs";
            this.jButton2.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnParent;
            this.jButton2.VerticalGradient = true;
            this.jButton2.ZOrder = 0;
            this.jButton2.Click += new System.EventHandler(this.jButton2_Click);
            // 
            // PictureBoxTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.ClientSize = new System.Drawing.Size(645, 513);
            this.Controls.Add(this.jButton1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PictureBoxTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "PictureBox Demo";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private VisualJS.Web.Forms.PictureBox pictureBox1;
        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.Label label2;
        private VisualJS.Web.Forms.PictureBox pictureBox2;
        private VisualJS.Web.Forms.Label label3;
        private VisualJS.Web.Forms.PictureBox pictureBox3;
        private VisualJS.Web.Forms.Label label4;
        private VisualJS.Web.Forms.PictureBox pictureBox4;
        private VisualJS.Web.Forms.Label label5;
        private VisualJS.Web.Forms.PictureBox pictureBox5;
        private VisualJS.Web.Forms.Label label6;
        private VisualJS.Web.Forms.PictureBox pictureBox6;
        private VisualJS.Web.Forms.JButton jButton1;
        private VisualJS.Web.Forms.PictureBox pictureBox7;
        private VisualJS.Web.Forms.ColorPicker clrText;
        private VisualJS.Web.Forms.Label label7;
        private VisualJS.Web.Forms.Label label8;
        private VisualJS.Web.Forms.TextBox txtImage;
        private VisualJS.Web.Forms.Panel panel1;
        private VisualJS.Web.Forms.JButton jButton2;
        private VisualJS.Web.Forms.ColorPicker clrBack;
        private VisualJS.Web.Forms.Label label9;
    }
}