﻿namespace VisualJSControlsSample.SampleForms
{
    partial class TextboxTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TextboxTest));
            this.panel1 = new VisualJS.Web.Forms.Panel();
            this.textBox1 = new VisualJS.Web.Forms.TextBox();
            this.label1 = new VisualJS.Web.Forms.Label();
            this.jButton1 = new VisualJS.Web.Forms.JButton();
            this.label2 = new VisualJS.Web.Forms.Label();
            this.textBox2 = new VisualJS.Web.Forms.TextBox();
            this.textBox3 = new VisualJS.Web.Forms.TextBox();
            this.label3 = new VisualJS.Web.Forms.Label();
            this.panel2 = new VisualJS.Web.Forms.Panel();
            this.panel3 = new VisualJS.Web.Forms.Panel();
            this.jButton2 = new VisualJS.Web.Forms.JButton();
            this.textBox4 = new VisualJS.Web.Forms.TextBox();
            this.label4 = new VisualJS.Web.Forms.Label();
            this.label5 = new VisualJS.Web.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.ApplicationWideResource = true;
            this.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.panel1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.panel1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BackColorEnd = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImagePosition = "";
            this.panel1.BackgroundImageQuality = ((short)(80));
            this.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.panel1.BorderColor = System.Drawing.Color.Black;
            this.panel1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Dashed;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.ClassName = "";
            this.panel1.ClientID = null;
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.CustomFontFamilies = "";
            this.panel1.Font = new System.Drawing.Font("Arial", 9F);
            this.panel1.HTML = "";
            this.panel1.ImageLocation = "";
            this.panel1.Location = new System.Drawing.Point(7, 22);
            this.panel1.Name = "panel1";
            this.panel1.Opacity = 100;
            this.panel1.Size = new System.Drawing.Size(281, 29);
            this.panel1.TabIndex = 0;
            this.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.panel1.TooltipText = "";
            this.panel1.VerticalGradient = true;
            this.panel1.ZOrder = 0;
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.CheckForEmail = false;
            this.textBox1.ClassName = "";
            this.textBox1.CustomFontFamilies = "";
            this.textBox1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(3, 4);
            this.textBox1.MaxLength = 65535;
            this.textBox1.MinLength = 1;
            this.textBox1.Name = "textBox1";
            this.textBox1.Opacity = 100;
            this.textBox1.PreventSQLInjection = false;
            this.textBox1.RegexCheck = "";
            this.textBox1.Size = new System.Drawing.Size(273, 19);
            this.textBox1.TabIndex = 1;
            this.textBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.textBox1.TooltipText = "";
            this.textBox1.ValidationMessage = "Enter some text";
            this.textBox1.ZOrder = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(4, 3);
            this.label1.Name = "label1";
            this.label1.Opacity = 100;
            this.label1.Size = new System.Drawing.Size(215, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Textbox inside a bordered panel";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.ZOrder = 0;
            // 
            // jButton1
            // 
            this.jButton1.ApplicationWideResource = true;
            this.jButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton1.BackgroundImagePosition = "";
            this.jButton1.BackgroundImageQuality = ((short)(80));
            this.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton1.ClassName = "";
            this.jButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton1.CustomFontFamilies = "";
            this.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton1.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton1.Icon = global::VisualJSControlsSample.Properties.Resources.search;
            this.jButton1.IconURL = "";
            this.jButton1.Image = null;
            this.jButton1.ImageLocation = "";
            this.jButton1.Location = new System.Drawing.Point(294, 22);
            this.jButton1.Name = "jButton1";
            this.jButton1.Opacity = 100;
            this.jButton1.PreventMultipleClicks = true;
            this.jButton1.Size = new System.Drawing.Size(102, 29);
            this.jButton1.TabIndex = 2;
            this.jButton1.Text = "Search";
            this.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton1.TooltipText = "";
            this.jButton1.UseVisualStyleBackColor = false;
            this.jButton1.ValidationFailedMessage = "Validation failed!";
            this.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnParent;
            this.jButton1.VerticalGradient = true;
            this.jButton1.ZOrder = 0;
            this.jButton1.Click += new System.EventHandler(this.jButton1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(15, 87);
            this.label2.Name = "label2";
            this.label2.Opacity = 100;
            this.label2.Size = new System.Drawing.Size(352, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "AutoComplete for known <font color=red>colors<font>";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.ZOrder = 0;
            // 
            // textBox2
            // 
            this.textBox2.CheckForEmail = false;
            this.textBox2.ClassName = "";
            this.textBox2.CustomFontFamilies = "";
            this.textBox2.Font = new System.Drawing.Font("Arial", 9F);
            this.textBox2.Location = new System.Drawing.Point(22, 106);
            this.textBox2.MaxLength = 65535;
            this.textBox2.MinLength = -1;
            this.textBox2.Name = "textBox2";
            this.textBox2.Opacity = 100;
            this.textBox2.PreventSQLInjection = false;
            this.textBox2.RegexCheck = "";
            this.textBox2.Size = new System.Drawing.Size(273, 21);
            this.textBox2.TabIndex = 3;
            this.textBox2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.textBox2.TooltipText = "";
            this.textBox2.ValidationMessage = "An action is required";
            this.textBox2.ZOrder = 0;
            this.textBox2.OnSuggestion += new VisualJS.Web.Forms.TextBox.TextSuggestionDelegate(this.textBox2_OnSuggestion);
            // 
            // textBox3
            // 
            this.textBox3.CheckForEmail = false;
            this.textBox3.ClassName = "";
            this.textBox3.CustomFontFamilies = "";
            this.textBox3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(11, 28);
            this.textBox3.MaxLength = 65535;
            this.textBox3.MinLength = 1;
            this.textBox3.Name = "textBox3";
            this.textBox3.Opacity = 100;
            this.textBox3.PreventSQLInjection = true;
            this.textBox3.RegexCheck = "";
            this.textBox3.Size = new System.Drawing.Size(272, 26);
            this.textBox3.TabIndex = 5;
            this.textBox3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.textBox3.TooltipText = "";
            this.textBox3.ValidationMessage = "Enter some text";
            this.textBox3.ZOrder = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ClassName = "";
            this.label3.CustomFontFamilies = "";
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Image = null;
            this.label3.Location = new System.Drawing.Point(3, 9);
            this.label3.Name = "label3";
            this.label3.Opacity = 100;
            this.label3.Size = new System.Drawing.Size(153, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Prevents SQL Injection";
            this.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label3.TooltipText = "";
            this.label3.UseMnemonic = false;
            this.label3.ZOrder = 0;
            // 
            // panel2
            // 
            this.panel2.ApplicationWideResource = true;
            this.panel2.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.panel2.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.panel2.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BackColorEnd = System.Drawing.Color.Transparent;
            this.panel2.BackgroundImagePosition = "";
            this.panel2.BackgroundImageQuality = ((short)(80));
            this.panel2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.panel2.BorderColor = System.Drawing.Color.Black;
            this.panel2.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Dotted;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.ClassName = "";
            this.panel2.ClientID = null;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.jButton1);
            this.panel2.CustomFontFamilies = "";
            this.panel2.Font = new System.Drawing.Font("Arial", 9F);
            this.panel2.HTML = "";
            this.panel2.ImageLocation = "";
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Opacity = 100;
            this.panel2.Size = new System.Drawing.Size(409, 66);
            this.panel2.TabIndex = 6;
            this.panel2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.panel2.TooltipText = "";
            this.panel2.VerticalGradient = true;
            this.panel2.ZOrder = 0;
            // 
            // panel3
            // 
            this.panel3.ApplicationWideResource = true;
            this.panel3.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.panel3.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.panel3.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BackColorEnd = System.Drawing.Color.Transparent;
            this.panel3.BackgroundImagePosition = "";
            this.panel3.BackgroundImageQuality = ((short)(80));
            this.panel3.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.panel3.BorderColor = System.Drawing.Color.Black;
            this.panel3.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Dotted;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.ClassName = "";
            this.panel3.ClientID = null;
            this.panel3.Controls.Add(this.jButton2);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.textBox3);
            this.panel3.CustomFontFamilies = "";
            this.panel3.Font = new System.Drawing.Font("Arial", 9F);
            this.panel3.HTML = "";
            this.panel3.ImageLocation = "";
            this.panel3.Location = new System.Drawing.Point(12, 137);
            this.panel3.Name = "panel3";
            this.panel3.Opacity = 100;
            this.panel3.Size = new System.Drawing.Size(409, 62);
            this.panel3.TabIndex = 7;
            this.panel3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.panel3.TooltipText = "";
            this.panel3.VerticalGradient = true;
            this.panel3.ZOrder = 0;
            // 
            // jButton2
            // 
            this.jButton2.ApplicationWideResource = true;
            this.jButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton2.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton2.BackgroundImagePosition = "";
            this.jButton2.BackgroundImageQuality = ((short)(80));
            this.jButton2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton2.ClassName = "";
            this.jButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton2.CustomFontFamilies = "";
            this.jButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton2.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton2.Icon = global::VisualJSControlsSample.Properties.Resources.search;
            this.jButton2.IconURL = "";
            this.jButton2.Image = null;
            this.jButton2.ImageLocation = "";
            this.jButton2.Location = new System.Drawing.Point(294, 27);
            this.jButton2.Name = "jButton2";
            this.jButton2.Opacity = 100;
            this.jButton2.PreventMultipleClicks = true;
            this.jButton2.Size = new System.Drawing.Size(102, 29);
            this.jButton2.TabIndex = 0;
            this.jButton2.Text = "Search";
            this.jButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton2.TooltipText = "";
            this.jButton2.UseVisualStyleBackColor = false;
            this.jButton2.ValidationFailedMessage = "Validation failed!";
            this.jButton2.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnParent;
            this.jButton2.VerticalGradient = true;
            this.jButton2.ZOrder = 0;
            this.jButton2.Click += new System.EventHandler(this.jButton2_Click);
            // 
            // textBox4
            // 
            this.textBox4.CheckForEmail = false;
            this.textBox4.ClassName = "";
            this.textBox4.CustomFontFamilies = "";
            this.textBox4.Font = new System.Drawing.Font("Arial", 9F);
            this.textBox4.Location = new System.Drawing.Point(443, 35);
            this.textBox4.MaxLength = 65535;
            this.textBox4.MinLength = -1;
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Opacity = 100;
            this.textBox4.PreventSQLInjection = false;
            this.textBox4.RegexCheck = "";
            this.textBox4.Size = new System.Drawing.Size(273, 164);
            this.textBox4.TabIndex = 9;
            this.textBox4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.textBox4.TooltipText = "";
            this.textBox4.ValidationMessage = "An action is required";
            this.textBox4.ZOrder = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ClassName = "";
            this.label4.CustomFontFamilies = "";
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Image = null;
            this.label4.Location = new System.Drawing.Point(436, 16);
            this.label4.Name = "label4";
            this.label4.Opacity = 100;
            this.label4.Size = new System.Drawing.Size(123, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Supports Multiline";
            this.label4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label4.TooltipText = "";
            this.label4.UseMnemonic = false;
            this.label4.ZOrder = 0;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ClassName = "";
            this.label5.CustomFontFamilies = "";
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Image = null;
            this.label5.Location = new System.Drawing.Point(12, 217);
            this.label5.Name = "label5";
            this.label5.Opacity = 100;
            this.label5.Size = new System.Drawing.Size(704, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "And many useful features like <strong>EmailCheck</strong>, <strong>RegEx Validati" +
    "on</strong>, <strong>Custom fonts, opacity, docking..</strong>";
            this.label5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.label5.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label5.TooltipText = "";
            this.label5.UseMnemonic = false;
            this.label5.ZOrder = 0;
            // 
            // TextboxTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(734, 247);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TextboxTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "Textbox Demo";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private VisualJS.Web.Forms.Panel panel1;
        private VisualJS.Web.Forms.TextBox textBox1;
        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.JButton jButton1;
        private VisualJS.Web.Forms.Label label2;
        private VisualJS.Web.Forms.TextBox textBox2;
        private VisualJS.Web.Forms.TextBox textBox3;
        private VisualJS.Web.Forms.Label label3;
        private VisualJS.Web.Forms.Panel panel2;
        private VisualJS.Web.Forms.Panel panel3;
        private VisualJS.Web.Forms.JButton jButton2;
        private VisualJS.Web.Forms.TextBox textBox4;
        private VisualJS.Web.Forms.Label label4;
        private VisualJS.Web.Forms.Label label5;
    }
}