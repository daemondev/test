﻿namespace VisualJSControlsSample.SampleForms
{
    partial class CaptchaTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CaptchaTest));
            this.textBox1 = new VisualJS.Web.Forms.TextBox();
            this.captchaBox1 = new VisualJS.Web.Forms.CaptchaBox();
            this.jButton1 = new VisualJS.Web.Forms.JButton();
            ((System.ComponentModel.ISupportInitialize)(this.captchaBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.CheckForEmail = false;
            this.textBox1.ClassName = "";
            this.textBox1.CustomFontFamilies = "";
            this.textBox1.Font = new System.Drawing.Font("Arial", 9F);
            this.textBox1.Location = new System.Drawing.Point(12, 139);
            this.textBox1.MaxLength = 65535;
            this.textBox1.MinLength = 6;
            this.textBox1.Name = "textBox1";
            this.textBox1.Opacity = 100;
            this.textBox1.PreventSQLInjection = false;
            this.textBox1.RegexCheck = "";
            this.textBox1.Size = new System.Drawing.Size(184, 21);
            this.textBox1.TabIndex = 1;
            this.textBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.textBox1.TooltipText = "Enter Captcha Text Here";
            this.textBox1.ValidationMessage = "Please enter captcha text here";
            this.textBox1.ZOrder = 0;
            // 
            // captchaBox1
            // 
            this.captchaBox1.BackColor = System.Drawing.Color.Black;
            this.captchaBox1.ClassName = "";
            this.captchaBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("captchaBox1.ErrorImage")));
            this.captchaBox1.Image = null;
            this.captchaBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("captchaBox1.InitialImage")));
            this.captchaBox1.Location = new System.Drawing.Point(12, 12);
            this.captchaBox1.Name = "captchaBox1";
            this.captchaBox1.Opacity = 100;
            this.captchaBox1.Size = new System.Drawing.Size(184, 121);
            this.captchaBox1.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal;
            this.captchaBox1.TabIndex = 0;
            this.captchaBox1.TabStop = false;
            this.captchaBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.captchaBox1.TooltipText = "";
            this.captchaBox1.ZOrder = 0;
            // 
            // jButton1
            // 
            this.jButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton1.BackgroundImagePosition = "";
            this.jButton1.BackgroundImageQuality = ((short)(80));
            this.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton1.ClassName = "";
            this.jButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton1.CustomFontFamilies = "";
            this.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton1.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton1.Icon = null;
            this.jButton1.IconURL = "";
            this.jButton1.Image = null;
            this.jButton1.Location = new System.Drawing.Point(12, 166);
            this.jButton1.Name = "jButton1";
            this.jButton1.Opacity = 100;
            this.jButton1.Size = new System.Drawing.Size(184, 23);
            this.jButton1.TabIndex = 2;
            this.jButton1.Text = "Submit";
            this.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton1.TooltipText = "";
            this.jButton1.UseVisualStyleBackColor = false;
            this.jButton1.ValidationFailedMessage = "Enter Captcha Text";
            this.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnForm;
            this.jButton1.VerticalGradient = true;
            this.jButton1.ZOrder = 0;
            this.jButton1.Click += new System.EventHandler(this.jButton1_Click);
            // 
            // CaptchaTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(209, 203);
            this.Controls.Add(this.jButton1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.captchaBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CaptchaTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "Captcha Demo";
            ((System.ComponentModel.ISupportInitialize)(this.captchaBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private VisualJS.Web.Forms.CaptchaBox captchaBox1;
        private VisualJS.Web.Forms.TextBox textBox1;
        private VisualJS.Web.Forms.JButton jButton1;
    }
}