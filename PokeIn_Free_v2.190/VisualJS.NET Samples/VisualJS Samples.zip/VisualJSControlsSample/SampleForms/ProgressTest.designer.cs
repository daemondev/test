﻿namespace VisualJSControlsSample.SampleForms
{
    partial class ProgressTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProgressTest));
            this.progressBar1 = new VisualJS.Web.Forms.ProgressBar();
            this.jButton1 = new VisualJS.Web.Forms.JButton();
            this.borderStyle = new VisualJS.Web.Forms.ComboBox();
            this.borderColor = new VisualJS.Web.Forms.ColorPicker();
            this.backColor = new VisualJS.Web.Forms.ColorPicker();
            this.label1 = new VisualJS.Web.Forms.Label();
            this.label2 = new VisualJS.Web.Forms.Label();
            this.label3 = new VisualJS.Web.Forms.Label();
            this.SuspendLayout();
            // 
            // progressBar1
            // 
            this.progressBar1.BarColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(221)))), ((int)(((byte)(0)))));
            this.progressBar1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(153)))));
            this.progressBar1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Dashed;
            this.progressBar1.ClassName = "";
            this.progressBar1.CustomFontFamilies = "";
            this.progressBar1.Font = new System.Drawing.Font("Arial", 9F);
            this.progressBar1.ForeColor = System.Drawing.Color.Black;
            this.progressBar1.Location = new System.Drawing.Point(12, 12);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Opacity = 100;
            this.progressBar1.Size = new System.Drawing.Size(496, 43);
            this.progressBar1.TabIndex = 0;
            this.progressBar1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.progressBar1.TooltipText = "";
            this.progressBar1.ZOrder = 0;
            // 
            // jButton1
            // 
            this.jButton1.ApplicationWideResource = true;
            this.jButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton1.BackgroundImagePosition = "";
            this.jButton1.BackgroundImageQuality = ((short)(80));
            this.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton1.ClassName = "";
            this.jButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton1.CustomFontFamilies = "";
            this.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton1.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton1.Icon = null;
            this.jButton1.IconURL = "";
            this.jButton1.Image = null;
            this.jButton1.ImageLocation = "";
            this.jButton1.Location = new System.Drawing.Point(383, 85);
            this.jButton1.Name = "jButton1";
            this.jButton1.Opacity = 100;
            this.jButton1.PreventMultipleClicks = true;
            this.jButton1.Size = new System.Drawing.Size(125, 23);
            this.jButton1.TabIndex = 7;
            this.jButton1.Text = "Start Process";
            this.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton1.TooltipText = "";
            this.jButton1.UseVisualStyleBackColor = false;
            this.jButton1.ValidationFailedMessage = "Validation failed!";
            this.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton1.VerticalGradient = true;
            this.jButton1.ZOrder = 0;
            this.jButton1.Click += new System.EventHandler(this.jButton1_Click);
            // 
            // borderStyle
            // 
            this.borderStyle.ClassName = "";
            this.borderStyle.CustomFontFamilies = "";
            this.borderStyle.Font = new System.Drawing.Font("Arial", 9F);
            this.borderStyle.Items.AddRange(new object[] {
            "Solid",
            "Dotted",
            "Dashed",
            "Double"});
            this.borderStyle.Location = new System.Drawing.Point(14, 87);
            this.borderStyle.MinSelectedIndex = -1;
            this.borderStyle.Name = "borderStyle";
            this.borderStyle.Opacity = 100;
            this.borderStyle.Size = new System.Drawing.Size(121, 23);
            this.borderStyle.TabIndex = 1;
            this.borderStyle.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.borderStyle.TooltipText = "";
            this.borderStyle.UpdateTextBySelection = null;
            this.borderStyle.ValidationMessage = "An action is required";
            this.borderStyle.ZOrder = 0;
            this.borderStyle.SelectedIndexChanged += new System.EventHandler(this.borderStyle_SelectedIndexChanged);
            // 
            // borderColor
            // 
            this.borderColor.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.borderColor.CheckForEmail = false;
            this.borderColor.ClassName = "";
            this.borderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(221)))), ((int)(((byte)(0)))));
            this.borderColor.ColorInputValidation = true;
            this.borderColor.CustomFontFamilies = "";
            this.borderColor.Font = new System.Drawing.Font("Arial", 9F);
            this.borderColor.Location = new System.Drawing.Point(150, 87);
            this.borderColor.Mask = "#??????";
            this.borderColor.MinLength = -1;
            this.borderColor.Name = "borderColor";
            this.borderColor.Opacity = 100;
            this.borderColor.PreventSQLInjection = false;
            this.borderColor.RegexCheck = "^#?([a-f]|[A-F]|[0-9]){3}(([a-f]|[A-F]|[0-9]){3})?$";
            this.borderColor.Size = new System.Drawing.Size(100, 21);
            this.borderColor.TabIndex = 2;
            this.borderColor.Text = "00DD00";
            this.borderColor.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.borderColor.TooltipText = "";
            this.borderColor.ValidationMessage = "An action is required";
            this.borderColor.ZOrder = 0;
            this.borderColor.TextChanged += new System.EventHandler(this.borderColor_TextChanged);
            // 
            // backColor
            // 
            this.backColor.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.backColor.CheckForEmail = false;
            this.backColor.ClassName = "";
            this.backColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(153)))));
            this.backColor.ColorInputValidation = true;
            this.backColor.CustomFontFamilies = "";
            this.backColor.Font = new System.Drawing.Font("Arial", 9F);
            this.backColor.Location = new System.Drawing.Point(256, 87);
            this.backColor.Mask = "#??????";
            this.backColor.MinLength = -1;
            this.backColor.Name = "backColor";
            this.backColor.Opacity = 100;
            this.backColor.PreventSQLInjection = false;
            this.backColor.RegexCheck = "^#?([a-f]|[A-F]|[0-9]){3}(([a-f]|[A-F]|[0-9]){3})?$";
            this.backColor.Size = new System.Drawing.Size(100, 21);
            this.backColor.TabIndex = 3;
            this.backColor.Text = "006699";
            this.backColor.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.backColor.TooltipText = "";
            this.backColor.ValidationMessage = "An action is required";
            this.backColor.ZOrder = 0;
            this.backColor.TextChanged += new System.EventHandler(this.backColor_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 9F);
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(12, 69);
            this.label1.Name = "label1";
            this.label1.Opacity = 100;
            this.label1.Size = new System.Drawing.Size(73, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "Border Style";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.ZOrder = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9F);
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(147, 69);
            this.label2.Name = "label2";
            this.label2.Opacity = 100;
            this.label2.Size = new System.Drawing.Size(77, 15);
            this.label2.TabIndex = 5;
            this.label2.Text = "Border Color";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.ZOrder = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ClassName = "";
            this.label3.CustomFontFamilies = "";
            this.label3.Font = new System.Drawing.Font("Arial", 9F);
            this.label3.Image = null;
            this.label3.Location = new System.Drawing.Point(253, 69);
            this.label3.Name = "label3";
            this.label3.Opacity = 100;
            this.label3.Size = new System.Drawing.Size(37, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "Color";
            this.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label3.TooltipText = "";
            this.label3.UseMnemonic = false;
            this.label3.ZOrder = 0;
            // 
            // ProgressTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(527, 118);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.backColor);
            this.Controls.Add(this.borderColor);
            this.Controls.Add(this.borderStyle);
            this.Controls.Add(this.jButton1);
            this.Controls.Add(this.progressBar1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ProgressTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProgressBar Demo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private VisualJS.Web.Forms.ProgressBar progressBar1;
        private VisualJS.Web.Forms.JButton jButton1;
        private VisualJS.Web.Forms.ComboBox borderStyle;
        private VisualJS.Web.Forms.ColorPicker borderColor;
        private VisualJS.Web.Forms.ColorPicker backColor;
        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.Label label2;
        private VisualJS.Web.Forms.Label label3;
    }
}