﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing; 
using VisualJS;
using VisualJS.Web.Forms;
using System.Linq;
using System.Text;

namespace VisualJSControlsSample.SampleForms
{
    public partial class DateTimePickerTest : VisualJS.Web.Forms.Form
    {
        public DateTimePickerTest()
        {
            InitializeComponent();
            StartUp();
        } 

        //Use the below constructor if you create the instance of this Form object other than the active Thread
        //otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        public DateTimePickerTest(string clientId): base(clientId)
        {
            InitializeComponent();
            StartUp();
        }

        void StartUp()
        {
            dateTimePicker1.Value = DateTime.Now;
        }

        private void dateTimePicker1_TextChanged(object sender, EventArgs e)
        {
            DateTimePicker s = (DateTimePicker)sender;
            dateTimePicker1.Value = s.Value;
            dtChinese.Value = s.Value;
            dtGerman.Value = s.Value;
            dtTurkish.Value = s.Value;
            dtArabic.Value = s.Value;
        }

        private void jButton1_Click(object sender, EventArgs e)
        {
            lblLongDate.Text = dateTimePicker1.Value.ToLongDateString();
        }
    }
}