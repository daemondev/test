﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing; 
using VisualJS;
using VisualJS.Web.Forms;
using System.Linq;
using System.Text;

namespace VisualJSControlsSample.SampleForms
{
    public partial class SliderControlTest : VisualJS.Web.Forms.Form
    {

#region Constructors
        public SliderControlTest()
        {
            InitializeComponent();
            AfterInitialization();
        } 

        //Use the below constructor if you create the instance of this Form object other than the active Thread
        //otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        public SliderControlTest(string clientId): base(clientId)
        {
            InitializeComponent(); 
            AfterInitialization();
        }
#endregion

        //Use below method for the tasks after the initialization of the Form
        void  AfterInitialization()
        {
            List<SliderControl.SliderItem> slides = new List<SliderControl.SliderItem>();
            slides.Add(new SliderControl.SliderItem("Resources/ControlList.jpg", "", "Feature Rich User Interface Controls"));
            slides.Add(new SliderControl.SliderItem("Resources/OneClick.jpg", "", "Create ONCE Target ALL!"));
            slides.Add(new SliderControl.SliderItem("Resources/Charts.png", "", "Interactive Charts Support"));
            slides.Add(new SliderControl.SliderItem("Resources/TurnInto.png", "", "Use your existing codes"));
            slider1.AddSlide(slides);
        }
    }
}