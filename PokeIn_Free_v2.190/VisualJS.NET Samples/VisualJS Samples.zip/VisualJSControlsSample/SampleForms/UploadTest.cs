﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing; 
using VisualJS;
using VisualJS.Web.Forms;
using System.Linq;
using System.Text;

namespace VisualJSControlsSample.SampleForms
{
    using PokeIn.Comet;

    public partial class UploadTest : VisualJS.Web.Forms.Form
    {

#region Constructors
        public UploadTest()
        {
            InitializeComponent();
            AfterInitialization();
        } 

        //Use the below constructor if you create the instance of this Form object other than the active Thread
        //otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        public UploadTest(string clientId): base(clientId)
        {
            InitializeComponent(); 
            AfterInitialization();
        }
#endregion

        //Use below method for the tasks after the initialization of the Form
        void  AfterInitialization()
        {

        }

        internal static object demoLock = new object();
        private void uploadFile1_OnUpload(ref PokeIn.Comet.HttpFile file)
        {
            if (file.ContentLength > 1024 * 1024)
            {
                MessageBox.Show("For this demo, max allowed file size is 1mb", this);
                return;
            }
            //keep image component's output from multiple concurrent updates
            lock (demoLock)
            {
                file.SaveAs(Page.ApplicationPath + "//App_Data/" + file.FileName);
                ResourceManager.AddReplaceResource(
                    Page.ApplicationPath + "//App_Data/" + file.FileName, "uploadFile", ResourceType.Image, null);
                pictureBox1.ImageLocation = ResourceManager.GetResourceURL("uploadFile", ResourceType.Image);
            }
        }

        private void jButton1_Click(object sender, EventArgs e)
        {
            uploadFile1.Start();
        }
    }
}