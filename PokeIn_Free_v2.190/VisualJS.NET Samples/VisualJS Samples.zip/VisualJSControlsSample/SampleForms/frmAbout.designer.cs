﻿namespace VisualJSControlsSample.SampleForms
{
    partial class frmAbout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAbout));
            this.label1 = new VisualJS.Web.Forms.Label();
            this.jButton1 = new VisualJS.Web.Forms.JButton();
            this.label2 = new VisualJS.Web.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(34, 37);
            this.label1.Name = "label1";
            this.label1.Opacity = 100;
            this.label1.Size = new System.Drawing.Size(41, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sample About Form";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.ZOrder = 0;
            // 
            // jButton1
            // 
            this.jButton1.ApplicationWideResource = true;
            this.jButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton1.BackgroundImagePosition = "";
            this.jButton1.BackgroundImageQuality = ((short)(80));
            this.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton1.ClassName = "";
            this.jButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton1.CustomFontFamilies = "";
            this.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton1.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton1.Icon = null;
            this.jButton1.IconURL = "";
            this.jButton1.Image = null;
            this.jButton1.ImageLocation = "";
            this.jButton1.Location = new System.Drawing.Point(89, 80);
            this.jButton1.Name = "jButton1";
            this.jButton1.Opacity = 100;
            this.jButton1.Size = new System.Drawing.Size(75, 23);
            this.jButton1.TabIndex = 1;
            this.jButton1.Text = "Close";
            this.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton1.TooltipText = "";
            this.jButton1.UseVisualStyleBackColor = false;
            this.jButton1.ValidationFailedMessage = "Validation failed!";
            this.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton1.VerticalGradient = true;
            this.jButton1.ZOrder = 0;
            this.jButton1.Click += new System.EventHandler(this.jButton1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9F);
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Opacity = 100;
            this.label2.Size = new System.Drawing.Size(41, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "You can\'t close this form from above X button";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.ZOrder = 0;
            // 
            // frmAbout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(272, 114);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.jButton1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.FormClosableByUser = false;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAbout";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "About";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.JButton jButton1;
        private VisualJS.Web.Forms.Label label2;
    }
}