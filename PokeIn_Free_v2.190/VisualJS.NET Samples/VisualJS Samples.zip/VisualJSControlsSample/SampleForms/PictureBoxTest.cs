﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing; 
using VisualJS;
using VisualJS.Web.Forms;
using System.Linq;
using System.Text;

namespace VisualJSControlsSample.SampleForms
{
    public partial class PictureBoxTest : VisualJS.Web.Forms.Form
    {

#region Constructors
        public PictureBoxTest()
        {
            InitializeComponent();
            AfterInitialization();
        } 

        //Use the below constructor if you create the instance of this Form object other than the active Thread
        //otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        public PictureBoxTest(string clientId): base(clientId)
        {
            InitializeComponent(); 
            AfterInitialization();
        }
#endregion

        //Use below method for the tasks after the initialization of the Form
        void  AfterInitialization()
        {
            this.Height = 230;
        }

        bool mored = false;
        int oldLocation = 0;
        private void jButton1_Click(object sender, EventArgs e)
        {
            if (mored)
            {
                jButton1.Text = "More Sample..";
                mored = false;
                this.Height = 230;
                this.Top = oldLocation;
            }
            else
            {
                jButton1.Text = "Less Sample..";
                mored = true;
                this.Height = 520;
                oldLocation = this.Top;
                this.Top = 100;
            }
        }

        private void jButton2_Click(object sender, EventArgs e)
        {
            Bitmap bmp = new Bitmap(pictureBox7.Width, pictureBox7.Height);
            Graphics grp = Graphics.FromImage(bmp);
            grp.FillRectangle(new SolidBrush(clrBack.Color), 0, 0, pictureBox7.Width, pictureBox7.Height);
            grp.DrawString(txtImage.Text, this.Font, new SolidBrush(clrText.Color), 15, 15);
            grp.Flush();
            grp.Save();
            pictureBox7.Image = bmp;
        }
    }
}