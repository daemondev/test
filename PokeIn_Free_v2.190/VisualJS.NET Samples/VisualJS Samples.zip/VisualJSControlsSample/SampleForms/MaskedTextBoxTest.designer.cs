﻿namespace VisualJSControlsSample.SampleForms
{
    partial class MaskedTextBoxTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MaskedTextBoxTest));
            this.maskedTextBox1 = new VisualJS.Web.Forms.MaskedTextBox();
            this.label1 = new VisualJS.Web.Forms.Label();
            this.label3 = new VisualJS.Web.Forms.Label();
            this.maskedTextBox3 = new VisualJS.Web.Forms.MaskedTextBox();
            this.label2 = new VisualJS.Web.Forms.Label();
            this.maskedTextBox2 = new VisualJS.Web.Forms.MaskedTextBox();
            this.jButton1 = new VisualJS.Web.Forms.JButton();
            this.label4 = new VisualJS.Web.Forms.Label();
            this.maskedTextBox4 = new VisualJS.Web.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.maskedTextBox1.CheckForEmail = false;
            this.maskedTextBox1.ClassName = "";
            this.maskedTextBox1.CustomFontFamilies = "";
            this.maskedTextBox1.Font = new System.Drawing.Font("Arial", 9F);
            this.maskedTextBox1.Location = new System.Drawing.Point(12, 29);
            this.maskedTextBox1.Mask = "0000-0000-0000-0000";
            this.maskedTextBox1.MinLength = 16;
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Opacity = 100;
            this.maskedTextBox1.PreventSQLInjection = false;
            this.maskedTextBox1.RegexCheck = "";
            this.maskedTextBox1.Size = new System.Drawing.Size(174, 21);
            this.maskedTextBox1.TabIndex = 2;
            this.maskedTextBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.maskedTextBox1.TooltipText = "";
            this.maskedTextBox1.ValidationMessage = "Enter Credit Card Number";
            this.maskedTextBox1.ZOrder = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 9F);
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(12, 11);
            this.label1.Name = "label1";
            this.label1.Opacity = 100;
            this.label1.Size = new System.Drawing.Size(118, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Credit Card Number";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.ZOrder = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ClassName = "";
            this.label3.CustomFontFamilies = "";
            this.label3.Font = new System.Drawing.Font("Arial", 9F);
            this.label3.Image = null;
            this.label3.Location = new System.Drawing.Point(12, 57);
            this.label3.Name = "label3";
            this.label3.Opacity = 100;
            this.label3.Size = new System.Drawing.Size(43, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Phone";
            this.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label3.TooltipText = "";
            this.label3.UseMnemonic = false;
            this.label3.ZOrder = 0;
            // 
            // maskedTextBox3
            // 
            this.maskedTextBox3.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.maskedTextBox3.CheckForEmail = false;
            this.maskedTextBox3.ClassName = "";
            this.maskedTextBox3.CustomFontFamilies = "";
            this.maskedTextBox3.Font = new System.Drawing.Font("Arial", 9F);
            this.maskedTextBox3.Location = new System.Drawing.Point(12, 75);
            this.maskedTextBox3.Mask = "+(00) 00000000000";
            this.maskedTextBox3.MinLength = 12;
            this.maskedTextBox3.Name = "maskedTextBox3";
            this.maskedTextBox3.Opacity = 100;
            this.maskedTextBox3.PreventSQLInjection = false;
            this.maskedTextBox3.RegexCheck = "";
            this.maskedTextBox3.Size = new System.Drawing.Size(174, 21);
            this.maskedTextBox3.TabIndex = 3;
            this.maskedTextBox3.Text = "00";
            this.maskedTextBox3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.maskedTextBox3.TooltipText = "";
            this.maskedTextBox3.ValidationMessage = "Enter Your Phone Number (12 Number)";
            this.maskedTextBox3.ZOrder = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9F);
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(9, 107);
            this.label2.Name = "label2";
            this.label2.Opacity = 100;
            this.label2.Size = new System.Drawing.Size(63, 15);
            this.label2.TabIndex = 8;
            this.label2.Text = "Password";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.ZOrder = 0;
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.maskedTextBox2.CheckForEmail = false;
            this.maskedTextBox2.ClassName = "";
            this.maskedTextBox2.CustomFontFamilies = "";
            this.maskedTextBox2.Font = new System.Drawing.Font("Arial", 9F);
            this.maskedTextBox2.Location = new System.Drawing.Point(12, 125);
            this.maskedTextBox2.MinLength = 5;
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Opacity = 100;
            this.maskedTextBox2.PasswordMode = true;
            this.maskedTextBox2.PreventSQLInjection = false;
            this.maskedTextBox2.RegexCheck = "";
            this.maskedTextBox2.Size = new System.Drawing.Size(174, 21);
            this.maskedTextBox2.TabIndex = 4;
            this.maskedTextBox2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.maskedTextBox2.TooltipText = "";
            this.maskedTextBox2.ValidationMessage = "Min 5 Chars";
            this.maskedTextBox2.ZOrder = 0;
            // 
            // jButton1
            // 
            this.jButton1.ApplicationWideResource = true;
            this.jButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton1.BackgroundImagePosition = "";
            this.jButton1.BackgroundImageQuality = ((short)(80));
            this.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton1.ClassName = "";
            this.jButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton1.CustomFontFamilies = "";
            this.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton1.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton1.Icon = null;
            this.jButton1.IconURL = "";
            this.jButton1.Image = null;
            this.jButton1.ImageLocation = "";
            this.jButton1.Location = new System.Drawing.Point(96, 205);
            this.jButton1.Name = "jButton1";
            this.jButton1.Opacity = 100;
            this.jButton1.Size = new System.Drawing.Size(90, 23);
            this.jButton1.TabIndex = 10;
            this.jButton1.Text = "Submit";
            this.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton1.TooltipText = "";
            this.jButton1.UseVisualStyleBackColor = false;
            this.jButton1.ValidationFailedMessage = "Validation failed!";
            this.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnForm;
            this.jButton1.VerticalGradient = true;
            this.jButton1.ZOrder = 0;
            this.jButton1.Click += new System.EventHandler(this.jButton1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ClassName = "";
            this.label4.CustomFontFamilies = "";
            this.label4.Font = new System.Drawing.Font("Arial", 9F);
            this.label4.Image = null;
            this.label4.Location = new System.Drawing.Point(12, 152);
            this.label4.Name = "label4";
            this.label4.Opacity = 100;
            this.label4.Size = new System.Drawing.Size(66, 15);
            this.label4.TabIndex = 11;
            this.label4.Text = "IP Address";
            this.label4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label4.TooltipText = "";
            this.label4.UseMnemonic = false;
            this.label4.ZOrder = 0;
            // 
            // maskedTextBox4
            // 
            this.maskedTextBox4.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.maskedTextBox4.CheckForEmail = false;
            this.maskedTextBox4.ClassName = "";
            this.maskedTextBox4.CustomFontFamilies = "";
            this.maskedTextBox4.Font = new System.Drawing.Font("Arial", 9F);
            this.maskedTextBox4.Location = new System.Drawing.Point(12, 170);
            this.maskedTextBox4.MinLength = -1;
            this.maskedTextBox4.Name = "maskedTextBox4";
            this.maskedTextBox4.Opacity = 100;
            this.maskedTextBox4.PreventSQLInjection = false;
            this.maskedTextBox4.RegexCheck = "^((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\\.){3}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|" +
    "[0-9]{1,2})$";
            this.maskedTextBox4.Size = new System.Drawing.Size(174, 21);
            this.maskedTextBox4.TabIndex = 5;
            this.maskedTextBox4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.maskedTextBox4.TooltipText = "Checks the input using Regex Validation feature";
            this.maskedTextBox4.ValidationMessage = "Enter an IP address";
            this.maskedTextBox4.ZOrder = 0;
            // 
            // MaskedTextBoxTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(198, 240);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.maskedTextBox4);
            this.Controls.Add(this.jButton1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.maskedTextBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.maskedTextBox3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.maskedTextBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MaskedTextBoxTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "MaskedTextBox Demo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private VisualJS.Web.Forms.MaskedTextBox maskedTextBox1;
        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.Label label3;
        private VisualJS.Web.Forms.MaskedTextBox maskedTextBox3;
        private VisualJS.Web.Forms.Label label2;
        private VisualJS.Web.Forms.MaskedTextBox maskedTextBox2;
        private VisualJS.Web.Forms.JButton jButton1;
        private VisualJS.Web.Forms.Label label4;
        private VisualJS.Web.Forms.MaskedTextBox maskedTextBox4;
    }
}