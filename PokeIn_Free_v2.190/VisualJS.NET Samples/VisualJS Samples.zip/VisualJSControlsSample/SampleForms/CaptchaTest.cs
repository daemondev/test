﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using VisualJS;
using VisualJS.Web.Forms;
using System.Linq;
using System.Text;

namespace VisualJSControlsSample.SampleForms
{
    public partial class CaptchaTest : VisualJS.Web.Forms.Form
    {
        public CaptchaTest()
        {
            InitializeComponent();
        } 

        //Use the below constructor if you create the instance of this Form object other than the active Thread
        //otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        public CaptchaTest(string clientId): base(clientId)
        {
            InitializeComponent(); 
        }

        private void jButton1_Click(object sender, EventArgs e)
        {
            if (captchaBox1.PassByTextBox(textBox1, true, true))
                MessageBox.Show("Congratulations!", "You have passed the captcha", MessageBoxIcons.Information, this);
            else
                MessageBox.Show("Failed!", "Wrong captcha text", MessageBoxIcons.Warning, this);
        }
    }
}