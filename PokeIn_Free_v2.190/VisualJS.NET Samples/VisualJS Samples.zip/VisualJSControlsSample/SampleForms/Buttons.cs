﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using VisualJS;
using VisualJS.Web.Forms;
using System.Linq;
using System.Text;

namespace VisualJSControlsSample.SampleForms
{
    public partial class Buttons : VisualJS.Web.Forms.Form
    {
        public Buttons()
        {
            InitializeComponent();
        }

        //Use the below constructor if you create the instance of this Form object other than the active Thread
        //otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        public Buttons(string clientId): base(clientId)
        {
            InitializeComponent(); 
        }
    }
}