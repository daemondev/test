﻿namespace VisualJSControlsSample.SampleForms
{
    partial class FlashPlayerTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FlashPlayerTest));
            this.flashPlayer1 = new VisualJS.Web.Forms.FlashPlayer();
            this.SuspendLayout();
            // 
            // flashPlayer1
            // 
            this.flashPlayer1.AutoPlay = false;
            this.flashPlayer1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.flashPlayer1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.flashPlayer1.BackColor = System.Drawing.Color.Black;
            this.flashPlayer1.ClassName = "";
            this.flashPlayer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flashPlayer1.Font = new System.Drawing.Font("Arial", 9F);
            this.flashPlayer1.Location = new System.Drawing.Point(0, 0);
            this.flashPlayer1.Name = "flashPlayer1";
            this.flashPlayer1.Opacity = 100;
            this.flashPlayer1.Size = new System.Drawing.Size(626, 306);
            this.flashPlayer1.SWF = "http://www.youtube.com/v/flj-919bKMU?version=3&amp;hl=en_US&amp;rel=0";
            this.flashPlayer1.TabIndex = 0;
            this.flashPlayer1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.flashPlayer1.TooltipText = "";
            this.flashPlayer1.ZOrder = 0;
            // 
            // FlashPlayerTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 306);
            this.Controls.Add(this.flashPlayer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimizeBox = false;
            this.Name = "FlashPlayerTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "FlashPlayer Demo";
            this.ResumeLayout(false);

        }

        #endregion

        private VisualJS.Web.Forms.FlashPlayer flashPlayer1;
    }
}