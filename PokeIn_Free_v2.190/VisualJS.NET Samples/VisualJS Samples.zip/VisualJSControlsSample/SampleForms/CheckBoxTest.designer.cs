﻿namespace VisualJSControlsSample.SampleForms
{
    partial class CheckBoxTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CheckBoxTest));
            this.checkBox1 = new VisualJS.Web.Forms.CheckBox();
            this.label1 = new VisualJS.Web.Forms.Label();
            this.checkBox2 = new VisualJS.Web.Forms.CheckBox();
            this.checkBox3 = new VisualJS.Web.Forms.CheckBox();
            this.checkBox4 = new VisualJS.Web.Forms.CheckBox();
            this.maskedTextBox1 = new VisualJS.Web.Forms.MaskedTextBox();
            this.label2 = new VisualJS.Web.Forms.Label();
            this.SuspendLayout();
            // 
            // checkBox1
            // 
            this.checkBox1.BackColor = System.Drawing.Color.Transparent;
            this.checkBox1.ClassName = "";
            this.checkBox1.CustomFontFamilies = "";
            this.checkBox1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Image = null;
            this.checkBox1.Location = new System.Drawing.Point(15, 36);
            this.checkBox1.MustBeCheckedBeforeSubmit = false;
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Opacity = 100;
            this.checkBox1.Size = new System.Drawing.Size(170, 23);
            this.checkBox1.TabIndex = 8;
            this.checkBox1.Tag = "200000";
            this.checkBox1.Text = "Sport Car [USD 200.000]";
            this.checkBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.checkBox1.TooltipText = "";
            this.checkBox1.UseMnemonic = false;
            this.checkBox1.UseVisualStyleBackColor = false;
            this.checkBox1.ValidationMessage = "An action is required";
            this.checkBox1.ZOrder = 0;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 9F);
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Opacity = 100;
            this.label1.Size = new System.Drawing.Size(167, 22);
            this.label1.TabIndex = 1;
            this.label1.Text = "Please check the below things you are going to buy";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.ZOrder = 0;
            // 
            // checkBox2
            // 
            this.checkBox2.BackColor = System.Drawing.Color.Transparent;
            this.checkBox2.ClassName = "";
            this.checkBox2.CustomFontFamilies = "";
            this.checkBox2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.Image = null;
            this.checkBox2.Location = new System.Drawing.Point(15, 61);
            this.checkBox2.MustBeCheckedBeforeSubmit = false;
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Opacity = 100;
            this.checkBox2.Size = new System.Drawing.Size(161, 23);
            this.checkBox2.TabIndex = 3;
            this.checkBox2.Tag = "400000";
            this.checkBox2.Text = "House [USD 400.000]";
            this.checkBox2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.checkBox2.TooltipText = "";
            this.checkBox2.UseMnemonic = false;
            this.checkBox2.UseVisualStyleBackColor = false;
            this.checkBox2.ValidationMessage = "An action is required";
            this.checkBox2.ZOrder = 0;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.BackColor = System.Drawing.Color.Transparent;
            this.checkBox3.ClassName = "";
            this.checkBox3.CustomFontFamilies = "";
            this.checkBox3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox3.Image = null;
            this.checkBox3.Location = new System.Drawing.Point(15, 90);
            this.checkBox3.MustBeCheckedBeforeSubmit = false;
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Opacity = 100;
            this.checkBox3.Size = new System.Drawing.Size(161, 23);
            this.checkBox3.TabIndex = 4;
            this.checkBox3.Tag = "500";
            this.checkBox3.Text = "QPAD [USD 500]";
            this.checkBox3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.checkBox3.TooltipText = "";
            this.checkBox3.UseMnemonic = false;
            this.checkBox3.UseVisualStyleBackColor = false;
            this.checkBox3.ValidationMessage = "An action is required";
            this.checkBox3.ZOrder = 0;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // checkBox4
            // 
            this.checkBox4.BackColor = System.Drawing.Color.Transparent;
            this.checkBox4.ClassName = "";
            this.checkBox4.CustomFontFamilies = "";
            this.checkBox4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox4.Image = null;
            this.checkBox4.Location = new System.Drawing.Point(15, 115);
            this.checkBox4.MustBeCheckedBeforeSubmit = false;
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Opacity = 100;
            this.checkBox4.Size = new System.Drawing.Size(161, 23);
            this.checkBox4.TabIndex = 5;
            this.checkBox4.Tag = "500";
            this.checkBox4.Text = "MBOX 360 [USD 500]";
            this.checkBox4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.checkBox4.TooltipText = "";
            this.checkBox4.UseMnemonic = false;
            this.checkBox4.UseVisualStyleBackColor = false;
            this.checkBox4.ValidationMessage = "An action is required";
            this.checkBox4.ZOrder = 0;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.maskedTextBox1.CheckForEmail = false;
            this.maskedTextBox1.ClassName = "";
            this.maskedTextBox1.CustomFontFamilies = "";
            this.maskedTextBox1.Font = new System.Drawing.Font("Arial", 9F);
            this.maskedTextBox1.Location = new System.Drawing.Point(191, 119);
            this.maskedTextBox1.MinLength = -1;
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Opacity = 100;
            this.maskedTextBox1.PreventSQLInjection = false;
            this.maskedTextBox1.ReadOnly = true;
            this.maskedTextBox1.RegexCheck = "";
            this.maskedTextBox1.Size = new System.Drawing.Size(120, 21);
            this.maskedTextBox1.TabIndex = 6;
            this.maskedTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.maskedTextBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.maskedTextBox1.TooltipText = "";
            this.maskedTextBox1.ValidationMessage = "An action is required";
            this.maskedTextBox1.ZOrder = 0;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Maroon;
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(188, 98);
            this.label2.Name = "label2";
            this.label2.Opacity = 100;
            this.label2.Size = new System.Drawing.Size(81, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "Total";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.ZOrder = 0;
            // 
            // CheckBoxTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 161);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.maskedTextBox1);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CheckBoxTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "CheckBox Demo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private VisualJS.Web.Forms.CheckBox checkBox1;
        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.CheckBox checkBox2;
        private VisualJS.Web.Forms.CheckBox checkBox3;
        private VisualJS.Web.Forms.CheckBox checkBox4;
        private VisualJS.Web.Forms.MaskedTextBox maskedTextBox1;
        private VisualJS.Web.Forms.Label label2;
    }
}