﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing; 
using VisualJS;
using VisualJS.Web.Forms;
using System.Linq;
using System.Text;

namespace VisualJSControlsSample.SampleForms
{
    public partial class ListBoxTest : VisualJS.Web.Forms.Form
    {
        public ListBoxTest()
        {
            InitializeComponent();
        } 

        //Use the below constructor if you create the instance of this Form object other than the active Thread
        //otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        public ListBoxTest(string clientId): base(clientId)
        {
            InitializeComponent(); 
        }

        long n = 0;

        //Add Item
        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("Item " + (n++).ToString());
        }

        //Insert Item
        private void button4_Click(object sender, EventArgs e)
        {
            Int32 number;
            if (Int32.TryParse(maskedTextBox1.Text, out number))
            {
                if (number < listBox1.Items.Count)
                {
                    listBox1.Items.Insert(number, "Item " + (n++).ToString());
                    return;
                }
            }

            MessageBox.Show("Error", "Enter a number within the range of listbox items", MessageBoxIcons.Error, this);
        }

        //Remove Item
        private void button2_Click(object sender, EventArgs e)
        {
            Int32 number;
            if (Int32.TryParse(maskedTextBox2.Text, out number))
            {
                if (number < listBox1.Items.Count)
                {
                    listBox1.Items.RemoveAt(number);
                    return;
                }
            }

            MessageBox.Show("Error", "Enter a number within the range of listbox items", MessageBoxIcons.Error, this);
        }

        //Clear Items
        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        Color[] colors = new Color[4] { Color.Yellow, Color.Orange, Color.White, Color.Red };
        void UpdateDraw(string [] texts)
        {
            Bitmap bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            Graphics grp = Graphics.FromImage(bmp);
            for(int i=0;i<texts.Length;i++)
                grp.DrawString(texts[i], this.Font, new SolidBrush(colors[i % 4]), 15, 10 + (i * 20)); 
            grp.Flush();
            grp.Save();
            pictureBox1.Image = bmp;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string[] list = new string[]{
                "Selected Index:" + listBox1.SelectedIndex.ToString(),
                "Value:" + listBox1.SelectedItem
            };
            UpdateDraw(list);
        }
    }
}