﻿namespace VisualJSControlsSample.SampleForms
{
    partial class PanelTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PanelTest));
            this.panel1 = new VisualJS.Web.Forms.Panel();
            this.panel4 = new VisualJS.Web.Forms.Panel();
            this.label5 = new VisualJS.Web.Forms.Label();
            this.label4 = new VisualJS.Web.Forms.Label();
            this.panel3 = new VisualJS.Web.Forms.Panel();
            this.label3 = new VisualJS.Web.Forms.Label();
            this.panel2 = new VisualJS.Web.Forms.Panel();
            this.label2 = new VisualJS.Web.Forms.Label();
            this.label1 = new VisualJS.Web.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.ApplicationWideResource = true;
            this.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.panel1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.panel1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel1.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel1.BackgroundImagePosition = "";
            this.panel1.BackgroundImageQuality = ((short)(80));
            this.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.panel1.BorderColor = System.Drawing.Color.Black;
            this.panel1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid;
            this.panel1.ClassName = "";
            this.panel1.ClientID = null;
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.CustomFontFamilies = "";
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Font = new System.Drawing.Font("Arial", 9F);
            this.panel1.HTML = "";
            this.panel1.ImageLocation = "";
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Opacity = 100;
            this.panel1.Size = new System.Drawing.Size(860, 476);
            this.panel1.TabIndex = 0;
            this.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.panel1.TooltipText = "";
            this.panel1.VerticalGradient = true;
            this.panel1.ZOrder = 0;
            // 
            // panel4
            // 
            this.panel4.ApplicationWideResource = true;
            this.panel4.AutoGrowShrink = VisualJS.Service.GrowShrink.ByWidth;
            this.panel4.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.panel4.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.BackColorEnd = System.Drawing.Color.Transparent;
            this.panel4.BackgroundImagePosition = "";
            this.panel4.BackgroundImageQuality = ((short)(80));
            this.panel4.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.panel4.BorderColor = System.Drawing.Color.OrangeRed;
            this.panel4.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Dashed;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.ClassName = "";
            this.panel4.ClientID = null;
            this.panel4.Controls.Add(this.label5);
            this.panel4.CustomFontFamilies = "";
            this.panel4.Font = new System.Drawing.Font("Arial", 9F);
            this.panel4.ForeColor = System.Drawing.Color.Yellow;
            this.panel4.HTML = "<p style=\'margin:10px;\'>This is the <strong>HTML</html> content inside the Panel " +
    "control</p>";
            this.panel4.ImageLocation = "";
            this.panel4.Location = new System.Drawing.Point(0, 75);
            this.panel4.Name = "panel4";
            this.panel4.Opacity = 100;
            this.panel4.Size = new System.Drawing.Size(860, 122);
            this.panel4.TabIndex = 4;
            this.panel4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.panel4.TooltipText = "";
            this.panel4.VerticalGradient = true;
            this.panel4.ZOrder = 0;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ClassName = "";
            this.label5.CustomFontFamilies = "";
            this.label5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Image = null;
            this.label5.Location = new System.Drawing.Point(689, 11);
            this.label5.Name = "label5";
            this.label5.Opacity = 90;
            this.label5.Size = new System.Drawing.Size(158, 69);
            this.label5.TabIndex = 3;
            this.label5.Text = "AutoGrowShrink by Width, HTML Content Support, Transparent Background, Dashed Ora" +
    "nge Border";
            this.label5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.label5.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label5.TooltipText = "";
            this.label5.UseMnemonic = false;
            this.label5.ZOrder = 0;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ClassName = "";
            this.label4.CustomFontFamilies = "";
            this.label4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Image = null;
            this.label4.Location = new System.Drawing.Point(604, 9);
            this.label4.Name = "label4";
            this.label4.Opacity = 90;
            this.label4.Size = new System.Drawing.Size(140, 36);
            this.label4.TabIndex = 3;
            this.label4.Text = "Min Form Width:  550, Min Form Height: 400";
            this.label4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label4.TooltipText = "";
            this.label4.UseMnemonic = false;
            this.label4.ZOrder = 0;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panel3.ApplicationWideResource = true;
            this.panel3.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.panel3.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.panel3.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.panel3.BackgroundImagePosition = "";
            this.panel3.BackgroundImageQuality = ((short)(80));
            this.panel3.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.panel3.BorderColor = System.Drawing.Color.Black;
            this.panel3.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid;
            this.panel3.ClassName = "";
            this.panel3.ClientID = null;
            this.panel3.Controls.Add(this.label3);
            this.panel3.CustomFontFamilies = "";
            this.panel3.Font = new System.Drawing.Font("Arial", 9F);
            this.panel3.HTML = "";
            this.panel3.ImageLocation = "";
            this.panel3.Location = new System.Drawing.Point(12, 230);
            this.panel3.Name = "panel3";
            this.panel3.Opacity = 20;
            this.panel3.Size = new System.Drawing.Size(241, 229);
            this.panel3.TabIndex = 2;
            this.panel3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.panel3.TooltipText = "";
            this.panel3.VerticalGradient = true;
            this.panel3.ZOrder = 0;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ClassName = "";
            this.label3.CustomFontFamilies = "";
            this.label3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Image = null;
            this.label3.Location = new System.Drawing.Point(12, 13);
            this.label3.Name = "label3";
            this.label3.Opacity = 90;
            this.label3.Size = new System.Drawing.Size(106, 67);
            this.label3.TabIndex = 2;
            this.label3.Text = "Opacity 20%, Gradient, Anchored to bottom left";
            this.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label3.TooltipText = "";
            this.label3.UseMnemonic = false;
            this.label3.ZOrder = 0;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.ApplicationWideResource = true;
            this.panel2.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.panel2.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.panel2.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.panel2.BackgroundImagePosition = "";
            this.panel2.BackgroundImageQuality = ((short)(80));
            this.panel2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.panel2.BorderColor = System.Drawing.Color.Black;
            this.panel2.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid;
            this.panel2.ClassName = "";
            this.panel2.ClientID = null;
            this.panel2.Controls.Add(this.label2);
            this.panel2.CustomFontFamilies = "";
            this.panel2.Font = new System.Drawing.Font("Arial", 9F);
            this.panel2.HTML = "";
            this.panel2.ImageLocation = "";
            this.panel2.Location = new System.Drawing.Point(607, 230);
            this.panel2.Name = "panel2";
            this.panel2.Opacity = 70;
            this.panel2.Size = new System.Drawing.Size(241, 229);
            this.panel2.TabIndex = 1;
            this.panel2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.panel2.TooltipText = "";
            this.panel2.VerticalGradient = true;
            this.panel2.ZOrder = 0;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(12, 13);
            this.label2.Name = "label2";
            this.label2.Opacity = 90;
            this.label2.Size = new System.Drawing.Size(106, 67);
            this.label2.TabIndex = 2;
            this.label2.Text = "Opacity 70%, Gradient, Anchored to bottom right";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.ZOrder = 0;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Opacity = 90;
            this.label1.Size = new System.Drawing.Size(241, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Base Panel is Docked in Fill Mode with Gradient Background Color";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.ZOrder = 0;
            // 
            // PanelTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(860, 476);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PanelTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "Panel Demo";
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private VisualJS.Web.Forms.Panel panel1;
        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.Panel panel3;
        private VisualJS.Web.Forms.Label label3;
        private VisualJS.Web.Forms.Panel panel2;
        private VisualJS.Web.Forms.Label label2;
        private VisualJS.Web.Forms.Label label4;
        private VisualJS.Web.Forms.Panel panel4;
        private VisualJS.Web.Forms.Label label5;
    }
}