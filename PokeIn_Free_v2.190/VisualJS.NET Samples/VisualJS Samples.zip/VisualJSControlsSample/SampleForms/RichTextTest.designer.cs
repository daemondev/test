﻿namespace VisualJSControlsSample.SampleForms
{
    partial class RichTextTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RichTextTest));
            this.richTextBox1 = new VisualJS.Web.Forms.RichTextBox();
            this.panel1 = new VisualJS.Web.Forms.Panel();
            this.panel2 = new VisualJS.Web.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Buttons = "style,alignment,colors,insert,undoredo";
            this.richTextBox1.CheckForEmail = false;
            this.richTextBox1.ClassName = "";
            this.richTextBox1.CustomFontFamilies = "";
            this.richTextBox1.Font = new System.Drawing.Font("Arial", 9F);
            this.richTextBox1.Location = new System.Drawing.Point(12, 12);
            this.richTextBox1.MaxLength = 65535;
            this.richTextBox1.MinLength = -1;
            this.richTextBox1.Multiline = true;
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Opacity = 100;
            this.richTextBox1.PreventSQLInjection = false;
            this.richTextBox1.RegexCheck = "";
            this.richTextBox1.Size = new System.Drawing.Size(411, 236);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.richTextBox1.TooltipText = "";
            this.richTextBox1.ValidationMessage = "An action is required";
            this.richTextBox1.ZOrder = 0;
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // panel1
            // 
            this.panel1.ApplicationWideResource = true;
            this.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.panel1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.panel1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackColorEnd = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImagePosition = "";
            this.panel1.BackgroundImageQuality = ((short)(80));
            this.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.panel1.BorderColor = System.Drawing.Color.DimGray;
            this.panel1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.ClassName = "";
            this.panel1.ClientID = null;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.CustomFontFamilies = "";
            this.panel1.Font = new System.Drawing.Font("Arial", 9F);
            this.panel1.HTML = "";
            this.panel1.ImageLocation = "";
            this.panel1.Location = new System.Drawing.Point(438, 12);
            this.panel1.Name = "panel1";
            this.panel1.Opacity = 100;
            this.panel1.Size = new System.Drawing.Size(374, 236);
            this.panel1.TabIndex = 1;
            this.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.panel1.TooltipText = "";
            this.panel1.VerticalGradient = true;
            this.panel1.ZOrder = 0;
            // 
            // panel2
            // 
            this.panel2.ApplicationWideResource = true;
            this.panel2.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.panel2.AutoScroll = true;
            this.panel2.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.panel2.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BackColorEnd = System.Drawing.Color.Transparent;
            this.panel2.BackgroundImagePosition = "";
            this.panel2.BackgroundImageQuality = ((short)(80));
            this.panel2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.panel2.BorderColor = System.Drawing.Color.Black;
            this.panel2.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid;
            this.panel2.ClassName = "";
            this.panel2.ClientID = null;
            this.panel2.CustomFontFamilies = "";
            this.panel2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.HTML = "When the RichTextBox lost its focus, this component\'s HTML will be updated";
            this.panel2.ImageLocation = "";
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Opacity = 100;
            this.panel2.Size = new System.Drawing.Size(366, 228);
            this.panel2.TabIndex = 0;
            this.panel2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.panel2.TooltipText = "";
            this.panel2.VerticalGradient = true;
            this.panel2.ZOrder = 0;
            // 
            // RichTextTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 260);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.richTextBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RichTextTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "RichTextBox Demo";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private VisualJS.Web.Forms.RichTextBox richTextBox1;
        private VisualJS.Web.Forms.Panel panel1;
        private VisualJS.Web.Forms.Panel panel2;
    }
}