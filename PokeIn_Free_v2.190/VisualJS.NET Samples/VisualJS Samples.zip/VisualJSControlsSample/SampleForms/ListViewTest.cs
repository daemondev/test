﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing; 
using VisualJS;
using VisualJS.Web.Forms;
using System.Linq;
using System.Text;

namespace VisualJSControlsSample.SampleForms
{
    public partial class ListViewTest : VisualJS.Web.Forms.Form
    {
        public ListViewTest()
        {
            InitializeComponent();
            AfterInitialization();
        } 

        //Use the below constructor if you create the instance of this Form object other than the active Thread
        //otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        public ListViewTest(string clientId): base(clientId)
        {
            InitializeComponent();
            AfterInitialization();
        }

        void AfterInitialization()
        {
            listView1.Columns.Add("Column 1", 100, System.Windows.Forms.HorizontalAlignment.Left);
            listView1.Columns.Add("Column 2", 115, System.Windows.Forms.HorizontalAlignment.Left);
            listView1.Columns.Add("Column 3", 115, System.Windows.Forms.HorizontalAlignment.Left);
            listView1.Columns.Add("Column 4", 115, System.Windows.Forms.HorizontalAlignment.Left);
        }

        private void jButton1_Click(object sender, EventArgs e)
        {
            if (listView1.HeaderStyle == System.Windows.Forms.ColumnHeaderStyle.None)
            {
                jButton1.Text = "Hide Headers";
                listView1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Clickable;
            }
            else
            {
                jButton1.Text = "Show Headers";
                listView1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            }
        }

        private void jButton4_Click(object sender, EventArgs e)
        {
            if (listView1.CheckBoxes)
            {
                jButton4.Text = "Show CheckBoxes";
            }
            else
            {
                jButton4.Text = "Hide CheckBoxes";
            }
            listView1.CheckBoxes = !listView1.CheckBoxes;
        }

        private void jButton3_Click(object sender, EventArgs e)
        {
            n = 0;
            listView1.Items.Clear();
        }

        int n = 0;
        private void jButton2_Click(object sender, EventArgs e)
        {
            if (listView1.Items.Count >= 5000)
            {
                MessageBox.Show("We limit this DEMO to 5.000 Rows", this);
                return;
            }
            ListView.ListViewItem[] items = new ListView.ListViewItem[100];
            for (int i = 0; i < 100; i++)
            {
                items[i] = new ListView.ListViewItem("Item " + n.ToString());
                items[i].SubItems.Add("Sub Item 1 - " + n.ToString());
                items[i].SubItems.Add("Sub Item 2 - " + n.ToString());
                items[i].SubItems.Add("Sub Item 3 - " + n.ToString());
                items[i].SubItems[0].IconIndex = n % 7;
                n++;
            }
            listView1.Items.AddRange(items);
        }

        private void listView1_OnCellValueUpdated(object sender, int rowIndex, int columnIndex, string value)
        {
            listView1.Items[rowIndex].BackColor = Color.YellowGreen;
        }
    }
}