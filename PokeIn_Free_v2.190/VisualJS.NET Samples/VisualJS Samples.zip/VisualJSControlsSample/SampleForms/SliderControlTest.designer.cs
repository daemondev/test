﻿namespace VisualJSControlsSample.SampleForms
{
    partial class SliderControlTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SliderControlTest));
            this.slider1 = new VisualJS.Web.Forms.SliderControl();
            this.SuspendLayout();
            // 
            // slider1
            // 
            this.slider1.ApplicationWideResource = true;
            this.slider1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.slider1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.slider1.BackColor = System.Drawing.Color.GreenYellow;
            this.slider1.BackgroundImagePosition = "";
            this.slider1.BackgroundImageQuality = ((short)(80));
            this.slider1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.slider1.BoxCols = 5;
            this.slider1.BoxRows = 5;
            this.slider1.ClassName = "";
            this.slider1.CustomFontFamilies = "";
            this.slider1.DirectNav = true;
            this.slider1.DirectNavHide = true;
            this.slider1.Font = new System.Drawing.Font("Arial", 9F);
            this.slider1.ImageLocation = "";
            this.slider1.Location = new System.Drawing.Point(12, 12);
            this.slider1.Name = "slider1";
            this.slider1.PauseTime = 4000;
            this.slider1.ReadOnly = false;
            this.slider1.Size = new System.Drawing.Size(873, 301);
            this.slider1.Slices = 5;
            this.slider1.StartSlide = 0;
            this.slider1.TabIndex = 0;
            this.slider1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.slider1.TooltipText = "";
            this.slider1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.slider1.ZOrder = 0;
            // 
            // SliderControlTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(900, 324);
            this.Controls.Add(this.slider1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SliderControlTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "SliderControl Demo";
            this.ResumeLayout(false);

        }

        #endregion

        private VisualJS.Web.Forms.SliderControl slider1;
    }
}