﻿namespace VisualJSControlsSample.SampleForms
{
    partial class FeedBoxTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FeedBoxTest));
            this.label1 = new VisualJS.Web.Forms.Label();
            this.label2 = new VisualJS.Web.Forms.Label();
            this.feedBox2 = new VisualJS.Web.Forms.FeedBox();
            this.feedBox1 = new VisualJS.Web.Forms.FeedBox();
            ((System.ComponentModel.ISupportInitialize)(this.feedBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.feedBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.LightSkyBlue;
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Opacity = 100;
            this.label1.Size = new System.Drawing.Size(119, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Target External URL";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.ZOrder = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.LightSkyBlue;
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(222, 9);
            this.label2.Name = "label2";
            this.label2.Opacity = 100;
            this.label2.Size = new System.Drawing.Size(146, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Target Server Side Event";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.ZOrder = 0;
            // 
            // feedBox2
            // 
            this.feedBox2.ApplicationWideResource = true;
            this.feedBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(46)))), ((int)(((byte)(16)))));
            this.feedBox2.ClassName = "";
            this.feedBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.feedBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("feedBox2.ErrorImage")));
            this.feedBox2.ForeColor = System.Drawing.Color.White;
            this.feedBox2.Image = global::VisualJSControlsSample.Properties.Resources.ios5;
            this.feedBox2.ImageQuality = ((short)(80));
            this.feedBox2.ImageText = "Target IOS Devices";
            this.feedBox2.InitialImage = ((System.Drawing.Image)(resources.GetObject("feedBox2.InitialImage")));
            this.feedBox2.Location = new System.Drawing.Point(225, 27);
            this.feedBox2.Name = "feedBox2";
            this.feedBox2.Opacity = 100;
            this.feedBox2.Size = new System.Drawing.Size(190, 200);
            this.feedBox2.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal;
            this.feedBox2.TabIndex = 2;
            this.feedBox2.TabStop = false;
            this.feedBox2.Target = VisualJS.Web.Forms.FeedBox.URLOpen.NewWindow;
            this.feedBox2.TargetURL = "";
            this.feedBox2.Text = "VisualJS.NET IOS Support";
            this.feedBox2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.feedBox2.TooltipText = "";
            this.feedBox2.ZOrder = 0;
            this.feedBox2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.feedBox2_MouseDown);
            // 
            // feedBox1
            // 
            this.feedBox1.ApplicationWideResource = true;
            this.feedBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(46)))), ((int)(((byte)(16)))));
            this.feedBox1.ClassName = "";
            this.feedBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("feedBox1.ErrorImage")));
            this.feedBox1.ForeColor = System.Drawing.Color.White;
            this.feedBox1.Image = ((System.Drawing.Image)(resources.GetObject("feedBox1.Image")));
            this.feedBox1.ImageQuality = ((short)(80));
            this.feedBox1.ImageText = "Target Android Devices";
            this.feedBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("feedBox1.InitialImage")));
            this.feedBox1.Location = new System.Drawing.Point(15, 27);
            this.feedBox1.Name = "feedBox1";
            this.feedBox1.Opacity = 100;
            this.feedBox1.Size = new System.Drawing.Size(190, 200);
            this.feedBox1.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal;
            this.feedBox1.TabIndex = 0;
            this.feedBox1.TabStop = false;
            this.feedBox1.Target = VisualJS.Web.Forms.FeedBox.URLOpen.NewWindow;
            this.feedBox1.TargetURL = "http://www.visualjs.net";
            this.feedBox1.Text = "VisualJS.NET Android Support";
            this.feedBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.feedBox1.TooltipText = "";
            this.feedBox1.ZOrder = 0;
            // 
            // FeedBoxTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(437, 243);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.feedBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.feedBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FeedBoxTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "FeedBox Demo";
            ((System.ComponentModel.ISupportInitialize)(this.feedBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.feedBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private VisualJS.Web.Forms.FeedBox feedBox1;
        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.Label label2;
        private VisualJS.Web.Forms.FeedBox feedBox2;
    }
}