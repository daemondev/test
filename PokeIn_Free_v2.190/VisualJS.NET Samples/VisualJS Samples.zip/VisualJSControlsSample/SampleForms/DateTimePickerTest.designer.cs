﻿namespace VisualJSControlsSample.SampleForms
{
    partial class DateTimePickerTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DateTimePickerTest));
            this.dateTimePicker1 = new VisualJS.Web.Forms.DateTimePicker();
            this.dtChinese = new VisualJS.Web.Forms.DateTimePicker();
            this.label1 = new VisualJS.Web.Forms.Label();
            this.label2 = new VisualJS.Web.Forms.Label();
            this.dtTurkish = new VisualJS.Web.Forms.DateTimePicker();
            this.label3 = new VisualJS.Web.Forms.Label();
            this.dtGerman = new VisualJS.Web.Forms.DateTimePicker();
            this.lblArabic = new VisualJS.Web.Forms.Label();
            this.dtArabic = new VisualJS.Web.Forms.DateTimePicker();
            this.label4 = new VisualJS.Web.Forms.Label();
            this.label5 = new VisualJS.Web.Forms.Label();
            this.label6 = new VisualJS.Web.Forms.Label();
            this.panel1 = new VisualJS.Web.Forms.Panel();
            this.jButton1 = new VisualJS.Web.Forms.JButton();
            this.lblLongDate = new VisualJS.Web.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.dateTimePicker1.CheckForEmail = false;
            this.dateTimePicker1.ClassName = "";
            this.dateTimePicker1.CustomFontFamilies = "";
            this.dateTimePicker1.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker1.Font = new System.Drawing.Font("Arial", 9F);
            this.dateTimePicker1.Localize = VisualJS.Kernel.Localization.EnglishUS;
            this.dateTimePicker1.Location = new System.Drawing.Point(12, 29);
            this.dateTimePicker1.Mask = "99/99/9999";
            this.dateTimePicker1.MaxDate = new System.DateTime(9999, 12, 31, 23, 59, 59, 999);
            this.dateTimePicker1.MinDate = new System.DateTime(((long)(0)));
            this.dateTimePicker1.MinLength = -1;
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Opacity = 100;
            this.dateTimePicker1.PreventSQLInjection = false;
            this.dateTimePicker1.RegexCheck = "";
            this.dateTimePicker1.Size = new System.Drawing.Size(150, 21);
            this.dateTimePicker1.TabIndex = 14;
            this.dateTimePicker1.Text = "02/26/2012";
            this.dateTimePicker1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.dateTimePicker1.TooltipText = "";
            this.dateTimePicker1.ValidationMessage = "An action is required";
            this.dateTimePicker1.Value = new System.DateTime(2012, 2, 26, 0, 0, 0, 0);
            this.dateTimePicker1.ZOrder = 0;
            this.dateTimePicker1.TextChanged += new System.EventHandler(this.dateTimePicker1_TextChanged);
            // 
            // dtChinese
            // 
            this.dtChinese.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.dtChinese.CheckForEmail = false;
            this.dtChinese.ClassName = "";
            this.dtChinese.CustomFontFamilies = "";
            this.dtChinese.CustomFormat = "MM/dd/yyyy";
            this.dtChinese.Font = new System.Drawing.Font("Arial", 9F);
            this.dtChinese.Localize = VisualJS.Kernel.Localization.Chinese;
            this.dtChinese.Location = new System.Drawing.Point(12, 75);
            this.dtChinese.Mask = "99/99/9999";
            this.dtChinese.MaxDate = new System.DateTime(9999, 12, 31, 23, 59, 59, 999);
            this.dtChinese.MinDate = new System.DateTime(((long)(0)));
            this.dtChinese.MinLength = -1;
            this.dtChinese.Name = "dtChinese";
            this.dtChinese.Opacity = 100;
            this.dtChinese.PreventSQLInjection = false;
            this.dtChinese.RegexCheck = "";
            this.dtChinese.Size = new System.Drawing.Size(150, 21);
            this.dtChinese.TabIndex = 2;
            this.dtChinese.Text = "02/26/2012";
            this.dtChinese.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.dtChinese.TooltipText = "";
            this.dtChinese.ValidationMessage = "An action is required";
            this.dtChinese.Value = new System.DateTime(2012, 2, 26, 0, 0, 0, 0);
            this.dtChinese.ZOrder = 0;
            this.dtChinese.TextChanged += new System.EventHandler(this.dateTimePicker1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 9F);
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(9, 57);
            this.label1.Name = "label1";
            this.label1.Opacity = 100;
            this.label1.Size = new System.Drawing.Size(54, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "Chinese";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.ZOrder = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9F);
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(9, 108);
            this.label2.Name = "label2";
            this.label2.Opacity = 100;
            this.label2.Size = new System.Drawing.Size(48, 15);
            this.label2.TabIndex = 5;
            this.label2.Text = "Turkish";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.ZOrder = 0;
            // 
            // dtTurkish
            // 
            this.dtTurkish.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.dtTurkish.CheckForEmail = false;
            this.dtTurkish.ClassName = "";
            this.dtTurkish.CustomFontFamilies = "";
            this.dtTurkish.CustomFormat = "MM/dd/yyyy";
            this.dtTurkish.Font = new System.Drawing.Font("Arial", 9F);
            this.dtTurkish.Localize = VisualJS.Kernel.Localization.Turkish;
            this.dtTurkish.Location = new System.Drawing.Point(12, 126);
            this.dtTurkish.Mask = "99/99/9999";
            this.dtTurkish.MaxDate = new System.DateTime(9999, 12, 31, 23, 59, 59, 999);
            this.dtTurkish.MinDate = new System.DateTime(((long)(0)));
            this.dtTurkish.MinLength = -1;
            this.dtTurkish.Name = "dtTurkish";
            this.dtTurkish.Opacity = 100;
            this.dtTurkish.PreventSQLInjection = false;
            this.dtTurkish.RegexCheck = "";
            this.dtTurkish.Size = new System.Drawing.Size(150, 21);
            this.dtTurkish.TabIndex = 4;
            this.dtTurkish.Text = "02/26/2012";
            this.dtTurkish.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.dtTurkish.TooltipText = "";
            this.dtTurkish.ValidationMessage = "An action is required";
            this.dtTurkish.Value = new System.DateTime(2012, 2, 26, 20, 11, 3, 800);
            this.dtTurkish.ZOrder = 0;
            this.dtTurkish.TextChanged += new System.EventHandler(this.dateTimePicker1_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ClassName = "";
            this.label3.CustomFontFamilies = "";
            this.label3.Font = new System.Drawing.Font("Arial", 9F);
            this.label3.Image = null;
            this.label3.Location = new System.Drawing.Point(9, 162);
            this.label3.Name = "label3";
            this.label3.Opacity = 100;
            this.label3.Size = new System.Drawing.Size(52, 15);
            this.label3.TabIndex = 7;
            this.label3.Text = "German";
            this.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label3.TooltipText = "";
            this.label3.UseMnemonic = false;
            this.label3.ZOrder = 0;
            // 
            // dtGerman
            // 
            this.dtGerman.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.dtGerman.CheckForEmail = false;
            this.dtGerman.ClassName = "";
            this.dtGerman.CustomFontFamilies = "";
            this.dtGerman.CustomFormat = "MM/dd/yyyy";
            this.dtGerman.Font = new System.Drawing.Font("Arial", 9F);
            this.dtGerman.Localize = VisualJS.Kernel.Localization.German;
            this.dtGerman.Location = new System.Drawing.Point(12, 180);
            this.dtGerman.Mask = "99/99/9999";
            this.dtGerman.MaxDate = new System.DateTime(9999, 12, 31, 23, 59, 59, 999);
            this.dtGerman.MinDate = new System.DateTime(((long)(0)));
            this.dtGerman.MinLength = -1;
            this.dtGerman.Name = "dtGerman";
            this.dtGerman.Opacity = 100;
            this.dtGerman.PreventSQLInjection = false;
            this.dtGerman.RegexCheck = "";
            this.dtGerman.Size = new System.Drawing.Size(150, 21);
            this.dtGerman.TabIndex = 6;
            this.dtGerman.Text = "02/26/2012";
            this.dtGerman.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.dtGerman.TooltipText = "";
            this.dtGerman.ValidationMessage = "An action is required";
            this.dtGerman.Value = new System.DateTime(2012, 2, 26, 20, 11, 3, 800);
            this.dtGerman.ZOrder = 0;
            this.dtGerman.TextChanged += new System.EventHandler(this.dateTimePicker1_TextChanged);
            // 
            // lblArabic
            // 
            this.lblArabic.AutoSize = true;
            this.lblArabic.BackColor = System.Drawing.Color.Transparent;
            this.lblArabic.ClassName = "";
            this.lblArabic.CustomFontFamilies = "";
            this.lblArabic.Font = new System.Drawing.Font("Arial", 9F);
            this.lblArabic.Image = null;
            this.lblArabic.Location = new System.Drawing.Point(9, 210);
            this.lblArabic.Name = "lblArabic";
            this.lblArabic.Opacity = 100;
            this.lblArabic.Size = new System.Drawing.Size(41, 15);
            this.lblArabic.TabIndex = 9;
            this.lblArabic.Text = "Arabic";
            this.lblArabic.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.lblArabic.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.lblArabic.TooltipText = "";
            this.lblArabic.UseMnemonic = false;
            this.lblArabic.ZOrder = 0;
            // 
            // dtArabic
            // 
            this.dtArabic.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.dtArabic.CheckForEmail = false;
            this.dtArabic.ClassName = "";
            this.dtArabic.CustomFontFamilies = "";
            this.dtArabic.CustomFormat = "MM/dd/yyyy";
            this.dtArabic.Font = new System.Drawing.Font("Arial", 9F);
            this.dtArabic.Localize = VisualJS.Kernel.Localization.Arabic;
            this.dtArabic.Location = new System.Drawing.Point(12, 228);
            this.dtArabic.Mask = "99/99/9999";
            this.dtArabic.MaxDate = new System.DateTime(9999, 12, 31, 23, 59, 59, 999);
            this.dtArabic.MinDate = new System.DateTime(((long)(0)));
            this.dtArabic.MinLength = -1;
            this.dtArabic.Name = "dtArabic";
            this.dtArabic.Opacity = 100;
            this.dtArabic.PreventSQLInjection = false;
            this.dtArabic.RegexCheck = "";
            this.dtArabic.Size = new System.Drawing.Size(150, 21);
            this.dtArabic.TabIndex = 8;
            this.dtArabic.Text = "02/26/2012";
            this.dtArabic.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.dtArabic.TooltipText = "";
            this.dtArabic.ValidationMessage = "An action is required";
            this.dtArabic.Value = new System.DateTime(2012, 2, 26, 20, 11, 3, 800);
            this.dtArabic.ZOrder = 0;
            this.dtArabic.TextChanged += new System.EventHandler(this.dateTimePicker1_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ClassName = "";
            this.label4.CustomFontFamilies = "";
            this.label4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Image = null;
            this.label4.Location = new System.Drawing.Point(70, 39);
            this.label4.Name = "label4";
            this.label4.Opacity = 100;
            this.label4.Size = new System.Drawing.Size(342, 15);
            this.label4.TabIndex = 10;
            this.label4.Text = "This sample shows DateTimePicker from JQuery UI Library";
            this.label4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label4.TooltipText = "";
            this.label4.UseMnemonic = false;
            this.label4.ZOrder = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ClassName = "";
            this.label5.CustomFontFamilies = "";
            this.label5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Yellow;
            this.label5.Image = null;
            this.label5.Location = new System.Drawing.Point(17, 15);
            this.label5.Name = "label5";
            this.label5.Opacity = 100;
            this.label5.Size = new System.Drawing.Size(395, 15);
            this.label5.TabIndex = 11;
            this.label5.Text = "VisualJS.NET\'s extensibility allows 3rd party custom JS components";
            this.label5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label5.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label5.TooltipText = "";
            this.label5.UseMnemonic = false;
            this.label5.ZOrder = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.ClassName = "";
            this.label6.CustomFontFamilies = "";
            this.label6.Font = new System.Drawing.Font("Arial", 9F);
            this.label6.Image = null;
            this.label6.Location = new System.Drawing.Point(12, 9);
            this.label6.Name = "label6";
            this.label6.Opacity = 100;
            this.label6.Size = new System.Drawing.Size(66, 15);
            this.label6.TabIndex = 12;
            this.label6.Text = "EnglishUS";
            this.label6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label6.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label6.TooltipText = "";
            this.label6.UseMnemonic = false;
            this.label6.ZOrder = 0;
            // 
            // panel1
            // 
            this.panel1.ApplicationWideResource = true;
            this.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.panel1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.panel1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(153)))));
            this.panel1.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.panel1.BackgroundImagePosition = "";
            this.panel1.BackgroundImageQuality = ((short)(80));
            this.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.panel1.ClassName = "";
            this.panel1.ClientID = null;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.CustomFontFamilies = "";
            this.panel1.Font = new System.Drawing.Font("Arial", 9F);
            this.panel1.HTML = "";
            this.panel1.ImageLocation = "";
            this.panel1.Location = new System.Drawing.Point(185, 29);
            this.panel1.Name = "panel1";
            this.panel1.Opacity = 60;
            this.panel1.Size = new System.Drawing.Size(433, 69);
            this.panel1.TabIndex = 13;
            this.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.panel1.TooltipText = "";
            this.panel1.VerticalGradient = true;
            this.panel1.ZOrder = 0;
            // 
            // jButton1
            // 
            this.jButton1.ApplicationWideResource = true;
            this.jButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton1.BackgroundImagePosition = "";
            this.jButton1.BackgroundImageQuality = ((short)(80));
            this.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton1.ClassName = "";
            this.jButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton1.CustomFontFamilies = "";
            this.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton1.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton1.Icon = null;
            this.jButton1.IconURL = "";
            this.jButton1.Image = null;
            this.jButton1.ImageLocation = "";
            this.jButton1.Location = new System.Drawing.Point(185, 172);
            this.jButton1.Name = "jButton1";
            this.jButton1.Opacity = 100;
            this.jButton1.Size = new System.Drawing.Size(149, 36);
            this.jButton1.TabIndex = 15;
            this.jButton1.Text = "Get Long Date String";
            this.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton1.TooltipText = "";
            this.jButton1.UseVisualStyleBackColor = false;
            this.jButton1.ValidationFailedMessage = "Validation failed!";
            this.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton1.VerticalGradient = true;
            this.jButton1.ZOrder = 0;
            this.jButton1.Click += new System.EventHandler(this.jButton1_Click);
            // 
            // lblLongDate
            // 
            this.lblLongDate.AutoSize = true;
            this.lblLongDate.BackColor = System.Drawing.Color.Transparent;
            this.lblLongDate.ClassName = "";
            this.lblLongDate.CustomFontFamilies = "";
            this.lblLongDate.Font = new System.Drawing.Font("Arial", 9F);
            this.lblLongDate.Image = null;
            this.lblLongDate.Location = new System.Drawing.Point(345, 183);
            this.lblLongDate.Name = "lblLongDate";
            this.lblLongDate.Opacity = 100;
            this.lblLongDate.Size = new System.Drawing.Size(16, 15);
            this.lblLongDate.TabIndex = 16;
            this.lblLongDate.Text = "...";
            this.lblLongDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.lblLongDate.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.lblLongDate.TooltipText = "";
            this.lblLongDate.UseMnemonic = false;
            this.lblLongDate.ZOrder = 0;
            // 
            // DateTimePickerTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(630, 270);
            this.Controls.Add(this.lblLongDate);
            this.Controls.Add(this.jButton1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblArabic);
            this.Controls.Add(this.dtArabic);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dtGerman);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtTurkish);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtChinese);
            this.Controls.Add(this.dateTimePicker1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DateTimePickerTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "DateTimePicker Demo";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private VisualJS.Web.Forms.DateTimePicker dateTimePicker1;
        private VisualJS.Web.Forms.DateTimePicker dtChinese;
        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.Label label2;
        private VisualJS.Web.Forms.DateTimePicker dtTurkish;
        private VisualJS.Web.Forms.Label label3;
        private VisualJS.Web.Forms.DateTimePicker dtGerman;
        private VisualJS.Web.Forms.Label lblArabic;
        private VisualJS.Web.Forms.DateTimePicker dtArabic;
        private VisualJS.Web.Forms.Label label4;
        private VisualJS.Web.Forms.Label label5;
        private VisualJS.Web.Forms.Label label6;
        private VisualJS.Web.Forms.Panel panel1;
        private VisualJS.Web.Forms.JButton jButton1;
        private VisualJS.Web.Forms.Label lblLongDate;
    }
}