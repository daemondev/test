﻿namespace VisualJSControlsSample.SampleForms
{
    partial class ChartTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChartTest));
            this.pnlChart1 = new VisualJS.Web.Forms.Panel();
            this.label1 = new VisualJS.Web.Forms.Label();
            this.label2 = new VisualJS.Web.Forms.Label();
            this.pnlChart2 = new VisualJS.Web.Forms.Panel();
            this.label3 = new VisualJS.Web.Forms.Label();
            this.SuspendLayout();
            // 
            // pnlChart1
            // 
            this.pnlChart1.ApplicationWideResource = true;
            this.pnlChart1.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.pnlChart1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.pnlChart1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.pnlChart1.BackColor = System.Drawing.Color.White;
            this.pnlChart1.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(255)))), ((int)(((byte)(238)))));
            this.pnlChart1.BackgroundImagePosition = "";
            this.pnlChart1.BackgroundImageQuality = ((short)(80));
            this.pnlChart1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.pnlChart1.BorderColor = System.Drawing.Color.Black;
            this.pnlChart1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid;
            this.pnlChart1.ClassName = "";
            this.pnlChart1.ClientID = null;
            this.pnlChart1.CustomFontFamilies = "";
            this.pnlChart1.Font = new System.Drawing.Font("Arial", 9F);
            this.pnlChart1.HTML = "";
            this.pnlChart1.ImageLocation = "";
            this.pnlChart1.Location = new System.Drawing.Point(12, 28);
            this.pnlChart1.Name = "pnlChart1";
            this.pnlChart1.Opacity = 100;
            this.pnlChart1.Size = new System.Drawing.Size(366, 241);
            this.pnlChart1.TabIndex = 0;
            this.pnlChart1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.pnlChart1.TooltipText = "";
            this.pnlChart1.VerticalGradient = true;
            this.pnlChart1.ZOrder = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(9, 10);
            this.label1.Name = "label1";
            this.label1.Opacity = 100;
            this.label1.Size = new System.Drawing.Size(197, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Full interactive Line && Bar Chart.";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.ZOrder = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(396, 10);
            this.label2.Name = "label2";
            this.label2.Opacity = 100;
            this.label2.Size = new System.Drawing.Size(250, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Pie Chart (Click one of the pie areas below)";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.ZOrder = 0;
            // 
            // pnlChart2
            // 
            this.pnlChart2.ApplicationWideResource = true;
            this.pnlChart2.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.pnlChart2.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.pnlChart2.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.pnlChart2.BackColor = System.Drawing.Color.White;
            this.pnlChart2.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(255)))), ((int)(((byte)(238)))));
            this.pnlChart2.BackgroundImagePosition = "";
            this.pnlChart2.BackgroundImageQuality = ((short)(80));
            this.pnlChart2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.pnlChart2.BorderColor = System.Drawing.Color.Black;
            this.pnlChart2.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid;
            this.pnlChart2.ClassName = "";
            this.pnlChart2.ClientID = null;
            this.pnlChart2.CustomFontFamilies = "";
            this.pnlChart2.Font = new System.Drawing.Font("Arial", 9F);
            this.pnlChart2.HTML = "";
            this.pnlChart2.ImageLocation = "";
            this.pnlChart2.Location = new System.Drawing.Point(399, 28);
            this.pnlChart2.Name = "pnlChart2";
            this.pnlChart2.Opacity = 100;
            this.pnlChart2.Size = new System.Drawing.Size(366, 241);
            this.pnlChart2.TabIndex = 2;
            this.pnlChart2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.pnlChart2.TooltipText = "";
            this.pnlChart2.VerticalGradient = true;
            this.pnlChart2.ZOrder = 0;
            this.pnlChart2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlChart2_MouseDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ClassName = "";
            this.label3.CustomFontFamilies = "";
            this.label3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Image = null;
            this.label3.Location = new System.Drawing.Point(12, 280);
            this.label3.Name = "label3";
            this.label3.Opacity = 100;
            this.label3.Size = new System.Drawing.Size(334, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Column, Doughnut Charts. Flow Support. User Interaction. ";
            this.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label3.TooltipText = "";
            this.label3.UseMnemonic = false;
            this.label3.ZOrder = 0;
            // 
            // ChartTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(781, 304);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pnlChart2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pnlChart1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ChartTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chart Demo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private VisualJS.Web.Forms.Panel pnlChart1;
        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.Label label2;
        private VisualJS.Web.Forms.Panel pnlChart2;
        private VisualJS.Web.Forms.Label label3;
    }
}