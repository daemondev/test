﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing; 
using VisualJS;
using VisualJS.Web.Forms;
using System.Linq;
using System.Text;

namespace VisualJSControlsSample.SampleForms
{
    using VisualJS.Charts;

    public partial class ChartTest : VisualJS.Web.Forms.Form
    {

#region Constructors
        public ChartTest()
        {
            InitializeComponent();
            AfterInitialization();
        } 

        //Use the below constructor if you create the instance of this Form object other than the active Thread
        //otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        public ChartTest(string clientId): base(clientId)
        {
            InitializeComponent(); 
            AfterInitialization();
        }
#endregion

        //Use below method for the tasks after the initialization of the Form
        void  AfterInitialization()
        {
            DrawChart1();
            DrawChart2();
        }

        Chart chart1, chart2;
        void DrawChart1()
        {
            chart1 = new Chart(pnlChart1);
            Chart cs = chart1;
            cs["Series1"].Items.Add(new ChartData(1, 1));
            cs["Series1"].Items.Add(new ChartData(2, 2));
            cs["Series1"].Items.Add(new ChartData(3, 3));
            cs["Series1"][SerieType.Bar].Show = true;
            cs["Series1"][SerieType.Bar].BarWidth = 0.4f;
            cs["Series1"][SerieType.Point].Show = true;

            cs["Series2"].Items.Add(new ChartData(1, 1.4));
            cs["Series2"].Items.Add(new ChartData(2, 2.1));
            cs["Series2"].Items.Add(new ChartData(3, 4));
            cs.XAxis.FormatterFunction = "function(v){return '$ ' + v;}";

            cs["Series2"][SerieType.Line].Show = true;
            cs["Series2"][SerieType.Point].Show = true;
            cs["Series2"].Label = "Series2";
            cs["Series2"].LineColor = Color.Orange;

            cs.BackgroundColor = Color.White;
            cs.BackgroundColorEnd = Color.YellowGreen;
            cs.Zoom = true;
            cs.Navigation = true;

            cs.Draw();
        }

        void DrawChart2()
        {
            chart2 = new Chart(pnlChart2);
            Chart cs = chart2;
            cs["Series2"].Items.Add(new ChartData(100, "Apple"));
            cs["Series2"].Items.Add(new ChartData(60, "Orange"));
            cs["Series2"].Items.Add(new ChartData(140, "Pineapple"));
            cs["Series2"][SerieType.Pie].PieLabelFormatter = "function(label, value, percent){ return label+'<br/>'+Math.round(percent)+'%';} ";
            cs["Series2"][SerieType.Pie].Show = true;
            cs.BackgroundColor = Color.White;
            cs.BackgroundColorEnd = Color.Blue;
            cs.ShowLegends = false;
            cs.Draw();
        }

        private void pnlChart2_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            string sname = chart2.GetClickedSerieName();
            int index = chart2.GetClickedPointIndex();
            MessageBox.Show("You have clicked <font color='blue'>" +
            sname + "</font>, <font color='red'>" + chart2[sname].Items[index].PieLabel +"</font>", this);
        }
    }
}