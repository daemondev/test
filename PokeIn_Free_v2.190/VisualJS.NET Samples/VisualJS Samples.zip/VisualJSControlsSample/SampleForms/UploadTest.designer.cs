﻿namespace VisualJSControlsSample.SampleForms
{
    partial class UploadTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UploadTest));
            this.uploadFile1 = new VisualJS.Web.Forms.UploadFile();
            this.jButton1 = new VisualJS.Web.Forms.JButton();
            this.pictureBox1 = new VisualJS.Web.Forms.PictureBox();
            this.label1 = new VisualJS.Web.Forms.Label();
            this.label2 = new VisualJS.Web.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // uploadFile1
            // 
            this.uploadFile1.BackColor = System.Drawing.Color.White;
            this.uploadFile1.FailText = "Failed!";
            this.uploadFile1.FileNotSelectedMessage = "Select an image file";
            this.uploadFile1.FileTypes = "*.jpg;*.gif;*.png";
            this.uploadFile1.FinalizeText = "Finishing..";
            this.uploadFile1.InvalidFileTypeMessage = "Invalid File Type. Only JPG, GIF or PNG";
            this.uploadFile1.Location = new System.Drawing.Point(249, 33);
            this.uploadFile1.Name = "uploadFile1";
            this.uploadFile1.Size = new System.Drawing.Size(226, 23);
            this.uploadFile1.SuccessText = "File Uploaded";
            this.uploadFile1.TabIndex = 1;
            this.uploadFile1.UploadText = "Uploading..";
            this.uploadFile1.ZOrder = 0;
            this.uploadFile1.OnUpload += new VisualJS.Web.Forms.UploadFile.UploadDelegate(this.uploadFile1_OnUpload);
            // 
            // jButton1
            // 
            this.jButton1.ApplicationWideResource = true;
            this.jButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton1.BackgroundImagePosition = "";
            this.jButton1.BackgroundImageQuality = ((short)(80));
            this.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton1.ClassName = "";
            this.jButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton1.CustomFontFamilies = "";
            this.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton1.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton1.Icon = global::VisualJSControlsSample.Properties.Resources.uploadfile;
            this.jButton1.IconURL = "";
            this.jButton1.Image = null;
            this.jButton1.ImageLocation = "";
            this.jButton1.Location = new System.Drawing.Point(334, 62);
            this.jButton1.Name = "jButton1";
            this.jButton1.Opacity = 100;
            this.jButton1.PreventMultipleClicks = true;
            this.jButton1.Size = new System.Drawing.Size(141, 29);
            this.jButton1.TabIndex = 4;
            this.jButton1.Text = "Update The Image";
            this.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton1.TooltipText = "";
            this.jButton1.UseVisualStyleBackColor = false;
            this.jButton1.ValidationFailedMessage = "Validation failed!";
            this.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnForm;
            this.jButton1.VerticalGradient = true;
            this.jButton1.ZOrder = 0;
            this.jButton1.Click += new System.EventHandler(this.jButton1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.ApplicationWideResource = true;
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.ClassName = "";
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Font = new System.Drawing.Font("Arial", 9F);
            this.pictureBox1.Image = null;
            this.pictureBox1.ImageLocation = "";
            this.pictureBox1.ImageQuality = ((short)(80));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Opacity = 100;
            this.pictureBox1.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.JPG;
            this.pictureBox1.Size = new System.Drawing.Size(231, 181);
            this.pictureBox1.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.pictureBox1.TooltipText = "";
            this.pictureBox1.ZOrder = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 9F);
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(249, 15);
            this.label1.Name = "label1";
            this.label1.Opacity = 100;
            this.label1.Size = new System.Drawing.Size(121, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "Upload an image file";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.ZOrder = 0;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9F);
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(277, 119);
            this.label2.Name = "label2";
            this.label2.Opacity = 100;
            this.label2.Size = new System.Drawing.Size(148, 46);
            this.label2.TabIndex = 3;
            this.label2.Text = "This demo only accepts gif, png and jpg types under 1mb";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.ZOrder = 0;
            // 
            // UploadTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(487, 208);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.jButton1);
            this.Controls.Add(this.uploadFile1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "UploadTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "Upload Demo";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private VisualJS.Web.Forms.PictureBox pictureBox1;
        private VisualJS.Web.Forms.UploadFile uploadFile1;
        private VisualJS.Web.Forms.JButton jButton1;
        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.Label label2;
    }
}