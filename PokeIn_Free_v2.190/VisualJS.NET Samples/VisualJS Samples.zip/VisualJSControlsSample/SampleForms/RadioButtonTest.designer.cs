﻿namespace VisualJSControlsSample.SampleForms
{
    partial class RadioButtonTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RadioButtonTest));
            this.panel1 = new VisualJS.Web.Forms.Panel();
            this.label1 = new VisualJS.Web.Forms.Label();
            this.pnlColor = new VisualJS.Web.Forms.Panel();
            this.rdBlue = new VisualJS.Web.Forms.RadioButton();
            this.rdGreen = new VisualJS.Web.Forms.RadioButton();
            this.rdRed = new VisualJS.Web.Forms.RadioButton();
            this.panel2 = new VisualJS.Web.Forms.Panel();
            this.label2 = new VisualJS.Web.Forms.Label();
            this.pnlColor2 = new VisualJS.Web.Forms.Panel();
            this.radioButton1 = new VisualJS.Web.Forms.RadioButton();
            this.radioButton2 = new VisualJS.Web.Forms.RadioButton();
            this.radioButton3 = new VisualJS.Web.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.ApplicationWideResource = true;
            this.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.panel1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.panel1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackColorEnd = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImagePosition = "";
            this.panel1.BackgroundImageQuality = ((short)(80));
            this.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.panel1.BorderColor = System.Drawing.Color.Black;
            this.panel1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Dotted;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.ClassName = "";
            this.panel1.ClientID = null;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pnlColor);
            this.panel1.Controls.Add(this.rdBlue);
            this.panel1.Controls.Add(this.rdGreen);
            this.panel1.Controls.Add(this.rdRed);
            this.panel1.CustomFontFamilies = "";
            this.panel1.Font = new System.Drawing.Font("Arial", 9F);
            this.panel1.HTML = "";
            this.panel1.ImageLocation = "";
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Opacity = 100;
            this.panel1.Size = new System.Drawing.Size(268, 100);
            this.panel1.TabIndex = 0;
            this.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.panel1.TooltipText = "";
            this.panel1.VerticalGradient = true;
            this.panel1.ZOrder = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 9F);
            this.label1.ForeColor = System.Drawing.Color.Silver;
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(148, 78);
            this.label1.Name = "label1";
            this.label1.Opacity = 100;
            this.label1.Size = new System.Drawing.Size(112, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "RadioButton Group";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.ZOrder = 0;
            // 
            // pnlColor
            // 
            this.pnlColor.ApplicationWideResource = true;
            this.pnlColor.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.pnlColor.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.pnlColor.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.pnlColor.BackColor = System.Drawing.Color.White;
            this.pnlColor.BackColorEnd = System.Drawing.Color.Transparent;
            this.pnlColor.BackgroundImagePosition = "";
            this.pnlColor.BackgroundImageQuality = ((short)(80));
            this.pnlColor.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.pnlColor.BorderColor = System.Drawing.Color.Gray;
            this.pnlColor.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid;
            this.pnlColor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlColor.ClassName = "";
            this.pnlColor.ClientID = null;
            this.pnlColor.CustomFontFamilies = "";
            this.pnlColor.Font = new System.Drawing.Font("Arial", 9F);
            this.pnlColor.HTML = "";
            this.pnlColor.ImageLocation = "";
            this.pnlColor.Location = new System.Drawing.Point(161, 28);
            this.pnlColor.Name = "pnlColor";
            this.pnlColor.Opacity = 100;
            this.pnlColor.Size = new System.Drawing.Size(74, 39);
            this.pnlColor.TabIndex = 6;
            this.pnlColor.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.pnlColor.TooltipText = "";
            this.pnlColor.VerticalGradient = true;
            this.pnlColor.ZOrder = 0;
            // 
            // rdBlue
            // 
            this.rdBlue.BackColor = System.Drawing.Color.Transparent;
            this.rdBlue.ClassName = "";
            this.rdBlue.CustomFontFamilies = "";
            this.rdBlue.Font = new System.Drawing.Font("Arial", 9F);
            this.rdBlue.Image = null;
            this.rdBlue.Location = new System.Drawing.Point(20, 62);
            this.rdBlue.Name = "rdBlue";
            this.rdBlue.Opacity = 100;
            this.rdBlue.Size = new System.Drawing.Size(72, 19);
            this.rdBlue.TabIndex = 4;
            this.rdBlue.TabStop = true;
            this.rdBlue.Text = "Blue";
            this.rdBlue.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.rdBlue.TooltipText = "";
            this.rdBlue.UseMnemonic = false;
            this.rdBlue.UseVisualStyleBackColor = false;
            this.rdBlue.ZOrder = 0;
            this.rdBlue.CheckedChanged += new System.EventHandler(this.rdRed_CheckedChanged);
            // 
            // rdGreen
            // 
            this.rdGreen.BackColor = System.Drawing.Color.Transparent;
            this.rdGreen.ClassName = "";
            this.rdGreen.CustomFontFamilies = "";
            this.rdGreen.Font = new System.Drawing.Font("Arial", 9F);
            this.rdGreen.Image = null;
            this.rdGreen.Location = new System.Drawing.Point(20, 37);
            this.rdGreen.Name = "rdGreen";
            this.rdGreen.Opacity = 100;
            this.rdGreen.Size = new System.Drawing.Size(72, 19);
            this.rdGreen.TabIndex = 2;
            this.rdGreen.TabStop = true;
            this.rdGreen.Text = "Green";
            this.rdGreen.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.rdGreen.TooltipText = "";
            this.rdGreen.UseMnemonic = false;
            this.rdGreen.UseVisualStyleBackColor = false;
            this.rdGreen.ZOrder = 0;
            this.rdGreen.CheckedChanged += new System.EventHandler(this.rdRed_CheckedChanged);
            // 
            // rdRed
            // 
            this.rdRed.BackColor = System.Drawing.Color.Transparent;
            this.rdRed.ClassName = "";
            this.rdRed.CustomFontFamilies = "";
            this.rdRed.Font = new System.Drawing.Font("Arial", 9F);
            this.rdRed.Image = null;
            this.rdRed.Location = new System.Drawing.Point(20, 12);
            this.rdRed.Name = "rdRed";
            this.rdRed.Opacity = 100;
            this.rdRed.Size = new System.Drawing.Size(72, 19);
            this.rdRed.TabIndex = 5;
            this.rdRed.TabStop = true;
            this.rdRed.Text = "Red";
            this.rdRed.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.rdRed.TooltipText = "";
            this.rdRed.UseMnemonic = false;
            this.rdRed.UseVisualStyleBackColor = false;
            this.rdRed.ZOrder = 0;
            this.rdRed.CheckedChanged += new System.EventHandler(this.rdRed_CheckedChanged);
            // 
            // panel2
            // 
            this.panel2.ApplicationWideResource = true;
            this.panel2.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.panel2.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.panel2.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BackColorEnd = System.Drawing.Color.Transparent;
            this.panel2.BackgroundImagePosition = "";
            this.panel2.BackgroundImageQuality = ((short)(80));
            this.panel2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.panel2.BorderColor = System.Drawing.Color.Black;
            this.panel2.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Dotted;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.ClassName = "";
            this.panel2.ClientID = null;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.pnlColor2);
            this.panel2.Controls.Add(this.radioButton1);
            this.panel2.Controls.Add(this.radioButton2);
            this.panel2.Controls.Add(this.radioButton3);
            this.panel2.CustomFontFamilies = "";
            this.panel2.Font = new System.Drawing.Font("Arial", 9F);
            this.panel2.HTML = "";
            this.panel2.ImageLocation = "";
            this.panel2.Location = new System.Drawing.Point(12, 118);
            this.panel2.Name = "panel2";
            this.panel2.Opacity = 100;
            this.panel2.Size = new System.Drawing.Size(268, 100);
            this.panel2.TabIndex = 1;
            this.panel2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.panel2.TooltipText = "";
            this.panel2.VerticalGradient = true;
            this.panel2.ZOrder = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9F);
            this.label2.ForeColor = System.Drawing.Color.Silver;
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(148, 78);
            this.label2.Name = "label2";
            this.label2.Opacity = 100;
            this.label2.Size = new System.Drawing.Size(112, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "RadioButton Group";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.ZOrder = 0;
            // 
            // pnlColor2
            // 
            this.pnlColor2.ApplicationWideResource = true;
            this.pnlColor2.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.pnlColor2.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.pnlColor2.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.pnlColor2.BackColor = System.Drawing.Color.White;
            this.pnlColor2.BackColorEnd = System.Drawing.Color.Transparent;
            this.pnlColor2.BackgroundImagePosition = "";
            this.pnlColor2.BackgroundImageQuality = ((short)(80));
            this.pnlColor2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.pnlColor2.BorderColor = System.Drawing.Color.Gray;
            this.pnlColor2.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Double;
            this.pnlColor2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlColor2.ClassName = "";
            this.pnlColor2.ClientID = null;
            this.pnlColor2.CustomFontFamilies = "";
            this.pnlColor2.Font = new System.Drawing.Font("Arial", 9F);
            this.pnlColor2.HTML = "";
            this.pnlColor2.ImageLocation = "";
            this.pnlColor2.Location = new System.Drawing.Point(161, 28);
            this.pnlColor2.Name = "pnlColor2";
            this.pnlColor2.Opacity = 100;
            this.pnlColor2.Size = new System.Drawing.Size(74, 39);
            this.pnlColor2.TabIndex = 6;
            this.pnlColor2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.pnlColor2.TooltipText = "";
            this.pnlColor2.VerticalGradient = true;
            this.pnlColor2.ZOrder = 0;
            // 
            // radioButton1
            // 
            this.radioButton1.BackColor = System.Drawing.Color.Transparent;
            this.radioButton1.ClassName = "";
            this.radioButton1.CustomFontFamilies = "";
            this.radioButton1.Font = new System.Drawing.Font("Arial", 9F);
            this.radioButton1.Image = null;
            this.radioButton1.Location = new System.Drawing.Point(20, 62);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Opacity = 100;
            this.radioButton1.Size = new System.Drawing.Size(72, 19);
            this.radioButton1.TabIndex = 4;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Olive";
            this.radioButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.radioButton1.TooltipText = "";
            this.radioButton1.UseMnemonic = false;
            this.radioButton1.UseVisualStyleBackColor = false;
            this.radioButton1.ZOrder = 0;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.BackColor = System.Drawing.Color.Transparent;
            this.radioButton2.ClassName = "";
            this.radioButton2.CustomFontFamilies = "";
            this.radioButton2.Font = new System.Drawing.Font("Arial", 9F);
            this.radioButton2.Image = null;
            this.radioButton2.Location = new System.Drawing.Point(20, 37);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Opacity = 100;
            this.radioButton2.Size = new System.Drawing.Size(72, 19);
            this.radioButton2.TabIndex = 2;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Brown";
            this.radioButton2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.radioButton2.TooltipText = "";
            this.radioButton2.UseMnemonic = false;
            this.radioButton2.UseVisualStyleBackColor = false;
            this.radioButton2.ZOrder = 0;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.BackColor = System.Drawing.Color.Transparent;
            this.radioButton3.ClassName = "";
            this.radioButton3.CustomFontFamilies = "";
            this.radioButton3.Font = new System.Drawing.Font("Arial", 9F);
            this.radioButton3.Image = null;
            this.radioButton3.Location = new System.Drawing.Point(20, 12);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Opacity = 100;
            this.radioButton3.Size = new System.Drawing.Size(72, 19);
            this.radioButton3.TabIndex = 5;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Orange";
            this.radioButton3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.radioButton3.TooltipText = "";
            this.radioButton3.UseMnemonic = false;
            this.radioButton3.UseVisualStyleBackColor = false;
            this.radioButton3.ZOrder = 0;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // RadioButtonTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(296, 230);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RadioButtonTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "RadioButton Demo";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private VisualJS.Web.Forms.Panel panel1;
        private VisualJS.Web.Forms.RadioButton rdBlue;
        private VisualJS.Web.Forms.RadioButton rdGreen;
        private VisualJS.Web.Forms.RadioButton rdRed;
        private VisualJS.Web.Forms.Panel pnlColor;
        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.Panel panel2;
        private VisualJS.Web.Forms.Label label2;
        private VisualJS.Web.Forms.Panel pnlColor2;
        private VisualJS.Web.Forms.RadioButton radioButton1;
        private VisualJS.Web.Forms.RadioButton radioButton2;
        private VisualJS.Web.Forms.RadioButton radioButton3;
    }
}