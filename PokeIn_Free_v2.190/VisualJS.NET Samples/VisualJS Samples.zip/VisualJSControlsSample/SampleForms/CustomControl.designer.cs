﻿namespace VisualJSControlsSample.SampleForms
{
    partial class CustomControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomControl));
            this.myCustomControl1 = new VisualJSControlsSample.CustomControl.MyCustomControl();
            this.SuspendLayout();
            // 
            // myCustomControl1
            // 
            this.myCustomControl1.ApplicationWideResource = true;
            this.myCustomControl1.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.myCustomControl1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.myCustomControl1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.myCustomControl1.BackColor = System.Drawing.Color.Gray;
            this.myCustomControl1.BackColorEnd = System.Drawing.Color.Transparent;
            this.myCustomControl1.BackgroundImagePosition = "";
            this.myCustomControl1.BackgroundImageQuality = ((short)(80));
            this.myCustomControl1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.myCustomControl1.BorderColor = System.Drawing.Color.Black;
            this.myCustomControl1.BorderLineStyle = VisualJS.Web.Forms.UserControl.ClientBorderStyle.Solid;
            this.myCustomControl1.ClassName = "";
            this.myCustomControl1.ClientID = null;
            this.myCustomControl1.CustomFontFamilies = "";
            this.myCustomControl1.Font = new System.Drawing.Font("Arial", 9F);
            this.myCustomControl1.HTML = "";
            this.myCustomControl1.ImageLocation = "";
            this.myCustomControl1.Location = new System.Drawing.Point(30, 46);
            this.myCustomControl1.Name = "myCustomControl1";
            this.myCustomControl1.Opacity = 100;
            this.myCustomControl1.Size = new System.Drawing.Size(249, 35);
            this.myCustomControl1.TabIndex = 0;
            this.myCustomControl1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.myCustomControl1.TooltipText = "";
            this.myCustomControl1.VerticalGradient = true;
            this.myCustomControl1.ZOrder = 0;
            // 
            // CustomControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(325, 139);
            this.Controls.Add(this.myCustomControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CustomControl";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "CustomControl";
            this.ResumeLayout(false);

        }

        #endregion

        private VisualJSControlsSample.CustomControl.MyCustomControl myCustomControl1;
    }
}