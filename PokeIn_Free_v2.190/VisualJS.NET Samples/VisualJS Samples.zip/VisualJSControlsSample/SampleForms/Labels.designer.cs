﻿namespace VisualJSControlsSample.SampleForms
{
    partial class Labels
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Labels));
            this.label1 = new VisualJS.Web.Forms.Label();
            this.label2 = new VisualJS.Web.Forms.Label();
            this.label3 = new VisualJS.Web.Forms.Label();
            this.label4 = new VisualJS.Web.Forms.Label();
            this.label5 = new VisualJS.Web.Forms.Label();
            this.label6 = new VisualJS.Web.Forms.Label();
            this.linkLabel1 = new VisualJS.Web.Forms.LinkLabel();
            this.linkLabel2 = new VisualJS.Web.Forms.LinkLabel();
            this.linkLabel3 = new VisualJS.Web.Forms.LinkLabel();
            this.linkLabel4 = new VisualJS.Web.Forms.LinkLabel();
            this.linkLabel5 = new VisualJS.Web.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 9F);
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Opacity = 100;
            this.label1.Size = new System.Drawing.Size(106, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Normal Text Label";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.ZOrder = 0;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9F);
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(12, 33);
            this.label2.Name = "label2";
            this.label2.Opacity = 100;
            this.label2.Size = new System.Drawing.Size(184, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Normal Text Label with <font color=\'#b00000\'>HTML</font>";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.ZOrder = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ClassName = "";
            this.label3.CustomFontFamilies = "Tahoma,Verdana";
            this.label3.Font = new System.Drawing.Font("Arial", 9F);
            this.label3.Image = null;
            this.label3.Location = new System.Drawing.Point(12, 57);
            this.label3.Name = "label3";
            this.label3.Opacity = 100;
            this.label3.Size = new System.Drawing.Size(256, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Normal Text Label with Custom Font Families";
            this.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label3.TooltipText = "";
            this.label3.UseMnemonic = false;
            this.label3.ZOrder = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Gold;
            this.label4.ClassName = "";
            this.label4.CustomFontFamilies = "";
            this.label4.Font = new System.Drawing.Font("Arial", 9F);
            this.label4.Image = null;
            this.label4.Location = new System.Drawing.Point(12, 81);
            this.label4.Name = "label4";
            this.label4.Opacity = 100;
            this.label4.Size = new System.Drawing.Size(233, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Normal Text Label with Background Color";
            this.label4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label4.TooltipText = "";
            this.label4.UseMnemonic = false;
            this.label4.ZOrder = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Gold;
            this.label5.ClassName = "";
            this.label5.CustomFontFamilies = "";
            this.label5.Font = new System.Drawing.Font("Arial", 9F);
            this.label5.Image = null;
            this.label5.Location = new System.Drawing.Point(12, 105);
            this.label5.Name = "label5";
            this.label5.Opacity = 70;
            this.label5.Size = new System.Drawing.Size(287, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Normal Text Label with Background Color & Opacity";
            this.label5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label5.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label5.TooltipText = "";
            this.label5.UseMnemonic = false;
            this.label5.ZOrder = 0;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Orange;
            this.label6.ClassName = "";
            this.label6.CustomFontFamilies = "";
            this.label6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label6.Font = new System.Drawing.Font("Arial", 9F);
            this.label6.Image = null;
            this.label6.Location = new System.Drawing.Point(0, 138);
            this.label6.Name = "label6";
            this.label6.Opacity = 100;
            this.label6.Size = new System.Drawing.Size(626, 18);
            this.label6.TabIndex = 5;
            this.label6.Text = "Docked Text Label with Background Color";
            this.label6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label6.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label6.TooltipText = "";
            this.label6.UseMnemonic = false;
            this.label6.ZOrder = 0;
            // 
            // linkLabel1
            // 
            this.linkLabel1.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel1.ClassName = "";
            this.linkLabel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel1.CustomFontFamilies = "";
            this.linkLabel1.DisabledLinkColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.linkLabel1.Font = new System.Drawing.Font("Arial", 9F);
            this.linkLabel1.HoverLinkColor = System.Drawing.Color.Orange;
            this.linkLabel1.Image = null;
            this.linkLabel1.LinkArea = new System.Windows.Forms.LinkArea(0, 26);
            this.linkLabel1.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel1.Location = new System.Drawing.Point(394, 9);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Opacity = 100;
            this.linkLabel1.Size = new System.Drawing.Size(151, 15);
            this.linkLabel1.TabIndex = 6;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Target = VisualJS.Web.Forms.LinkLabel.URLOpen.NewWindow;
            this.linkLabel1.TargetURL = "http://www.visualjs.net";
            this.linkLabel1.Text = "Link Label with URL target";
            this.linkLabel1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.linkLabel1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.linkLabel1.TooltipText = "";
            this.linkLabel1.UseMnemonic = false;
            this.linkLabel1.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(0)))), ((int)(((byte)(128)))));
            this.linkLabel1.ZOrder = 0;
            // 
            // linkLabel2
            // 
            this.linkLabel2.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel2.ClassName = "";
            this.linkLabel2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel2.CustomFontFamilies = "";
            this.linkLabel2.DisabledLinkColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.linkLabel2.Font = new System.Drawing.Font("Arial", 9F);
            this.linkLabel2.HoverLinkColor = System.Drawing.Color.Orange;
            this.linkLabel2.Image = null;
            this.linkLabel2.LinkArea = new System.Windows.Forms.LinkArea(0, 34);
            this.linkLabel2.LinkColor = System.Drawing.Color.OrangeRed;
            this.linkLabel2.Location = new System.Drawing.Point(394, 33);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Opacity = 100;
            this.linkLabel2.Size = new System.Drawing.Size(190, 15);
            this.linkLabel2.TabIndex = 7;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Target = VisualJS.Web.Forms.LinkLabel.URLOpen.NewWindow;
            this.linkLabel2.TargetURL = "";
            this.linkLabel2.Text = "Link Label with Server Click Event";
            this.linkLabel2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.linkLabel2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.linkLabel2.TooltipText = "";
            this.linkLabel2.UseMnemonic = false;
            this.linkLabel2.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(0)))), ((int)(((byte)(128)))));
            this.linkLabel2.ZOrder = 0;
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // linkLabel3
            // 
            this.linkLabel3.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel3.ClassName = "";
            this.linkLabel3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel3.CustomFontFamilies = "";
            this.linkLabel3.DisabledLinkColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.linkLabel3.Enabled = false;
            this.linkLabel3.Font = new System.Drawing.Font("Arial", 9F);
            this.linkLabel3.HoverLinkColor = System.Drawing.Color.Orange;
            this.linkLabel3.Image = null;
            this.linkLabel3.LinkArea = new System.Windows.Forms.LinkArea(0, 19);
            this.linkLabel3.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel3.Location = new System.Drawing.Point(394, 57);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Opacity = 100;
            this.linkLabel3.Size = new System.Drawing.Size(117, 15);
            this.linkLabel3.TabIndex = 8;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Target = VisualJS.Web.Forms.LinkLabel.URLOpen.NewWindow;
            this.linkLabel3.TargetURL = "";
            this.linkLabel3.Text = "Disabled Link Label";
            this.linkLabel3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.linkLabel3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.linkLabel3.TooltipText = "";
            this.linkLabel3.UseMnemonic = false;
            this.linkLabel3.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(0)))), ((int)(((byte)(128)))));
            this.linkLabel3.ZOrder = 0;
            // 
            // linkLabel4
            // 
            this.linkLabel4.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel4.ClassName = "";
            this.linkLabel4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel4.CustomFontFamilies = "";
            this.linkLabel4.DisabledLinkColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.linkLabel4.Font = new System.Drawing.Font("Arial", 9F);
            this.linkLabel4.HoverLinkColor = System.Drawing.Color.Orange;
            this.linkLabel4.Image = null;
            this.linkLabel4.LinkArea = new System.Windows.Forms.LinkArea(0, 20);
            this.linkLabel4.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel4.Location = new System.Drawing.Point(394, 81);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Opacity = 70;
            this.linkLabel4.Size = new System.Drawing.Size(118, 15);
            this.linkLabel4.TabIndex = 9;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Target = VisualJS.Web.Forms.LinkLabel.URLOpen.NewWindow;
            this.linkLabel4.TargetURL = "";
            this.linkLabel4.Text = "Link Label & Opacity";
            this.linkLabel4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.linkLabel4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.linkLabel4.TooltipText = "";
            this.linkLabel4.UseMnemonic = false;
            this.linkLabel4.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(0)))), ((int)(((byte)(128)))));
            this.linkLabel4.ZOrder = 0;
            // 
            // linkLabel5
            // 
            this.linkLabel5.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.linkLabel5.AutoSize = true;
            this.linkLabel5.BackColor = System.Drawing.Color.GreenYellow;
            this.linkLabel5.ClassName = "";
            this.linkLabel5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel5.CustomFontFamilies = "";
            this.linkLabel5.DisabledLinkColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.linkLabel5.Font = new System.Drawing.Font("Arial", 9F);
            this.linkLabel5.HoverLinkColor = System.Drawing.Color.Orange;
            this.linkLabel5.Image = null;
            this.linkLabel5.LinkArea = new System.Windows.Forms.LinkArea(0, 29);
            this.linkLabel5.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel5.Location = new System.Drawing.Point(394, 105);
            this.linkLabel5.Name = "linkLabel5";
            this.linkLabel5.Opacity = 100;
            this.linkLabel5.Size = new System.Drawing.Size(177, 15);
            this.linkLabel5.TabIndex = 10;
            this.linkLabel5.TabStop = true;
            this.linkLabel5.Target = VisualJS.Web.Forms.LinkLabel.URLOpen.NewWindow;
            this.linkLabel5.TargetURL = "";
            this.linkLabel5.Text = "Link Label & Background Color";
            this.linkLabel5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.linkLabel5.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.linkLabel5.TooltipText = "";
            this.linkLabel5.UseMnemonic = false;
            this.linkLabel5.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(0)))), ((int)(((byte)(128)))));
            this.linkLabel5.ZOrder = 0;
            // 
            // Labels
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 156);
            this.Controls.Add(this.linkLabel5);
            this.Controls.Add(this.linkLabel4);
            this.Controls.Add(this.linkLabel3);
            this.Controls.Add(this.linkLabel2);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Labels";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "Labels Demo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.Label label2;
        private VisualJS.Web.Forms.Label label3;
        private VisualJS.Web.Forms.Label label4;
        private VisualJS.Web.Forms.Label label5;
        private VisualJS.Web.Forms.Label label6;
        private VisualJS.Web.Forms.LinkLabel linkLabel1;
        private VisualJS.Web.Forms.LinkLabel linkLabel2;
        private VisualJS.Web.Forms.LinkLabel linkLabel3;
        private VisualJS.Web.Forms.LinkLabel linkLabel4;
        private VisualJS.Web.Forms.LinkLabel linkLabel5;
    }
}