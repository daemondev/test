﻿namespace VisualJSControlsSample.SampleForms
{
    partial class ListViewTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ListViewTest));
            this.listView1 = new VisualJS.Web.Forms.ListView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.jButton1 = new VisualJS.Web.Forms.JButton();
            this.jButton2 = new VisualJS.Web.Forms.JButton();
            this.jButton3 = new VisualJS.Web.Forms.JButton();
            this.jButton4 = new VisualJS.Web.Forms.JButton();
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.CellsEditable = true;
            this.listView1.ClassName = "";
            this.listView1.CustomFontFamilies = "";
            this.listView1.Font = new System.Drawing.Font("Arial", 9F);
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.Groups = false;
            this.listView1.HideSelection = false;
            this.listView1.LabelWrap = false;
            this.listView1.LineColor = System.Drawing.Color.White;
            this.listView1.Location = new System.Drawing.Point(12, 12);
            this.listView1.Name = "listView1";
            this.listView1.SelectedFontColor = System.Drawing.Color.White;
            this.listView1.SelectedLineColor = System.Drawing.Color.Silver;
            this.listView1.ShowGroups = false;
            this.listView1.Size = new System.Drawing.Size(518, 270);
            this.listView1.SmallImageList = this.imageList1;
            this.listView1.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.listView1.TabIndex = 0;
            this.listView1.TileSize = new System.Drawing.Size(0, 0);
            this.listView1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.listView1.TooltipText = "";
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.ZOrder = 0;
            this.listView1.OnCellValueUpdated += new VisualJS.Web.Forms.ListView.CellValueUpdatedDelegate(this.listView1_OnCellValueUpdated);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.Tag = "ListViewIcons";
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "android.png");
            this.imageList1.Images.SetKeyName(1, "apple.png");
            this.imageList1.Images.SetKeyName(2, "Chrome.png");
            this.imageList1.Images.SetKeyName(3, "Firefox.png");
            this.imageList1.Images.SetKeyName(4, "IE.png");
            this.imageList1.Images.SetKeyName(5, "Opera.png");
            this.imageList1.Images.SetKeyName(6, "Safari.png");
            // 
            // jButton1
            // 
            this.jButton1.ApplicationWideResource = true;
            this.jButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton1.BackgroundImagePosition = "";
            this.jButton1.BackgroundImageQuality = ((short)(80));
            this.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton1.ClassName = "";
            this.jButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton1.CustomFontFamilies = "";
            this.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton1.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton1.Icon = null;
            this.jButton1.IconURL = "";
            this.jButton1.Image = null;
            this.jButton1.ImageLocation = "";
            this.jButton1.Location = new System.Drawing.Point(536, 12);
            this.jButton1.Name = "jButton1";
            this.jButton1.Opacity = 100;
            this.jButton1.PreventMultipleClicks = true;
            this.jButton1.Size = new System.Drawing.Size(122, 23);
            this.jButton1.TabIndex = 3;
            this.jButton1.Text = "Hide Headers";
            this.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton1.TooltipText = "";
            this.jButton1.UseVisualStyleBackColor = false;
            this.jButton1.ValidationFailedMessage = "Validation failed!";
            this.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton1.VerticalGradient = true;
            this.jButton1.ZOrder = 0;
            this.jButton1.Click += new System.EventHandler(this.jButton1_Click);
            // 
            // jButton2
            // 
            this.jButton2.ApplicationWideResource = true;
            this.jButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton2.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton2.BackgroundImagePosition = "";
            this.jButton2.BackgroundImageQuality = ((short)(80));
            this.jButton2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton2.ClassName = "";
            this.jButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton2.CustomFontFamilies = "";
            this.jButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton2.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton2.Icon = null;
            this.jButton2.IconURL = "";
            this.jButton2.Image = null;
            this.jButton2.ImageLocation = "";
            this.jButton2.Location = new System.Drawing.Point(536, 41);
            this.jButton2.Name = "jButton2";
            this.jButton2.Opacity = 100;
            this.jButton2.PreventMultipleClicks = true;
            this.jButton2.Size = new System.Drawing.Size(122, 23);
            this.jButton2.TabIndex = 2;
            this.jButton2.Text = "Add 100 Rows";
            this.jButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton2.TooltipText = "";
            this.jButton2.UseVisualStyleBackColor = false;
            this.jButton2.ValidationFailedMessage = "Validation failed!";
            this.jButton2.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton2.VerticalGradient = true;
            this.jButton2.ZOrder = 0;
            this.jButton2.Click += new System.EventHandler(this.jButton2_Click);
            // 
            // jButton3
            // 
            this.jButton3.ApplicationWideResource = true;
            this.jButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton3.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton3.BackgroundImagePosition = "";
            this.jButton3.BackgroundImageQuality = ((short)(80));
            this.jButton3.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton3.ClassName = "";
            this.jButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton3.CustomFontFamilies = "";
            this.jButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton3.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton3.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton3.Icon = null;
            this.jButton3.IconURL = "";
            this.jButton3.Image = null;
            this.jButton3.ImageLocation = "";
            this.jButton3.Location = new System.Drawing.Point(536, 70);
            this.jButton3.Name = "jButton3";
            this.jButton3.Opacity = 100;
            this.jButton3.PreventMultipleClicks = true;
            this.jButton3.Size = new System.Drawing.Size(122, 23);
            this.jButton3.TabIndex = 1;
            this.jButton3.Text = "Clear Rows";
            this.jButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton3.TooltipText = "";
            this.jButton3.UseVisualStyleBackColor = false;
            this.jButton3.ValidationFailedMessage = "Validation failed!";
            this.jButton3.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton3.VerticalGradient = true;
            this.jButton3.ZOrder = 0;
            this.jButton3.Click += new System.EventHandler(this.jButton3_Click);
            // 
            // jButton4
            // 
            this.jButton4.ApplicationWideResource = true;
            this.jButton4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton4.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton4.BackgroundImagePosition = "";
            this.jButton4.BackgroundImageQuality = ((short)(80));
            this.jButton4.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton4.ClassName = "";
            this.jButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton4.CustomFontFamilies = "";
            this.jButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton4.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton4.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton4.Icon = null;
            this.jButton4.IconURL = "";
            this.jButton4.Image = null;
            this.jButton4.ImageLocation = "";
            this.jButton4.Location = new System.Drawing.Point(536, 99);
            this.jButton4.Name = "jButton4";
            this.jButton4.Opacity = 100;
            this.jButton4.PreventMultipleClicks = true;
            this.jButton4.Size = new System.Drawing.Size(122, 23);
            this.jButton4.TabIndex = 0;
            this.jButton4.Text = "Show CheckBoxes";
            this.jButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton4.TooltipText = "";
            this.jButton4.UseVisualStyleBackColor = false;
            this.jButton4.ValidationFailedMessage = "Validation failed!";
            this.jButton4.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton4.VerticalGradient = true;
            this.jButton4.ZOrder = 0;
            this.jButton4.Click += new System.EventHandler(this.jButton4_Click);
            // 
            // ListViewTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(666, 295);
            this.Controls.Add(this.jButton4);
            this.Controls.Add(this.jButton3);
            this.Controls.Add(this.jButton2);
            this.Controls.Add(this.jButton1);
            this.Controls.Add(this.listView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ListViewTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "ListView Demo";
            this.ResumeLayout(false);

        }

        #endregion

        private VisualJS.Web.Forms.ListView listView1;
        private VisualJS.Web.Forms.JButton jButton1;
        private VisualJS.Web.Forms.JButton jButton2;
        private VisualJS.Web.Forms.JButton jButton3;
        private VisualJS.Web.Forms.JButton jButton4;
        private System.Windows.Forms.ImageList imageList1;
    }
}