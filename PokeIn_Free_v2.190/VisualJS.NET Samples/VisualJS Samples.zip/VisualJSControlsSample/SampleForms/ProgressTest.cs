﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing; 
using VisualJS;
using VisualJS.Web.Forms;
using System.Linq;
using System.Text;

namespace VisualJSControlsSample.SampleForms
{
    using System.Threading;

    public partial class ProgressTest : VisualJS.Web.Forms.Form
    {

#region Constructors
        public ProgressTest()
        {
            InitializeComponent();
            AfterInitialization();
        } 

        //Use the below constructor if you create the instance of this Form object other than the active Thread
        //otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        public ProgressTest(string clientId): base(clientId)
        {
            InitializeComponent(); 
            AfterInitialization();
        }
#endregion

        //Use below method for the tasks after the initialization of the Form
        void  AfterInitialization()
        {

        }

        private void jButton1_Click(object sender, EventArgs e)
        {
            jButton1.Enabled = false;
            jButton1.Text = "Processing..";
            this.FormClosableByUser = false;
            borderColor.Enabled = false;
            borderStyle.Enabled = false;
            backColor.Enabled = false;
            progressBar1.Value = 0;
            Thread.Sleep(1000);//Fake Wait

            for (int i = 1; i <= 99; i += 3)
            {
                progressBar1.Value = i;
                Thread.Sleep(500);//Fake Wait
            }
            progressBar1.Value = 100;
            MessageBox.Show("Done!", this);
            jButton1.Enabled = true;
            jButton1.Text = "Start Process";
            this.FormClosableByUser = true;
            borderColor.Enabled = true;
            borderStyle.Enabled = true;
            backColor.Enabled = true;
        }

        private void borderStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            progressBar1.BorderLineStyle = (Panel.ClientBorderStyle)borderStyle.SelectedIndex;
        }

        private void borderColor_TextChanged(object sender, EventArgs e)
        {
            progressBar1.BorderColor = borderColor.Color;
        }

        private void backColor_TextChanged(object sender, EventArgs e)
        {
            progressBar1.BarColor = backColor.Color;
        }
    }
}