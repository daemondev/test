﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing; 
using VisualJS;
using VisualJS.Web.Forms;
using System.Linq;
using System.Text;

namespace VisualJSControlsSample.SampleForms
{
    public partial class TextboxTest : VisualJS.Web.Forms.Form
    {

#region Constructors
        public TextboxTest()
        {
            InitializeComponent();
            AfterInitialization();
        } 

        //Use the below constructor if you create the instance of this Form object other than the active Thread
        //otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        public TextboxTest(string clientId): base(clientId)
        {
            InitializeComponent(); 
            AfterInitialization();
        }
#endregion

        //Use below method for the tasks after the initialization of the Form
        void  AfterInitialization()
        {

        }

        internal static string[] colors ={"red", "orange", "black", "white", "green", "blue", "yellow"
                              ,"maroon", "whitesmoke", "gray", "dimgray", "silvergray",
                              "lightblue", "skyblue", "forestgreen", "gold" };

        internal string prevValue = "";
        private void textBox2_OnSuggestion(string value)
        {
            if (value == prevValue)
                return;

            prevValue = value;

            string[] vals = value.ToLower().Replace(',', ' ').Split(' ');
            Dictionary<string, string> suggestions = new Dictionary<string, string>(); //value, color
            foreach(string val in vals)
            {
                if (val == "")
                    continue;
                foreach (string s in colors) 
                    if (s.Contains(val)) 
						if(!suggestions.ContainsKey(s))
							suggestions.Add(s, "black");
            }

            textBox2.UpdateSuggestion(suggestions);
        }

        private void jButton1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You entered : " + textBox1.Text, this);
        }

        private void jButton2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Input passed the SQLInjection Validation test", this);
        }
    }
}