﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing; 
using VisualJS;
using VisualJS.Web.Forms;
using System.Linq;
using System.Text;

namespace VisualJSControlsSample.SampleForms
{
    public partial class CheckBoxTest : VisualJS.Web.Forms.Form
    {
        public CheckBoxTest()
        {
            InitializeComponent();
        } 

        //Use the below constructor if you create the instance of this Form object other than the active Thread
        //otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        public CheckBoxTest(string clientId): base(clientId)
        {
            InitializeComponent(); 
        }

        double total = 0;
        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chk = (CheckBox)sender;
            if (chk.Checked)
                total += Convert.ToDouble(chk.Tag);
            else
                total -= Convert.ToDouble(chk.Tag);

            maskedTextBox1.Text = "$ " + total.ToString("#,#");
        }
    }
}