﻿namespace VisualJSControlsSample.SampleForms
{
    partial class ComboBoxTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ComboBoxTest));
            this.comboBox1 = new VisualJS.Web.Forms.ComboBox();
            this.button1 = new VisualJS.Web.Forms.Button();
            this.button2 = new VisualJS.Web.Forms.Button();
            this.button3 = new VisualJS.Web.Forms.Button();
            this.maskedTextBox2 = new VisualJS.Web.Forms.MaskedTextBox();
            this.label2 = new VisualJS.Web.Forms.Label();
            this.pictureBox1 = new VisualJS.Web.Forms.PictureBox();
            this.panel1 = new VisualJS.Web.Forms.Panel();
            this.panel2 = new VisualJS.Web.Forms.Panel();
            this.button4 = new VisualJS.Web.Forms.Button();
            this.maskedTextBox1 = new VisualJS.Web.Forms.MaskedTextBox();
            this.label1 = new VisualJS.Web.Forms.Label();
            this.label3 = new VisualJS.Web.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.ClassName = "";
            this.comboBox1.CustomFontFamilies = "";
            this.comboBox1.Font = new System.Drawing.Font("Arial", 9F);
            this.comboBox1.Location = new System.Drawing.Point(12, 12);
            this.comboBox1.MinSelectedIndex = -1;
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Opacity = 100;
            this.comboBox1.Size = new System.Drawing.Size(176, 23);
            this.comboBox1.TabIndex = 13;
            this.comboBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.comboBox1.TooltipText = "";
            this.comboBox1.UpdateTextBySelection = this.label3;
            this.comboBox1.ValidationMessage = "An action is required";
            this.comboBox1.ZOrder = 0;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.BackgroundImagePosition = "";
            this.button1.BackgroundImageQuality = ((short)(80));
            this.button1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.button1.ClassName = "";
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.CustomFontFamilies = "";
            this.button1.Font = new System.Drawing.Font("Arial", 9F);
            this.button1.Image = null;
            this.button1.Location = new System.Drawing.Point(211, 12);
            this.button1.Name = "button1";
            this.button1.Opacity = 100;
            this.button1.Size = new System.Drawing.Size(109, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Add Item";
            this.button1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.button1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.button1.TooltipText = "";
            this.button1.UseMnemonic = false;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.ValidationFailedMessage = "Validation failed!";
            this.button1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.button1.ZOrder = 0;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackgroundImagePosition = "";
            this.button2.BackgroundImageQuality = ((short)(80));
            this.button2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.button2.ClassName = "";
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.CustomFontFamilies = "";
            this.button2.Font = new System.Drawing.Font("Arial", 9F);
            this.button2.Image = null;
            this.button2.Location = new System.Drawing.Point(3, 6);
            this.button2.Name = "button2";
            this.button2.Opacity = 100;
            this.button2.Size = new System.Drawing.Size(109, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Remove Item";
            this.button2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.button2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.button2.TooltipText = "";
            this.button2.UseMnemonic = false;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.ValidationFailedMessage = "Enter the index you want to remove";
            this.button2.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnParent;
            this.button2.ZOrder = 0;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackgroundImagePosition = "";
            this.button3.BackgroundImageQuality = ((short)(80));
            this.button3.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.button3.ClassName = "";
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.CustomFontFamilies = "";
            this.button3.Font = new System.Drawing.Font("Arial", 9F);
            this.button3.Image = null;
            this.button3.Location = new System.Drawing.Point(211, 113);
            this.button3.Name = "button3";
            this.button3.Opacity = 100;
            this.button3.Size = new System.Drawing.Size(109, 23);
            this.button3.TabIndex = 3;
            this.button3.Text = "Clear Items";
            this.button3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.button3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.button3.TooltipText = "";
            this.button3.UseMnemonic = false;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.ValidationFailedMessage = "Validation failed!";
            this.button3.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.button3.ZOrder = 0;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.maskedTextBox2.CheckForEmail = false;
            this.maskedTextBox2.ClassName = "";
            this.maskedTextBox2.CustomFontFamilies = "";
            this.maskedTextBox2.Font = new System.Drawing.Font("Arial", 9F);
            this.maskedTextBox2.Location = new System.Drawing.Point(118, 8);
            this.maskedTextBox2.MinLength = -1;
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Opacity = 100;
            this.maskedTextBox2.PreventSQLInjection = false;
            this.maskedTextBox2.RegexCheck = "";
            this.maskedTextBox2.Size = new System.Drawing.Size(70, 21);
            this.maskedTextBox2.TabIndex = 7;
            this.maskedTextBox2.Text = "0";
            this.maskedTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.maskedTextBox2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.maskedTextBox2.TooltipText = "";
            this.maskedTextBox2.ValidationMessage = "Enter a number";
            this.maskedTextBox2.ZOrder = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9F);
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(194, 10);
            this.label2.Name = "label2";
            this.label2.Opacity = 100;
            this.label2.Size = new System.Drawing.Size(41, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "index";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.ZOrder = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.ApplicationWideResource = false;
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.ClassName = "";
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Font = new System.Drawing.Font("Arial", 9F);
            this.pictureBox1.Image = null;
            this.pictureBox1.ImageLocation = "";
            this.pictureBox1.ImageQuality = ((short)(90));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 62);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Opacity = 100;
            this.pictureBox1.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.JPG;
            this.pictureBox1.Size = new System.Drawing.Size(176, 72);
            this.pictureBox1.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.StretchImage;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.pictureBox1.TooltipText = "";
            this.pictureBox1.ZOrder = 0;
            // 
            // panel1
            // 
            this.panel1.ApplicationWideResource = true;
            this.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.panel1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.panel1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackColorEnd = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImagePosition = "";
            this.panel1.BackgroundImageQuality = ((short)(80));
            this.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.panel1.ClassName = "";
            this.panel1.ClientID = null;
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.maskedTextBox2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.CustomFontFamilies = "";
            this.panel1.Font = new System.Drawing.Font("Arial", 9F);
            this.panel1.HTML = "";
            this.panel1.ImageLocation = "";
            this.panel1.Location = new System.Drawing.Point(208, 73);
            this.panel1.Name = "panel1";
            this.panel1.Opacity = 100;
            this.panel1.Size = new System.Drawing.Size(239, 32);
            this.panel1.TabIndex = 11;
            this.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.panel1.TooltipText = "";
            this.panel1.VerticalGradient = true;
            this.panel1.ZOrder = 0;
            // 
            // panel2
            // 
            this.panel2.ApplicationWideResource = true;
            this.panel2.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.panel2.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.panel2.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BackColorEnd = System.Drawing.Color.Transparent;
            this.panel2.BackgroundImagePosition = "";
            this.panel2.BackgroundImageQuality = ((short)(80));
            this.panel2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.panel2.ClassName = "";
            this.panel2.ClientID = null;
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.maskedTextBox1);
            this.panel2.Controls.Add(this.label1);
            this.panel2.CustomFontFamilies = "";
            this.panel2.Font = new System.Drawing.Font("Arial", 9F);
            this.panel2.HTML = "";
            this.panel2.ImageLocation = "";
            this.panel2.Location = new System.Drawing.Point(208, 38);
            this.panel2.Name = "panel2";
            this.panel2.Opacity = 100;
            this.panel2.Size = new System.Drawing.Size(239, 32);
            this.panel2.TabIndex = 12;
            this.panel2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.panel2.TooltipText = "";
            this.panel2.VerticalGradient = true;
            this.panel2.ZOrder = 0;
            // 
            // button4
            // 
            this.button4.BackgroundImagePosition = "";
            this.button4.BackgroundImageQuality = ((short)(80));
            this.button4.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.button4.ClassName = "";
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.CustomFontFamilies = "";
            this.button4.Font = new System.Drawing.Font("Arial", 9F);
            this.button4.Image = null;
            this.button4.Location = new System.Drawing.Point(3, 6);
            this.button4.Name = "button4";
            this.button4.Opacity = 100;
            this.button4.Size = new System.Drawing.Size(109, 23);
            this.button4.TabIndex = 2;
            this.button4.Text = "Insert Item";
            this.button4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.button4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.button4.TooltipText = "";
            this.button4.UseMnemonic = false;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.ValidationFailedMessage = "Enter the index you want to insert";
            this.button4.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnParent;
            this.button4.ZOrder = 0;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.maskedTextBox1.CheckForEmail = false;
            this.maskedTextBox1.ClassName = "";
            this.maskedTextBox1.CustomFontFamilies = "";
            this.maskedTextBox1.Font = new System.Drawing.Font("Arial", 9F);
            this.maskedTextBox1.Location = new System.Drawing.Point(118, 8);
            this.maskedTextBox1.MinLength = -1;
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Opacity = 100;
            this.maskedTextBox1.PreventSQLInjection = false;
            this.maskedTextBox1.RegexCheck = "";
            this.maskedTextBox1.Size = new System.Drawing.Size(70, 21);
            this.maskedTextBox1.TabIndex = 7;
            this.maskedTextBox1.Text = "0";
            this.maskedTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.maskedTextBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.maskedTextBox1.TooltipText = "";
            this.maskedTextBox1.ValidationMessage = "Enter a number";
            this.maskedTextBox1.ZOrder = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 9F);
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(194, 10);
            this.label1.Name = "label1";
            this.label1.Opacity = 100;
            this.label1.Size = new System.Drawing.Size(41, 15);
            this.label1.TabIndex = 9;
            this.label1.Text = "index";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.ZOrder = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ClassName = "";
            this.label3.CustomFontFamilies = "";
            this.label3.Font = new System.Drawing.Font("Arial", 9F);
            this.label3.Image = null;
            this.label3.Location = new System.Drawing.Point(12, 42);
            this.label3.Name = "label3";
            this.label3.Opacity = 100;
            this.label3.Size = new System.Drawing.Size(41, 15);
            this.label3.TabIndex = 14;
            this.label3.Text = "IText Feature";
            this.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label3.TooltipText = "";
            this.label3.UseMnemonic = false;
            this.label3.ZOrder = 0;
            // 
            // ComboBoxTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 148);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ComboBoxTest";
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "ComboBox Demo";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private VisualJS.Web.Forms.ComboBox comboBox1;
        private VisualJS.Web.Forms.Button button1;
        private VisualJS.Web.Forms.Button button2;
        private VisualJS.Web.Forms.Button button3;
        private VisualJS.Web.Forms.MaskedTextBox maskedTextBox2;
        private VisualJS.Web.Forms.Label label2;
        private VisualJS.Web.Forms.PictureBox pictureBox1;
        private VisualJS.Web.Forms.Panel panel1;
        private VisualJS.Web.Forms.Panel panel2;
        private VisualJS.Web.Forms.Button button4;
        private VisualJS.Web.Forms.MaskedTextBox maskedTextBox1;
        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.Label label3;
    }
}