﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VisualJSControlsSample.CustomControl
{
    using VisualJS.Web.Forms;

    public class MyCustomControl:VisualJS.Web.Forms.UserControl
    {
        private VisualJS.Web.Forms.TextBox textBox1;
        private VisualJS.Web.Forms.JButton jButton1;

        #region InitializeComponent
        private void InitializeComponent()
        {
            this.jButton1 = new VisualJS.Web.Forms.JButton();
            this.textBox1 = new VisualJS.Web.Forms.TextBox();
            this.SuspendLayout();
            // 
            // jButton1
            // 
            this.jButton1.ApplicationWideResource = true;
            this.jButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton1.BackgroundImagePosition = "";
            this.jButton1.BackgroundImageQuality = ((short)(80));
            this.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton1.ClassName = "";
            this.jButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton1.CustomFontFamilies = "";
            this.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton1.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton1.Icon = null;
            this.jButton1.IconURL = "";
            this.jButton1.Image = null;
            this.jButton1.ImageLocation = "";
            this.jButton1.Location = new System.Drawing.Point(163, 6);
            this.jButton1.Name = "jButton1";
            this.jButton1.Opacity = 100;
            this.jButton1.PreventMultipleClicks = true;
            this.jButton1.Size = new System.Drawing.Size(80, 23);
            this.jButton1.TabIndex = 0;
            this.jButton1.Text = "Test Me";
            this.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton1.TooltipText = "";
            this.jButton1.UseVisualStyleBackColor = false;
            this.jButton1.ValidationFailedMessage = "Validation failed!";
            this.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnParent;
            this.jButton1.VerticalGradient = true;
            this.jButton1.ZOrder = 0;
            this.jButton1.Click += new System.EventHandler(this.jButton1_Click);
            // 
            // textBox1
            // 
            this.textBox1.CheckForEmail = false;
            this.textBox1.ClassName = "";
            this.textBox1.CustomFontFamilies = "";
            this.textBox1.Font = new System.Drawing.Font("Arial", 9F);
            this.textBox1.Location = new System.Drawing.Point(5, 6);
            this.textBox1.MaxLength = 65535;
            this.textBox1.MinLength = 3;
            this.textBox1.Name = "textBox1";
            this.textBox1.Opacity = 100;
            this.textBox1.PreventSQLInjection = false;
            this.textBox1.RegexCheck = "";
            this.textBox1.Size = new System.Drawing.Size(152, 21);
            this.textBox1.TabIndex = 1;
            this.textBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.textBox1.TooltipText = "";
            this.textBox1.ValidationMessage = "Enter Your Name";
            this.textBox1.ZOrder = 0;
            // 
            // MyCustomControl
            // 
            this.BackColor = System.Drawing.Color.Gray;
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.jButton1);
            this.Name = "MyCustomControl";
            this.Size = new System.Drawing.Size(253, 37);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion 

        public MyCustomControl()
        {
            InitializeComponent();
        }

        private void jButton1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hello " + textBox1.Text, (Form)this.ParentForm);
        }
    }
}