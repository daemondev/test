﻿namespace VisualJSControlsSample.VisualJSApp
{
    partial class MobileMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MobileMainForm));
            this.pictureBox1 = new VisualJS.Web.Forms.PictureBox();
            this.panel1 = new VisualJS.Web.Forms.Panel();
            this.jButton4 = new VisualJS.Web.Forms.JButton();
            this.label2 = new VisualJS.Web.Forms.Label();
            this.jButton3 = new VisualJS.Web.Forms.JButton();
            this.progressBar1 = new VisualJS.Web.Forms.ProgressBar();
            this.jButton2 = new VisualJS.Web.Forms.JButton();
            this.lblTime = new VisualJS.Web.Forms.Label();
            this.jButton1 = new VisualJS.Web.Forms.JButton();
            this.label1 = new VisualJS.Web.Forms.Label();
            this.timer1 = new VisualJS.Web.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBox1.ApplicationWideResource = true;
            this.pictureBox1.ClassName = "";
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Font = new System.Drawing.Font("Arial", 9F);
            this.pictureBox1.HoverImage = null;
            this.pictureBox1.HoverImageLocation = "";
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.ImageLocation = "";
            this.pictureBox1.ImageQuality = ((short)(80));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(60, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Opacity = 100;
            this.pictureBox1.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.PNG;
            this.pictureBox1.Size = new System.Drawing.Size(150, 30);
            this.pictureBox1.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal;
            this.pictureBox1.TabIndex = 34;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.pictureBox1.TooltipText = "";
            this.pictureBox1.ZOrder = 0;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.ApplicationWideResource = true;
            this.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None;
            this.panel1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.panel1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.BackColorEnd = System.Drawing.Color.DimGray;
            this.panel1.BackgroundImagePosition = "";
            this.panel1.BackgroundImageQuality = ((short)(80));
            this.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.panel1.BorderColor = System.Drawing.Color.Black;
            this.panel1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid;
            this.panel1.ClassName = "";
            this.panel1.ClientID = null;
            this.panel1.Controls.Add(this.jButton4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.jButton3);
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.jButton2);
            this.panel1.Controls.Add(this.lblTime);
            this.panel1.Controls.Add(this.jButton1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.CustomFontFamilies = "";
            this.panel1.Font = new System.Drawing.Font("Arial", 9F);
            this.panel1.HTML = "";
            this.panel1.ImageLocation = "";
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Opacity = 100;
            this.panel1.Size = new System.Drawing.Size(277, 376);
            this.panel1.TabIndex = 57;
            this.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.panel1.TooltipText = "";
            this.panel1.VerticalGradient = true;
            this.panel1.ZOrder = 0;
            // 
            // jButton4
            // 
            this.jButton4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.jButton4.ApplicationWideResource = true;
            this.jButton4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton4.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton4.BackgroundImagePosition = "";
            this.jButton4.BackgroundImageQuality = ((short)(80));
            this.jButton4.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton4.ClassName = "";
            this.jButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton4.CustomFontFamilies = "";
            this.jButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton4.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton4.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton4.Icon = null;
            this.jButton4.IconURL = "";
            this.jButton4.Image = null;
            this.jButton4.ImageLocation = "";
            this.jButton4.Location = new System.Drawing.Point(16, 325);
            this.jButton4.Name = "jButton4";
            this.jButton4.Opacity = 100;
            this.jButton4.PreventMultipleClicks = true;
            this.jButton4.Size = new System.Drawing.Size(247, 34);
            this.jButton4.TabIndex = 0;
            this.jButton4.Text = "Show MessageBox";
            this.jButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton4.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton4.TooltipText = "";
            this.jButton4.UseVisualStyleBackColor = false;
            this.jButton4.ValidationFailedMessage = "Validation failed!";
            this.jButton4.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton4.VerticalGradient = true;
            this.jButton4.ZOrder = 0;
            this.jButton4.Click += new System.EventHandler(this.jButton4_Click);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ClassName = "";
            this.label2.CustomFontFamilies = "";
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label2.Image = null;
            this.label2.Location = new System.Drawing.Point(56, 210);
            this.label2.Name = "label2";
            this.label2.Opacity = 100;
            this.label2.Size = new System.Drawing.Size(167, 24);
            this.label2.TabIndex = 43;
            this.label2.Text = "Try ProgressBar";
            this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label2.TooltipText = "";
            this.label2.UseMnemonic = false;
            this.label2.ZOrder = 0;
            // 
            // jButton3
            // 
            this.jButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jButton3.ApplicationWideResource = true;
            this.jButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton3.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton3.BackgroundImagePosition = "";
            this.jButton3.BackgroundImageQuality = ((short)(80));
            this.jButton3.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton3.ClassName = "";
            this.jButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton3.CustomFontFamilies = "";
            this.jButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton3.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jButton3.ForeColor = System.Drawing.Color.Black;
            this.jButton3.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton3.Icon = null;
            this.jButton3.IconURL = "";
            this.jButton3.Image = null;
            this.jButton3.ImageLocation = "";
            this.jButton3.Location = new System.Drawing.Point(229, 200);
            this.jButton3.Name = "jButton3";
            this.jButton3.Opacity = 100;
            this.jButton3.PreventMultipleClicks = true;
            this.jButton3.Size = new System.Drawing.Size(34, 34);
            this.jButton3.TabIndex = 44;
            this.jButton3.Text = "+";
            this.jButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton3.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton3.TooltipText = "";
            this.jButton3.UseVisualStyleBackColor = false;
            this.jButton3.ValidationFailedMessage = "Validation failed!";
            this.jButton3.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton3.VerticalGradient = true;
            this.jButton3.ZOrder = 0;
            this.jButton3.Click += new System.EventHandler(this.jButton3_Click);
            // 
            // progressBar1
            // 
            this.progressBar1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.progressBar1.BarColor = System.Drawing.Color.DarkRed;
            this.progressBar1.BorderColor = System.Drawing.Color.White;
            this.progressBar1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid;
            this.progressBar1.ClassName = "";
            this.progressBar1.CustomFontFamilies = "";
            this.progressBar1.Font = new System.Drawing.Font("Arial", 9F);
            this.progressBar1.ForeColor = System.Drawing.Color.Black;
            this.progressBar1.Location = new System.Drawing.Point(16, 240);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Opacity = 100;
            this.progressBar1.Size = new System.Drawing.Size(247, 51);
            this.progressBar1.TabIndex = 40;
            this.progressBar1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.progressBar1.TooltipText = "";
            this.progressBar1.ZOrder = 0;
            // 
            // jButton2
            // 
            this.jButton2.ApplicationWideResource = true;
            this.jButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton2.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton2.BackgroundImagePosition = "";
            this.jButton2.BackgroundImageQuality = ((short)(80));
            this.jButton2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton2.ClassName = "";
            this.jButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton2.CustomFontFamilies = "";
            this.jButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton2.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jButton2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton2.Icon = null;
            this.jButton2.IconURL = "";
            this.jButton2.Image = null;
            this.jButton2.ImageLocation = "";
            this.jButton2.Location = new System.Drawing.Point(16, 200);
            this.jButton2.Name = "jButton2";
            this.jButton2.Opacity = 100;
            this.jButton2.PreventMultipleClicks = true;
            this.jButton2.Size = new System.Drawing.Size(34, 34);
            this.jButton2.TabIndex = 45;
            this.jButton2.Text = "-";
            this.jButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton2.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton2.TooltipText = "";
            this.jButton2.UseVisualStyleBackColor = false;
            this.jButton2.ValidationFailedMessage = "Validation failed!";
            this.jButton2.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton2.VerticalGradient = true;
            this.jButton2.ZOrder = 0;
            this.jButton2.Click += new System.EventHandler(this.jButton2_Click);
            // 
            // lblTime
            // 
            this.lblTime.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTime.BackColor = System.Drawing.Color.Transparent;
            this.lblTime.ClassName = "";
            this.lblTime.CustomFontFamilies = "";
            this.lblTime.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.ForeColor = System.Drawing.Color.Gold;
            this.lblTime.Image = null;
            this.lblTime.Location = new System.Drawing.Point(16, 148);
            this.lblTime.Name = "lblTime";
            this.lblTime.Opacity = 100;
            this.lblTime.Size = new System.Drawing.Size(247, 36);
            this.lblTime.TabIndex = 37;
            this.lblTime.Text = "00:00:00";
            this.lblTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.lblTime.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.lblTime.TooltipText = "";
            this.lblTime.UseMnemonic = false;
            this.lblTime.ZOrder = 0;
            // 
            // jButton1
            // 
            this.jButton1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.jButton1.ApplicationWideResource = true;
            this.jButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton1.BackgroundImagePosition = "";
            this.jButton1.BackgroundImageQuality = ((short)(80));
            this.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton1.ClassName = "";
            this.jButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton1.CustomFontFamilies = "";
            this.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton1.Font = new System.Drawing.Font("Arial", 9F);
            this.jButton1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton1.Icon = null;
            this.jButton1.IconURL = "";
            this.jButton1.Image = null;
            this.jButton1.ImageLocation = "";
            this.jButton1.Location = new System.Drawing.Point(16, 93);
            this.jButton1.Name = "jButton1";
            this.jButton1.Opacity = 100;
            this.jButton1.PreventMultipleClicks = true;
            this.jButton1.Size = new System.Drawing.Size(247, 34);
            this.jButton1.TabIndex = 46;
            this.jButton1.Text = "Enable Server Time";
            this.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton1.TooltipText = "";
            this.jButton1.UseVisualStyleBackColor = false;
            this.jButton1.ValidationFailedMessage = "Validation failed!";
            this.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton1.VerticalGradient = true;
            this.jButton1.ZOrder = 0;
            this.jButton1.Click += new System.EventHandler(this.jButton1_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ClassName = "";
            this.label1.CustomFontFamilies = "";
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Image = null;
            this.label1.Location = new System.Drawing.Point(13, 53);
            this.label1.Name = "label1";
            this.label1.Opacity = 100;
            this.label1.Size = new System.Drawing.Size(250, 37);
            this.label1.TabIndex = 35;
            this.label1.Text = "Create cross-browser touch compatible applications easily";
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.label1.TooltipText = "";
            this.label1.UseMnemonic = false;
            this.label1.ZOrder = 0;
            // 
            // timer1
            // 
            this.timer1.Interval = 999;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // MobileMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(301, 400);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.FormClosableByUser = false;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MobileMainForm";
            this.Text = "VisualJS.NET Controls Sample";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private VisualJS.Web.Forms.PictureBox pictureBox1;
        private VisualJS.Web.Forms.Panel panel1;
        private VisualJS.Web.Forms.JButton jButton4;
        private VisualJS.Web.Forms.Label label2;
        private VisualJS.Web.Forms.JButton jButton3;
        private VisualJS.Web.Forms.ProgressBar progressBar1;
        private VisualJS.Web.Forms.JButton jButton2;
        private VisualJS.Web.Forms.Label lblTime;
        private VisualJS.Web.Forms.JButton jButton1;
        private VisualJS.Web.Forms.Label label1;
        private VisualJS.Web.Forms.Timer timer1;
    }
}