﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using VisualJS;
using VisualJS.Kernel;
using PokeIn.Comet;

#region VisualJS.Kernel.VisualJSProjectKey - Do Not Edit
//Right click to project under solution windows and then Register the project
[assembly:VisualJS.Kernel.VisualJSProjectKey("NONE")]
#endregion 

namespace VisualJSControlsSample.VisualJSApp.Helper
{
    internal static class globalAsaxHelper
    {
        internal static void Application_Start()
        {
            //Using chunked mode transfers helps reducing load
            CometSettings.ChunkedMode = true;

            //enable below line in order to use Chart Support (requires Settings.JQuerySupport is enabled)
            Settings.ChartSupport = true;

            //use below line in order to activate built-in JQuery Support 1.7.1
            Settings.JQuerySupport = true;

            //Update the below parameter with your own copy of JQuery to change the working version of JQuery
            //Settings.JQueryBase = .....

            Settings.ActiveTheme = VisualJS.Kernel.Theme.Default;

            //For this sample project, we have defined the PreferredScreenSize on both main forms in order 
            //to activate VisualJS.NET's Automatic Form Selector by users' screen size
            try
            {
                VisualJS.Page.CreateApplication(
                    new Type[]{
                    typeof(VisualJSControlsSample.VisualJSApp.MobileMainForm),
                    typeof(VisualJSControlsSample.VisualJSApp.MainForm)}
                    );
            }
            catch(VisualJS.Kernel.LicenseFailedException ex)
            {
                throw;
            }

            //Below event fires when a form open request is received from the client side
            VisualJS.Page.OnFormOpenRequest += new FormOpenDelegate(Page_OnFormOpenRequest);

            //Use below event listener instead CometWorker.OnClientConnected for your VisualJS.NET applications
            //VisualJS.Page.OnClientConnected += new DefineClassObjects(Page_OnClientConnected);

            //Above rule applies to OnClientDisconnected
            //VisualJS.Page.OnClientDisconnected += new ClientDisconnectedDelegate(Page_OnClientDisconnected);
        }

        internal static void Page_OnFormOpenRequest(ConnectionDetails details, string formName)
        {

        } 

        internal static void Page_OnClientConnected(ConnectionDetails details, ref Dictionary<string, object> classList)
        {
            
        }

        internal static void Page_OnClientDisconnected(string clientId)
        {
            
        }
    }
}