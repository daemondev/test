﻿namespace VisualJSControlsSample.VisualJSApp
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.contextMenu1 = new VisualJS.Web.Forms.ContextMenu();
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.menuItem2 = new System.Windows.Forms.MenuItem();
            this.menuItem3 = new System.Windows.Forms.MenuItem();
            this.menuItem4 = new System.Windows.Forms.MenuItem();
            this.pictureBox1 = new VisualJS.Web.Forms.PictureBox();
            this.BtnMessageBox = new VisualJS.Web.Forms.JButton();
            this.btnCharts = new VisualJS.Web.Forms.JButton();
            this.btnBrowser = new VisualJS.Web.Forms.JButton();
            this.btnUploadFile = new VisualJS.Web.Forms.JButton();
            this.btnTimer = new VisualJS.Web.Forms.JButton();
            this.btnTextBox = new VisualJS.Web.Forms.JButton();
            this.btnTabs = new VisualJS.Web.Forms.JButton();
            this.btnSlider = new VisualJS.Web.Forms.JButton();
            this.btnRichText = new VisualJS.Web.Forms.JButton();
            this.btnRadioButton = new VisualJS.Web.Forms.JButton();
            this.btnProgressBar = new VisualJS.Web.Forms.JButton();
            this.btnPictureBox = new VisualJS.Web.Forms.JButton();
            this.btnPanel = new VisualJS.Web.Forms.JButton();
            this.btnMaskedTextBox = new VisualJS.Web.Forms.JButton();
            this.btnListView = new VisualJS.Web.Forms.JButton();
            this.btnListBox = new VisualJS.Web.Forms.JButton();
            this.btnLabels = new VisualJS.Web.Forms.JButton();
            this.btnFlashPlayer = new VisualJS.Web.Forms.JButton();
            this.btnFeedBox = new VisualJS.Web.Forms.JButton();
            this.btnDateTimePicker = new VisualJS.Web.Forms.JButton();
            this.btnMenu = new VisualJS.Web.Forms.JButton();
            this.btnComboBox = new VisualJS.Web.Forms.JButton();
            this.btnColorPicker = new VisualJS.Web.Forms.JButton();
            this.btnCheckBox = new VisualJS.Web.Forms.JButton();
            this.btnCaptcha = new VisualJS.Web.Forms.JButton();
            this.btnButtons = new VisualJS.Web.Forms.JButton();
            this.jButton1 = new VisualJS.Web.Forms.JButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // contextMenu1
            // 
            this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem1,
            this.menuItem2});
            // 
            // menuItem1
            // 
            this.menuItem1.Index = 0;
            this.menuItem1.Text = "About";
            this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
            // 
            // menuItem2
            // 
            this.menuItem2.Index = 1;
            this.menuItem2.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem3,
            this.menuItem4});
            this.menuItem2.Text = "Dialogs";
            // 
            // menuItem3
            // 
            this.menuItem3.Index = 0;
            this.menuItem3.Text = "New Empty Window";
            this.menuItem3.Click += new System.EventHandler(this.menuItem3_Click);
            // 
            // menuItem4
            // 
            this.menuItem4.Index = 1;
            this.menuItem4.Text = "CheckBox Sample";
            this.menuItem4.Click += new System.EventHandler(this.menuItem4_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.ApplicationWideResource = true;
            this.pictureBox1.ClassName = "";
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Font = new System.Drawing.Font("Arial", 9F);
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.ImageLocation = "";
            this.pictureBox1.ImageQuality = ((short)(80));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(528, 269);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Opacity = 100;
            this.pictureBox1.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.PNG;
            this.pictureBox1.Size = new System.Drawing.Size(140, 30);
            this.pictureBox1.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal;
            this.pictureBox1.TabIndex = 34;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.pictureBox1.TooltipText = "";
            this.pictureBox1.ZOrder = 0;
            // 
            // BtnMessageBox
            // 
            this.BtnMessageBox.ApplicationWideResource = true;
            this.BtnMessageBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.BtnMessageBox.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.BtnMessageBox.BackgroundImagePosition = "";
            this.BtnMessageBox.BackgroundImageQuality = ((short)(80));
            this.BtnMessageBox.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.BtnMessageBox.ClassName = "";
            this.BtnMessageBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnMessageBox.CustomFontFamilies = "";
            this.BtnMessageBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMessageBox.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMessageBox.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.BtnMessageBox.Icon = ((System.Drawing.Image)(resources.GetObject("BtnMessageBox.Icon")));
            this.BtnMessageBox.IconURL = "";
            this.BtnMessageBox.Image = null;
            this.BtnMessageBox.ImageLocation = "";
            this.BtnMessageBox.Location = new System.Drawing.Point(516, 180);
            this.BtnMessageBox.Name = "BtnMessageBox";
            this.BtnMessageBox.Opacity = 100;
            this.BtnMessageBox.PreventMultipleClicks = true;
            this.BtnMessageBox.Size = new System.Drawing.Size(162, 36);
            this.BtnMessageBox.TabIndex = 35;
            this.BtnMessageBox.Text = "MessageBox";
            this.BtnMessageBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BtnMessageBox.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.BtnMessageBox.TooltipText = "";
            this.BtnMessageBox.UseVisualStyleBackColor = false;
            this.BtnMessageBox.ValidationFailedMessage = "Validation failed!";
            this.BtnMessageBox.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.BtnMessageBox.VerticalGradient = true;
            this.BtnMessageBox.ZOrder = 0;
            this.BtnMessageBox.Click += new System.EventHandler(this.BtnMessageBox_Click);
            // 
            // btnCharts
            // 
            this.btnCharts.ApplicationWideResource = true;
            this.btnCharts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnCharts.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnCharts.BackgroundImagePosition = "";
            this.btnCharts.BackgroundImageQuality = ((short)(80));
            this.btnCharts.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnCharts.ClassName = "";
            this.btnCharts.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCharts.CustomFontFamilies = "";
            this.btnCharts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCharts.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCharts.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnCharts.Icon = ((System.Drawing.Image)(resources.GetObject("btnCharts.Icon")));
            this.btnCharts.IconURL = "";
            this.btnCharts.Image = null;
            this.btnCharts.ImageLocation = "";
            this.btnCharts.Location = new System.Drawing.Point(516, 138);
            this.btnCharts.Name = "btnCharts";
            this.btnCharts.Opacity = 100;
            this.btnCharts.PreventMultipleClicks = true;
            this.btnCharts.Size = new System.Drawing.Size(162, 36);
            this.btnCharts.TabIndex = 36;
            this.btnCharts.Text = "Charts";
            this.btnCharts.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnCharts.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnCharts.TooltipText = "";
            this.btnCharts.UseVisualStyleBackColor = false;
            this.btnCharts.ValidationFailedMessage = "Validation failed!";
            this.btnCharts.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnCharts.VerticalGradient = true;
            this.btnCharts.ZOrder = 0;
            this.btnCharts.Click += new System.EventHandler(this.btnCharts_Click);
            // 
            // btnBrowser
            // 
            this.btnBrowser.ApplicationWideResource = true;
            this.btnBrowser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnBrowser.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnBrowser.BackgroundImagePosition = "";
            this.btnBrowser.BackgroundImageQuality = ((short)(80));
            this.btnBrowser.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnBrowser.ClassName = "";
            this.btnBrowser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBrowser.CustomFontFamilies = "";
            this.btnBrowser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBrowser.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowser.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnBrowser.Icon = ((System.Drawing.Image)(resources.GetObject("btnBrowser.Icon")));
            this.btnBrowser.IconURL = "";
            this.btnBrowser.Image = null;
            this.btnBrowser.ImageLocation = "";
            this.btnBrowser.Location = new System.Drawing.Point(516, 96);
            this.btnBrowser.Name = "btnBrowser";
            this.btnBrowser.Opacity = 100;
            this.btnBrowser.PreventMultipleClicks = true;
            this.btnBrowser.Size = new System.Drawing.Size(162, 36);
            this.btnBrowser.TabIndex = 37;
            this.btnBrowser.Text = "WebBrowser";
            this.btnBrowser.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnBrowser.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnBrowser.TooltipText = "";
            this.btnBrowser.UseVisualStyleBackColor = false;
            this.btnBrowser.ValidationFailedMessage = "Validation failed!";
            this.btnBrowser.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnBrowser.VerticalGradient = true;
            this.btnBrowser.ZOrder = 0;
            this.btnBrowser.Click += new System.EventHandler(this.btnBrowser_Click);
            // 
            // btnUploadFile
            // 
            this.btnUploadFile.ApplicationWideResource = true;
            this.btnUploadFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnUploadFile.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnUploadFile.BackgroundImagePosition = "";
            this.btnUploadFile.BackgroundImageQuality = ((short)(80));
            this.btnUploadFile.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnUploadFile.ClassName = "";
            this.btnUploadFile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUploadFile.CustomFontFamilies = "";
            this.btnUploadFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUploadFile.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUploadFile.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnUploadFile.Icon = ((System.Drawing.Image)(resources.GetObject("btnUploadFile.Icon")));
            this.btnUploadFile.IconURL = "";
            this.btnUploadFile.Image = null;
            this.btnUploadFile.ImageLocation = "";
            this.btnUploadFile.Location = new System.Drawing.Point(516, 54);
            this.btnUploadFile.Name = "btnUploadFile";
            this.btnUploadFile.Opacity = 100;
            this.btnUploadFile.PreventMultipleClicks = true;
            this.btnUploadFile.Size = new System.Drawing.Size(162, 36);
            this.btnUploadFile.TabIndex = 38;
            this.btnUploadFile.Text = "UploadFile";
            this.btnUploadFile.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnUploadFile.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnUploadFile.TooltipText = "";
            this.btnUploadFile.UseVisualStyleBackColor = false;
            this.btnUploadFile.ValidationFailedMessage = "Validation failed!";
            this.btnUploadFile.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnUploadFile.VerticalGradient = true;
            this.btnUploadFile.ZOrder = 0;
            this.btnUploadFile.Click += new System.EventHandler(this.btnUploadFile_Click);
            // 
            // btnTimer
            // 
            this.btnTimer.ApplicationWideResource = true;
            this.btnTimer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnTimer.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnTimer.BackgroundImagePosition = "";
            this.btnTimer.BackgroundImageQuality = ((short)(80));
            this.btnTimer.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnTimer.ClassName = "";
            this.btnTimer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTimer.CustomFontFamilies = "";
            this.btnTimer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTimer.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimer.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnTimer.Icon = ((System.Drawing.Image)(resources.GetObject("btnTimer.Icon")));
            this.btnTimer.IconURL = "";
            this.btnTimer.Image = null;
            this.btnTimer.ImageLocation = "";
            this.btnTimer.Location = new System.Drawing.Point(516, 12);
            this.btnTimer.Name = "btnTimer";
            this.btnTimer.Opacity = 100;
            this.btnTimer.PreventMultipleClicks = true;
            this.btnTimer.Size = new System.Drawing.Size(162, 36);
            this.btnTimer.TabIndex = 39;
            this.btnTimer.Text = "Timer";
            this.btnTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnTimer.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnTimer.TooltipText = "";
            this.btnTimer.UseVisualStyleBackColor = false;
            this.btnTimer.ValidationFailedMessage = "Validation failed!";
            this.btnTimer.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnTimer.VerticalGradient = true;
            this.btnTimer.ZOrder = 0;
            this.btnTimer.Click += new System.EventHandler(this.btnTimer_Click);
            // 
            // btnTextBox
            // 
            this.btnTextBox.ApplicationWideResource = true;
            this.btnTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnTextBox.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnTextBox.BackgroundImagePosition = "";
            this.btnTextBox.BackgroundImageQuality = ((short)(80));
            this.btnTextBox.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnTextBox.ClassName = "";
            this.btnTextBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTextBox.CustomFontFamilies = "";
            this.btnTextBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTextBox.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTextBox.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnTextBox.Icon = ((System.Drawing.Image)(resources.GetObject("btnTextBox.Icon")));
            this.btnTextBox.IconURL = "";
            this.btnTextBox.Image = null;
            this.btnTextBox.ImageLocation = "";
            this.btnTextBox.Location = new System.Drawing.Point(348, 264);
            this.btnTextBox.Name = "btnTextBox";
            this.btnTextBox.Opacity = 100;
            this.btnTextBox.PreventMultipleClicks = true;
            this.btnTextBox.Size = new System.Drawing.Size(162, 36);
            this.btnTextBox.TabIndex = 40;
            this.btnTextBox.Text = "TextBox";
            this.btnTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnTextBox.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnTextBox.TooltipText = "";
            this.btnTextBox.UseVisualStyleBackColor = false;
            this.btnTextBox.ValidationFailedMessage = "Validation failed!";
            this.btnTextBox.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnTextBox.VerticalGradient = true;
            this.btnTextBox.ZOrder = 0;
            this.btnTextBox.Click += new System.EventHandler(this.btnTextBox_Click);
            // 
            // btnTabs
            // 
            this.btnTabs.ApplicationWideResource = true;
            this.btnTabs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnTabs.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnTabs.BackgroundImagePosition = "";
            this.btnTabs.BackgroundImageQuality = ((short)(80));
            this.btnTabs.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnTabs.ClassName = "";
            this.btnTabs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTabs.CustomFontFamilies = "";
            this.btnTabs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTabs.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTabs.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnTabs.Icon = ((System.Drawing.Image)(resources.GetObject("btnTabs.Icon")));
            this.btnTabs.IconURL = "";
            this.btnTabs.Image = null;
            this.btnTabs.ImageLocation = "";
            this.btnTabs.Location = new System.Drawing.Point(348, 222);
            this.btnTabs.Name = "btnTabs";
            this.btnTabs.Opacity = 100;
            this.btnTabs.PreventMultipleClicks = true;
            this.btnTabs.Size = new System.Drawing.Size(162, 36);
            this.btnTabs.TabIndex = 41;
            this.btnTabs.Text = "Tabs";
            this.btnTabs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnTabs.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnTabs.TooltipText = "";
            this.btnTabs.UseVisualStyleBackColor = false;
            this.btnTabs.ValidationFailedMessage = "Validation failed!";
            this.btnTabs.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnTabs.VerticalGradient = true;
            this.btnTabs.ZOrder = 0;
            this.btnTabs.Click += new System.EventHandler(this.btnTabs_Click);
            // 
            // btnSlider
            // 
            this.btnSlider.ApplicationWideResource = true;
            this.btnSlider.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnSlider.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnSlider.BackgroundImagePosition = "";
            this.btnSlider.BackgroundImageQuality = ((short)(80));
            this.btnSlider.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnSlider.ClassName = "";
            this.btnSlider.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSlider.CustomFontFamilies = "";
            this.btnSlider.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSlider.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSlider.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnSlider.Icon = ((System.Drawing.Image)(resources.GetObject("btnSlider.Icon")));
            this.btnSlider.IconURL = "";
            this.btnSlider.Image = null;
            this.btnSlider.ImageLocation = "";
            this.btnSlider.Location = new System.Drawing.Point(348, 180);
            this.btnSlider.Name = "btnSlider";
            this.btnSlider.Opacity = 100;
            this.btnSlider.PreventMultipleClicks = true;
            this.btnSlider.Size = new System.Drawing.Size(162, 36);
            this.btnSlider.TabIndex = 42;
            this.btnSlider.Text = "SliderControl";
            this.btnSlider.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnSlider.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnSlider.TooltipText = "";
            this.btnSlider.UseVisualStyleBackColor = false;
            this.btnSlider.ValidationFailedMessage = "Validation failed!";
            this.btnSlider.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnSlider.VerticalGradient = true;
            this.btnSlider.ZOrder = 0;
            this.btnSlider.Click += new System.EventHandler(this.btnSlider_Click);
            // 
            // btnRichText
            // 
            this.btnRichText.ApplicationWideResource = true;
            this.btnRichText.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnRichText.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnRichText.BackgroundImagePosition = "";
            this.btnRichText.BackgroundImageQuality = ((short)(80));
            this.btnRichText.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnRichText.ClassName = "";
            this.btnRichText.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRichText.CustomFontFamilies = "";
            this.btnRichText.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRichText.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRichText.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnRichText.Icon = ((System.Drawing.Image)(resources.GetObject("btnRichText.Icon")));
            this.btnRichText.IconURL = "";
            this.btnRichText.Image = null;
            this.btnRichText.ImageLocation = "";
            this.btnRichText.Location = new System.Drawing.Point(348, 138);
            this.btnRichText.Name = "btnRichText";
            this.btnRichText.Opacity = 100;
            this.btnRichText.PreventMultipleClicks = true;
            this.btnRichText.Size = new System.Drawing.Size(162, 36);
            this.btnRichText.TabIndex = 43;
            this.btnRichText.Text = "RichTextBox";
            this.btnRichText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnRichText.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnRichText.TooltipText = "";
            this.btnRichText.UseVisualStyleBackColor = false;
            this.btnRichText.ValidationFailedMessage = "Validation failed!";
            this.btnRichText.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnRichText.VerticalGradient = true;
            this.btnRichText.ZOrder = 0;
            this.btnRichText.Click += new System.EventHandler(this.btnRichText_Click);
            // 
            // btnRadioButton
            // 
            this.btnRadioButton.ApplicationWideResource = true;
            this.btnRadioButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnRadioButton.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnRadioButton.BackgroundImagePosition = "";
            this.btnRadioButton.BackgroundImageQuality = ((short)(80));
            this.btnRadioButton.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnRadioButton.ClassName = "";
            this.btnRadioButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRadioButton.CustomFontFamilies = "";
            this.btnRadioButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRadioButton.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRadioButton.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnRadioButton.Icon = ((System.Drawing.Image)(resources.GetObject("btnRadioButton.Icon")));
            this.btnRadioButton.IconURL = "";
            this.btnRadioButton.Image = null;
            this.btnRadioButton.ImageLocation = "";
            this.btnRadioButton.Location = new System.Drawing.Point(348, 96);
            this.btnRadioButton.Name = "btnRadioButton";
            this.btnRadioButton.Opacity = 100;
            this.btnRadioButton.PreventMultipleClicks = true;
            this.btnRadioButton.Size = new System.Drawing.Size(162, 36);
            this.btnRadioButton.TabIndex = 44;
            this.btnRadioButton.Text = "RadioButton";
            this.btnRadioButton.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnRadioButton.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnRadioButton.TooltipText = "";
            this.btnRadioButton.UseVisualStyleBackColor = false;
            this.btnRadioButton.ValidationFailedMessage = "Validation failed!";
            this.btnRadioButton.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnRadioButton.VerticalGradient = true;
            this.btnRadioButton.ZOrder = 0;
            this.btnRadioButton.Click += new System.EventHandler(this.btnRadioButton_Click);
            // 
            // btnProgressBar
            // 
            this.btnProgressBar.ApplicationWideResource = true;
            this.btnProgressBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnProgressBar.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnProgressBar.BackgroundImagePosition = "";
            this.btnProgressBar.BackgroundImageQuality = ((short)(80));
            this.btnProgressBar.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnProgressBar.ClassName = "";
            this.btnProgressBar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProgressBar.CustomFontFamilies = "";
            this.btnProgressBar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProgressBar.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProgressBar.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnProgressBar.Icon = ((System.Drawing.Image)(resources.GetObject("btnProgressBar.Icon")));
            this.btnProgressBar.IconURL = "";
            this.btnProgressBar.Image = null;
            this.btnProgressBar.ImageLocation = "";
            this.btnProgressBar.Location = new System.Drawing.Point(348, 54);
            this.btnProgressBar.Name = "btnProgressBar";
            this.btnProgressBar.Opacity = 100;
            this.btnProgressBar.PreventMultipleClicks = true;
            this.btnProgressBar.Size = new System.Drawing.Size(162, 36);
            this.btnProgressBar.TabIndex = 45;
            this.btnProgressBar.Text = "ProgressBar";
            this.btnProgressBar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnProgressBar.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnProgressBar.TooltipText = "";
            this.btnProgressBar.UseVisualStyleBackColor = false;
            this.btnProgressBar.ValidationFailedMessage = "Validation failed!";
            this.btnProgressBar.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnProgressBar.VerticalGradient = true;
            this.btnProgressBar.ZOrder = 0;
            this.btnProgressBar.Click += new System.EventHandler(this.btnProgressBar_Click);
            // 
            // btnPictureBox
            // 
            this.btnPictureBox.ApplicationWideResource = true;
            this.btnPictureBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnPictureBox.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnPictureBox.BackgroundImagePosition = "";
            this.btnPictureBox.BackgroundImageQuality = ((short)(80));
            this.btnPictureBox.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnPictureBox.ClassName = "";
            this.btnPictureBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPictureBox.CustomFontFamilies = "";
            this.btnPictureBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPictureBox.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPictureBox.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnPictureBox.Icon = ((System.Drawing.Image)(resources.GetObject("btnPictureBox.Icon")));
            this.btnPictureBox.IconURL = "";
            this.btnPictureBox.Image = null;
            this.btnPictureBox.ImageLocation = "";
            this.btnPictureBox.Location = new System.Drawing.Point(348, 12);
            this.btnPictureBox.Name = "btnPictureBox";
            this.btnPictureBox.Opacity = 100;
            this.btnPictureBox.PreventMultipleClicks = true;
            this.btnPictureBox.Size = new System.Drawing.Size(162, 36);
            this.btnPictureBox.TabIndex = 46;
            this.btnPictureBox.Text = "PictureBox";
            this.btnPictureBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnPictureBox.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnPictureBox.TooltipText = "";
            this.btnPictureBox.UseVisualStyleBackColor = false;
            this.btnPictureBox.ValidationFailedMessage = "Validation failed!";
            this.btnPictureBox.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnPictureBox.VerticalGradient = true;
            this.btnPictureBox.ZOrder = 0;
            this.btnPictureBox.Click += new System.EventHandler(this.btnPictureBox_Click);
            // 
            // btnPanel
            // 
            this.btnPanel.ApplicationWideResource = true;
            this.btnPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnPanel.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnPanel.BackgroundImagePosition = "";
            this.btnPanel.BackgroundImageQuality = ((short)(80));
            this.btnPanel.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnPanel.ClassName = "";
            this.btnPanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPanel.CustomFontFamilies = "";
            this.btnPanel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPanel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPanel.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnPanel.Icon = ((System.Drawing.Image)(resources.GetObject("btnPanel.Icon")));
            this.btnPanel.IconURL = "";
            this.btnPanel.Image = null;
            this.btnPanel.ImageLocation = "";
            this.btnPanel.Location = new System.Drawing.Point(180, 264);
            this.btnPanel.Name = "btnPanel";
            this.btnPanel.Opacity = 100;
            this.btnPanel.PreventMultipleClicks = true;
            this.btnPanel.Size = new System.Drawing.Size(162, 36);
            this.btnPanel.TabIndex = 47;
            this.btnPanel.Text = "Panel";
            this.btnPanel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnPanel.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnPanel.TooltipText = "";
            this.btnPanel.UseVisualStyleBackColor = false;
            this.btnPanel.ValidationFailedMessage = "Validation failed!";
            this.btnPanel.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnPanel.VerticalGradient = true;
            this.btnPanel.ZOrder = 0;
            this.btnPanel.Click += new System.EventHandler(this.btnPanel_Click);
            // 
            // btnMaskedTextBox
            // 
            this.btnMaskedTextBox.ApplicationWideResource = true;
            this.btnMaskedTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnMaskedTextBox.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnMaskedTextBox.BackgroundImagePosition = "";
            this.btnMaskedTextBox.BackgroundImageQuality = ((short)(80));
            this.btnMaskedTextBox.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnMaskedTextBox.ClassName = "";
            this.btnMaskedTextBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMaskedTextBox.CustomFontFamilies = "";
            this.btnMaskedTextBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMaskedTextBox.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMaskedTextBox.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnMaskedTextBox.Icon = ((System.Drawing.Image)(resources.GetObject("btnMaskedTextBox.Icon")));
            this.btnMaskedTextBox.IconURL = "";
            this.btnMaskedTextBox.Image = null;
            this.btnMaskedTextBox.ImageLocation = "";
            this.btnMaskedTextBox.Location = new System.Drawing.Point(180, 222);
            this.btnMaskedTextBox.Name = "btnMaskedTextBox";
            this.btnMaskedTextBox.Opacity = 100;
            this.btnMaskedTextBox.PreventMultipleClicks = true;
            this.btnMaskedTextBox.Size = new System.Drawing.Size(162, 36);
            this.btnMaskedTextBox.TabIndex = 48;
            this.btnMaskedTextBox.Text = "MaskedTextBox";
            this.btnMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnMaskedTextBox.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnMaskedTextBox.TooltipText = "";
            this.btnMaskedTextBox.UseVisualStyleBackColor = false;
            this.btnMaskedTextBox.ValidationFailedMessage = "Validation failed!";
            this.btnMaskedTextBox.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnMaskedTextBox.VerticalGradient = true;
            this.btnMaskedTextBox.ZOrder = 0;
            this.btnMaskedTextBox.Click += new System.EventHandler(this.btnMaskedTextBox_Click);
            // 
            // btnListView
            // 
            this.btnListView.ApplicationWideResource = true;
            this.btnListView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnListView.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnListView.BackgroundImagePosition = "";
            this.btnListView.BackgroundImageQuality = ((short)(80));
            this.btnListView.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnListView.ClassName = "";
            this.btnListView.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnListView.CustomFontFamilies = "";
            this.btnListView.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnListView.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListView.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnListView.Icon = ((System.Drawing.Image)(resources.GetObject("btnListView.Icon")));
            this.btnListView.IconURL = "";
            this.btnListView.Image = null;
            this.btnListView.ImageLocation = "";
            this.btnListView.Location = new System.Drawing.Point(180, 180);
            this.btnListView.Name = "btnListView";
            this.btnListView.Opacity = 100;
            this.btnListView.PreventMultipleClicks = true;
            this.btnListView.Size = new System.Drawing.Size(162, 36);
            this.btnListView.TabIndex = 49;
            this.btnListView.Text = "ListView";
            this.btnListView.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnListView.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnListView.TooltipText = "";
            this.btnListView.UseVisualStyleBackColor = false;
            this.btnListView.ValidationFailedMessage = "Validation failed!";
            this.btnListView.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnListView.VerticalGradient = true;
            this.btnListView.ZOrder = 0;
            this.btnListView.Click += new System.EventHandler(this.btnListView_Click);
            // 
            // btnListBox
            // 
            this.btnListBox.ApplicationWideResource = true;
            this.btnListBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnListBox.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnListBox.BackgroundImagePosition = "";
            this.btnListBox.BackgroundImageQuality = ((short)(80));
            this.btnListBox.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnListBox.ClassName = "";
            this.btnListBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnListBox.CustomFontFamilies = "";
            this.btnListBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnListBox.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListBox.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnListBox.Icon = ((System.Drawing.Image)(resources.GetObject("btnListBox.Icon")));
            this.btnListBox.IconURL = "";
            this.btnListBox.Image = null;
            this.btnListBox.ImageLocation = "";
            this.btnListBox.Location = new System.Drawing.Point(180, 138);
            this.btnListBox.Name = "btnListBox";
            this.btnListBox.Opacity = 100;
            this.btnListBox.PreventMultipleClicks = true;
            this.btnListBox.Size = new System.Drawing.Size(162, 36);
            this.btnListBox.TabIndex = 50;
            this.btnListBox.Text = "ListBox";
            this.btnListBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnListBox.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnListBox.TooltipText = "";
            this.btnListBox.UseVisualStyleBackColor = false;
            this.btnListBox.ValidationFailedMessage = "Validation failed!";
            this.btnListBox.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnListBox.VerticalGradient = true;
            this.btnListBox.ZOrder = 0;
            this.btnListBox.Click += new System.EventHandler(this.btnListBox_Click);
            // 
            // btnLabels
            // 
            this.btnLabels.ApplicationWideResource = true;
            this.btnLabels.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnLabels.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnLabels.BackgroundImagePosition = "";
            this.btnLabels.BackgroundImageQuality = ((short)(80));
            this.btnLabels.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnLabels.ClassName = "";
            this.btnLabels.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLabels.CustomFontFamilies = "";
            this.btnLabels.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLabels.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLabels.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnLabels.Icon = ((System.Drawing.Image)(resources.GetObject("btnLabels.Icon")));
            this.btnLabels.IconURL = "";
            this.btnLabels.Image = null;
            this.btnLabels.ImageLocation = "";
            this.btnLabels.Location = new System.Drawing.Point(180, 96);
            this.btnLabels.Name = "btnLabels";
            this.btnLabels.Opacity = 100;
            this.btnLabels.PreventMultipleClicks = true;
            this.btnLabels.Size = new System.Drawing.Size(162, 36);
            this.btnLabels.TabIndex = 51;
            this.btnLabels.Text = "Labels";
            this.btnLabels.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnLabels.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnLabels.TooltipText = "";
            this.btnLabels.UseVisualStyleBackColor = false;
            this.btnLabels.ValidationFailedMessage = "Validation failed!";
            this.btnLabels.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnLabels.VerticalGradient = true;
            this.btnLabels.ZOrder = 0;
            this.btnLabels.Click += new System.EventHandler(this.btnLabels_Click);
            // 
            // btnFlashPlayer
            // 
            this.btnFlashPlayer.ApplicationWideResource = true;
            this.btnFlashPlayer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnFlashPlayer.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnFlashPlayer.BackgroundImagePosition = "";
            this.btnFlashPlayer.BackgroundImageQuality = ((short)(80));
            this.btnFlashPlayer.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnFlashPlayer.ClassName = "";
            this.btnFlashPlayer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFlashPlayer.CustomFontFamilies = "";
            this.btnFlashPlayer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFlashPlayer.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFlashPlayer.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnFlashPlayer.Icon = ((System.Drawing.Image)(resources.GetObject("btnFlashPlayer.Icon")));
            this.btnFlashPlayer.IconURL = "";
            this.btnFlashPlayer.Image = null;
            this.btnFlashPlayer.ImageLocation = "";
            this.btnFlashPlayer.Location = new System.Drawing.Point(180, 54);
            this.btnFlashPlayer.Name = "btnFlashPlayer";
            this.btnFlashPlayer.Opacity = 100;
            this.btnFlashPlayer.PreventMultipleClicks = true;
            this.btnFlashPlayer.Size = new System.Drawing.Size(162, 36);
            this.btnFlashPlayer.TabIndex = 52;
            this.btnFlashPlayer.Text = "FlashPlayer";
            this.btnFlashPlayer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnFlashPlayer.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnFlashPlayer.TooltipText = "";
            this.btnFlashPlayer.UseVisualStyleBackColor = false;
            this.btnFlashPlayer.ValidationFailedMessage = "Validation failed!";
            this.btnFlashPlayer.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnFlashPlayer.VerticalGradient = true;
            this.btnFlashPlayer.ZOrder = 0;
            this.btnFlashPlayer.Click += new System.EventHandler(this.btnFlashPlayer_Click);
            // 
            // btnFeedBox
            // 
            this.btnFeedBox.ApplicationWideResource = true;
            this.btnFeedBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnFeedBox.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnFeedBox.BackgroundImagePosition = "";
            this.btnFeedBox.BackgroundImageQuality = ((short)(80));
            this.btnFeedBox.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnFeedBox.ClassName = "";
            this.btnFeedBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFeedBox.CustomFontFamilies = "";
            this.btnFeedBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFeedBox.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFeedBox.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnFeedBox.Icon = ((System.Drawing.Image)(resources.GetObject("btnFeedBox.Icon")));
            this.btnFeedBox.IconURL = "";
            this.btnFeedBox.Image = null;
            this.btnFeedBox.ImageLocation = "";
            this.btnFeedBox.Location = new System.Drawing.Point(180, 12);
            this.btnFeedBox.Name = "btnFeedBox";
            this.btnFeedBox.Opacity = 100;
            this.btnFeedBox.PreventMultipleClicks = true;
            this.btnFeedBox.Size = new System.Drawing.Size(162, 36);
            this.btnFeedBox.TabIndex = 53;
            this.btnFeedBox.Text = "FeedBox";
            this.btnFeedBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnFeedBox.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnFeedBox.TooltipText = "";
            this.btnFeedBox.UseVisualStyleBackColor = false;
            this.btnFeedBox.ValidationFailedMessage = "Validation failed!";
            this.btnFeedBox.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnFeedBox.VerticalGradient = true;
            this.btnFeedBox.ZOrder = 0;
            this.btnFeedBox.Click += new System.EventHandler(this.btnFeedBox_Click);
            // 
            // btnDateTimePicker
            // 
            this.btnDateTimePicker.ApplicationWideResource = true;
            this.btnDateTimePicker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnDateTimePicker.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnDateTimePicker.BackgroundImagePosition = "";
            this.btnDateTimePicker.BackgroundImageQuality = ((short)(80));
            this.btnDateTimePicker.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnDateTimePicker.ClassName = "";
            this.btnDateTimePicker.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDateTimePicker.CustomFontFamilies = "";
            this.btnDateTimePicker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDateTimePicker.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDateTimePicker.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnDateTimePicker.Icon = ((System.Drawing.Image)(resources.GetObject("btnDateTimePicker.Icon")));
            this.btnDateTimePicker.IconURL = "";
            this.btnDateTimePicker.Image = null;
            this.btnDateTimePicker.ImageLocation = "";
            this.btnDateTimePicker.Location = new System.Drawing.Point(12, 264);
            this.btnDateTimePicker.Name = "btnDateTimePicker";
            this.btnDateTimePicker.Opacity = 100;
            this.btnDateTimePicker.PreventMultipleClicks = true;
            this.btnDateTimePicker.Size = new System.Drawing.Size(162, 36);
            this.btnDateTimePicker.TabIndex = 54;
            this.btnDateTimePicker.Text = "DateTimePicker";
            this.btnDateTimePicker.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnDateTimePicker.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnDateTimePicker.TooltipText = "";
            this.btnDateTimePicker.UseVisualStyleBackColor = false;
            this.btnDateTimePicker.ValidationFailedMessage = "Validation failed!";
            this.btnDateTimePicker.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnDateTimePicker.VerticalGradient = true;
            this.btnDateTimePicker.ZOrder = 0;
            this.btnDateTimePicker.Click += new System.EventHandler(this.btnDateTimePicker_Click);
            // 
            // btnMenu
            // 
            this.btnMenu.ApplicationWideResource = true;
            this.btnMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnMenu.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnMenu.BackgroundImagePosition = "";
            this.btnMenu.BackgroundImageQuality = ((short)(80));
            this.btnMenu.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnMenu.ClassName = "";
            this.btnMenu.ContextMenu = this.contextMenu1;
            this.btnMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMenu.CustomFontFamilies = "";
            this.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenu.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenu.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnMenu.Icon = ((System.Drawing.Image)(resources.GetObject("btnMenu.Icon")));
            this.btnMenu.IconURL = "";
            this.btnMenu.Image = null;
            this.btnMenu.ImageLocation = "";
            this.btnMenu.Location = new System.Drawing.Point(12, 222);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Opacity = 100;
            this.btnMenu.PreventMultipleClicks = true;
            this.btnMenu.Size = new System.Drawing.Size(162, 36);
            this.btnMenu.TabIndex = 55;
            this.btnMenu.Text = "ContextMenu";
            this.btnMenu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnMenu.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnMenu.TooltipText = "";
            this.btnMenu.UseVisualStyleBackColor = false;
            this.btnMenu.ValidationFailedMessage = "Validation failed!";
            this.btnMenu.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnMenu.VerticalGradient = true;
            this.btnMenu.ZOrder = 0;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnComboBox
            // 
            this.btnComboBox.ApplicationWideResource = true;
            this.btnComboBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnComboBox.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnComboBox.BackgroundImagePosition = "";
            this.btnComboBox.BackgroundImageQuality = ((short)(80));
            this.btnComboBox.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnComboBox.ClassName = "";
            this.btnComboBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnComboBox.CustomFontFamilies = "";
            this.btnComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnComboBox.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComboBox.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnComboBox.Icon = ((System.Drawing.Image)(resources.GetObject("btnComboBox.Icon")));
            this.btnComboBox.IconURL = "";
            this.btnComboBox.Image = null;
            this.btnComboBox.ImageLocation = "";
            this.btnComboBox.Location = new System.Drawing.Point(12, 180);
            this.btnComboBox.Name = "btnComboBox";
            this.btnComboBox.Opacity = 100;
            this.btnComboBox.PreventMultipleClicks = true;
            this.btnComboBox.Size = new System.Drawing.Size(162, 36);
            this.btnComboBox.TabIndex = 56;
            this.btnComboBox.Text = "ComboBox";
            this.btnComboBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnComboBox.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnComboBox.TooltipText = "";
            this.btnComboBox.UseVisualStyleBackColor = false;
            this.btnComboBox.ValidationFailedMessage = "Validation failed!";
            this.btnComboBox.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnComboBox.VerticalGradient = true;
            this.btnComboBox.ZOrder = 0;
            this.btnComboBox.Click += new System.EventHandler(this.btnComboBox_Click);
            // 
            // btnColorPicker
            // 
            this.btnColorPicker.ApplicationWideResource = true;
            this.btnColorPicker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnColorPicker.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnColorPicker.BackgroundImagePosition = "";
            this.btnColorPicker.BackgroundImageQuality = ((short)(80));
            this.btnColorPicker.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnColorPicker.ClassName = "";
            this.btnColorPicker.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColorPicker.CustomFontFamilies = "";
            this.btnColorPicker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColorPicker.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnColorPicker.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnColorPicker.Icon = ((System.Drawing.Image)(resources.GetObject("btnColorPicker.Icon")));
            this.btnColorPicker.IconURL = "";
            this.btnColorPicker.Image = null;
            this.btnColorPicker.ImageLocation = "";
            this.btnColorPicker.Location = new System.Drawing.Point(12, 138);
            this.btnColorPicker.Name = "btnColorPicker";
            this.btnColorPicker.Opacity = 100;
            this.btnColorPicker.PreventMultipleClicks = true;
            this.btnColorPicker.Size = new System.Drawing.Size(162, 36);
            this.btnColorPicker.TabIndex = 57;
            this.btnColorPicker.Text = "ColorPicker";
            this.btnColorPicker.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnColorPicker.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnColorPicker.TooltipText = "";
            this.btnColorPicker.UseVisualStyleBackColor = false;
            this.btnColorPicker.ValidationFailedMessage = "Validation failed!";
            this.btnColorPicker.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnColorPicker.VerticalGradient = true;
            this.btnColorPicker.ZOrder = 0;
            this.btnColorPicker.Click += new System.EventHandler(this.btnColorPicker_Click);
            // 
            // btnCheckBox
            // 
            this.btnCheckBox.ApplicationWideResource = true;
            this.btnCheckBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnCheckBox.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnCheckBox.BackgroundImagePosition = "";
            this.btnCheckBox.BackgroundImageQuality = ((short)(80));
            this.btnCheckBox.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnCheckBox.ClassName = "";
            this.btnCheckBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCheckBox.CustomFontFamilies = "";
            this.btnCheckBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCheckBox.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckBox.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnCheckBox.Icon = ((System.Drawing.Image)(resources.GetObject("btnCheckBox.Icon")));
            this.btnCheckBox.IconURL = "";
            this.btnCheckBox.Image = null;
            this.btnCheckBox.ImageLocation = "";
            this.btnCheckBox.Location = new System.Drawing.Point(12, 96);
            this.btnCheckBox.Name = "btnCheckBox";
            this.btnCheckBox.Opacity = 100;
            this.btnCheckBox.PreventMultipleClicks = true;
            this.btnCheckBox.Size = new System.Drawing.Size(162, 36);
            this.btnCheckBox.TabIndex = 58;
            this.btnCheckBox.Text = "CheckBox";
            this.btnCheckBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnCheckBox.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnCheckBox.TooltipText = "";
            this.btnCheckBox.UseVisualStyleBackColor = false;
            this.btnCheckBox.ValidationFailedMessage = "Validation failed!";
            this.btnCheckBox.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnCheckBox.VerticalGradient = true;
            this.btnCheckBox.ZOrder = 0;
            this.btnCheckBox.Click += new System.EventHandler(this.btnCheckBox_Click);
            // 
            // btnCaptcha
            // 
            this.btnCaptcha.ApplicationWideResource = true;
            this.btnCaptcha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnCaptcha.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnCaptcha.BackgroundImagePosition = "";
            this.btnCaptcha.BackgroundImageQuality = ((short)(80));
            this.btnCaptcha.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnCaptcha.ClassName = "";
            this.btnCaptcha.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCaptcha.CustomFontFamilies = "";
            this.btnCaptcha.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCaptcha.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaptcha.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnCaptcha.Icon = ((System.Drawing.Image)(resources.GetObject("btnCaptcha.Icon")));
            this.btnCaptcha.IconURL = "";
            this.btnCaptcha.Image = null;
            this.btnCaptcha.ImageLocation = "";
            this.btnCaptcha.Location = new System.Drawing.Point(12, 54);
            this.btnCaptcha.Name = "btnCaptcha";
            this.btnCaptcha.Opacity = 100;
            this.btnCaptcha.PreventMultipleClicks = true;
            this.btnCaptcha.Size = new System.Drawing.Size(162, 36);
            this.btnCaptcha.TabIndex = 59;
            this.btnCaptcha.Text = "CaptchaBox";
            this.btnCaptcha.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnCaptcha.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnCaptcha.TooltipText = "";
            this.btnCaptcha.UseVisualStyleBackColor = false;
            this.btnCaptcha.ValidationFailedMessage = "Validation failed!";
            this.btnCaptcha.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnCaptcha.VerticalGradient = true;
            this.btnCaptcha.ZOrder = 0;
            this.btnCaptcha.Click += new System.EventHandler(this.btnCaptcha_Click);
            // 
            // btnButtons
            // 
            this.btnButtons.ApplicationWideResource = true;
            this.btnButtons.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.btnButtons.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.btnButtons.BackgroundImagePosition = "";
            this.btnButtons.BackgroundImageQuality = ((short)(80));
            this.btnButtons.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.btnButtons.ClassName = "";
            this.btnButtons.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnButtons.CustomFontFamilies = "";
            this.btnButtons.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnButtons.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnButtons.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.btnButtons.Icon = ((System.Drawing.Image)(resources.GetObject("btnButtons.Icon")));
            this.btnButtons.IconURL = "";
            this.btnButtons.Image = null;
            this.btnButtons.ImageLocation = "";
            this.btnButtons.Location = new System.Drawing.Point(12, 12);
            this.btnButtons.Name = "btnButtons";
            this.btnButtons.Opacity = 100;
            this.btnButtons.PreventMultipleClicks = true;
            this.btnButtons.Size = new System.Drawing.Size(162, 36);
            this.btnButtons.TabIndex = 60;
            this.btnButtons.Text = "Buttons";
            this.btnButtons.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnButtons.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.btnButtons.TooltipText = "";
            this.btnButtons.UseVisualStyleBackColor = false;
            this.btnButtons.ValidationFailedMessage = "Validation failed!";
            this.btnButtons.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.btnButtons.VerticalGradient = true;
            this.btnButtons.ZOrder = 0;
            this.btnButtons.Click += new System.EventHandler(this.btnButtons_Click);
            // 
            // jButton1
            // 
            this.jButton1.ApplicationWideResource = true;
            this.jButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(237)))));
            this.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.jButton1.BackgroundImagePosition = "";
            this.jButton1.BackgroundImageQuality = ((short)(80));
            this.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY;
            this.jButton1.ClassName = "";
            this.jButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jButton1.CustomFontFamilies = "";
            this.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jButton1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jButton1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.jButton1.Icon = ((System.Drawing.Image)(resources.GetObject("jButton1.Icon")));
            this.jButton1.IconURL = "";
            this.jButton1.Image = null;
            this.jButton1.ImageLocation = "";
            this.jButton1.Location = new System.Drawing.Point(516, 222);
            this.jButton1.Name = "jButton1";
            this.jButton1.Opacity = 100;
            this.jButton1.PreventMultipleClicks = true;
            this.jButton1.Size = new System.Drawing.Size(162, 36);
            this.jButton1.TabIndex = 62;
            this.jButton1.Text = "UserControl";
            this.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East;
            this.jButton1.TooltipText = "";
            this.jButton1.UseVisualStyleBackColor = false;
            this.jButton1.ValidationFailedMessage = "Validation failed!";
            this.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never;
            this.jButton1.VerticalGradient = true;
            this.jButton1.ZOrder = 0;
            this.jButton1.Click += new System.EventHandler(this.jButton1_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.ClientSize = new System.Drawing.Size(690, 314);
            this.Controls.Add(this.jButton1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.BtnMessageBox);
            this.Controls.Add(this.btnCharts);
            this.Controls.Add(this.btnBrowser);
            this.Controls.Add(this.btnUploadFile);
            this.Controls.Add(this.btnTimer);
            this.Controls.Add(this.btnTextBox);
            this.Controls.Add(this.btnTabs);
            this.Controls.Add(this.btnSlider);
            this.Controls.Add(this.btnRichText);
            this.Controls.Add(this.btnRadioButton);
            this.Controls.Add(this.btnProgressBar);
            this.Controls.Add(this.btnPictureBox);
            this.Controls.Add(this.btnPanel);
            this.Controls.Add(this.btnMaskedTextBox);
            this.Controls.Add(this.btnListView);
            this.Controls.Add(this.btnListBox);
            this.Controls.Add(this.btnLabels);
            this.Controls.Add(this.btnFlashPlayer);
            this.Controls.Add(this.btnFeedBox);
            this.Controls.Add(this.btnDateTimePicker);
            this.Controls.Add(this.btnMenu);
            this.Controls.Add(this.btnComboBox);
            this.Controls.Add(this.btnColorPicker);
            this.Controls.Add(this.btnCheckBox);
            this.Controls.Add(this.btnCaptcha);
            this.Controls.Add(this.btnButtons);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.FormClosableByUser = false;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.PreferredScreenSize = new VisualJS.Kernel.ScreenWidth(801, 0);
            this.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen;
            this.Text = "VisualJS.NET Controls Sample";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private VisualJS.Web.Forms.JButton btnButtons;
        private VisualJS.Web.Forms.JButton btnCaptcha;
        private VisualJS.Web.Forms.JButton btnCheckBox;
        private VisualJS.Web.Forms.JButton btnColorPicker;
        private VisualJS.Web.Forms.JButton btnComboBox;
        private VisualJS.Web.Forms.JButton btnMenu;
        private VisualJS.Web.Forms.JButton btnDateTimePicker;
        private VisualJS.Web.Forms.JButton btnPanel;
        private VisualJS.Web.Forms.JButton btnMaskedTextBox;
        private VisualJS.Web.Forms.JButton btnListView;
        private VisualJS.Web.Forms.JButton btnListBox;
        private VisualJS.Web.Forms.JButton btnLabels;
        private VisualJS.Web.Forms.JButton btnFlashPlayer;
        private VisualJS.Web.Forms.JButton btnFeedBox;
        private VisualJS.Web.Forms.JButton btnTextBox;
        private VisualJS.Web.Forms.JButton btnTabs;
        private VisualJS.Web.Forms.JButton btnSlider;
        private VisualJS.Web.Forms.JButton btnRichText;
        private VisualJS.Web.Forms.JButton btnRadioButton;
        private VisualJS.Web.Forms.JButton btnProgressBar;
        private VisualJS.Web.Forms.JButton btnPictureBox;
        private VisualJS.Web.Forms.JButton BtnMessageBox;
        private VisualJS.Web.Forms.JButton btnCharts;
        private VisualJS.Web.Forms.JButton btnBrowser;
        private VisualJS.Web.Forms.JButton btnUploadFile;
        private VisualJS.Web.Forms.JButton btnTimer;
        private VisualJS.Web.Forms.PictureBox pictureBox1;
        private VisualJS.Web.Forms.ContextMenu contextMenu1;
        private System.Windows.Forms.MenuItem menuItem1;
        private System.Windows.Forms.MenuItem menuItem2;
        private System.Windows.Forms.MenuItem menuItem3;
        private System.Windows.Forms.MenuItem menuItem4;
        private VisualJS.Web.Forms.JButton jButton1;
    }
}