﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using VisualJS;
using VisualJS.Web.Forms;
using System.Linq;
using System.Text;

namespace VisualJSControlsSample.VisualJSApp
{
    using VisualJSControlsSample.SampleForms;

    public partial class MobileMainForm : VisualJS.Web.Forms.Form
    {
        public MobileMainForm()
        {
            InitializeComponent();
        }

        //Use the below constructor if you create the instance of this Form object other than the active Thread
        //otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        public MobileMainForm(string clientId)
            : base(clientId)
        {
            InitializeComponent(); 
        }
        
        private void jButton2_Click(object sender, EventArgs e)
        {
            if(progressBar1.Value>0)
                progressBar1.Value -= 5; 
        }

        private void jButton3_Click(object sender, EventArgs e)
        {
            if (progressBar1.Value < 100)
                progressBar1.Value += 5; 
        }

        private void jButton1_Click(object sender, EventArgs e)
        {
            if (!timer1.Enabled)
            {
                jButton1.Text = "Disable Server Time";
            }
            else
            {
                jButton1.Text = "Enable Server Time";
            }

            timer1.Enabled = !timer1.Enabled;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToLongTimeString();
        }

        private void jButton4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Question", "Did you like it?", MessageBoxIcons.Question, this, MessageBoxType.YesNo
                , delegate(MessageBoxResult result)
                {
                    if (result == MessageBoxResult.No)
                    {
                        MessageBox.Show("Why!!!", this);
                    }
                });
        }
    }
}