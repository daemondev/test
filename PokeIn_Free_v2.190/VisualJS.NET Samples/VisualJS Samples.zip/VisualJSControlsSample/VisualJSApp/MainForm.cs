﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using VisualJS;
using VisualJS.Web.Forms;
using System.Linq;
using System.Text;

namespace VisualJSControlsSample.VisualJSApp
{
    using VisualJSControlsSample.SampleForms;

    public partial class MainForm : VisualJS.Web.Forms.Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        //Use the below constructor if you create the instance of this Form object other than the active Thread
        //otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        public MainForm(string clientId): base(clientId)
        {
            InitializeComponent(); 
        }

        private void btnButtons_Click(object sender, EventArgs e)
        {
            new Buttons().ShowDialog();
        }

        private void btnCaptcha_Click(object sender, EventArgs e)
        {
            new CaptchaTest().ShowDialog();
        }

        private void btnCheckBox_Click(object sender, EventArgs e)
        {
            new CheckBoxTest().ShowDialog();
        }

        private void btnColorPicker_Click(object sender, EventArgs e)
        {
            new ColorPickerTest().ShowDialog();
        }

        private void btnComboBox_Click(object sender, EventArgs e)
        {
            new ComboBoxTest().ShowDialog();
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            //MessageBox Text accepts HTML code
            MessageBox.Show("Tip", "Try <strong>Right-Click</strong><br/>or<br/><strong>(Double finger Touch)</strong> on ContextMenu Button", MessageBoxIcons.Information, this);
        }

        //New Empty Window
        private void menuItem3_Click(object sender, EventArgs e)
        {
            new EmptyForm().Show();
        }

        //About
        private void menuItem1_Click(object sender, EventArgs e)
        {
            new frmAbout().ShowDialog();
        }

        //CheckBox Sample from Menu
        private void menuItem4_Click(object sender, EventArgs e)
        {
            new CheckBoxTest().ShowDialog();
        }

        private void btnDateTimePicker_Click(object sender, EventArgs e)
        {
            new DateTimePickerTest().ShowDialog();
        }

        private void btnBrowser_Click(object sender, EventArgs e)
        {
            new WebBrowserTest().ShowDialog();
        }

        private void btnFeedBox_Click(object sender, EventArgs e)
        {
            new FeedBoxTest().ShowDialog();
        }

        private void btnFlashPlayer_Click(object sender, EventArgs e)
        {
            new FlashPlayerTest().ShowDialog();
        }

        private void btnLabels_Click(object sender, EventArgs e)
        {
            new Labels().ShowDialog();
        }

        private void btnListBox_Click(object sender, EventArgs e)
        {
            new ListBoxTest().ShowDialog();
        }

        private void btnListView_Click(object sender, EventArgs e)
        {
            new ListViewTest().ShowDialog();
        }

        private void btnMaskedTextBox_Click(object sender, EventArgs e)
        {
            new MaskedTextBoxTest().ShowDialog();
        }

        private void btnPanel_Click(object sender, EventArgs e)
        {
            new PanelTest().ShowDialog();
        }

        private void btnPictureBox_Click(object sender, EventArgs e)
        {
            new PictureBoxTest().ShowDialog();
        }

        private void btnProgressBar_Click(object sender, EventArgs e)
        {
            new ProgressTest().ShowDialog();
        }

        private void btnRadioButton_Click(object sender, EventArgs e)
        {
            new RadioButtonTest().ShowDialog();
        }

        private void btnRichText_Click(object sender, EventArgs e)
        {
            new RichTextTest().ShowDialog();
        }

        private void btnSlider_Click(object sender, EventArgs e)
        {
            new SliderControlTest().ShowDialog();
        }

        private void btnTabs_Click(object sender, EventArgs e)
        {
            new TabsTest().ShowDialog();
        }

        private void btnTimer_Click(object sender, EventArgs e)
        {
            new TimerTest().ShowDialog();
        }

        private void btnTextBox_Click(object sender, EventArgs e)
        {
            new TextboxTest().ShowDialog();
        }

        private void btnUploadFile_Click(object sender, EventArgs e)
        {
            new UploadTest().ShowDialog();
        }

        private void btnCharts_Click(object sender, EventArgs e)
        {
            new ChartTest().ShowDialog();
        }

        private void BtnMessageBox_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Sample MessageBox", "VisualJS.NET MessageBox, accepts both <strong>HTML</strong> and text inputs.<br>Did you like it?",
                MessageBoxIcons.Information, this, MessageBoxType.YesNo, 
                delegate(MessageBoxResult result)
                {
                    if (result == MessageBoxResult.No)
                    {
                        MessageBox.Show("Why!", this);
                    }
                    else
                    {
                        MessageBox.Show("Thanks!", this);
                    }
                });
        }

        private void jButton1_Click(object sender, EventArgs e)
        {
            new CustomControl().ShowDialog();
        }
    }
}