﻿/*
 * VisualJS.NET UploadHandler File for PokeIn Comet Ajax Library
 */
using System;
using System.Collections.Generic;
using System.Net;
using System.Resources;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VisualJS;
using System.Reflection; 
using System.Text;

namespace VisualJSControlsSample.VisualJSApp
{
    public partial class PokeInHandler : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        { 
            //Similar to PokeIn.Handler
            VisualJS.Page.Handle(); 
        } 
    }
}