﻿Imports System
Imports VisualJS
Imports VisualJS.Kernel
Imports PokeIn.Comet

#Region "VisualJS.Kernel.VisualJSProjectKey - Do Not Edit"
'Right click to project under solution windows and then Register the project
<Assembly: VisualJS.Kernel.VisualJSProjectKey("NONE")> 
#End Region

NameSpace VisualJSControlsVB.VisualJSApp.Helper
    Public Class globalAsaxHelper

        Shared Sub Application_Start()
            'Using chunked mode transfers helps reducing load
            CometSettings.ChunkedMode = True

            'enable below line in order to use Chart Support (requires Settings.JQuerySupport is enabled)
            Settings.ChartSupport = True

            'use below line in order to activate built-in JQuery Support 1.7.1
            Settings.JQuerySupport = True

            'Update the below parameter with your own copy of JQuery to change the working version of JQuery
            'Settings.JQueryBase = .....

            Settings.ActiveTheme = VisualJS.Kernel.Theme.Default

            Dim MainForms() As Type = {
                GetType(VisualJSControlsVB.VisualJSApp.MainForm),
                GetType(VisualJSControlsVB.VisualJSApp.MobileMainForm)} 

            'For this sample project, we have defined the PreferredScreenSize on both main forms in order 
            'to activate VisualJS.NET's Automatic Form Selector by users' screen size
            Try
                VisualJS.Page.CreateApplication(MainForms)
            Catch Ex As VisualJS.Kernel.LicenseFailedException
                Throw
            End Try

            'Below event fires when a form open request is received from the client side
            'AddHandler VisualJS.Page.OnFormOpenRequest, New VisualJS.FormOpenDelegate(AddressOf Page_OnFormOpenRequest)

            'Use below event listener instead CometWorker.OnClientConnected for your VisualJS.NET applications
            'AddHandler VisualJS.Page.OnClientConnected, New DefineClassObjects(AddressOf Page_OnClientConnected)

            'Above rule applies to OnClientDisconnected
            'AddHandler VisualJS.Page.OnClientDisconnected, New ClientDisconnectedDelegate(AddressOf Page_OnClientDisconnected)
        End Sub

        Shared Sub Page_OnFormOpenRequest(ByVal details As ConnectionDetails, ByVal formName As String)

        End Sub

        Shared Sub Page_OnClientConnected(ByVal details As ConnectionDetails, ByRef classList As Dictionary(Of String, Object))

        End Sub

        Shared Sub Page_OnClientDisconnected(ByVal clientId As String)

        End Sub

    End Class
End Namespace
