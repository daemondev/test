﻿Namespace VisualJSControlsVB.VisualJSApp
    <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
    Partial Class MainForm
        Inherits VisualJS.Web.Forms.Form

        'Form overrides dispose to clean up the component list.
        <System.Diagnostics.DebuggerNonUserCode()> _
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            Try
                If disposing AndAlso components IsNot Nothing Then
                    components.Dispose()
                End If
            Finally
                MyBase.Dispose(disposing)
            End Try
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
            Me.pictureBox1 = New VisualJS.Web.Forms.PictureBox()
            Me.BtnMessageBox = New VisualJS.Web.Forms.JButton()
            Me.btnCharts = New VisualJS.Web.Forms.JButton()
            Me.btnBrowser = New VisualJS.Web.Forms.JButton()
            Me.btnUploadFile = New VisualJS.Web.Forms.JButton()
            Me.btnTimer = New VisualJS.Web.Forms.JButton()
            Me.btnTextBox = New VisualJS.Web.Forms.JButton()
            Me.btnTabs = New VisualJS.Web.Forms.JButton()
            Me.btnSlider = New VisualJS.Web.Forms.JButton()
            Me.btnRichText = New VisualJS.Web.Forms.JButton()
            Me.btnRadioButton = New VisualJS.Web.Forms.JButton()
            Me.btnProgressBar = New VisualJS.Web.Forms.JButton()
            Me.btnPictureBox = New VisualJS.Web.Forms.JButton()
            Me.btnPanel = New VisualJS.Web.Forms.JButton()
            Me.btnMaskedTextBox = New VisualJS.Web.Forms.JButton()
            Me.btnListView = New VisualJS.Web.Forms.JButton()
            Me.btnListBox = New VisualJS.Web.Forms.JButton()
            Me.btnLabels = New VisualJS.Web.Forms.JButton()
            Me.btnFlashPlayer = New VisualJS.Web.Forms.JButton()
            Me.btnFeedBox = New VisualJS.Web.Forms.JButton()
            Me.btnDateTimePicker = New VisualJS.Web.Forms.JButton()
            Me.btnMenu = New VisualJS.Web.Forms.JButton()
            Me.contextMenu1 = New VisualJS.Web.Forms.ContextMenu()
            Me.menuItem1 = New System.Windows.Forms.MenuItem()
            Me.menuItem2 = New System.Windows.Forms.MenuItem()
            Me.menuItem3 = New System.Windows.Forms.MenuItem()
            Me.menuItem4 = New System.Windows.Forms.MenuItem()
            Me.btnComboBox = New VisualJS.Web.Forms.JButton()
            Me.btnColorPicker = New VisualJS.Web.Forms.JButton()
            Me.btnCheckBox = New VisualJS.Web.Forms.JButton()
            Me.btnCaptcha = New VisualJS.Web.Forms.JButton()
            Me.btnButtons = New VisualJS.Web.Forms.JButton()
            Me.jButton1 = New VisualJS.Web.Forms.JButton()
            CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.SuspendLayout()
            '
            'pictureBox1
            '
            Me.pictureBox1.ApplicationWideResource = True
            Me.pictureBox1.ClassName = ""
            Me.pictureBox1.ErrorImage = CType(resources.GetObject("pictureBox1.ErrorImage"), System.Drawing.Image)
            Me.pictureBox1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.pictureBox1.Image = CType(resources.GetObject("pictureBox1.Image"), System.Drawing.Image)
            Me.pictureBox1.ImageLocation = ""
            Me.pictureBox1.ImageQuality = CType(80, Short)
            Me.pictureBox1.InitialImage = CType(resources.GetObject("pictureBox1.InitialImage"), System.Drawing.Image)
            Me.pictureBox1.Location = New System.Drawing.Point(527, 268)
            Me.pictureBox1.Name = "pictureBox1"
            Me.pictureBox1.Opacity = 100
            Me.pictureBox1.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.PNG
            Me.pictureBox1.Size = New System.Drawing.Size(140, 30)
            Me.pictureBox1.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal
            Me.pictureBox1.TabIndex = 61
            Me.pictureBox1.TabStop = False
            Me.pictureBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.pictureBox1.TooltipText = ""
            Me.pictureBox1.ZOrder = 0
            '
            'BtnMessageBox
            '
            Me.BtnMessageBox.ApplicationWideResource = True
            Me.BtnMessageBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.BtnMessageBox.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.BtnMessageBox.BackgroundImagePosition = ""
            Me.BtnMessageBox.BackgroundImageQuality = CType(80, Short)
            Me.BtnMessageBox.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.BtnMessageBox.ClassName = ""
            Me.BtnMessageBox.Cursor = System.Windows.Forms.Cursors.Hand
            Me.BtnMessageBox.CustomFontFamilies = ""
            Me.BtnMessageBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.BtnMessageBox.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.BtnMessageBox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.BtnMessageBox.Icon = CType(resources.GetObject("BtnMessageBox.Icon"), System.Drawing.Image)
            Me.BtnMessageBox.IconURL = ""
            Me.BtnMessageBox.Image = Nothing
            Me.BtnMessageBox.ImageLocation = ""
            Me.BtnMessageBox.Location = New System.Drawing.Point(516, 180)
            Me.BtnMessageBox.Name = "BtnMessageBox"
            Me.BtnMessageBox.Opacity = 100
            Me.BtnMessageBox.PreventMultipleClicks = True
            Me.BtnMessageBox.Size = New System.Drawing.Size(162, 36)
            Me.BtnMessageBox.TabIndex = 62
            Me.BtnMessageBox.Text = "MessageBox"
            Me.BtnMessageBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.BtnMessageBox.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.BtnMessageBox.TooltipText = ""
            Me.BtnMessageBox.UseVisualStyleBackColor = False
            Me.BtnMessageBox.ValidationFailedMessage = "Validation failed!"
            Me.BtnMessageBox.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.BtnMessageBox.VerticalGradient = True
            Me.BtnMessageBox.ZOrder = 0
            '
            'btnCharts
            '
            Me.btnCharts.ApplicationWideResource = True
            Me.btnCharts.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnCharts.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnCharts.BackgroundImagePosition = ""
            Me.btnCharts.BackgroundImageQuality = CType(80, Short)
            Me.btnCharts.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnCharts.ClassName = ""
            Me.btnCharts.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnCharts.CustomFontFamilies = ""
            Me.btnCharts.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnCharts.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnCharts.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnCharts.Icon = CType(resources.GetObject("btnCharts.Icon"), System.Drawing.Image)
            Me.btnCharts.IconURL = ""
            Me.btnCharts.Image = Nothing
            Me.btnCharts.ImageLocation = ""
            Me.btnCharts.Location = New System.Drawing.Point(516, 138)
            Me.btnCharts.Name = "btnCharts"
            Me.btnCharts.Opacity = 100
            Me.btnCharts.PreventMultipleClicks = True
            Me.btnCharts.Size = New System.Drawing.Size(162, 36)
            Me.btnCharts.TabIndex = 63
            Me.btnCharts.Text = "Charts"
            Me.btnCharts.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnCharts.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnCharts.TooltipText = ""
            Me.btnCharts.UseVisualStyleBackColor = False
            Me.btnCharts.ValidationFailedMessage = "Validation failed!"
            Me.btnCharts.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnCharts.VerticalGradient = True
            Me.btnCharts.ZOrder = 0
            '
            'btnBrowser
            '
            Me.btnBrowser.ApplicationWideResource = True
            Me.btnBrowser.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnBrowser.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnBrowser.BackgroundImagePosition = ""
            Me.btnBrowser.BackgroundImageQuality = CType(80, Short)
            Me.btnBrowser.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnBrowser.ClassName = ""
            Me.btnBrowser.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnBrowser.CustomFontFamilies = ""
            Me.btnBrowser.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnBrowser.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnBrowser.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnBrowser.Icon = CType(resources.GetObject("btnBrowser.Icon"), System.Drawing.Image)
            Me.btnBrowser.IconURL = ""
            Me.btnBrowser.Image = Nothing
            Me.btnBrowser.ImageLocation = ""
            Me.btnBrowser.Location = New System.Drawing.Point(516, 96)
            Me.btnBrowser.Name = "btnBrowser"
            Me.btnBrowser.Opacity = 100
            Me.btnBrowser.PreventMultipleClicks = True
            Me.btnBrowser.Size = New System.Drawing.Size(162, 36)
            Me.btnBrowser.TabIndex = 64
            Me.btnBrowser.Text = "WebBrowser"
            Me.btnBrowser.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnBrowser.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnBrowser.TooltipText = ""
            Me.btnBrowser.UseVisualStyleBackColor = False
            Me.btnBrowser.ValidationFailedMessage = "Validation failed!"
            Me.btnBrowser.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnBrowser.VerticalGradient = True
            Me.btnBrowser.ZOrder = 0
            '
            'btnUploadFile
            '
            Me.btnUploadFile.ApplicationWideResource = True
            Me.btnUploadFile.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnUploadFile.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnUploadFile.BackgroundImagePosition = ""
            Me.btnUploadFile.BackgroundImageQuality = CType(80, Short)
            Me.btnUploadFile.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnUploadFile.ClassName = ""
            Me.btnUploadFile.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnUploadFile.CustomFontFamilies = ""
            Me.btnUploadFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnUploadFile.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnUploadFile.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnUploadFile.Icon = CType(resources.GetObject("btnUploadFile.Icon"), System.Drawing.Image)
            Me.btnUploadFile.IconURL = ""
            Me.btnUploadFile.Image = Nothing
            Me.btnUploadFile.ImageLocation = ""
            Me.btnUploadFile.Location = New System.Drawing.Point(516, 54)
            Me.btnUploadFile.Name = "btnUploadFile"
            Me.btnUploadFile.Opacity = 100
            Me.btnUploadFile.PreventMultipleClicks = True
            Me.btnUploadFile.Size = New System.Drawing.Size(162, 36)
            Me.btnUploadFile.TabIndex = 65
            Me.btnUploadFile.Text = "UploadFile"
            Me.btnUploadFile.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnUploadFile.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnUploadFile.TooltipText = ""
            Me.btnUploadFile.UseVisualStyleBackColor = False
            Me.btnUploadFile.ValidationFailedMessage = "Validation failed!"
            Me.btnUploadFile.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnUploadFile.VerticalGradient = True
            Me.btnUploadFile.ZOrder = 0
            '
            'btnTimer
            '
            Me.btnTimer.ApplicationWideResource = True
            Me.btnTimer.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnTimer.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnTimer.BackgroundImagePosition = ""
            Me.btnTimer.BackgroundImageQuality = CType(80, Short)
            Me.btnTimer.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnTimer.ClassName = ""
            Me.btnTimer.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnTimer.CustomFontFamilies = ""
            Me.btnTimer.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnTimer.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnTimer.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnTimer.Icon = CType(resources.GetObject("btnTimer.Icon"), System.Drawing.Image)
            Me.btnTimer.IconURL = ""
            Me.btnTimer.Image = Nothing
            Me.btnTimer.ImageLocation = ""
            Me.btnTimer.Location = New System.Drawing.Point(516, 12)
            Me.btnTimer.Name = "btnTimer"
            Me.btnTimer.Opacity = 100
            Me.btnTimer.PreventMultipleClicks = True
            Me.btnTimer.Size = New System.Drawing.Size(162, 36)
            Me.btnTimer.TabIndex = 66
            Me.btnTimer.Text = "Timer"
            Me.btnTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnTimer.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnTimer.TooltipText = ""
            Me.btnTimer.UseVisualStyleBackColor = False
            Me.btnTimer.ValidationFailedMessage = "Validation failed!"
            Me.btnTimer.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnTimer.VerticalGradient = True
            Me.btnTimer.ZOrder = 0
            '
            'btnTextBox
            '
            Me.btnTextBox.ApplicationWideResource = True
            Me.btnTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnTextBox.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnTextBox.BackgroundImagePosition = ""
            Me.btnTextBox.BackgroundImageQuality = CType(80, Short)
            Me.btnTextBox.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnTextBox.ClassName = ""
            Me.btnTextBox.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnTextBox.CustomFontFamilies = ""
            Me.btnTextBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnTextBox.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnTextBox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnTextBox.Icon = CType(resources.GetObject("btnTextBox.Icon"), System.Drawing.Image)
            Me.btnTextBox.IconURL = ""
            Me.btnTextBox.Image = Nothing
            Me.btnTextBox.ImageLocation = ""
            Me.btnTextBox.Location = New System.Drawing.Point(348, 264)
            Me.btnTextBox.Name = "btnTextBox"
            Me.btnTextBox.Opacity = 100
            Me.btnTextBox.PreventMultipleClicks = True
            Me.btnTextBox.Size = New System.Drawing.Size(162, 36)
            Me.btnTextBox.TabIndex = 67
            Me.btnTextBox.Text = "TextBox"
            Me.btnTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnTextBox.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnTextBox.TooltipText = ""
            Me.btnTextBox.UseVisualStyleBackColor = False
            Me.btnTextBox.ValidationFailedMessage = "Validation failed!"
            Me.btnTextBox.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnTextBox.VerticalGradient = True
            Me.btnTextBox.ZOrder = 0
            '
            'btnTabs
            '
            Me.btnTabs.ApplicationWideResource = True
            Me.btnTabs.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnTabs.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnTabs.BackgroundImagePosition = ""
            Me.btnTabs.BackgroundImageQuality = CType(80, Short)
            Me.btnTabs.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnTabs.ClassName = ""
            Me.btnTabs.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnTabs.CustomFontFamilies = ""
            Me.btnTabs.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnTabs.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnTabs.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnTabs.Icon = CType(resources.GetObject("btnTabs.Icon"), System.Drawing.Image)
            Me.btnTabs.IconURL = ""
            Me.btnTabs.Image = Nothing
            Me.btnTabs.ImageLocation = ""
            Me.btnTabs.Location = New System.Drawing.Point(348, 222)
            Me.btnTabs.Name = "btnTabs"
            Me.btnTabs.Opacity = 100
            Me.btnTabs.PreventMultipleClicks = True
            Me.btnTabs.Size = New System.Drawing.Size(162, 36)
            Me.btnTabs.TabIndex = 68
            Me.btnTabs.Text = "Tabs"
            Me.btnTabs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnTabs.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnTabs.TooltipText = ""
            Me.btnTabs.UseVisualStyleBackColor = False
            Me.btnTabs.ValidationFailedMessage = "Validation failed!"
            Me.btnTabs.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnTabs.VerticalGradient = True
            Me.btnTabs.ZOrder = 0
            '
            'btnSlider
            '
            Me.btnSlider.ApplicationWideResource = True
            Me.btnSlider.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnSlider.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnSlider.BackgroundImagePosition = ""
            Me.btnSlider.BackgroundImageQuality = CType(80, Short)
            Me.btnSlider.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnSlider.ClassName = ""
            Me.btnSlider.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnSlider.CustomFontFamilies = ""
            Me.btnSlider.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnSlider.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnSlider.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnSlider.Icon = CType(resources.GetObject("btnSlider.Icon"), System.Drawing.Image)
            Me.btnSlider.IconURL = ""
            Me.btnSlider.Image = Nothing
            Me.btnSlider.ImageLocation = ""
            Me.btnSlider.Location = New System.Drawing.Point(348, 180)
            Me.btnSlider.Name = "btnSlider"
            Me.btnSlider.Opacity = 100
            Me.btnSlider.PreventMultipleClicks = True
            Me.btnSlider.Size = New System.Drawing.Size(162, 36)
            Me.btnSlider.TabIndex = 69
            Me.btnSlider.Text = "SliderControl"
            Me.btnSlider.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnSlider.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnSlider.TooltipText = ""
            Me.btnSlider.UseVisualStyleBackColor = False
            Me.btnSlider.ValidationFailedMessage = "Validation failed!"
            Me.btnSlider.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnSlider.VerticalGradient = True
            Me.btnSlider.ZOrder = 0
            '
            'btnRichText
            '
            Me.btnRichText.ApplicationWideResource = True
            Me.btnRichText.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnRichText.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnRichText.BackgroundImagePosition = ""
            Me.btnRichText.BackgroundImageQuality = CType(80, Short)
            Me.btnRichText.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnRichText.ClassName = ""
            Me.btnRichText.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnRichText.CustomFontFamilies = ""
            Me.btnRichText.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnRichText.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnRichText.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnRichText.Icon = CType(resources.GetObject("btnRichText.Icon"), System.Drawing.Image)
            Me.btnRichText.IconURL = ""
            Me.btnRichText.Image = Nothing
            Me.btnRichText.ImageLocation = ""
            Me.btnRichText.Location = New System.Drawing.Point(348, 138)
            Me.btnRichText.Name = "btnRichText"
            Me.btnRichText.Opacity = 100
            Me.btnRichText.PreventMultipleClicks = True
            Me.btnRichText.Size = New System.Drawing.Size(162, 36)
            Me.btnRichText.TabIndex = 70
            Me.btnRichText.Text = "RichTextBox"
            Me.btnRichText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnRichText.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnRichText.TooltipText = ""
            Me.btnRichText.UseVisualStyleBackColor = False
            Me.btnRichText.ValidationFailedMessage = "Validation failed!"
            Me.btnRichText.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnRichText.VerticalGradient = True
            Me.btnRichText.ZOrder = 0
            '
            'btnRadioButton
            '
            Me.btnRadioButton.ApplicationWideResource = True
            Me.btnRadioButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnRadioButton.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnRadioButton.BackgroundImagePosition = ""
            Me.btnRadioButton.BackgroundImageQuality = CType(80, Short)
            Me.btnRadioButton.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnRadioButton.ClassName = ""
            Me.btnRadioButton.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnRadioButton.CustomFontFamilies = ""
            Me.btnRadioButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnRadioButton.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnRadioButton.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnRadioButton.Icon = CType(resources.GetObject("btnRadioButton.Icon"), System.Drawing.Image)
            Me.btnRadioButton.IconURL = ""
            Me.btnRadioButton.Image = Nothing
            Me.btnRadioButton.ImageLocation = ""
            Me.btnRadioButton.Location = New System.Drawing.Point(348, 96)
            Me.btnRadioButton.Name = "btnRadioButton"
            Me.btnRadioButton.Opacity = 100
            Me.btnRadioButton.PreventMultipleClicks = True
            Me.btnRadioButton.Size = New System.Drawing.Size(162, 36)
            Me.btnRadioButton.TabIndex = 71
            Me.btnRadioButton.Text = "RadioButton"
            Me.btnRadioButton.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnRadioButton.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnRadioButton.TooltipText = ""
            Me.btnRadioButton.UseVisualStyleBackColor = False
            Me.btnRadioButton.ValidationFailedMessage = "Validation failed!"
            Me.btnRadioButton.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnRadioButton.VerticalGradient = True
            Me.btnRadioButton.ZOrder = 0
            '
            'btnProgressBar
            '
            Me.btnProgressBar.ApplicationWideResource = True
            Me.btnProgressBar.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnProgressBar.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnProgressBar.BackgroundImagePosition = ""
            Me.btnProgressBar.BackgroundImageQuality = CType(80, Short)
            Me.btnProgressBar.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnProgressBar.ClassName = ""
            Me.btnProgressBar.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnProgressBar.CustomFontFamilies = ""
            Me.btnProgressBar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnProgressBar.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnProgressBar.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnProgressBar.Icon = CType(resources.GetObject("btnProgressBar.Icon"), System.Drawing.Image)
            Me.btnProgressBar.IconURL = ""
            Me.btnProgressBar.Image = Nothing
            Me.btnProgressBar.ImageLocation = ""
            Me.btnProgressBar.Location = New System.Drawing.Point(348, 54)
            Me.btnProgressBar.Name = "btnProgressBar"
            Me.btnProgressBar.Opacity = 100
            Me.btnProgressBar.PreventMultipleClicks = True
            Me.btnProgressBar.Size = New System.Drawing.Size(162, 36)
            Me.btnProgressBar.TabIndex = 72
            Me.btnProgressBar.Text = "ProgressBar"
            Me.btnProgressBar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnProgressBar.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnProgressBar.TooltipText = ""
            Me.btnProgressBar.UseVisualStyleBackColor = False
            Me.btnProgressBar.ValidationFailedMessage = "Validation failed!"
            Me.btnProgressBar.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnProgressBar.VerticalGradient = True
            Me.btnProgressBar.ZOrder = 0
            '
            'btnPictureBox
            '
            Me.btnPictureBox.ApplicationWideResource = True
            Me.btnPictureBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnPictureBox.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnPictureBox.BackgroundImagePosition = ""
            Me.btnPictureBox.BackgroundImageQuality = CType(80, Short)
            Me.btnPictureBox.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnPictureBox.ClassName = ""
            Me.btnPictureBox.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnPictureBox.CustomFontFamilies = ""
            Me.btnPictureBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnPictureBox.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnPictureBox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnPictureBox.Icon = CType(resources.GetObject("btnPictureBox.Icon"), System.Drawing.Image)
            Me.btnPictureBox.IconURL = ""
            Me.btnPictureBox.Image = Nothing
            Me.btnPictureBox.ImageLocation = ""
            Me.btnPictureBox.Location = New System.Drawing.Point(348, 12)
            Me.btnPictureBox.Name = "btnPictureBox"
            Me.btnPictureBox.Opacity = 100
            Me.btnPictureBox.PreventMultipleClicks = True
            Me.btnPictureBox.Size = New System.Drawing.Size(162, 36)
            Me.btnPictureBox.TabIndex = 73
            Me.btnPictureBox.Text = "PictureBox"
            Me.btnPictureBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnPictureBox.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnPictureBox.TooltipText = ""
            Me.btnPictureBox.UseVisualStyleBackColor = False
            Me.btnPictureBox.ValidationFailedMessage = "Validation failed!"
            Me.btnPictureBox.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnPictureBox.VerticalGradient = True
            Me.btnPictureBox.ZOrder = 0
            '
            'btnPanel
            '
            Me.btnPanel.ApplicationWideResource = True
            Me.btnPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnPanel.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnPanel.BackgroundImagePosition = ""
            Me.btnPanel.BackgroundImageQuality = CType(80, Short)
            Me.btnPanel.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnPanel.ClassName = ""
            Me.btnPanel.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnPanel.CustomFontFamilies = ""
            Me.btnPanel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnPanel.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnPanel.Icon = CType(resources.GetObject("btnPanel.Icon"), System.Drawing.Image)
            Me.btnPanel.IconURL = ""
            Me.btnPanel.Image = Nothing
            Me.btnPanel.ImageLocation = ""
            Me.btnPanel.Location = New System.Drawing.Point(180, 264)
            Me.btnPanel.Name = "btnPanel"
            Me.btnPanel.Opacity = 100
            Me.btnPanel.PreventMultipleClicks = True
            Me.btnPanel.Size = New System.Drawing.Size(162, 36)
            Me.btnPanel.TabIndex = 74
            Me.btnPanel.Text = "Panel"
            Me.btnPanel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnPanel.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnPanel.TooltipText = ""
            Me.btnPanel.UseVisualStyleBackColor = False
            Me.btnPanel.ValidationFailedMessage = "Validation failed!"
            Me.btnPanel.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnPanel.VerticalGradient = True
            Me.btnPanel.ZOrder = 0
            '
            'btnMaskedTextBox
            '
            Me.btnMaskedTextBox.ApplicationWideResource = True
            Me.btnMaskedTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnMaskedTextBox.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnMaskedTextBox.BackgroundImagePosition = ""
            Me.btnMaskedTextBox.BackgroundImageQuality = CType(80, Short)
            Me.btnMaskedTextBox.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnMaskedTextBox.ClassName = ""
            Me.btnMaskedTextBox.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnMaskedTextBox.CustomFontFamilies = ""
            Me.btnMaskedTextBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnMaskedTextBox.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnMaskedTextBox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnMaskedTextBox.Icon = CType(resources.GetObject("btnMaskedTextBox.Icon"), System.Drawing.Image)
            Me.btnMaskedTextBox.IconURL = ""
            Me.btnMaskedTextBox.Image = Nothing
            Me.btnMaskedTextBox.ImageLocation = ""
            Me.btnMaskedTextBox.Location = New System.Drawing.Point(180, 222)
            Me.btnMaskedTextBox.Name = "btnMaskedTextBox"
            Me.btnMaskedTextBox.Opacity = 100
            Me.btnMaskedTextBox.PreventMultipleClicks = True
            Me.btnMaskedTextBox.Size = New System.Drawing.Size(162, 36)
            Me.btnMaskedTextBox.TabIndex = 75
            Me.btnMaskedTextBox.Text = "MaskedTextBox"
            Me.btnMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnMaskedTextBox.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnMaskedTextBox.TooltipText = ""
            Me.btnMaskedTextBox.UseVisualStyleBackColor = False
            Me.btnMaskedTextBox.ValidationFailedMessage = "Validation failed!"
            Me.btnMaskedTextBox.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnMaskedTextBox.VerticalGradient = True
            Me.btnMaskedTextBox.ZOrder = 0
            '
            'btnListView
            '
            Me.btnListView.ApplicationWideResource = True
            Me.btnListView.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnListView.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnListView.BackgroundImagePosition = ""
            Me.btnListView.BackgroundImageQuality = CType(80, Short)
            Me.btnListView.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnListView.ClassName = ""
            Me.btnListView.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnListView.CustomFontFamilies = ""
            Me.btnListView.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnListView.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnListView.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnListView.Icon = CType(resources.GetObject("btnListView.Icon"), System.Drawing.Image)
            Me.btnListView.IconURL = ""
            Me.btnListView.Image = Nothing
            Me.btnListView.ImageLocation = ""
            Me.btnListView.Location = New System.Drawing.Point(180, 180)
            Me.btnListView.Name = "btnListView"
            Me.btnListView.Opacity = 100
            Me.btnListView.PreventMultipleClicks = True
            Me.btnListView.Size = New System.Drawing.Size(162, 36)
            Me.btnListView.TabIndex = 76
            Me.btnListView.Text = "ListView"
            Me.btnListView.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnListView.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnListView.TooltipText = ""
            Me.btnListView.UseVisualStyleBackColor = False
            Me.btnListView.ValidationFailedMessage = "Validation failed!"
            Me.btnListView.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnListView.VerticalGradient = True
            Me.btnListView.ZOrder = 0
            '
            'btnListBox
            '
            Me.btnListBox.ApplicationWideResource = True
            Me.btnListBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnListBox.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnListBox.BackgroundImagePosition = ""
            Me.btnListBox.BackgroundImageQuality = CType(80, Short)
            Me.btnListBox.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnListBox.ClassName = ""
            Me.btnListBox.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnListBox.CustomFontFamilies = ""
            Me.btnListBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnListBox.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnListBox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnListBox.Icon = CType(resources.GetObject("btnListBox.Icon"), System.Drawing.Image)
            Me.btnListBox.IconURL = ""
            Me.btnListBox.Image = Nothing
            Me.btnListBox.ImageLocation = ""
            Me.btnListBox.Location = New System.Drawing.Point(180, 138)
            Me.btnListBox.Name = "btnListBox"
            Me.btnListBox.Opacity = 100
            Me.btnListBox.PreventMultipleClicks = True
            Me.btnListBox.Size = New System.Drawing.Size(162, 36)
            Me.btnListBox.TabIndex = 77
            Me.btnListBox.Text = "ListBox"
            Me.btnListBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnListBox.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnListBox.TooltipText = ""
            Me.btnListBox.UseVisualStyleBackColor = False
            Me.btnListBox.ValidationFailedMessage = "Validation failed!"
            Me.btnListBox.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnListBox.VerticalGradient = True
            Me.btnListBox.ZOrder = 0
            '
            'btnLabels
            '
            Me.btnLabels.ApplicationWideResource = True
            Me.btnLabels.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnLabels.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnLabels.BackgroundImagePosition = ""
            Me.btnLabels.BackgroundImageQuality = CType(80, Short)
            Me.btnLabels.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnLabels.ClassName = ""
            Me.btnLabels.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnLabels.CustomFontFamilies = ""
            Me.btnLabels.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnLabels.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnLabels.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnLabels.Icon = CType(resources.GetObject("btnLabels.Icon"), System.Drawing.Image)
            Me.btnLabels.IconURL = ""
            Me.btnLabels.Image = Nothing
            Me.btnLabels.ImageLocation = ""
            Me.btnLabels.Location = New System.Drawing.Point(180, 96)
            Me.btnLabels.Name = "btnLabels"
            Me.btnLabels.Opacity = 100
            Me.btnLabels.PreventMultipleClicks = True
            Me.btnLabels.Size = New System.Drawing.Size(162, 36)
            Me.btnLabels.TabIndex = 78
            Me.btnLabels.Text = "Labels"
            Me.btnLabels.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnLabels.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnLabels.TooltipText = ""
            Me.btnLabels.UseVisualStyleBackColor = False
            Me.btnLabels.ValidationFailedMessage = "Validation failed!"
            Me.btnLabels.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnLabels.VerticalGradient = True
            Me.btnLabels.ZOrder = 0
            '
            'btnFlashPlayer
            '
            Me.btnFlashPlayer.ApplicationWideResource = True
            Me.btnFlashPlayer.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnFlashPlayer.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnFlashPlayer.BackgroundImagePosition = ""
            Me.btnFlashPlayer.BackgroundImageQuality = CType(80, Short)
            Me.btnFlashPlayer.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnFlashPlayer.ClassName = ""
            Me.btnFlashPlayer.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnFlashPlayer.CustomFontFamilies = ""
            Me.btnFlashPlayer.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnFlashPlayer.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnFlashPlayer.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnFlashPlayer.Icon = CType(resources.GetObject("btnFlashPlayer.Icon"), System.Drawing.Image)
            Me.btnFlashPlayer.IconURL = ""
            Me.btnFlashPlayer.Image = Nothing
            Me.btnFlashPlayer.ImageLocation = ""
            Me.btnFlashPlayer.Location = New System.Drawing.Point(180, 54)
            Me.btnFlashPlayer.Name = "btnFlashPlayer"
            Me.btnFlashPlayer.Opacity = 100
            Me.btnFlashPlayer.PreventMultipleClicks = True
            Me.btnFlashPlayer.Size = New System.Drawing.Size(162, 36)
            Me.btnFlashPlayer.TabIndex = 79
            Me.btnFlashPlayer.Text = "FlashPlayer"
            Me.btnFlashPlayer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnFlashPlayer.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnFlashPlayer.TooltipText = ""
            Me.btnFlashPlayer.UseVisualStyleBackColor = False
            Me.btnFlashPlayer.ValidationFailedMessage = "Validation failed!"
            Me.btnFlashPlayer.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnFlashPlayer.VerticalGradient = True
            Me.btnFlashPlayer.ZOrder = 0
            '
            'btnFeedBox
            '
            Me.btnFeedBox.ApplicationWideResource = True
            Me.btnFeedBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnFeedBox.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnFeedBox.BackgroundImagePosition = ""
            Me.btnFeedBox.BackgroundImageQuality = CType(80, Short)
            Me.btnFeedBox.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnFeedBox.ClassName = ""
            Me.btnFeedBox.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnFeedBox.CustomFontFamilies = ""
            Me.btnFeedBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnFeedBox.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnFeedBox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnFeedBox.Icon = CType(resources.GetObject("btnFeedBox.Icon"), System.Drawing.Image)
            Me.btnFeedBox.IconURL = ""
            Me.btnFeedBox.Image = Nothing
            Me.btnFeedBox.ImageLocation = ""
            Me.btnFeedBox.Location = New System.Drawing.Point(180, 12)
            Me.btnFeedBox.Name = "btnFeedBox"
            Me.btnFeedBox.Opacity = 100
            Me.btnFeedBox.PreventMultipleClicks = True
            Me.btnFeedBox.Size = New System.Drawing.Size(162, 36)
            Me.btnFeedBox.TabIndex = 80
            Me.btnFeedBox.Text = "FeedBox"
            Me.btnFeedBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnFeedBox.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnFeedBox.TooltipText = ""
            Me.btnFeedBox.UseVisualStyleBackColor = False
            Me.btnFeedBox.ValidationFailedMessage = "Validation failed!"
            Me.btnFeedBox.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnFeedBox.VerticalGradient = True
            Me.btnFeedBox.ZOrder = 0
            '
            'btnDateTimePicker
            '
            Me.btnDateTimePicker.ApplicationWideResource = True
            Me.btnDateTimePicker.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnDateTimePicker.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnDateTimePicker.BackgroundImagePosition = ""
            Me.btnDateTimePicker.BackgroundImageQuality = CType(80, Short)
            Me.btnDateTimePicker.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnDateTimePicker.ClassName = ""
            Me.btnDateTimePicker.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnDateTimePicker.CustomFontFamilies = ""
            Me.btnDateTimePicker.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnDateTimePicker.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnDateTimePicker.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnDateTimePicker.Icon = CType(resources.GetObject("btnDateTimePicker.Icon"), System.Drawing.Image)
            Me.btnDateTimePicker.IconURL = ""
            Me.btnDateTimePicker.Image = Nothing
            Me.btnDateTimePicker.ImageLocation = ""
            Me.btnDateTimePicker.Location = New System.Drawing.Point(12, 264)
            Me.btnDateTimePicker.Name = "btnDateTimePicker"
            Me.btnDateTimePicker.Opacity = 100
            Me.btnDateTimePicker.PreventMultipleClicks = True
            Me.btnDateTimePicker.Size = New System.Drawing.Size(162, 36)
            Me.btnDateTimePicker.TabIndex = 81
            Me.btnDateTimePicker.Text = "DateTimePicker"
            Me.btnDateTimePicker.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnDateTimePicker.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnDateTimePicker.TooltipText = ""
            Me.btnDateTimePicker.UseVisualStyleBackColor = False
            Me.btnDateTimePicker.ValidationFailedMessage = "Validation failed!"
            Me.btnDateTimePicker.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnDateTimePicker.VerticalGradient = True
            Me.btnDateTimePicker.ZOrder = 0
            '
            'btnMenu
            '
            Me.btnMenu.ApplicationWideResource = True
            Me.btnMenu.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnMenu.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnMenu.BackgroundImagePosition = ""
            Me.btnMenu.BackgroundImageQuality = CType(80, Short)
            Me.btnMenu.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnMenu.ClassName = ""
            Me.btnMenu.ContextMenu = Me.contextMenu1
            Me.btnMenu.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnMenu.CustomFontFamilies = ""
            Me.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnMenu.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnMenu.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnMenu.Icon = CType(resources.GetObject("btnMenu.Icon"), System.Drawing.Image)
            Me.btnMenu.IconURL = ""
            Me.btnMenu.Image = Nothing
            Me.btnMenu.ImageLocation = ""
            Me.btnMenu.Location = New System.Drawing.Point(12, 222)
            Me.btnMenu.Name = "btnMenu"
            Me.btnMenu.Opacity = 100
            Me.btnMenu.PreventMultipleClicks = True
            Me.btnMenu.Size = New System.Drawing.Size(162, 36)
            Me.btnMenu.TabIndex = 82
            Me.btnMenu.Text = "ContextMenu"
            Me.btnMenu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnMenu.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnMenu.TooltipText = ""
            Me.btnMenu.UseVisualStyleBackColor = False
            Me.btnMenu.ValidationFailedMessage = "Validation failed!"
            Me.btnMenu.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnMenu.VerticalGradient = True
            Me.btnMenu.ZOrder = 0
            '
            'contextMenu1
            '
            Me.contextMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1, Me.menuItem2})
            '
            'menuItem1
            '
            Me.menuItem1.Index = 0
            Me.menuItem1.Text = "About"
            '
            'menuItem2
            '
            Me.menuItem2.Index = 1
            Me.menuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem3, Me.menuItem4})
            Me.menuItem2.Text = "Dialogs"
            '
            'menuItem3
            '
            Me.menuItem3.Index = 0
            Me.menuItem3.Text = "New Empty Window"
            '
            'menuItem4
            '
            Me.menuItem4.Index = 1
            Me.menuItem4.Text = "CheckBox Sample"
            '
            'btnComboBox
            '
            Me.btnComboBox.ApplicationWideResource = True
            Me.btnComboBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnComboBox.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnComboBox.BackgroundImagePosition = ""
            Me.btnComboBox.BackgroundImageQuality = CType(80, Short)
            Me.btnComboBox.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnComboBox.ClassName = ""
            Me.btnComboBox.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnComboBox.CustomFontFamilies = ""
            Me.btnComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnComboBox.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnComboBox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnComboBox.Icon = CType(resources.GetObject("btnComboBox.Icon"), System.Drawing.Image)
            Me.btnComboBox.IconURL = ""
            Me.btnComboBox.Image = Nothing
            Me.btnComboBox.ImageLocation = ""
            Me.btnComboBox.Location = New System.Drawing.Point(12, 180)
            Me.btnComboBox.Name = "btnComboBox"
            Me.btnComboBox.Opacity = 100
            Me.btnComboBox.PreventMultipleClicks = True
            Me.btnComboBox.Size = New System.Drawing.Size(162, 36)
            Me.btnComboBox.TabIndex = 83
            Me.btnComboBox.Text = "ComboBox"
            Me.btnComboBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnComboBox.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnComboBox.TooltipText = ""
            Me.btnComboBox.UseVisualStyleBackColor = False
            Me.btnComboBox.ValidationFailedMessage = "Validation failed!"
            Me.btnComboBox.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnComboBox.VerticalGradient = True
            Me.btnComboBox.ZOrder = 0
            '
            'btnColorPicker
            '
            Me.btnColorPicker.ApplicationWideResource = True
            Me.btnColorPicker.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnColorPicker.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnColorPicker.BackgroundImagePosition = ""
            Me.btnColorPicker.BackgroundImageQuality = CType(80, Short)
            Me.btnColorPicker.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnColorPicker.ClassName = ""
            Me.btnColorPicker.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnColorPicker.CustomFontFamilies = ""
            Me.btnColorPicker.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnColorPicker.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnColorPicker.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnColorPicker.Icon = CType(resources.GetObject("btnColorPicker.Icon"), System.Drawing.Image)
            Me.btnColorPicker.IconURL = ""
            Me.btnColorPicker.Image = Nothing
            Me.btnColorPicker.ImageLocation = ""
            Me.btnColorPicker.Location = New System.Drawing.Point(12, 138)
            Me.btnColorPicker.Name = "btnColorPicker"
            Me.btnColorPicker.Opacity = 100
            Me.btnColorPicker.PreventMultipleClicks = True
            Me.btnColorPicker.Size = New System.Drawing.Size(162, 36)
            Me.btnColorPicker.TabIndex = 84
            Me.btnColorPicker.Text = "ColorPicker"
            Me.btnColorPicker.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnColorPicker.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnColorPicker.TooltipText = ""
            Me.btnColorPicker.UseVisualStyleBackColor = False
            Me.btnColorPicker.ValidationFailedMessage = "Validation failed!"
            Me.btnColorPicker.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnColorPicker.VerticalGradient = True
            Me.btnColorPicker.ZOrder = 0
            '
            'btnCheckBox
            '
            Me.btnCheckBox.ApplicationWideResource = True
            Me.btnCheckBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnCheckBox.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnCheckBox.BackgroundImagePosition = ""
            Me.btnCheckBox.BackgroundImageQuality = CType(80, Short)
            Me.btnCheckBox.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnCheckBox.ClassName = ""
            Me.btnCheckBox.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnCheckBox.CustomFontFamilies = ""
            Me.btnCheckBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnCheckBox.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnCheckBox.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnCheckBox.Icon = CType(resources.GetObject("btnCheckBox.Icon"), System.Drawing.Image)
            Me.btnCheckBox.IconURL = ""
            Me.btnCheckBox.Image = Nothing
            Me.btnCheckBox.ImageLocation = ""
            Me.btnCheckBox.Location = New System.Drawing.Point(12, 96)
            Me.btnCheckBox.Name = "btnCheckBox"
            Me.btnCheckBox.Opacity = 100
            Me.btnCheckBox.PreventMultipleClicks = True
            Me.btnCheckBox.Size = New System.Drawing.Size(162, 36)
            Me.btnCheckBox.TabIndex = 85
            Me.btnCheckBox.Text = "CheckBox"
            Me.btnCheckBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnCheckBox.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnCheckBox.TooltipText = ""
            Me.btnCheckBox.UseVisualStyleBackColor = False
            Me.btnCheckBox.ValidationFailedMessage = "Validation failed!"
            Me.btnCheckBox.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnCheckBox.VerticalGradient = True
            Me.btnCheckBox.ZOrder = 0
            '
            'btnCaptcha
            '
            Me.btnCaptcha.ApplicationWideResource = True
            Me.btnCaptcha.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnCaptcha.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnCaptcha.BackgroundImagePosition = ""
            Me.btnCaptcha.BackgroundImageQuality = CType(80, Short)
            Me.btnCaptcha.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnCaptcha.ClassName = ""
            Me.btnCaptcha.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnCaptcha.CustomFontFamilies = ""
            Me.btnCaptcha.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnCaptcha.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnCaptcha.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnCaptcha.Icon = CType(resources.GetObject("btnCaptcha.Icon"), System.Drawing.Image)
            Me.btnCaptcha.IconURL = ""
            Me.btnCaptcha.Image = Nothing
            Me.btnCaptcha.ImageLocation = ""
            Me.btnCaptcha.Location = New System.Drawing.Point(12, 54)
            Me.btnCaptcha.Name = "btnCaptcha"
            Me.btnCaptcha.Opacity = 100
            Me.btnCaptcha.PreventMultipleClicks = True
            Me.btnCaptcha.Size = New System.Drawing.Size(162, 36)
            Me.btnCaptcha.TabIndex = 86
            Me.btnCaptcha.Text = "CaptchaBox"
            Me.btnCaptcha.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnCaptcha.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnCaptcha.TooltipText = ""
            Me.btnCaptcha.UseVisualStyleBackColor = False
            Me.btnCaptcha.ValidationFailedMessage = "Validation failed!"
            Me.btnCaptcha.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnCaptcha.VerticalGradient = True
            Me.btnCaptcha.ZOrder = 0
            '
            'btnButtons
            '
            Me.btnButtons.ApplicationWideResource = True
            Me.btnButtons.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.btnButtons.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.btnButtons.BackgroundImagePosition = ""
            Me.btnButtons.BackgroundImageQuality = CType(80, Short)
            Me.btnButtons.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.btnButtons.ClassName = ""
            Me.btnButtons.Cursor = System.Windows.Forms.Cursors.Hand
            Me.btnButtons.CustomFontFamilies = ""
            Me.btnButtons.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.btnButtons.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.btnButtons.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.btnButtons.Icon = CType(resources.GetObject("btnButtons.Icon"), System.Drawing.Image)
            Me.btnButtons.IconURL = ""
            Me.btnButtons.Image = Nothing
            Me.btnButtons.ImageLocation = ""
            Me.btnButtons.Location = New System.Drawing.Point(12, 12)
            Me.btnButtons.Name = "btnButtons"
            Me.btnButtons.Opacity = 100
            Me.btnButtons.PreventMultipleClicks = True
            Me.btnButtons.Size = New System.Drawing.Size(162, 36)
            Me.btnButtons.TabIndex = 87
            Me.btnButtons.Text = "Buttons"
            Me.btnButtons.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.btnButtons.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.btnButtons.TooltipText = ""
            Me.btnButtons.UseVisualStyleBackColor = False
            Me.btnButtons.ValidationFailedMessage = "Validation failed!"
            Me.btnButtons.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.btnButtons.VerticalGradient = True
            Me.btnButtons.ZOrder = 0
            '
            'jButton1
            '
            Me.jButton1.ApplicationWideResource = True
            Me.jButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton1.BackgroundImagePosition = ""
            Me.jButton1.BackgroundImageQuality = CType(80, Short)
            Me.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton1.ClassName = ""
            Me.jButton1.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton1.CustomFontFamilies = ""
            Me.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.jButton1.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton1.Icon = CType(resources.GetObject("jButton1.Icon"), System.Drawing.Image)
            Me.jButton1.IconURL = ""
            Me.jButton1.Image = Nothing
            Me.jButton1.ImageLocation = ""
            Me.jButton1.Location = New System.Drawing.Point(516, 222)
            Me.jButton1.Name = "jButton1"
            Me.jButton1.Opacity = 100
            Me.jButton1.PreventMultipleClicks = True
            Me.jButton1.Size = New System.Drawing.Size(162, 36)
            Me.jButton1.TabIndex = 89
            Me.jButton1.Text = "UserControl"
            Me.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton1.TooltipText = ""
            Me.jButton1.UseVisualStyleBackColor = False
            Me.jButton1.ValidationFailedMessage = "Validation failed!"
            Me.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton1.VerticalGradient = True
            Me.jButton1.ZOrder = 0
            '
            'MainForm
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
            Me.ClientSize = New System.Drawing.Size(690, 313)
            Me.Controls.Add(Me.jButton1)
            Me.Controls.Add(Me.pictureBox1)
            Me.Controls.Add(Me.BtnMessageBox)
            Me.Controls.Add(Me.btnCharts)
            Me.Controls.Add(Me.btnBrowser)
            Me.Controls.Add(Me.btnUploadFile)
            Me.Controls.Add(Me.btnTimer)
            Me.Controls.Add(Me.btnTextBox)
            Me.Controls.Add(Me.btnTabs)
            Me.Controls.Add(Me.btnSlider)
            Me.Controls.Add(Me.btnRichText)
            Me.Controls.Add(Me.btnRadioButton)
            Me.Controls.Add(Me.btnProgressBar)
            Me.Controls.Add(Me.btnPictureBox)
            Me.Controls.Add(Me.btnPanel)
            Me.Controls.Add(Me.btnMaskedTextBox)
            Me.Controls.Add(Me.btnListView)
            Me.Controls.Add(Me.btnListBox)
            Me.Controls.Add(Me.btnLabels)
            Me.Controls.Add(Me.btnFlashPlayer)
            Me.Controls.Add(Me.btnFeedBox)
            Me.Controls.Add(Me.btnDateTimePicker)
            Me.Controls.Add(Me.btnMenu)
            Me.Controls.Add(Me.btnComboBox)
            Me.Controls.Add(Me.btnColorPicker)
            Me.Controls.Add(Me.btnCheckBox)
            Me.Controls.Add(Me.btnCaptcha)
            Me.Controls.Add(Me.btnButtons)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.FormClosableByUser = False
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "MainForm"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "VisualJS.NET Controls Sample"
            CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
            Me.ResumeLayout(False)

        End Sub
        Private WithEvents pictureBox1 As VisualJS.Web.Forms.PictureBox
        Private WithEvents BtnMessageBox As VisualJS.Web.Forms.JButton
        Private WithEvents btnCharts As VisualJS.Web.Forms.JButton
        Private WithEvents btnBrowser As VisualJS.Web.Forms.JButton
        Private WithEvents btnUploadFile As VisualJS.Web.Forms.JButton
        Private WithEvents btnTimer As VisualJS.Web.Forms.JButton
        Private WithEvents btnTextBox As VisualJS.Web.Forms.JButton
        Private WithEvents btnTabs As VisualJS.Web.Forms.JButton
        Private WithEvents btnSlider As VisualJS.Web.Forms.JButton
        Private WithEvents btnRichText As VisualJS.Web.Forms.JButton
        Private WithEvents btnRadioButton As VisualJS.Web.Forms.JButton
        Private WithEvents btnProgressBar As VisualJS.Web.Forms.JButton
        Private WithEvents btnPictureBox As VisualJS.Web.Forms.JButton
        Private WithEvents btnPanel As VisualJS.Web.Forms.JButton
        Private WithEvents btnMaskedTextBox As VisualJS.Web.Forms.JButton
        Private WithEvents btnListView As VisualJS.Web.Forms.JButton
        Private WithEvents btnListBox As VisualJS.Web.Forms.JButton
        Private WithEvents btnLabels As VisualJS.Web.Forms.JButton
        Private WithEvents btnFlashPlayer As VisualJS.Web.Forms.JButton
        Private WithEvents btnFeedBox As VisualJS.Web.Forms.JButton
        Private WithEvents btnDateTimePicker As VisualJS.Web.Forms.JButton
        Private WithEvents btnMenu As VisualJS.Web.Forms.JButton
        Private WithEvents btnComboBox As VisualJS.Web.Forms.JButton
        Private WithEvents btnColorPicker As VisualJS.Web.Forms.JButton
        Private WithEvents btnCheckBox As VisualJS.Web.Forms.JButton
        Private WithEvents btnCaptcha As VisualJS.Web.Forms.JButton
        Private WithEvents btnButtons As VisualJS.Web.Forms.JButton
        Private WithEvents contextMenu1 As VisualJS.Web.Forms.ContextMenu
        Private WithEvents menuItem1 As System.Windows.Forms.MenuItem
        Private WithEvents menuItem2 As System.Windows.Forms.MenuItem
        Private WithEvents menuItem3 As System.Windows.Forms.MenuItem
        Private WithEvents menuItem4 As System.Windows.Forms.MenuItem
        Private WithEvents jButton1 As VisualJS.Web.Forms.JButton

    End Class
End Namespace