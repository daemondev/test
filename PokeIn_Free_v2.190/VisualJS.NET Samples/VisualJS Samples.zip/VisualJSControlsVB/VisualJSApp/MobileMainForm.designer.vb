﻿Namespace VisualJSControlsVB.VisualJSApp
    <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
    Partial Class MobileMainForm
        Inherits VisualJS.Web.Forms.Form

        'Form overrides dispose to clean up the component list.
        <System.Diagnostics.DebuggerNonUserCode()> _
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            Try
                If disposing AndAlso components IsNot Nothing Then
                    components.Dispose()
                End If
            Finally
                MyBase.Dispose(disposing)
            End Try
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            Me.components = New System.ComponentModel.Container()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MobileMainForm))
            Me.panel1 = New VisualJS.Web.Forms.Panel()
            Me.jButton4 = New VisualJS.Web.Forms.JButton()
            Me.label2 = New VisualJS.Web.Forms.Label()
            Me.jButton3 = New VisualJS.Web.Forms.JButton()
            Me.progressBar1 = New VisualJS.Web.Forms.ProgressBar()
            Me.jButton2 = New VisualJS.Web.Forms.JButton()
            Me.lblTime = New VisualJS.Web.Forms.Label()
            Me.jButton1 = New VisualJS.Web.Forms.JButton()
            Me.label1 = New VisualJS.Web.Forms.Label()
            Me.timer1 = New VisualJS.Web.Forms.Timer(Me.components)
            Me.pictureBox1 = New VisualJS.Web.Forms.PictureBox()
            Me.panel1.SuspendLayout()
            CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.SuspendLayout()
            '
            'panel1
            '
            Me.panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.panel1.ApplicationWideResource = True
            Me.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.panel1.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.panel1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.panel1.BackColor = System.Drawing.Color.Black
            Me.panel1.BackColorEnd = System.Drawing.Color.DimGray
            Me.panel1.BackgroundImagePosition = ""
            Me.panel1.BackgroundImageQuality = CType(80, Short)
            Me.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.panel1.BorderColor = System.Drawing.Color.Black
            Me.panel1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid
            Me.panel1.ClassName = ""
            Me.panel1.ClientID = Nothing
            Me.panel1.Controls.Add(Me.jButton4)
            Me.panel1.Controls.Add(Me.label2)
            Me.panel1.Controls.Add(Me.jButton3)
            Me.panel1.Controls.Add(Me.progressBar1)
            Me.panel1.Controls.Add(Me.jButton2)
            Me.panel1.Controls.Add(Me.lblTime)
            Me.panel1.Controls.Add(Me.jButton1)
            Me.panel1.Controls.Add(Me.label1)
            Me.panel1.Controls.Add(Me.pictureBox1)
            Me.panel1.CustomFontFamilies = ""
            Me.panel1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.panel1.HTML = ""
            Me.panel1.ImageLocation = ""
            Me.panel1.Location = New System.Drawing.Point(12, 12)
            Me.panel1.Name = "panel1"
            Me.panel1.Opacity = 100
            Me.panel1.Size = New System.Drawing.Size(277, 376)
            Me.panel1.TabIndex = 58
            Me.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.panel1.TooltipText = ""
            Me.panel1.VerticalGradient = True
            Me.panel1.ZOrder = 0
            '
            'jButton4
            '
            Me.jButton4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.jButton4.ApplicationWideResource = True
            Me.jButton4.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton4.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton4.BackgroundImagePosition = ""
            Me.jButton4.BackgroundImageQuality = CType(80, Short)
            Me.jButton4.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton4.ClassName = ""
            Me.jButton4.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton4.CustomFontFamilies = ""
            Me.jButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton4.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton4.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton4.Icon = Nothing
            Me.jButton4.IconURL = ""
            Me.jButton4.Image = Nothing
            Me.jButton4.ImageLocation = ""
            Me.jButton4.Location = New System.Drawing.Point(16, 325)
            Me.jButton4.Name = "jButton4"
            Me.jButton4.Opacity = 100
            Me.jButton4.PreventMultipleClicks = True
            Me.jButton4.Size = New System.Drawing.Size(247, 34)
            Me.jButton4.TabIndex = 0
            Me.jButton4.Text = "Show MessageBox"
            Me.jButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton4.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton4.TooltipText = ""
            Me.jButton4.UseVisualStyleBackColor = False
            Me.jButton4.ValidationFailedMessage = "Validation failed!"
            Me.jButton4.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton4.VerticalGradient = True
            Me.jButton4.ZOrder = 0
            '
            'label2
            '
            Me.label2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.label2.BackColor = System.Drawing.Color.Transparent
            Me.label2.ClassName = ""
            Me.label2.CustomFontFamilies = ""
            Me.label2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label2.ForeColor = System.Drawing.Color.WhiteSmoke
            Me.label2.Image = Nothing
            Me.label2.Location = New System.Drawing.Point(56, 210)
            Me.label2.Name = "label2"
            Me.label2.Opacity = 100
            Me.label2.Size = New System.Drawing.Size(167, 24)
            Me.label2.TabIndex = 43
            Me.label2.Text = "Try ProgressBar"
            Me.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label2.TooltipText = ""
            Me.label2.UseMnemonic = False
            Me.label2.ZOrder = 0
            '
            'jButton3
            '
            Me.jButton3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.jButton3.ApplicationWideResource = True
            Me.jButton3.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton3.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton3.BackgroundImagePosition = ""
            Me.jButton3.BackgroundImageQuality = CType(80, Short)
            Me.jButton3.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton3.ClassName = ""
            Me.jButton3.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton3.CustomFontFamilies = ""
            Me.jButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton3.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.jButton3.ForeColor = System.Drawing.Color.Black
            Me.jButton3.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton3.Icon = Nothing
            Me.jButton3.IconURL = ""
            Me.jButton3.Image = Nothing
            Me.jButton3.ImageLocation = ""
            Me.jButton3.Location = New System.Drawing.Point(229, 200)
            Me.jButton3.Name = "jButton3"
            Me.jButton3.Opacity = 100
            Me.jButton3.PreventMultipleClicks = True
            Me.jButton3.Size = New System.Drawing.Size(34, 34)
            Me.jButton3.TabIndex = 44
            Me.jButton3.Text = "+"
            Me.jButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton3.TooltipText = ""
            Me.jButton3.UseVisualStyleBackColor = False
            Me.jButton3.ValidationFailedMessage = "Validation failed!"
            Me.jButton3.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton3.VerticalGradient = True
            Me.jButton3.ZOrder = 0
            '
            'progressBar1
            '
            Me.progressBar1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.progressBar1.BackColor = System.Drawing.Color.WhiteSmoke
            Me.progressBar1.BarColor = System.Drawing.Color.DarkRed
            Me.progressBar1.BorderColor = System.Drawing.Color.White
            Me.progressBar1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid
            Me.progressBar1.ClassName = ""
            Me.progressBar1.CustomFontFamilies = ""
            Me.progressBar1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.progressBar1.ForeColor = System.Drawing.Color.Black
            Me.progressBar1.Location = New System.Drawing.Point(16, 240)
            Me.progressBar1.Name = "progressBar1"
            Me.progressBar1.Opacity = 100
            Me.progressBar1.Size = New System.Drawing.Size(247, 51)
            Me.progressBar1.TabIndex = 40
            Me.progressBar1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.progressBar1.TooltipText = ""
            Me.progressBar1.ZOrder = 0
            '
            'jButton2
            '
            Me.jButton2.ApplicationWideResource = True
            Me.jButton2.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton2.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton2.BackgroundImagePosition = ""
            Me.jButton2.BackgroundImageQuality = CType(80, Short)
            Me.jButton2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton2.ClassName = ""
            Me.jButton2.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton2.CustomFontFamilies = ""
            Me.jButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton2.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.jButton2.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton2.Icon = Nothing
            Me.jButton2.IconURL = ""
            Me.jButton2.Image = Nothing
            Me.jButton2.ImageLocation = ""
            Me.jButton2.Location = New System.Drawing.Point(16, 200)
            Me.jButton2.Name = "jButton2"
            Me.jButton2.Opacity = 100
            Me.jButton2.PreventMultipleClicks = True
            Me.jButton2.Size = New System.Drawing.Size(34, 34)
            Me.jButton2.TabIndex = 45
            Me.jButton2.Text = "-"
            Me.jButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton2.TooltipText = ""
            Me.jButton2.UseVisualStyleBackColor = False
            Me.jButton2.ValidationFailedMessage = "Validation failed!"
            Me.jButton2.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton2.VerticalGradient = True
            Me.jButton2.ZOrder = 0
            '
            'lblTime
            '
            Me.lblTime.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.lblTime.BackColor = System.Drawing.Color.Transparent
            Me.lblTime.ClassName = ""
            Me.lblTime.CustomFontFamilies = ""
            Me.lblTime.Font = New System.Drawing.Font("Arial", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.lblTime.ForeColor = System.Drawing.Color.Gold
            Me.lblTime.Image = Nothing
            Me.lblTime.Location = New System.Drawing.Point(16, 148)
            Me.lblTime.Name = "lblTime"
            Me.lblTime.Opacity = 100
            Me.lblTime.Size = New System.Drawing.Size(247, 36)
            Me.lblTime.TabIndex = 37
            Me.lblTime.Text = "00:00:00"
            Me.lblTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.lblTime.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.lblTime.TooltipText = ""
            Me.lblTime.UseMnemonic = False
            Me.lblTime.ZOrder = 0
            '
            'jButton1
            '
            Me.jButton1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.jButton1.ApplicationWideResource = True
            Me.jButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton1.BackgroundImagePosition = ""
            Me.jButton1.BackgroundImageQuality = CType(80, Short)
            Me.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton1.ClassName = ""
            Me.jButton1.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton1.CustomFontFamilies = ""
            Me.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton1.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton1.Icon = Nothing
            Me.jButton1.IconURL = ""
            Me.jButton1.Image = Nothing
            Me.jButton1.ImageLocation = ""
            Me.jButton1.Location = New System.Drawing.Point(16, 93)
            Me.jButton1.Name = "jButton1"
            Me.jButton1.Opacity = 100
            Me.jButton1.PreventMultipleClicks = True
            Me.jButton1.Size = New System.Drawing.Size(247, 34)
            Me.jButton1.TabIndex = 46
            Me.jButton1.Text = "Enable Server Time"
            Me.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton1.TooltipText = ""
            Me.jButton1.UseVisualStyleBackColor = False
            Me.jButton1.ValidationFailedMessage = "Validation failed!"
            Me.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton1.VerticalGradient = True
            Me.jButton1.ZOrder = 0
            '
            'label1
            '
            Me.label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.label1.BackColor = System.Drawing.Color.Transparent
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label1.ForeColor = System.Drawing.Color.WhiteSmoke
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(13, 53)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 100
            Me.label1.Size = New System.Drawing.Size(250, 37)
            Me.label1.TabIndex = 35
            Me.label1.Text = "Create cross-browser touch compatible applications easily"
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.ZOrder = 0
            '
            'timer1
            '
            Me.timer1.Interval = 999
            '
            'pictureBox1
            '
            Me.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Top
            Me.pictureBox1.ApplicationWideResource = True
            Me.pictureBox1.ClassName = ""
            Me.pictureBox1.ErrorImage = CType(resources.GetObject("pictureBox1.ErrorImage"), System.Drawing.Image)
            Me.pictureBox1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.pictureBox1.HoverImage = Nothing
            Me.pictureBox1.HoverImageLocation = ""
            Me.pictureBox1.Image = CType(resources.GetObject("pictureBox1.Image"), System.Drawing.Image)
            Me.pictureBox1.ImageLocation = ""
            Me.pictureBox1.ImageQuality = CType(80, Short)
            Me.pictureBox1.InitialImage = CType(resources.GetObject("pictureBox1.InitialImage"), System.Drawing.Image)
            Me.pictureBox1.Location = New System.Drawing.Point(60, 13)
            Me.pictureBox1.Name = "pictureBox1"
            Me.pictureBox1.Opacity = 100
            Me.pictureBox1.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.PNG
            Me.pictureBox1.Size = New System.Drawing.Size(150, 30)
            Me.pictureBox1.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal
            Me.pictureBox1.TabIndex = 34
            Me.pictureBox1.TabStop = False
            Me.pictureBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.pictureBox1.TooltipText = ""
            Me.pictureBox1.ZOrder = 0
            '
            'MobileMainForm
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.BackColor = System.Drawing.Color.WhiteSmoke
            Me.ClientSize = New System.Drawing.Size(300, 400)
            Me.Controls.Add(Me.panel1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
            Me.Name = "MobileMainForm"
            Me.Text = "MobileMainForm"
            Me.TouchPreferred = True
            Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
            Me.panel1.ResumeLayout(False)
            CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
            Me.ResumeLayout(False)

        End Sub
        Private WithEvents panel1 As VisualJS.Web.Forms.Panel
        Private WithEvents jButton4 As VisualJS.Web.Forms.JButton
        Private WithEvents label2 As VisualJS.Web.Forms.Label
        Private WithEvents jButton3 As VisualJS.Web.Forms.JButton
        Private WithEvents progressBar1 As VisualJS.Web.Forms.ProgressBar
        Private WithEvents jButton2 As VisualJS.Web.Forms.JButton
        Private WithEvents lblTime As VisualJS.Web.Forms.Label
        Private WithEvents jButton1 As VisualJS.Web.Forms.JButton
        Private WithEvents label1 As VisualJS.Web.Forms.Label
        Private WithEvents pictureBox1 As VisualJS.Web.Forms.PictureBox
        Private WithEvents timer1 As VisualJS.Web.Forms.Timer

    End Class
End Namespace