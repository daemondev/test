﻿'
' VisualJS.NET UploadHandler File for PokeIn Comet Ajax Library
'
NameSpace VisualJSApp
    Public Class PokeInHandler
        Inherits System.Web.UI.Page

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
            'Similar to PokeIn.Handler
            VisualJS.Page.Handle()
        End Sub

    End Class
End Namespace
