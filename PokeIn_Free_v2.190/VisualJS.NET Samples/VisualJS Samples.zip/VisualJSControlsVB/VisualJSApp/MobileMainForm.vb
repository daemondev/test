﻿Imports System
Imports System.Collections.Generic
Imports VisualJS.Web.Forms
Imports System.Drawing

Namespace VisualJSControlsVB.VisualJSApp
    Public Class MobileMainForm

#Region "Constructors"
        Public Sub New()
            ' This call is required by the designer.
            InitializeComponent()

            AfterInitialization()
            ' Add any initialization after the InitializeComponent() call.
        End Sub

        'Use the below constructor if you create the instance of this Form object other than the active Thread
        'otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        Public Sub New(clientId As String)
            MyBase.New(clientId)

            ' This call is required by the designer.
            InitializeComponent()

            AfterInitialization()
            ' Add any initialization after the InitializeComponent() call.

        End Sub
#End Region


        Sub AfterInitialization()
            'Use this method for the tasks after the initialization of the Form

        End Sub

        Private Sub jButton1_Click(sender As System.Object, e As System.EventArgs) Handles jButton1.Click
            If (timer1.Enabled) Then
                jButton1.Text = "Enable Server Time"
            Else
                jButton1.Text = "Disable Server Time"
            End If

            timer1.Enabled = Not timer1.Enabled
        End Sub

        Private Sub jButton3_Click(sender As System.Object, e As System.EventArgs) Handles jButton3.Click
            If (progressBar1.Value < 100) Then
                progressBar1.Value = progressBar1.Value + 5
            End If
        End Sub

        Private Sub jButton2_Click(sender As System.Object, e As System.EventArgs) Handles jButton2.Click
            If (progressBar1.Value > 0) Then
                progressBar1.Value = progressBar1.Value - 5
            End If
        End Sub

        Private Sub jButton4_Click(sender As System.Object, e As System.EventArgs) Handles jButton4.Click
            MessageBox.Show("Hello!", Me)
        End Sub
    End Class
End Namespace