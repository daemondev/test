﻿Imports System
Imports System.Collections.Generic
Imports VisualJS.Web.Forms
Imports System.Drawing
Imports VisualJSControlsVB.SampleForms

Namespace VisualJSControlsVB.VisualJSApp
    Public Class MainForm

#Region "Constructors"
        Public Sub New()
            ' This call is required by the designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.
        End Sub

        'Use the below constructor if you create the instance of this Form object other than the active Thread
        'otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        Public Sub New(clientId As String)
            MyBase.New(clientId)

            ' This call is required by the designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.

        End Sub
#End Region

        'Use below method for the tasks after the initialization of the Form
        Sub AfterInitialization()

        End Sub

        Private Sub btnButtons_Click(sender As System.Object, e As System.EventArgs) Handles btnButtons.Click
            Dim form As Buttons = New Buttons
            form.ShowDialog()
        End Sub

        Private Sub btnCaptcha_Click(sender As System.Object, e As System.EventArgs) Handles btnCaptcha.Click
            Dim form As CaptchaTest = New CaptchaTest
            form.ShowDialog()
        End Sub

        Private Sub btnCheckBox_Click(sender As System.Object, e As System.EventArgs) Handles btnCheckBox.Click
            Dim form As CheckBoxTest = New CheckBoxTest
            form.ShowDialog()
        End Sub

        Private Sub btnColorPicker_Click(sender As System.Object, e As System.EventArgs) Handles btnColorPicker.Click
            Dim form As ColorPickerTest = New ColorPickerTest
            form.ShowDialog()
        End Sub

        Private Sub btnComboBox_Click(sender As System.Object, e As System.EventArgs) Handles btnComboBox.Click
            Dim form As ComboBoxTest = New ComboBoxTest
            form.ShowDialog()
        End Sub

        Private Sub btnMenu_Click(sender As System.Object, e As System.EventArgs) Handles btnMenu.Click
            MessageBox.Show("Tip", "Try <strong>Right-Click</strong><br/>or<br/><strong>(Double finger Touch)</strong> on ContextMenu Button", MessageBoxIcons.Information, Me)
        End Sub

        Private Sub btnDateTimePicker_Click(sender As System.Object, e As System.EventArgs) Handles btnDateTimePicker.Click
            Dim form As DateTimePickerTest = New DateTimePickerTest
            form.ShowDialog()
        End Sub

        Private Sub btnFeedBox_Click(sender As System.Object, e As System.EventArgs) Handles btnFeedBox.Click
            Dim form As FeedBoxTest = New FeedBoxTest
            form.ShowDialog()
        End Sub

        Private Sub btnFlashPlayer_Click(sender As System.Object, e As System.EventArgs) Handles btnFlashPlayer.Click
            Dim form As FlashPlayerTest = New FlashPlayerTest
            form.ShowDialog()
        End Sub

        Private Sub btnLabels_Click(sender As System.Object, e As System.EventArgs) Handles btnLabels.Click
            Dim form As Labels = New Labels
            form.ShowDialog()
        End Sub

        Private Sub btnListBox_Click(sender As System.Object, e As System.EventArgs) Handles btnListBox.Click
            Dim form As ListBoxTest = New ListBoxTest
            form.ShowDialog()
        End Sub

        Private Sub btnListView_Click(sender As System.Object, e As System.EventArgs) Handles btnListView.Click
            Dim form As ListViewTest = New ListViewTest
            form.ShowDialog()
        End Sub

        Private Sub btnMaskedTextBox_Click(sender As System.Object, e As System.EventArgs) Handles btnMaskedTextBox.Click
            Dim form As MaskedTextBoxTest = New MaskedTextBoxTest
            form.ShowDialog()
        End Sub

        Private Sub btnPanel_Click(sender As System.Object, e As System.EventArgs) Handles btnPanel.Click
            Dim form As PanelTest = New PanelTest
            form.ShowDialog()
        End Sub

        Private Sub btnPictureBox_Click(sender As System.Object, e As System.EventArgs) Handles btnPictureBox.Click
            Dim form As PictureBoxTest = New PictureBoxTest
            form.ShowDialog()
        End Sub

        Private Sub btnProgressBar_Click(sender As System.Object, e As System.EventArgs) Handles btnProgressBar.Click
            Dim form As ProgressTest = New ProgressTest
            form.ShowDialog()
        End Sub

        Private Sub btnRadioButton_Click(sender As System.Object, e As System.EventArgs) Handles btnRadioButton.Click
            Dim form As RadioButtonTest = New RadioButtonTest
            form.ShowDialog()
        End Sub

        Private Sub btnRichText_Click(sender As System.Object, e As System.EventArgs) Handles btnRichText.Click
            Dim form As RichTextTest = New RichTextTest
            form.ShowDialog()
        End Sub

        Private Sub btnSlider_Click(sender As System.Object, e As System.EventArgs) Handles btnSlider.Click
            Dim form As SliderControlTest = New SliderControlTest
            form.ShowDialog()
        End Sub

        Private Sub btnTabs_Click(sender As System.Object, e As System.EventArgs) Handles btnTabs.Click
            Dim form As TabsTest = New TabsTest
            form.ShowDialog()
        End Sub

        Private Sub btnTextBox_Click(sender As System.Object, e As System.EventArgs) Handles btnTextBox.Click
            Dim form As TextboxTest = New TextboxTest
            form.ShowDialog()
        End Sub

        Private Sub btnTimer_Click(sender As System.Object, e As System.EventArgs) Handles btnTimer.Click
            Dim form As TimerTest = New TimerTest
            form.ShowDialog()
        End Sub

        Private Sub btnUploadFile_Click(sender As System.Object, e As System.EventArgs) Handles btnUploadFile.Click
            Dim form As UploadTest = New UploadTest
            form.ShowDialog()
        End Sub

        Private Sub btnBrowser_Click(sender As System.Object, e As System.EventArgs) Handles btnBrowser.Click
            Dim form As WebBrowserTest = New WebBrowserTest
            form.ShowDialog()
        End Sub

        Private Sub btnCharts_Click(sender As System.Object, e As System.EventArgs) Handles btnCharts.Click
            Dim form As ChartTest = New ChartTest
            form.ShowDialog()
        End Sub

        Private Sub BtnMessageBox_Click(sender As System.Object, e As System.EventArgs) Handles BtnMessageBox.Click
            MessageBox.Show("Sample MessageBox", "VisualJS.NET MessageBox, accepts both <strong>HTML</strong> and text inputs.<br>Did you like it?",
                MessageBoxIcons.Information, Me, MessageBoxType.YesNo,
                Sub(result As MessageBoxResult)
                    If result = MessageBoxResult.No Then
                        MessageBox.Show("Why!", Me)
                    Else
                        MessageBox.Show("Thanks!", Me)
                    End If
                End Sub)
        End Sub

        Private Sub menuItem1_Click(sender As System.Object, e As System.EventArgs) Handles menuItem1.Click
            Dim form As frmAbout = New frmAbout
            form.ShowDialog()
        End Sub

        Private Sub menuItem3_Click(sender As System.Object, e As System.EventArgs) Handles menuItem3.Click
            Dim form As EmptyForm = New EmptyForm
            form.ShowDialog()
        End Sub

        Private Sub menuItem4_Click(sender As System.Object, e As System.EventArgs) Handles menuItem4.Click
            Dim form As CheckBoxTest = New CheckBoxTest
            form.ShowDialog()
        End Sub

        Private Sub jButton1_Click(sender As System.Object, e As System.EventArgs) Handles jButton1.Click
            Dim form As VisualJSControlsVB.SampleForms.CustomControl = New VisualJSControlsVB.SampleForms.CustomControl
            form.ShowDialog()
        End Sub
    End Class
End Namespace