﻿Imports VisualJS
Imports VisualJS.Web.Forms

Namespace VisualJSControlsVB
    Public Class MyCustomControl
        Inherits VisualJS.Web.Forms.UserControl
        Private WithEvents jButton1 As VisualJS.Web.Forms.JButton
        Private WithEvents textBox1 As VisualJS.Web.Forms.TextBox

        Public Sub New()
            InitializeComponent()
        End Sub

        Private Sub InitializeComponent()
            Me.textBox1 = New VisualJS.Web.Forms.TextBox()
            Me.jButton1 = New VisualJS.Web.Forms.JButton()
            Me.SuspendLayout()
            '
            'textBox1
            '
            Me.textBox1.CheckForEmail = False
            Me.textBox1.ClassName = ""
            Me.textBox1.CustomFontFamilies = ""
            Me.textBox1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.textBox1.Location = New System.Drawing.Point(6, 9)
            Me.textBox1.MaxLength = 65535
            Me.textBox1.MinLength = 3
            Me.textBox1.Name = "textBox1"
            Me.textBox1.Opacity = 100
            Me.textBox1.PreventSQLInjection = False
            Me.textBox1.RegexCheck = ""
            Me.textBox1.Size = New System.Drawing.Size(152, 21)
            Me.textBox1.TabIndex = 3
            Me.textBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.textBox1.TooltipText = ""
            Me.textBox1.ValidationMessage = "Enter Your Name"
            Me.textBox1.ZOrder = 0
            '
            'jButton1
            '
            Me.jButton1.ApplicationWideResource = True
            Me.jButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton1.BackgroundImagePosition = ""
            Me.jButton1.BackgroundImageQuality = CType(80, Short)
            Me.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton1.ClassName = ""
            Me.jButton1.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton1.CustomFontFamilies = ""
            Me.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton1.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton1.Icon = Nothing
            Me.jButton1.IconURL = ""
            Me.jButton1.Image = Nothing
            Me.jButton1.ImageLocation = ""
            Me.jButton1.Location = New System.Drawing.Point(164, 8)
            Me.jButton1.Name = "jButton1"
            Me.jButton1.Opacity = 100
            Me.jButton1.PreventMultipleClicks = True
            Me.jButton1.Size = New System.Drawing.Size(80, 23)
            Me.jButton1.TabIndex = 4
            Me.jButton1.Text = "Test Me"
            Me.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton1.TooltipText = ""
            Me.jButton1.UseVisualStyleBackColor = False
            Me.jButton1.ValidationFailedMessage = "Validation failed!"
            Me.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnParent
            Me.jButton1.VerticalGradient = True
            Me.jButton1.ZOrder = 0
            '
            'MyCustomControl
            '
            Me.BackColor = System.Drawing.Color.Gray
            Me.Controls.Add(Me.textBox1)
            Me.Controls.Add(Me.jButton1)
            Me.Name = "MyCustomControl"
            Me.Size = New System.Drawing.Size(254, 40)
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

        Private Sub jButton1_Click(sender As System.Object, e As System.EventArgs) Handles jButton1.Click
            MessageBox.Show("Hello " + textBox1.Text, Me.ParentForm)
        End Sub
    End Class
End Namespace
