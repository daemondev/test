
Namespace SampleForms
	Partial Class UploadTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(UploadTest))
            Me.uploadFile1 = New VisualJS.Web.Forms.UploadFile()
            Me.jButton1 = New VisualJS.Web.Forms.JButton()
            Me.pictureBox1 = New VisualJS.Web.Forms.PictureBox()
            Me.label1 = New VisualJS.Web.Forms.Label()
            Me.label2 = New VisualJS.Web.Forms.Label()
            CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.SuspendLayout()
            '
            'uploadFile1
            '
            Me.uploadFile1.BackColor = System.Drawing.Color.White
            Me.uploadFile1.FailText = "Failed!"
            Me.uploadFile1.FileNotSelectedMessage = "Select an image file"
            Me.uploadFile1.FileTypes = "*.jpg;*.gif;*.png"
            Me.uploadFile1.FinalizeText = "Finishing.."
            Me.uploadFile1.InvalidFileTypeMessage = "Invalid File Type. Only JPG, GIF or PNG"
            Me.uploadFile1.Location = New System.Drawing.Point(249, 33)
            Me.uploadFile1.Name = "uploadFile1"
            Me.uploadFile1.Size = New System.Drawing.Size(226, 23)
            Me.uploadFile1.SuccessText = "File Uploaded"
            Me.uploadFile1.TabIndex = 1
            Me.uploadFile1.UploadText = "Uploading.."
            Me.uploadFile1.ZOrder = 0
            '
            'jButton1
            '
            Me.jButton1.ApplicationWideResource = True
            Me.jButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton1.BackgroundImagePosition = ""
            Me.jButton1.BackgroundImageQuality = CType(80, Short)
            Me.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton1.ClassName = ""
            Me.jButton1.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton1.CustomFontFamilies = ""
            Me.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton1.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton1.Icon = Global.VisualJSControlsVB.My.Resources.Resources.uploadfile
            Me.jButton1.IconURL = ""
            Me.jButton1.Image = Nothing
            Me.jButton1.ImageLocation = ""
            Me.jButton1.Location = New System.Drawing.Point(334, 62)
            Me.jButton1.Name = "jButton1"
            Me.jButton1.Opacity = 100
            Me.jButton1.PreventMultipleClicks = True
            Me.jButton1.Size = New System.Drawing.Size(141, 29)
            Me.jButton1.TabIndex = 4
            Me.jButton1.Text = "Update The Image"
            Me.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton1.TooltipText = ""
            Me.jButton1.UseVisualStyleBackColor = False
            Me.jButton1.ValidationFailedMessage = "Validation failed!"
            Me.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnForm
            Me.jButton1.VerticalGradient = True
            Me.jButton1.ZOrder = 0
            '
            'pictureBox1
            '
            Me.pictureBox1.ApplicationWideResource = True
            Me.pictureBox1.BackColor = System.Drawing.Color.White
            Me.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            Me.pictureBox1.ClassName = ""
            Me.pictureBox1.ErrorImage = CType(resources.GetObject("pictureBox1.ErrorImage"), System.Drawing.Image)
            Me.pictureBox1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.pictureBox1.Image = Nothing
            Me.pictureBox1.ImageLocation = ""
            Me.pictureBox1.ImageQuality = CType(80, Short)
            Me.pictureBox1.InitialImage = CType(resources.GetObject("pictureBox1.InitialImage"), System.Drawing.Image)
            Me.pictureBox1.Location = New System.Drawing.Point(12, 12)
            Me.pictureBox1.Name = "pictureBox1"
            Me.pictureBox1.Opacity = 100
            Me.pictureBox1.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.JPG
            Me.pictureBox1.Size = New System.Drawing.Size(231, 181)
            Me.pictureBox1.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.StretchImage
            Me.pictureBox1.TabIndex = 0
            Me.pictureBox1.TabStop = False
            Me.pictureBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.pictureBox1.TooltipText = ""
            Me.pictureBox1.ZOrder = 0
            '
            'label1
            '
            Me.label1.AutoSize = True
            Me.label1.BackColor = System.Drawing.Color.Transparent
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(249, 15)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 100
            Me.label1.Size = New System.Drawing.Size(121, 15)
            Me.label1.TabIndex = 2
            Me.label1.Text = "Upload an image file"
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.ZOrder = 0
            '
            'label2
            '
            Me.label2.BackColor = System.Drawing.Color.Transparent
            Me.label2.ClassName = ""
            Me.label2.CustomFontFamilies = ""
            Me.label2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label2.ForeColor = System.Drawing.Color.DimGray
            Me.label2.Image = Nothing
            Me.label2.Location = New System.Drawing.Point(277, 119)
            Me.label2.Name = "label2"
            Me.label2.Opacity = 100
            Me.label2.Size = New System.Drawing.Size(148, 46)
            Me.label2.TabIndex = 3
            Me.label2.Text = "This demo only accepts gif, png and jpg types under 1mb"
            Me.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label2.TooltipText = ""
            Me.label2.UseMnemonic = False
            Me.label2.ZOrder = 0
            '
            'UploadTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(487, 208)
            Me.Controls.Add(Me.label2)
            Me.Controls.Add(Me.label1)
            Me.Controls.Add(Me.jButton1)
            Me.Controls.Add(Me.uploadFile1)
            Me.Controls.Add(Me.pictureBox1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "UploadTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "Upload Demo"
            CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

		#End Region

		Private pictureBox1 As VisualJS.Web.Forms.PictureBox
        Friend WithEvents uploadFile1 As VisualJS.Web.Forms.UploadFile
        Friend WithEvents jButton1 As VisualJS.Web.Forms.JButton
		Private label1 As VisualJS.Web.Forms.Label
		Private label2 As VisualJS.Web.Forms.Label
	End Class
End Namespace 
