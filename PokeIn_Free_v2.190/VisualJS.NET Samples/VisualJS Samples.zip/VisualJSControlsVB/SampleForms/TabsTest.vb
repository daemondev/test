
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports VisualJS
Imports VisualJS.Web.Forms
Imports System.Linq
Imports System.Text

Namespace SampleForms
	Public Partial Class TabsTest
		Inherits VisualJS.Web.Forms.Form

		#Region "Constructors"
		Public Sub New()
			InitializeComponent()
			AfterInitialization()
		End Sub

		'Use the below constructor if you create the instance of this Form object other than the active Thread
		'otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
		Public Sub New(clientId As String)
			MyBase.New(clientId)
			InitializeComponent()
			AfterInitialization()
		End Sub
		#End Region

		'Use below method for the tasks after the initialization of the Form
		Private Sub AfterInitialization()

		End Sub

        Private Sub jButton1_Click(sender As Object, e As EventArgs) Handles jButton1.Click
            If tabControl1.HeadersVisible Then
                jButton1.Text = "Show Headers"
            Else
                jButton1.Text = "Hide Headers"
            End If

            tabControl1.HeadersVisible = Not tabControl1.HeadersVisible
            comboBox1.Visible = Not comboBox1.Visible
            label1.Visible = Not label1.Visible
        End Sub

        Private Sub tabPage8_TabClosed(sender As Object, e As EventArgs) Handles tabPage8.TabClosed
            comboBox1.Items.RemoveAt(3)
        End Sub
	End Class
End Namespace 
