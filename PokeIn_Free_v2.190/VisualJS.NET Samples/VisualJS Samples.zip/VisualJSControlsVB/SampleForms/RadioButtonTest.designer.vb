
Namespace SampleForms
	Partial Class RadioButtonTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(RadioButtonTest))
            Me.panel1 = New VisualJS.Web.Forms.Panel()
            Me.label1 = New VisualJS.Web.Forms.Label()
            Me.pnlColor = New VisualJS.Web.Forms.Panel()
            Me.rdBlue = New VisualJS.Web.Forms.RadioButton()
            Me.rdGreen = New VisualJS.Web.Forms.RadioButton()
            Me.rdRed = New VisualJS.Web.Forms.RadioButton()
            Me.panel2 = New VisualJS.Web.Forms.Panel()
            Me.label2 = New VisualJS.Web.Forms.Label()
            Me.pnlColor2 = New VisualJS.Web.Forms.Panel()
            Me.radioButton1 = New VisualJS.Web.Forms.RadioButton()
            Me.radioButton2 = New VisualJS.Web.Forms.RadioButton()
            Me.radioButton3 = New VisualJS.Web.Forms.RadioButton()
            Me.panel1.SuspendLayout()
            Me.panel2.SuspendLayout()
            Me.SuspendLayout()
            '
            'panel1
            '
            Me.panel1.ApplicationWideResource = True
            Me.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.panel1.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.panel1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.panel1.BackColor = System.Drawing.Color.Transparent
            Me.panel1.BackColorEnd = System.Drawing.Color.Transparent
            Me.panel1.BackgroundImagePosition = ""
            Me.panel1.BackgroundImageQuality = CType(80, Short)
            Me.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.panel1.BorderColor = System.Drawing.Color.Black
            Me.panel1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Dotted
            Me.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            Me.panel1.ClassName = ""
            Me.panel1.ClientID = Nothing
            Me.panel1.Controls.Add(Me.label1)
            Me.panel1.Controls.Add(Me.pnlColor)
            Me.panel1.Controls.Add(Me.rdBlue)
            Me.panel1.Controls.Add(Me.rdGreen)
            Me.panel1.Controls.Add(Me.rdRed)
            Me.panel1.CustomFontFamilies = ""
            Me.panel1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.panel1.HTML = ""
            Me.panel1.ImageLocation = ""
            Me.panel1.Location = New System.Drawing.Point(12, 12)
            Me.panel1.Name = "panel1"
            Me.panel1.Opacity = 100
            Me.panel1.Size = New System.Drawing.Size(268, 100)
            Me.panel1.TabIndex = 0
            Me.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.panel1.TooltipText = ""
            Me.panel1.VerticalGradient = True
            Me.panel1.ZOrder = 0
            '
            'label1
            '
            Me.label1.AutoSize = True
            Me.label1.BackColor = System.Drawing.Color.Transparent
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label1.ForeColor = System.Drawing.Color.Silver
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(148, 78)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 100
            Me.label1.Size = New System.Drawing.Size(112, 15)
            Me.label1.TabIndex = 7
            Me.label1.Text = "RadioButton Group"
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.ZOrder = 0
            '
            'pnlColor
            '
            Me.pnlColor.ApplicationWideResource = True
            Me.pnlColor.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.pnlColor.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.pnlColor.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.pnlColor.BackColor = System.Drawing.Color.White
            Me.pnlColor.BackColorEnd = System.Drawing.Color.Transparent
            Me.pnlColor.BackgroundImagePosition = ""
            Me.pnlColor.BackgroundImageQuality = CType(80, Short)
            Me.pnlColor.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.pnlColor.BorderColor = System.Drawing.Color.Gray
            Me.pnlColor.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid
            Me.pnlColor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
            Me.pnlColor.ClassName = ""
            Me.pnlColor.ClientID = Nothing
            Me.pnlColor.CustomFontFamilies = ""
            Me.pnlColor.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.pnlColor.HTML = ""
            Me.pnlColor.ImageLocation = ""
            Me.pnlColor.Location = New System.Drawing.Point(161, 28)
            Me.pnlColor.Name = "pnlColor"
            Me.pnlColor.Opacity = 100
            Me.pnlColor.Size = New System.Drawing.Size(74, 39)
            Me.pnlColor.TabIndex = 6
            Me.pnlColor.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.pnlColor.TooltipText = ""
            Me.pnlColor.VerticalGradient = True
            Me.pnlColor.ZOrder = 0
            '
            'rdBlue
            '
            Me.rdBlue.BackColor = System.Drawing.Color.Transparent
            Me.rdBlue.ClassName = ""
            Me.rdBlue.CustomFontFamilies = ""
            Me.rdBlue.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.rdBlue.Image = Nothing
            Me.rdBlue.Location = New System.Drawing.Point(20, 62)
            Me.rdBlue.Name = "rdBlue"
            Me.rdBlue.Opacity = 100
            Me.rdBlue.Size = New System.Drawing.Size(72, 19)
            Me.rdBlue.TabIndex = 4
            Me.rdBlue.TabStop = True
            Me.rdBlue.Text = "Blue"
            Me.rdBlue.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.rdBlue.TooltipText = ""
            Me.rdBlue.UseMnemonic = False
            Me.rdBlue.UseVisualStyleBackColor = False
            Me.rdBlue.ZOrder = 0
            '
            'rdGreen
            '
            Me.rdGreen.BackColor = System.Drawing.Color.Transparent
            Me.rdGreen.ClassName = ""
            Me.rdGreen.CustomFontFamilies = ""
            Me.rdGreen.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.rdGreen.Image = Nothing
            Me.rdGreen.Location = New System.Drawing.Point(20, 37)
            Me.rdGreen.Name = "rdGreen"
            Me.rdGreen.Opacity = 100
            Me.rdGreen.Size = New System.Drawing.Size(72, 19)
            Me.rdGreen.TabIndex = 2
            Me.rdGreen.TabStop = True
            Me.rdGreen.Text = "Green"
            Me.rdGreen.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.rdGreen.TooltipText = ""
            Me.rdGreen.UseMnemonic = False
            Me.rdGreen.UseVisualStyleBackColor = False
            Me.rdGreen.ZOrder = 0
            '
            'rdRed
            '
            Me.rdRed.BackColor = System.Drawing.Color.Transparent
            Me.rdRed.ClassName = ""
            Me.rdRed.CustomFontFamilies = ""
            Me.rdRed.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.rdRed.Image = Nothing
            Me.rdRed.Location = New System.Drawing.Point(20, 12)
            Me.rdRed.Name = "rdRed"
            Me.rdRed.Opacity = 100
            Me.rdRed.Size = New System.Drawing.Size(72, 19)
            Me.rdRed.TabIndex = 5
            Me.rdRed.TabStop = True
            Me.rdRed.Text = "Red"
            Me.rdRed.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.rdRed.TooltipText = ""
            Me.rdRed.UseMnemonic = False
            Me.rdRed.UseVisualStyleBackColor = False
            Me.rdRed.ZOrder = 0
            '
            'panel2
            '
            Me.panel2.ApplicationWideResource = True
            Me.panel2.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.panel2.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.panel2.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.panel2.BackColor = System.Drawing.Color.Transparent
            Me.panel2.BackColorEnd = System.Drawing.Color.Transparent
            Me.panel2.BackgroundImagePosition = ""
            Me.panel2.BackgroundImageQuality = CType(80, Short)
            Me.panel2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.panel2.BorderColor = System.Drawing.Color.Black
            Me.panel2.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Dotted
            Me.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            Me.panel2.ClassName = ""
            Me.panel2.ClientID = Nothing
            Me.panel2.Controls.Add(Me.label2)
            Me.panel2.Controls.Add(Me.pnlColor2)
            Me.panel2.Controls.Add(Me.radioButton1)
            Me.panel2.Controls.Add(Me.radioButton2)
            Me.panel2.Controls.Add(Me.radioButton3)
            Me.panel2.CustomFontFamilies = ""
            Me.panel2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.panel2.HTML = ""
            Me.panel2.ImageLocation = ""
            Me.panel2.Location = New System.Drawing.Point(12, 118)
            Me.panel2.Name = "panel2"
            Me.panel2.Opacity = 100
            Me.panel2.Size = New System.Drawing.Size(268, 100)
            Me.panel2.TabIndex = 1
            Me.panel2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.panel2.TooltipText = ""
            Me.panel2.VerticalGradient = True
            Me.panel2.ZOrder = 0
            '
            'label2
            '
            Me.label2.AutoSize = True
            Me.label2.BackColor = System.Drawing.Color.Transparent
            Me.label2.ClassName = ""
            Me.label2.CustomFontFamilies = ""
            Me.label2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label2.ForeColor = System.Drawing.Color.Silver
            Me.label2.Image = Nothing
            Me.label2.Location = New System.Drawing.Point(148, 78)
            Me.label2.Name = "label2"
            Me.label2.Opacity = 100
            Me.label2.Size = New System.Drawing.Size(112, 15)
            Me.label2.TabIndex = 7
            Me.label2.Text = "RadioButton Group"
            Me.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label2.TooltipText = ""
            Me.label2.UseMnemonic = False
            Me.label2.ZOrder = 0
            '
            'pnlColor2
            '
            Me.pnlColor2.ApplicationWideResource = True
            Me.pnlColor2.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.pnlColor2.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.pnlColor2.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.pnlColor2.BackColor = System.Drawing.Color.White
            Me.pnlColor2.BackColorEnd = System.Drawing.Color.Transparent
            Me.pnlColor2.BackgroundImagePosition = ""
            Me.pnlColor2.BackgroundImageQuality = CType(80, Short)
            Me.pnlColor2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.pnlColor2.BorderColor = System.Drawing.Color.Gray
            Me.pnlColor2.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.[Double]
            Me.pnlColor2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            Me.pnlColor2.ClassName = ""
            Me.pnlColor2.ClientID = Nothing
            Me.pnlColor2.CustomFontFamilies = ""
            Me.pnlColor2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.pnlColor2.HTML = ""
            Me.pnlColor2.ImageLocation = ""
            Me.pnlColor2.Location = New System.Drawing.Point(161, 28)
            Me.pnlColor2.Name = "pnlColor2"
            Me.pnlColor2.Opacity = 100
            Me.pnlColor2.Size = New System.Drawing.Size(74, 39)
            Me.pnlColor2.TabIndex = 6
            Me.pnlColor2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.pnlColor2.TooltipText = ""
            Me.pnlColor2.VerticalGradient = True
            Me.pnlColor2.ZOrder = 0
            '
            'radioButton1
            '
            Me.radioButton1.BackColor = System.Drawing.Color.Transparent
            Me.radioButton1.ClassName = ""
            Me.radioButton1.CustomFontFamilies = ""
            Me.radioButton1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.radioButton1.Image = Nothing
            Me.radioButton1.Location = New System.Drawing.Point(20, 62)
            Me.radioButton1.Name = "radioButton1"
            Me.radioButton1.Opacity = 100
            Me.radioButton1.Size = New System.Drawing.Size(72, 19)
            Me.radioButton1.TabIndex = 4
            Me.radioButton1.TabStop = True
            Me.radioButton1.Text = "Olive"
            Me.radioButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.radioButton1.TooltipText = ""
            Me.radioButton1.UseMnemonic = False
            Me.radioButton1.UseVisualStyleBackColor = False
            Me.radioButton1.ZOrder = 0
            '
            'radioButton2
            '
            Me.radioButton2.BackColor = System.Drawing.Color.Transparent
            Me.radioButton2.ClassName = ""
            Me.radioButton2.CustomFontFamilies = ""
            Me.radioButton2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.radioButton2.Image = Nothing
            Me.radioButton2.Location = New System.Drawing.Point(20, 37)
            Me.radioButton2.Name = "radioButton2"
            Me.radioButton2.Opacity = 100
            Me.radioButton2.Size = New System.Drawing.Size(72, 19)
            Me.radioButton2.TabIndex = 2
            Me.radioButton2.TabStop = True
            Me.radioButton2.Text = "Brown"
            Me.radioButton2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.radioButton2.TooltipText = ""
            Me.radioButton2.UseMnemonic = False
            Me.radioButton2.UseVisualStyleBackColor = False
            Me.radioButton2.ZOrder = 0
            '
            'radioButton3
            '
            Me.radioButton3.BackColor = System.Drawing.Color.Transparent
            Me.radioButton3.ClassName = ""
            Me.radioButton3.CustomFontFamilies = ""
            Me.radioButton3.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.radioButton3.Image = Nothing
            Me.radioButton3.Location = New System.Drawing.Point(20, 12)
            Me.radioButton3.Name = "radioButton3"
            Me.radioButton3.Opacity = 100
            Me.radioButton3.Size = New System.Drawing.Size(72, 19)
            Me.radioButton3.TabIndex = 5
            Me.radioButton3.TabStop = True
            Me.radioButton3.Text = "Orange"
            Me.radioButton3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.radioButton3.TooltipText = ""
            Me.radioButton3.UseMnemonic = False
            Me.radioButton3.UseVisualStyleBackColor = False
            Me.radioButton3.ZOrder = 0
            '
            'RadioButtonTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(296, 230)
            Me.Controls.Add(Me.panel2)
            Me.Controls.Add(Me.panel1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "RadioButtonTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "RadioButton Demo"
            Me.panel1.ResumeLayout(False)
            Me.panel1.PerformLayout()
            Me.panel2.ResumeLayout(False)
            Me.panel2.PerformLayout()
            Me.ResumeLayout(False)

        End Sub

		#End Region

		Private panel1 As VisualJS.Web.Forms.Panel
        Friend WithEvents rdBlue As VisualJS.Web.Forms.RadioButton
        Friend WithEvents rdGreen As VisualJS.Web.Forms.RadioButton
        Friend WithEvents rdRed As VisualJS.Web.Forms.RadioButton
		Private pnlColor As VisualJS.Web.Forms.Panel
		Private label1 As VisualJS.Web.Forms.Label
		Private panel2 As VisualJS.Web.Forms.Panel
		Private label2 As VisualJS.Web.Forms.Label
		Private pnlColor2 As VisualJS.Web.Forms.Panel
        Friend WithEvents radioButton1 As VisualJS.Web.Forms.RadioButton
        Friend WithEvents radioButton2 As VisualJS.Web.Forms.RadioButton
        Friend WithEvents radioButton3 As VisualJS.Web.Forms.RadioButton
	End Class
End Namespace 
