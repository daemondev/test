
Namespace SampleForms
	Partial Class TimerTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Me.components = New System.ComponentModel.Container()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(TimerTest))
            Me.label1 = New VisualJS.Web.Forms.Label()
            Me.label2 = New VisualJS.Web.Forms.Label()
            Me.timer1 = New VisualJS.Web.Forms.Timer(Me.components)
            Me.SuspendLayout()
            '
            'label1
            '
            Me.label1.AutoSize = True
            Me.label1.BackColor = System.Drawing.Color.Transparent
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(34, 82)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 100
            Me.label1.Size = New System.Drawing.Size(105, 29)
            Me.label1.TabIndex = 0
            Me.label1.Text = "00:00:00"
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.ZOrder = 0
            '
            'label2
            '
            Me.label2.BackColor = System.Drawing.Color.Khaki
            Me.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            Me.label2.ClassName = ""
            Me.label2.CustomFontFamilies = ""
            Me.label2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label2.Image = Nothing
            Me.label2.Location = New System.Drawing.Point(14, 9)
            Me.label2.Name = "label2"
            Me.label2.Opacity = 100
            Me.label2.Size = New System.Drawing.Size(143, 67)
            Me.label2.TabIndex = 1
            Me.label2.Text = "Server Side Time updated on the client side label by Timer control's Tick event"
            Me.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label2.TooltipText = ""
            Me.label2.UseMnemonic = False
            Me.label2.ZOrder = 0
            '
            'timer1
            '
            Me.timer1.Interval = 950
            '
            'TimerTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(176, 115)
            Me.Controls.Add(Me.label2)
            Me.Controls.Add(Me.label1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "TimerTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "Timer Demo"
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

		#End Region

		Private label1 As VisualJS.Web.Forms.Label
		Private label2 As VisualJS.Web.Forms.Label
        Private WithEvents timer1 As VisualJS.Web.Forms.Timer
	End Class
End Namespace 
