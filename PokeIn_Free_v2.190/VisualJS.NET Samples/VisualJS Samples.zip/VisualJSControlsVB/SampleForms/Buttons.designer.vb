
Namespace SampleForms
    Partial Class Buttons
        ''' <summary>
        ''' Required designer variable.
        ''' </summary>
        Private components As System.ComponentModel.IContainer = Nothing

        ''' <summary>
        ''' Clean up any resources being used.
        ''' </summary>
        ''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
        Protected Overrides Sub Dispose(disposing As Boolean)
            If disposing AndAlso (components IsNot Nothing) Then
                components.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub

#Region "Windows Form Designer generated code"

        ''' <summary>
        ''' Required method for Designer support - do not modify
        ''' the contents of this method with the code editor.
        ''' </summary>
        Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Buttons))
            Me.jButton1 = New VisualJS.Web.Forms.JButton()
            Me.label1 = New VisualJS.Web.Forms.Label()
            Me.jButton6 = New VisualJS.Web.Forms.JButton()
            Me.jButton5 = New VisualJS.Web.Forms.JButton()
            Me.jButton4 = New VisualJS.Web.Forms.JButton()
            Me.jButton3 = New VisualJS.Web.Forms.JButton()
            Me.jButton2 = New VisualJS.Web.Forms.JButton()
            Me.jButton7 = New VisualJS.Web.Forms.JButton()
            Me.jButton8 = New VisualJS.Web.Forms.JButton()
            Me.jButton9 = New VisualJS.Web.Forms.JButton()
            Me.jButton10 = New VisualJS.Web.Forms.JButton()
            Me.jButton11 = New VisualJS.Web.Forms.JButton()
            Me.button1 = New VisualJS.Web.Forms.Button()
            Me.textBox1 = New VisualJS.Web.Forms.TextBox()
            Me.label2 = New VisualJS.Web.Forms.Label()
            Me.button2 = New VisualJS.Web.Forms.Button()
            Me.jButton12 = New VisualJS.Web.Forms.JButton()
            Me.button3 = New VisualJS.Web.Forms.Button()
            Me.SuspendLayout()
            '
            'jButton1
            '
            Me.jButton1.ApplicationWideResource = True
            Me.jButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton1.BackgroundImagePosition = ""
            Me.jButton1.BackgroundImageQuality = CType(80, Short)
            Me.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton1.ClassName = ""
            Me.jButton1.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton1.CustomFontFamilies = ""
            Me.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton1.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton1.Icon = Nothing
            Me.jButton1.IconURL = ""
            Me.jButton1.Image = Nothing
            Me.jButton1.ImageLocation = ""
            Me.jButton1.Location = New System.Drawing.Point(12, 12)
            Me.jButton1.Name = "jButton1"
            Me.jButton1.Opacity = 100
            Me.jButton1.PreventMultipleClicks = True
            Me.jButton1.Size = New System.Drawing.Size(145, 23)
            Me.jButton1.TabIndex = 31
            Me.jButton1.Text = "Default JButton"
            Me.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton1.TooltipText = ""
            Me.jButton1.UseVisualStyleBackColor = False
            Me.jButton1.ValidationFailedMessage = "Validation failed!"
            Me.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton1.VerticalGradient = True
            Me.jButton1.ZOrder = 0
            '
            'label1
            '
            Me.label1.BackColor = System.Drawing.Color.Transparent
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(12, 48)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 100
            Me.label1.Size = New System.Drawing.Size(145, 49)
            Me.label1.TabIndex = 5
            Me.label1.Text = "Same Icon Resource Automatically Resizes by Button Size"
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.ZOrder = 0
            '
            'jButton6
            '
            Me.jButton6.ApplicationWideResource = True
            Me.jButton6.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton6.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton6.BackgroundImage = Global.VisualJSControlsVB.My.Resources.Resources.buttonImage
            Me.jButton6.BackgroundImagePosition = ""
            Me.jButton6.BackgroundImageQuality = CType(80, Short)
            Me.jButton6.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton6.ClassName = ""
            Me.jButton6.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton6.CustomFontFamilies = ""
            Me.jButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.jButton6.ForeColor = System.Drawing.Color.White
            Me.jButton6.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton6.Icon = Nothing
            Me.jButton6.IconURL = ""
            Me.jButton6.Image = Nothing
            Me.jButton6.ImageLocation = ""
            Me.jButton6.Location = New System.Drawing.Point(173, 12)
            Me.jButton6.Name = "jButton6"
            Me.jButton6.Opacity = 100
            Me.jButton6.PreventMultipleClicks = True
            Me.jButton6.Size = New System.Drawing.Size(145, 85)
            Me.jButton6.TabIndex = 26
            Me.jButton6.Text = "JButton with an Image"
            Me.jButton6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton6.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton6.TooltipText = ""
            Me.jButton6.UseVisualStyleBackColor = False
            Me.jButton6.ValidationFailedMessage = "Validation failed!"
            Me.jButton6.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton6.VerticalGradient = True
            Me.jButton6.ZOrder = 0
            '
            'jButton5
            '
            Me.jButton5.ApplicationWideResource = True
            Me.jButton5.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton5.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton5.BackgroundImagePosition = ""
            Me.jButton5.BackgroundImageQuality = CType(80, Short)
            Me.jButton5.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton5.ClassName = ""
            Me.jButton5.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton5.CustomFontFamilies = ""
            Me.jButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton5.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton5.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton5.Icon = Global.VisualJSControlsVB.My.Resources.Resources.Windows
            Me.jButton5.IconURL = ""
            Me.jButton5.Image = Nothing
            Me.jButton5.ImageLocation = ""
            Me.jButton5.Location = New System.Drawing.Point(12, 228)
            Me.jButton5.Name = "jButton5"
            Me.jButton5.Opacity = 100
            Me.jButton5.PreventMultipleClicks = True
            Me.jButton5.Size = New System.Drawing.Size(145, 55)
            Me.jButton5.TabIndex = 27
            Me.jButton5.Text = "JButton with Icon"
            Me.jButton5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton5.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton5.TooltipText = ""
            Me.jButton5.UseVisualStyleBackColor = False
            Me.jButton5.ValidationFailedMessage = "Validation failed!"
            Me.jButton5.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton5.VerticalGradient = True
            Me.jButton5.ZOrder = 0
            '
            'jButton4
            '
            Me.jButton4.ApplicationWideResource = True
            Me.jButton4.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton4.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton4.BackgroundImagePosition = ""
            Me.jButton4.BackgroundImageQuality = CType(80, Short)
            Me.jButton4.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton4.ClassName = ""
            Me.jButton4.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton4.CustomFontFamilies = ""
            Me.jButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton4.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton4.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton4.Icon = Global.VisualJSControlsVB.My.Resources.Resources.Windows
            Me.jButton4.IconURL = ""
            Me.jButton4.Image = Nothing
            Me.jButton4.ImageLocation = ""
            Me.jButton4.Location = New System.Drawing.Point(12, 179)
            Me.jButton4.Name = "jButton4"
            Me.jButton4.Opacity = 100
            Me.jButton4.PreventMultipleClicks = True
            Me.jButton4.Size = New System.Drawing.Size(145, 43)
            Me.jButton4.TabIndex = 28
            Me.jButton4.Text = "JButton with Icon"
            Me.jButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton4.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton4.TooltipText = ""
            Me.jButton4.UseVisualStyleBackColor = False
            Me.jButton4.ValidationFailedMessage = "Validation failed!"
            Me.jButton4.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton4.VerticalGradient = True
            Me.jButton4.ZOrder = 0
            '
            'jButton3
            '
            Me.jButton3.ApplicationWideResource = True
            Me.jButton3.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton3.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton3.BackgroundImagePosition = ""
            Me.jButton3.BackgroundImageQuality = CType(80, Short)
            Me.jButton3.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton3.ClassName = ""
            Me.jButton3.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton3.CustomFontFamilies = ""
            Me.jButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton3.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton3.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton3.Icon = Global.VisualJSControlsVB.My.Resources.Resources.Windows
            Me.jButton3.IconURL = ""
            Me.jButton3.Image = Nothing
            Me.jButton3.ImageLocation = ""
            Me.jButton3.Location = New System.Drawing.Point(12, 138)
            Me.jButton3.Name = "jButton3"
            Me.jButton3.Opacity = 100
            Me.jButton3.PreventMultipleClicks = True
            Me.jButton3.Size = New System.Drawing.Size(145, 35)
            Me.jButton3.TabIndex = 29
            Me.jButton3.Text = "JButton with Icon"
            Me.jButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton3.TooltipText = ""
            Me.jButton3.UseVisualStyleBackColor = False
            Me.jButton3.ValidationFailedMessage = "Validation failed!"
            Me.jButton3.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton3.VerticalGradient = True
            Me.jButton3.ZOrder = 0
            '
            'jButton2
            '
            Me.jButton2.ApplicationWideResource = True
            Me.jButton2.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton2.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton2.BackgroundImagePosition = ""
            Me.jButton2.BackgroundImageQuality = CType(80, Short)
            Me.jButton2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton2.ClassName = ""
            Me.jButton2.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton2.CustomFontFamilies = ""
            Me.jButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton2.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton2.Icon = Global.VisualJSControlsVB.My.Resources.Resources.Windows
            Me.jButton2.IconURL = ""
            Me.jButton2.Image = Nothing
            Me.jButton2.ImageLocation = ""
            Me.jButton2.Location = New System.Drawing.Point(12, 109)
            Me.jButton2.Name = "jButton2"
            Me.jButton2.Opacity = 100
            Me.jButton2.PreventMultipleClicks = True
            Me.jButton2.Size = New System.Drawing.Size(145, 23)
            Me.jButton2.TabIndex = 30
            Me.jButton2.Text = "JButton with Icon"
            Me.jButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton2.TooltipText = ""
            Me.jButton2.UseVisualStyleBackColor = False
            Me.jButton2.ValidationFailedMessage = "Validation failed!"
            Me.jButton2.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton2.VerticalGradient = True
            Me.jButton2.ZOrder = 0
            '
            'jButton7
            '
            Me.jButton7.ApplicationWideResource = True
            Me.jButton7.BackColor = System.Drawing.Color.Maroon
            Me.jButton7.BackColorEnd = System.Drawing.Color.Black
            Me.jButton7.BackgroundImagePosition = ""
            Me.jButton7.BackgroundImageQuality = CType(80, Short)
            Me.jButton7.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton7.ClassName = ""
            Me.jButton7.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton7.CustomFontFamilies = ""
            Me.jButton7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.jButton7.ForeColor = System.Drawing.Color.White
            Me.jButton7.HoverColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
            Me.jButton7.Icon = Nothing
            Me.jButton7.IconURL = ""
            Me.jButton7.Image = Nothing
            Me.jButton7.ImageLocation = ""
            Me.jButton7.Location = New System.Drawing.Point(173, 109)
            Me.jButton7.Name = "jButton7"
            Me.jButton7.Opacity = 100
            Me.jButton7.PreventMultipleClicks = True
            Me.jButton7.Size = New System.Drawing.Size(145, 23)
            Me.jButton7.TabIndex = 25
            Me.jButton7.Text = "Gradient JButton"
            Me.jButton7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton7.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton7.TooltipText = ""
            Me.jButton7.UseVisualStyleBackColor = False
            Me.jButton7.ValidationFailedMessage = "Validation failed!"
            Me.jButton7.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton7.VerticalGradient = True
            Me.jButton7.ZOrder = 0
            '
            'jButton8
            '
            Me.jButton8.ApplicationWideResource = True
            Me.jButton8.BackColor = System.Drawing.Color.Blue
            Me.jButton8.BackColorEnd = System.Drawing.Color.Black
            Me.jButton8.BackgroundImagePosition = ""
            Me.jButton8.BackgroundImageQuality = CType(80, Short)
            Me.jButton8.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton8.ClassName = ""
            Me.jButton8.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton8.CustomFontFamilies = ""
            Me.jButton8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.jButton8.ForeColor = System.Drawing.Color.White
            Me.jButton8.HoverColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
            Me.jButton8.Icon = Nothing
            Me.jButton8.IconURL = ""
            Me.jButton8.Image = Nothing
            Me.jButton8.ImageLocation = ""
            Me.jButton8.Location = New System.Drawing.Point(173, 138)
            Me.jButton8.Name = "jButton8"
            Me.jButton8.Opacity = 100
            Me.jButton8.PreventMultipleClicks = True
            Me.jButton8.Size = New System.Drawing.Size(145, 35)
            Me.jButton8.TabIndex = 24
            Me.jButton8.Text = "Gradient JButton"
            Me.jButton8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton8.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton8.TooltipText = ""
            Me.jButton8.UseVisualStyleBackColor = False
            Me.jButton8.ValidationFailedMessage = "Validation failed!"
            Me.jButton8.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton8.VerticalGradient = True
            Me.jButton8.ZOrder = 0
            '
            'jButton9
            '
            Me.jButton9.ApplicationWideResource = True
            Me.jButton9.BackColor = System.Drawing.Color.Maroon
            Me.jButton9.BackColorEnd = System.Drawing.Color.Green
            Me.jButton9.BackgroundImagePosition = ""
            Me.jButton9.BackgroundImageQuality = CType(80, Short)
            Me.jButton9.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton9.ClassName = ""
            Me.jButton9.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton9.CustomFontFamilies = ""
            Me.jButton9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.jButton9.ForeColor = System.Drawing.Color.White
            Me.jButton9.HoverColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
            Me.jButton9.Icon = Nothing
            Me.jButton9.IconURL = ""
            Me.jButton9.Image = Nothing
            Me.jButton9.ImageLocation = ""
            Me.jButton9.Location = New System.Drawing.Point(173, 179)
            Me.jButton9.Name = "jButton9"
            Me.jButton9.Opacity = 100
            Me.jButton9.PreventMultipleClicks = True
            Me.jButton9.Size = New System.Drawing.Size(145, 43)
            Me.jButton9.TabIndex = 23
            Me.jButton9.Text = "Gradient JButton"
            Me.jButton9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton9.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton9.TooltipText = ""
            Me.jButton9.UseVisualStyleBackColor = False
            Me.jButton9.ValidationFailedMessage = "Validation failed!"
            Me.jButton9.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton9.VerticalGradient = True
            Me.jButton9.ZOrder = 0
            '
            'jButton10
            '
            Me.jButton10.ApplicationWideResource = True
            Me.jButton10.BackColor = System.Drawing.Color.Green
            Me.jButton10.BackColorEnd = System.Drawing.Color.Orange
            Me.jButton10.BackgroundImagePosition = ""
            Me.jButton10.BackgroundImageQuality = CType(80, Short)
            Me.jButton10.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton10.ClassName = ""
            Me.jButton10.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton10.CustomFontFamilies = ""
            Me.jButton10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton10.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.jButton10.ForeColor = System.Drawing.Color.Black
            Me.jButton10.HoverColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
            Me.jButton10.Icon = Nothing
            Me.jButton10.IconURL = ""
            Me.jButton10.Image = Nothing
            Me.jButton10.ImageLocation = ""
            Me.jButton10.Location = New System.Drawing.Point(173, 228)
            Me.jButton10.Name = "jButton10"
            Me.jButton10.Opacity = 100
            Me.jButton10.PreventMultipleClicks = True
            Me.jButton10.Size = New System.Drawing.Size(145, 55)
            Me.jButton10.TabIndex = 22
            Me.jButton10.Text = "Gradient JButton"
            Me.jButton10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton10.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton10.TooltipText = ""
            Me.jButton10.UseVisualStyleBackColor = False
            Me.jButton10.ValidationFailedMessage = "Validation failed!"
            Me.jButton10.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton10.VerticalGradient = True
            Me.jButton10.ZOrder = 0
            '
            'jButton11
            '
            Me.jButton11.ApplicationWideResource = True
            Me.jButton11.BackColor = System.Drawing.Color.Black
            Me.jButton11.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(153, Byte), Integer))
            Me.jButton11.BackgroundImagePosition = ""
            Me.jButton11.BackgroundImageQuality = CType(80, Short)
            Me.jButton11.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton11.ClassName = ""
            Me.jButton11.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton11.CustomFontFamilies = ""
            Me.jButton11.Dock = System.Windows.Forms.DockStyle.Bottom
            Me.jButton11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton11.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.jButton11.ForeColor = System.Drawing.Color.White
            Me.jButton11.HoverColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
            Me.jButton11.Icon = Nothing
            Me.jButton11.IconURL = ""
            Me.jButton11.Image = Nothing
            Me.jButton11.ImageLocation = ""
            Me.jButton11.Location = New System.Drawing.Point(0, 298)
            Me.jButton11.Name = "jButton11"
            Me.jButton11.Opacity = 100
            Me.jButton11.PreventMultipleClicks = True
            Me.jButton11.Size = New System.Drawing.Size(516, 55)
            Me.jButton11.TabIndex = 21
            Me.jButton11.Text = "Docked Gradient JButton"
            Me.jButton11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton11.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton11.TooltipText = ""
            Me.jButton11.UseVisualStyleBackColor = False
            Me.jButton11.ValidationFailedMessage = "Validation failed!"
            Me.jButton11.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton11.VerticalGradient = True
            Me.jButton11.ZOrder = 0
            '
            'button1
            '
            Me.button1.BackgroundImagePosition = ""
            Me.button1.BackgroundImageQuality = CType(80, Short)
            Me.button1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.button1.ClassName = ""
            Me.button1.Cursor = System.Windows.Forms.Cursors.Hand
            Me.button1.CustomFontFamilies = ""
            Me.button1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.button1.Image = Nothing
            Me.button1.Location = New System.Drawing.Point(333, 12)
            Me.button1.Name = "button1"
            Me.button1.Opacity = 100
            Me.button1.PreventMultipleClicks = True
            Me.button1.Size = New System.Drawing.Size(171, 23)
            Me.button1.TabIndex = 14
            Me.button1.Text = "Normal Button"
            Me.button1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.button1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.button1.TooltipText = ""
            Me.button1.UseMnemonic = False
            Me.button1.UseVisualStyleBackColor = True
            Me.button1.ValidationFailedMessage = "Validation failed!"
            Me.button1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.button1.ZOrder = 0
            '
            'textBox1
            '
            Me.textBox1.CheckForEmail = True
            Me.textBox1.ClassName = ""
            Me.textBox1.CustomFontFamilies = ""
            Me.textBox1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.textBox1.Location = New System.Drawing.Point(333, 109)
            Me.textBox1.MaxLength = 65535
            Me.textBox1.MinLength = -1
            Me.textBox1.Name = "textBox1"
            Me.textBox1.Opacity = 100
            Me.textBox1.PreventSQLInjection = False
            Me.textBox1.RegexCheck = ""
            Me.textBox1.Size = New System.Drawing.Size(171, 21)
            Me.textBox1.TabIndex = 15
            Me.textBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.textBox1.TooltipText = ""
            Me.textBox1.ValidationMessage = "Email address is required"
            Me.textBox1.ZOrder = 0
            '
            'label2
            '
            Me.label2.AutoSize = True
            Me.label2.BackColor = System.Drawing.Color.Transparent
            Me.label2.ClassName = ""
            Me.label2.CustomFontFamilies = ""
            Me.label2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label2.Image = Nothing
            Me.label2.Location = New System.Drawing.Point(335, 89)
            Me.label2.Name = "label2"
            Me.label2.Opacity = 100
            Me.label2.Size = New System.Drawing.Size(96, 15)
            Me.label2.TabIndex = 16
            Me.label2.Text = "Enter your email"
            Me.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label2.TooltipText = ""
            Me.label2.UseMnemonic = False
            Me.label2.ZOrder = 0
            '
            'button2
            '
            Me.button2.BackgroundImagePosition = ""
            Me.button2.BackgroundImageQuality = CType(80, Short)
            Me.button2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.button2.ClassName = ""
            Me.button2.Cursor = System.Windows.Forms.Cursors.Hand
            Me.button2.CustomFontFamilies = ""
            Me.button2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.button2.Image = Nothing
            Me.button2.Location = New System.Drawing.Point(333, 139)
            Me.button2.Name = "button2"
            Me.button2.Opacity = 100
            Me.button2.PreventMultipleClicks = True
            Me.button2.Size = New System.Drawing.Size(171, 34)
            Me.button2.TabIndex = 17
            Me.button2.Text = "Validation Button"
            Me.button2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.button2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.button2.TooltipText = ""
            Me.button2.UseMnemonic = False
            Me.button2.UseVisualStyleBackColor = True
            Me.button2.ValidationFailedMessage = "Enter your Email Address!"
            Me.button2.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnParent
            Me.button2.ZOrder = 0
            '
            'jButton12
            '
            Me.jButton12.ApplicationWideResource = True
            Me.jButton12.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton12.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton12.BackgroundImagePosition = ""
            Me.jButton12.BackgroundImageQuality = CType(80, Short)
            Me.jButton12.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton12.ClassName = ""
            Me.jButton12.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton12.CustomFontFamilies = "Times New Roman,Arial"
            Me.jButton12.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton12.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton12.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton12.Icon = Nothing
            Me.jButton12.IconURL = ""
            Me.jButton12.Image = Nothing
            Me.jButton12.ImageLocation = ""
            Me.jButton12.Location = New System.Drawing.Point(333, 228)
            Me.jButton12.Name = "jButton12"
            Me.jButton12.Opacity = 100
            Me.jButton12.PreventMultipleClicks = True
            Me.jButton12.Size = New System.Drawing.Size(171, 55)
            Me.jButton12.TabIndex = 20
            Me.jButton12.Text = "Custom Font Families"
            Me.jButton12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton12.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton12.TooltipText = ""
            Me.jButton12.UseVisualStyleBackColor = False
            Me.jButton12.ValidationFailedMessage = "Validation failed!"
            Me.jButton12.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton12.VerticalGradient = True
            Me.jButton12.ZOrder = 0
            '
            'button3
            '
            Me.button3.BackgroundImagePosition = ""
            Me.button3.BackgroundImageQuality = CType(80, Short)
            Me.button3.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.button3.ClassName = ""
            Me.button3.Cursor = System.Windows.Forms.Cursors.Hand
            Me.button3.CustomFontFamilies = "verdana,tahoma"
            Me.button3.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.button3.Image = Nothing
            Me.button3.Location = New System.Drawing.Point(333, 179)
            Me.button3.Name = "button3"
            Me.button3.Opacity = 100
            Me.button3.PreventMultipleClicks = True
            Me.button3.Size = New System.Drawing.Size(171, 43)
            Me.button3.TabIndex = 19
            Me.button3.Text = "Custom Font Families"
            Me.button3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.button3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.button3.TooltipText = ""
            Me.button3.UseMnemonic = False
            Me.button3.UseVisualStyleBackColor = True
            Me.button3.ValidationFailedMessage = "Validation failed!"
            Me.button3.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.button3.ZOrder = 0
            '
            'Buttons
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(516, 353)
            Me.Controls.Add(Me.button3)
            Me.Controls.Add(Me.jButton12)
            Me.Controls.Add(Me.button2)
            Me.Controls.Add(Me.label2)
            Me.Controls.Add(Me.textBox1)
            Me.Controls.Add(Me.button1)
            Me.Controls.Add(Me.jButton11)
            Me.Controls.Add(Me.jButton10)
            Me.Controls.Add(Me.jButton9)
            Me.Controls.Add(Me.jButton8)
            Me.Controls.Add(Me.jButton7)
            Me.Controls.Add(Me.jButton6)
            Me.Controls.Add(Me.jButton5)
            Me.Controls.Add(Me.label1)
            Me.Controls.Add(Me.jButton4)
            Me.Controls.Add(Me.jButton3)
            Me.Controls.Add(Me.jButton2)
            Me.Controls.Add(Me.jButton1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "Buttons"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "Buttons Sample"
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

#End Region

        Private jButton1 As VisualJS.Web.Forms.JButton
        Private jButton2 As VisualJS.Web.Forms.JButton
        Private jButton3 As VisualJS.Web.Forms.JButton
        Private jButton4 As VisualJS.Web.Forms.JButton
        Private label1 As VisualJS.Web.Forms.Label
        Private jButton5 As VisualJS.Web.Forms.JButton
        Private jButton6 As VisualJS.Web.Forms.JButton
        Private jButton7 As VisualJS.Web.Forms.JButton
        Private jButton8 As VisualJS.Web.Forms.JButton
        Private jButton9 As VisualJS.Web.Forms.JButton
        Private jButton10 As VisualJS.Web.Forms.JButton
        Private jButton11 As VisualJS.Web.Forms.JButton
        Private button1 As VisualJS.Web.Forms.Button
        Private textBox1 As VisualJS.Web.Forms.TextBox
        Private label2 As VisualJS.Web.Forms.Label
        Friend WithEvents button2 As VisualJS.Web.Forms.Button
        Private jButton12 As VisualJS.Web.Forms.JButton
        Private button3 As VisualJS.Web.Forms.Button
    End Class
End Namespace
