
Namespace SampleForms
	Partial Class PictureBoxTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PictureBoxTest))
            Me.pictureBox1 = New VisualJS.Web.Forms.PictureBox()
            Me.label1 = New VisualJS.Web.Forms.Label()
            Me.label2 = New VisualJS.Web.Forms.Label()
            Me.pictureBox2 = New VisualJS.Web.Forms.PictureBox()
            Me.label3 = New VisualJS.Web.Forms.Label()
            Me.pictureBox3 = New VisualJS.Web.Forms.PictureBox()
            Me.label4 = New VisualJS.Web.Forms.Label()
            Me.pictureBox4 = New VisualJS.Web.Forms.PictureBox()
            Me.label5 = New VisualJS.Web.Forms.Label()
            Me.pictureBox5 = New VisualJS.Web.Forms.PictureBox()
            Me.label6 = New VisualJS.Web.Forms.Label()
            Me.pictureBox6 = New VisualJS.Web.Forms.PictureBox()
            Me.jButton1 = New VisualJS.Web.Forms.JButton()
            Me.pictureBox7 = New VisualJS.Web.Forms.PictureBox()
            Me.clrText = New VisualJS.Web.Forms.ColorPicker()
            Me.label7 = New VisualJS.Web.Forms.Label()
            Me.label8 = New VisualJS.Web.Forms.Label()
            Me.txtImage = New VisualJS.Web.Forms.TextBox()
            Me.panel1 = New VisualJS.Web.Forms.Panel()
            Me.clrBack = New VisualJS.Web.Forms.ColorPicker()
            Me.label9 = New VisualJS.Web.Forms.Label()
            Me.jButton2 = New VisualJS.Web.Forms.JButton()
            CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.pictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.pictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.pictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.pictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.pictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.pictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.panel1.SuspendLayout()
            Me.SuspendLayout()
            '
            'pictureBox1
            '
            Me.pictureBox1.ApplicationWideResource = True
            Me.pictureBox1.ClassName = ""
            Me.pictureBox1.ErrorImage = CType(resources.GetObject("pictureBox1.ErrorImage"), System.Drawing.Image)
            Me.pictureBox1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.pictureBox1.Image = Global.VisualJSControlsVB.My.Resources.Resources.vsjslogo
            Me.pictureBox1.ImageLocation = ""
            Me.pictureBox1.ImageQuality = CType(100, Short)
            Me.pictureBox1.InitialImage = CType(resources.GetObject("pictureBox1.InitialImage"), System.Drawing.Image)
            Me.pictureBox1.Location = New System.Drawing.Point(15, 222)
            Me.pictureBox1.Name = "pictureBox1"
            Me.pictureBox1.Opacity = 100
            Me.pictureBox1.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.PNG
            Me.pictureBox1.Size = New System.Drawing.Size(288, 60)
            Me.pictureBox1.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal
            Me.pictureBox1.TabIndex = 0
            Me.pictureBox1.TabStop = False
            Me.pictureBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.pictureBox1.TooltipText = "25 KB File Size"
            Me.pictureBox1.ZOrder = 0
            '
            'label1
            '
            Me.label1.AutoSize = True
            Me.label1.BackColor = System.Drawing.Color.Transparent
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label1.ForeColor = System.Drawing.Color.MintCream
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(12, 204)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 100
            Me.label1.Size = New System.Drawing.Size(202, 15)
            Me.label1.TabIndex = 1
            Me.label1.Text = "Normal Image Size, PNG Emulation"
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.ZOrder = 0
            '
            'label2
            '
            Me.label2.AutoSize = True
            Me.label2.BackColor = System.Drawing.Color.Transparent
            Me.label2.ClassName = ""
            Me.label2.CustomFontFamilies = ""
            Me.label2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label2.ForeColor = System.Drawing.Color.MintCream
            Me.label2.Image = Nothing
            Me.label2.Location = New System.Drawing.Point(12, 293)
            Me.label2.Name = "label2"
            Me.label2.Opacity = 100
            Me.label2.Size = New System.Drawing.Size(195, 15)
            Me.label2.TabIndex = 3
            Me.label2.Text = "Normal Image Size, GIF Emulation"
            Me.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label2.TooltipText = ""
            Me.label2.UseMnemonic = False
            Me.label2.ZOrder = 0
            '
            'pictureBox2
            '
            Me.pictureBox2.ApplicationWideResource = True
            Me.pictureBox2.ClassName = ""
            Me.pictureBox2.ErrorImage = CType(resources.GetObject("pictureBox2.ErrorImage"), System.Drawing.Image)
            Me.pictureBox2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.pictureBox2.Image = Global.VisualJSControlsVB.My.Resources.Resources.vsjslogo
            Me.pictureBox2.ImageLocation = ""
            Me.pictureBox2.ImageQuality = CType(100, Short)
            Me.pictureBox2.InitialImage = CType(resources.GetObject("pictureBox2.InitialImage"), System.Drawing.Image)
            Me.pictureBox2.Location = New System.Drawing.Point(15, 311)
            Me.pictureBox2.Name = "pictureBox2"
            Me.pictureBox2.Opacity = 100
            Me.pictureBox2.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.GIF
            Me.pictureBox2.Size = New System.Drawing.Size(288, 60)
            Me.pictureBox2.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal
            Me.pictureBox2.TabIndex = 2
            Me.pictureBox2.TabStop = False
            Me.pictureBox2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.pictureBox2.TooltipText = "7.3 KB File Size"
            Me.pictureBox2.ZOrder = 0
            '
            'label3
            '
            Me.label3.AutoSize = True
            Me.label3.BackColor = System.Drawing.Color.Transparent
            Me.label3.ClassName = ""
            Me.label3.CustomFontFamilies = ""
            Me.label3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label3.ForeColor = System.Drawing.Color.MintCream
            Me.label3.Image = Nothing
            Me.label3.Location = New System.Drawing.Point(12, 384)
            Me.label3.Name = "label3"
            Me.label3.Opacity = 100
            Me.label3.Size = New System.Drawing.Size(278, 15)
            Me.label3.TabIndex = 5
            Me.label3.Text = "Normal Image Size, %100 Quality, JPG Emulation"
            Me.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label3.TooltipText = ""
            Me.label3.UseMnemonic = False
            Me.label3.ZOrder = 0
            '
            'pictureBox3
            '
            Me.pictureBox3.ApplicationWideResource = True
            Me.pictureBox3.ClassName = ""
            Me.pictureBox3.ErrorImage = CType(resources.GetObject("pictureBox3.ErrorImage"), System.Drawing.Image)
            Me.pictureBox3.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.pictureBox3.Image = Global.VisualJSControlsVB.My.Resources.Resources.vsjslogo
            Me.pictureBox3.ImageLocation = ""
            Me.pictureBox3.ImageQuality = CType(100, Short)
            Me.pictureBox3.InitialImage = CType(resources.GetObject("pictureBox3.InitialImage"), System.Drawing.Image)
            Me.pictureBox3.Location = New System.Drawing.Point(15, 402)
            Me.pictureBox3.Name = "pictureBox3"
            Me.pictureBox3.Opacity = 100
            Me.pictureBox3.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.JPG
            Me.pictureBox3.Size = New System.Drawing.Size(288, 60)
            Me.pictureBox3.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal
            Me.pictureBox3.TabIndex = 4
            Me.pictureBox3.TabStop = False
            Me.pictureBox3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.pictureBox3.TooltipText = "18.8 KB File Size"
            Me.pictureBox3.ZOrder = 0
            '
            'label4
            '
            Me.label4.AutoSize = True
            Me.label4.BackColor = System.Drawing.Color.Transparent
            Me.label4.ClassName = ""
            Me.label4.CustomFontFamilies = ""
            Me.label4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label4.ForeColor = System.Drawing.Color.MintCream
            Me.label4.Image = Nothing
            Me.label4.Location = New System.Drawing.Point(317, 384)
            Me.label4.Name = "label4"
            Me.label4.Opacity = 100
            Me.label4.Size = New System.Drawing.Size(271, 15)
            Me.label4.TabIndex = 11
            Me.label4.Text = "Normal Image Size, %10 Quality, JPG Emulation"
            Me.label4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label4.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label4.TooltipText = ""
            Me.label4.UseMnemonic = False
            Me.label4.ZOrder = 0
            '
            'pictureBox4
            '
            Me.pictureBox4.ApplicationWideResource = True
            Me.pictureBox4.ClassName = ""
            Me.pictureBox4.ErrorImage = CType(resources.GetObject("pictureBox4.ErrorImage"), System.Drawing.Image)
            Me.pictureBox4.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.pictureBox4.Image = Global.VisualJSControlsVB.My.Resources.Resources.vsjslogo
            Me.pictureBox4.ImageLocation = ""
            Me.pictureBox4.ImageQuality = CType(10, Short)
            Me.pictureBox4.InitialImage = CType(resources.GetObject("pictureBox4.InitialImage"), System.Drawing.Image)
            Me.pictureBox4.Location = New System.Drawing.Point(320, 402)
            Me.pictureBox4.Name = "pictureBox4"
            Me.pictureBox4.Opacity = 100
            Me.pictureBox4.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.JPG
            Me.pictureBox4.Size = New System.Drawing.Size(286, 60)
            Me.pictureBox4.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal
            Me.pictureBox4.TabIndex = 10
            Me.pictureBox4.TabStop = False
            Me.pictureBox4.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.pictureBox4.TooltipText = "1.6 KB File Size"
            Me.pictureBox4.ZOrder = 0
            '
            'label5
            '
            Me.label5.AutoSize = True
            Me.label5.BackColor = System.Drawing.Color.Transparent
            Me.label5.ClassName = ""
            Me.label5.CustomFontFamilies = ""
            Me.label5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label5.ForeColor = System.Drawing.Color.MintCream
            Me.label5.Image = Nothing
            Me.label5.Location = New System.Drawing.Point(317, 293)
            Me.label5.Name = "label5"
            Me.label5.Opacity = 100
            Me.label5.Size = New System.Drawing.Size(179, 15)
            Me.label5.TabIndex = 9
            Me.label5.Text = "Streched Image, GIF Emulation"
            Me.label5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label5.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label5.TooltipText = ""
            Me.label5.UseMnemonic = False
            Me.label5.ZOrder = 0
            '
            'pictureBox5
            '
            Me.pictureBox5.ApplicationWideResource = True
            Me.pictureBox5.ClassName = ""
            Me.pictureBox5.ErrorImage = CType(resources.GetObject("pictureBox5.ErrorImage"), System.Drawing.Image)
            Me.pictureBox5.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.pictureBox5.Image = Global.VisualJSControlsVB.My.Resources.Resources.vsjslogo
            Me.pictureBox5.ImageLocation = ""
            Me.pictureBox5.ImageQuality = CType(100, Short)
            Me.pictureBox5.InitialImage = CType(resources.GetObject("pictureBox5.InitialImage"), System.Drawing.Image)
            Me.pictureBox5.Location = New System.Drawing.Point(320, 311)
            Me.pictureBox5.Name = "pictureBox5"
            Me.pictureBox5.Opacity = 100
            Me.pictureBox5.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.GIF
            Me.pictureBox5.Size = New System.Drawing.Size(304, 60)
            Me.pictureBox5.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.StretchImage
            Me.pictureBox5.TabIndex = 8
            Me.pictureBox5.TabStop = False
            Me.pictureBox5.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.pictureBox5.TooltipText = "7.3 KB File Size"
            Me.pictureBox5.ZOrder = 0
            '
            'label6
            '
            Me.label6.AutoSize = True
            Me.label6.BackColor = System.Drawing.Color.Transparent
            Me.label6.ClassName = ""
            Me.label6.CustomFontFamilies = ""
            Me.label6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label6.ForeColor = System.Drawing.Color.MintCream
            Me.label6.Image = Nothing
            Me.label6.Location = New System.Drawing.Point(317, 204)
            Me.label6.Name = "label6"
            Me.label6.Opacity = 100
            Me.label6.Size = New System.Drawing.Size(186, 15)
            Me.label6.TabIndex = 7
            Me.label6.Text = "Streched Image, PNG Emulation"
            Me.label6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label6.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label6.TooltipText = ""
            Me.label6.UseMnemonic = False
            Me.label6.ZOrder = 0
            '
            'pictureBox6
            '
            Me.pictureBox6.ApplicationWideResource = True
            Me.pictureBox6.ClassName = ""
            Me.pictureBox6.ErrorImage = CType(resources.GetObject("pictureBox6.ErrorImage"), System.Drawing.Image)
            Me.pictureBox6.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.pictureBox6.Image = Global.VisualJSControlsVB.My.Resources.Resources.vsjslogo
            Me.pictureBox6.ImageLocation = ""
            Me.pictureBox6.ImageQuality = CType(10, Short)
            Me.pictureBox6.InitialImage = CType(resources.GetObject("pictureBox6.InitialImage"), System.Drawing.Image)
            Me.pictureBox6.Location = New System.Drawing.Point(320, 222)
            Me.pictureBox6.Name = "pictureBox6"
            Me.pictureBox6.Opacity = 100
            Me.pictureBox6.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.PNG
            Me.pictureBox6.Size = New System.Drawing.Size(304, 60)
            Me.pictureBox6.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.StretchImage
            Me.pictureBox6.TabIndex = 6
            Me.pictureBox6.TabStop = False
            Me.pictureBox6.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.pictureBox6.TooltipText = "25 KB File Size"
            Me.pictureBox6.ZOrder = 0
            '
            'jButton1
            '
            Me.jButton1.ApplicationWideResource = True
            Me.jButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton1.BackgroundImagePosition = ""
            Me.jButton1.BackgroundImageQuality = CType(80, Short)
            Me.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton1.ClassName = ""
            Me.jButton1.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton1.CustomFontFamilies = ""
            Me.jButton1.Dock = System.Windows.Forms.DockStyle.Bottom
            Me.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.jButton1.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton1.Icon = Nothing
            Me.jButton1.IconURL = ""
            Me.jButton1.Image = Nothing
            Me.jButton1.ImageLocation = ""
            Me.jButton1.Location = New System.Drawing.Point(0, 479)
            Me.jButton1.Name = "jButton1"
            Me.jButton1.Opacity = 100
            Me.jButton1.PreventMultipleClicks = True
            Me.jButton1.Size = New System.Drawing.Size(645, 34)
            Me.jButton1.TabIndex = 0
            Me.jButton1.Text = "More Samples.."
            Me.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton1.TooltipText = ""
            Me.jButton1.UseVisualStyleBackColor = False
            Me.jButton1.ValidationFailedMessage = "Validation failed!"
            Me.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton1.VerticalGradient = True
            Me.jButton1.ZOrder = 0
            '
            'pictureBox7
            '
            Me.pictureBox7.ApplicationWideResource = False
            Me.pictureBox7.ClassName = ""
            Me.pictureBox7.ErrorImage = CType(resources.GetObject("pictureBox7.ErrorImage"), System.Drawing.Image)
            Me.pictureBox7.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.pictureBox7.Image = Nothing
            Me.pictureBox7.ImageLocation = ""
            Me.pictureBox7.ImageQuality = CType(100, Short)
            Me.pictureBox7.InitialImage = CType(resources.GetObject("pictureBox7.InitialImage"), System.Drawing.Image)
            Me.pictureBox7.Location = New System.Drawing.Point(19, 14)
            Me.pictureBox7.Name = "pictureBox7"
            Me.pictureBox7.Opacity = 100
            Me.pictureBox7.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.PNG
            Me.pictureBox7.Size = New System.Drawing.Size(288, 140)
            Me.pictureBox7.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.StretchImage
            Me.pictureBox7.TabIndex = 13
            Me.pictureBox7.TabStop = False
            Me.pictureBox7.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.pictureBox7.TooltipText = ""
            Me.pictureBox7.ZOrder = 0
            '
            'clrText
            '
            Me.clrText.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.clrText.CheckForEmail = False
            Me.clrText.ClassName = ""
            Me.clrText.Color = System.Drawing.Color.FromArgb(CType(CType(176, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
            Me.clrText.ColorInputValidation = True
            Me.clrText.CustomFontFamilies = ""
            Me.clrText.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.clrText.Location = New System.Drawing.Point(316, 84)
            Me.clrText.Mask = "#??????"
            Me.clrText.MinLength = -1
            Me.clrText.Name = "clrText"
            Me.clrText.Opacity = 100
            Me.clrText.PreventSQLInjection = False
            Me.clrText.RegexCheck = "^#?([a-f]|[A-F]|[0-9]){3}(([a-f]|[A-F]|[0-9]){3})?$"
            Me.clrText.Size = New System.Drawing.Size(103, 21)
            Me.clrText.TabIndex = 14
            Me.clrText.Text = "B00000"
            Me.clrText.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.clrText.TooltipText = ""
            Me.clrText.ValidationMessage = "Enter or Select Valid HTML Color"
            Me.clrText.ZOrder = 0
            '
            'label7
            '
            Me.label7.AutoSize = True
            Me.label7.BackColor = System.Drawing.Color.Transparent
            Me.label7.ClassName = ""
            Me.label7.CustomFontFamilies = ""
            Me.label7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label7.ForeColor = System.Drawing.Color.MintCream
            Me.label7.Image = Nothing
            Me.label7.Location = New System.Drawing.Point(313, 66)
            Me.label7.Name = "label7"
            Me.label7.Opacity = 100
            Me.label7.Size = New System.Drawing.Size(64, 15)
            Me.label7.TabIndex = 15
            Me.label7.Text = "Text Color"
            Me.label7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label7.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label7.TooltipText = ""
            Me.label7.UseMnemonic = False
            Me.label7.ZOrder = 0
            '
            'label8
            '
            Me.label8.AutoSize = True
            Me.label8.BackColor = System.Drawing.Color.Transparent
            Me.label8.ClassName = ""
            Me.label8.CustomFontFamilies = ""
            Me.label8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label8.ForeColor = System.Drawing.Color.MintCream
            Me.label8.Image = Nothing
            Me.label8.Location = New System.Drawing.Point(313, 14)
            Me.label8.Name = "label8"
            Me.label8.Opacity = 100
            Me.label8.Size = New System.Drawing.Size(69, 15)
            Me.label8.TabIndex = 16
            Me.label8.Text = "Image Text"
            Me.label8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label8.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label8.TooltipText = ""
            Me.label8.UseMnemonic = False
            Me.label8.ZOrder = 0
            '
            'txtImage
            '
            Me.txtImage.CheckForEmail = False
            Me.txtImage.ClassName = ""
            Me.txtImage.CustomFontFamilies = ""
            Me.txtImage.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.txtImage.Location = New System.Drawing.Point(316, 32)
            Me.txtImage.MaxLength = 65535
            Me.txtImage.MinLength = 4
            Me.txtImage.Name = "txtImage"
            Me.txtImage.Opacity = 100
            Me.txtImage.PreventSQLInjection = False
            Me.txtImage.RegexCheck = ""
            Me.txtImage.Size = New System.Drawing.Size(275, 21)
            Me.txtImage.TabIndex = 17
            Me.txtImage.Text = "Sample Text"
            Me.txtImage.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.txtImage.TooltipText = ""
            Me.txtImage.ValidationMessage = "Enter Something (Min 3 Chars)"
            Me.txtImage.ZOrder = 0
            '
            'panel1
            '
            Me.panel1.ApplicationWideResource = True
            Me.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.panel1.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.panel1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.panel1.BackColor = System.Drawing.Color.Black
            Me.panel1.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(153, Byte), Integer))
            Me.panel1.BackgroundImagePosition = ""
            Me.panel1.BackgroundImageQuality = CType(80, Short)
            Me.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.panel1.BorderColor = System.Drawing.Color.Black
            Me.panel1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid
            Me.panel1.ClassName = ""
            Me.panel1.ClientID = Nothing
            Me.panel1.Controls.Add(Me.clrBack)
            Me.panel1.Controls.Add(Me.label9)
            Me.panel1.Controls.Add(Me.jButton2)
            Me.panel1.Controls.Add(Me.pictureBox7)
            Me.panel1.Controls.Add(Me.txtImage)
            Me.panel1.Controls.Add(Me.clrText)
            Me.panel1.Controls.Add(Me.label8)
            Me.panel1.Controls.Add(Me.label7)
            Me.panel1.CustomFontFamilies = ""
            Me.panel1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.panel1.HTML = ""
            Me.panel1.ImageLocation = ""
            Me.panel1.Location = New System.Drawing.Point(12, 12)
            Me.panel1.Name = "panel1"
            Me.panel1.Opacity = 40
            Me.panel1.Size = New System.Drawing.Size(614, 171)
            Me.panel1.TabIndex = 18
            Me.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.panel1.TooltipText = ""
            Me.panel1.VerticalGradient = True
            Me.panel1.ZOrder = 0
            '
            'clrBack
            '
            Me.clrBack.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.clrBack.CheckForEmail = False
            Me.clrBack.ClassName = ""
            Me.clrBack.Color = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
            Me.clrBack.ColorInputValidation = True
            Me.clrBack.CustomFontFamilies = ""
            Me.clrBack.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.clrBack.Location = New System.Drawing.Point(316, 133)
            Me.clrBack.Mask = "#??????"
            Me.clrBack.MinLength = -1
            Me.clrBack.Name = "clrBack"
            Me.clrBack.Opacity = 100
            Me.clrBack.PreventSQLInjection = False
            Me.clrBack.RegexCheck = "^#?([a-f]|[A-F]|[0-9]){3}(([a-f]|[A-F]|[0-9]){3})?$"
            Me.clrBack.Size = New System.Drawing.Size(103, 21)
            Me.clrBack.TabIndex = 20
            Me.clrBack.Text = "FFFFFF"
            Me.clrBack.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.clrBack.TooltipText = ""
            Me.clrBack.ValidationMessage = "Enter or Select Valid HTML Color"
            Me.clrBack.ZOrder = 0
            '
            'label9
            '
            Me.label9.AutoSize = True
            Me.label9.BackColor = System.Drawing.Color.Transparent
            Me.label9.ClassName = ""
            Me.label9.CustomFontFamilies = ""
            Me.label9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label9.ForeColor = System.Drawing.Color.MintCream
            Me.label9.Image = Nothing
            Me.label9.Location = New System.Drawing.Point(313, 115)
            Me.label9.Name = "label9"
            Me.label9.Opacity = 100
            Me.label9.Size = New System.Drawing.Size(109, 15)
            Me.label9.TabIndex = 21
            Me.label9.Text = "Background Color"
            Me.label9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label9.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label9.TooltipText = ""
            Me.label9.UseMnemonic = False
            Me.label9.ZOrder = 0
            '
            'jButton2
            '
            Me.jButton2.ApplicationWideResource = True
            Me.jButton2.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton2.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton2.BackgroundImagePosition = ""
            Me.jButton2.BackgroundImageQuality = CType(80, Short)
            Me.jButton2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton2.ClassName = ""
            Me.jButton2.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton2.CustomFontFamilies = ""
            Me.jButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton2.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton2.Icon = Nothing
            Me.jButton2.IconURL = ""
            Me.jButton2.Image = Nothing
            Me.jButton2.ImageLocation = ""
            Me.jButton2.Location = New System.Drawing.Point(437, 131)
            Me.jButton2.Name = "jButton2"
            Me.jButton2.Opacity = 100
            Me.jButton2.PreventMultipleClicks = True
            Me.jButton2.Size = New System.Drawing.Size(80, 23)
            Me.jButton2.TabIndex = 22
            Me.jButton2.Text = "Draw"
            Me.jButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton2.TooltipText = ""
            Me.jButton2.UseVisualStyleBackColor = False
            Me.jButton2.ValidationFailedMessage = "Check the inputs"
            Me.jButton2.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnParent
            Me.jButton2.VerticalGradient = True
            Me.jButton2.ZOrder = 0
            '
            'PictureBoxTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
            Me.ClientSize = New System.Drawing.Size(645, 513)
            Me.Controls.Add(Me.jButton1)
            Me.Controls.Add(Me.panel1)
            Me.Controls.Add(Me.label4)
            Me.Controls.Add(Me.pictureBox4)
            Me.Controls.Add(Me.label5)
            Me.Controls.Add(Me.pictureBox5)
            Me.Controls.Add(Me.label6)
            Me.Controls.Add(Me.pictureBox6)
            Me.Controls.Add(Me.label3)
            Me.Controls.Add(Me.pictureBox3)
            Me.Controls.Add(Me.label2)
            Me.Controls.Add(Me.pictureBox2)
            Me.Controls.Add(Me.label1)
            Me.Controls.Add(Me.pictureBox1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "PictureBoxTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "PictureBox Demo"
            CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.pictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.pictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.pictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.pictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.pictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.pictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
            Me.panel1.ResumeLayout(False)
            Me.panel1.PerformLayout()
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

		#End Region

		Private pictureBox1 As VisualJS.Web.Forms.PictureBox
		Private label1 As VisualJS.Web.Forms.Label
		Private label2 As VisualJS.Web.Forms.Label
		Private pictureBox2 As VisualJS.Web.Forms.PictureBox
		Private label3 As VisualJS.Web.Forms.Label
		Private pictureBox3 As VisualJS.Web.Forms.PictureBox
		Private label4 As VisualJS.Web.Forms.Label
		Private pictureBox4 As VisualJS.Web.Forms.PictureBox
		Private label5 As VisualJS.Web.Forms.Label
		Private pictureBox5 As VisualJS.Web.Forms.PictureBox
		Private label6 As VisualJS.Web.Forms.Label
		Private pictureBox6 As VisualJS.Web.Forms.PictureBox
        Friend WithEvents jButton1 As VisualJS.Web.Forms.JButton
		Private pictureBox7 As VisualJS.Web.Forms.PictureBox
		Private clrText As VisualJS.Web.Forms.ColorPicker
		Private label7 As VisualJS.Web.Forms.Label
		Private label8 As VisualJS.Web.Forms.Label
		Private txtImage As VisualJS.Web.Forms.TextBox
		Private panel1 As VisualJS.Web.Forms.Panel
        Friend WithEvents jButton2 As VisualJS.Web.Forms.JButton
		Private clrBack As VisualJS.Web.Forms.ColorPicker
		Private label9 As VisualJS.Web.Forms.Label
	End Class
End Namespace 
