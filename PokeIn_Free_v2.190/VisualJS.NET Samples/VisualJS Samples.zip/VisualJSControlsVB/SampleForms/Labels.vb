
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports VisualJS
Imports VisualJS.Web.Forms
Imports System.Linq
Imports System.Text

Namespace SampleForms
	Public Partial Class Labels
		Inherits VisualJS.Web.Forms.Form
		Public Sub New()
			InitializeComponent()
		End Sub

		'Use the below constructor if you create the instance of this Form object other than the active Thread
        'otherwise you will receive an exception, saying "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter"
		Public Sub New(clientId As String)
			MyBase.New(clientId)
			InitializeComponent()
		End Sub

        Private Sub linkLabel2_LinkClicked(sender As Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles linkLabel2.LinkClicked
            MessageBox.Show("LinkLabel Clicked", Me)
        End Sub
	End Class
End Namespace 
