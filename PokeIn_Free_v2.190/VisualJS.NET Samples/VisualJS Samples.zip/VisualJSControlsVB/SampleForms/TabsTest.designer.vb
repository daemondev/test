
Namespace SampleForms
	Partial Class TabsTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Me.components = New System.ComponentModel.Container()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(TabsTest))
            Me.tabControl1 = New VisualJS.Web.Forms.TabControl()
            Me.tabPage2 = New VisualJS.Web.Forms.TabPage()
            Me.label2 = New VisualJS.Web.Forms.Label()
            Me.tabPage4 = New VisualJS.Web.Forms.TabPage()
            Me.label3 = New VisualJS.Web.Forms.Label()
            Me.tabPage6 = New VisualJS.Web.Forms.TabPage()
            Me.label4 = New VisualJS.Web.Forms.Label()
            Me.tabPage8 = New VisualJS.Web.Forms.TabPage()
            Me.label5 = New VisualJS.Web.Forms.Label()
            Me.comboBox1 = New VisualJS.Web.Forms.ComboBox()
            Me.imageList1 = New System.Windows.Forms.ImageList(Me.components)
            Me.label1 = New VisualJS.Web.Forms.Label()
            Me.jButton1 = New VisualJS.Web.Forms.JButton()
            Me.tabControl1.SuspendLayout()
            Me.tabPage2.SuspendLayout()
            Me.tabPage4.SuspendLayout()
            Me.tabPage6.SuspendLayout()
            Me.tabPage8.SuspendLayout()
            Me.SuspendLayout()
            '
            'tabControl1
            '
            Me.tabControl1.ClassName = ""
            Me.tabControl1.ClientID = Nothing
            Me.tabControl1.Controls.Add(Me.tabPage2)
            Me.tabControl1.Controls.Add(Me.tabPage4)
            Me.tabControl1.Controls.Add(Me.tabPage6)
            Me.tabControl1.Controls.Add(Me.tabPage8)
            Me.tabControl1.CustomFontFamilies = ""
            Me.tabControl1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.tabControl1.HeadersVisible = True
            Me.tabControl1.Location = New System.Drawing.Point(12, 12)
            Me.tabControl1.Multiline = True
            Me.tabControl1.Name = "tabControl1"
            Me.tabControl1.Opacity = 100
            Me.tabControl1.SelectedIndex = 0
            Me.tabControl1.SelectedTab = Nothing
            Me.tabControl1.SelectionHelper = Me.comboBox1
            Me.tabControl1.Size = New System.Drawing.Size(493, 311)
            Me.tabControl1.TabIcons = Me.imageList1
            Me.tabControl1.TabIndex = 0
            Me.tabControl1.TabPages = False
            Me.tabControl1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.tabControl1.TooltipText = ""
            Me.tabControl1.ZOrder = 0
            '
            'tabPage2
            '
            Me.tabPage2.BackColor = System.Drawing.Color.DarkKhaki
            Me.tabPage2.ClassName = ""
            Me.tabPage2.ClientID = Nothing
            Me.tabPage2.Closable = False
            Me.tabPage2.Controls.Add(Me.label2)
            Me.tabPage2.CustomFontFamilies = ""
            Me.tabPage2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.tabPage2.Location = New System.Drawing.Point(4, 24)
            Me.tabPage2.Name = "tabPage2"
            Me.tabPage2.Size = New System.Drawing.Size(485, 283)
            Me.tabPage2.TabIndex = 1
            Me.tabPage2.Text = "Customers"
            Me.tabPage2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.tabPage2.TooltipText = ""
            Me.tabPage2.Visible = False
            Me.tabPage2.ZOrder = 0
            '
            'label2
            '
            Me.label2.BackColor = System.Drawing.Color.SlateGray
            Me.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            Me.label2.ClassName = ""
            Me.label2.CustomFontFamilies = ""
            Me.label2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label2.ForeColor = System.Drawing.Color.White
            Me.label2.Image = Nothing
            Me.label2.Location = New System.Drawing.Point(107, 131)
            Me.label2.Name = "label2"
            Me.label2.Opacity = 100
            Me.label2.Size = New System.Drawing.Size(271, 21)
            Me.label2.TabIndex = 3
            Me.label2.Text = "Customers Tab Sample"
            Me.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label2.TooltipText = ""
            Me.label2.UseMnemonic = False
            Me.label2.ZOrder = 0
            '
            'tabPage4
            '
            Me.tabPage4.BackColor = System.Drawing.Color.Salmon
            Me.tabPage4.ClassName = ""
            Me.tabPage4.ClientID = Nothing
            Me.tabPage4.Closable = False
            Me.tabPage4.Controls.Add(Me.label3)
            Me.tabPage4.CustomFontFamilies = ""
            Me.tabPage4.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.tabPage4.Location = New System.Drawing.Point(4, 24)
            Me.tabPage4.Name = "tabPage4"
            Me.tabPage4.Size = New System.Drawing.Size(485, 283)
            Me.tabPage4.TabIndex = 3
            Me.tabPage4.Text = "Contacts"
            Me.tabPage4.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.tabPage4.TooltipText = ""
            Me.tabPage4.Visible = False
            Me.tabPage4.ZOrder = 0
            '
            'label3
            '
            Me.label3.BackColor = System.Drawing.Color.Brown
            Me.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            Me.label3.ClassName = ""
            Me.label3.CustomFontFamilies = ""
            Me.label3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label3.ForeColor = System.Drawing.Color.White
            Me.label3.Image = Nothing
            Me.label3.Location = New System.Drawing.Point(107, 131)
            Me.label3.Name = "label3"
            Me.label3.Opacity = 100
            Me.label3.Size = New System.Drawing.Size(271, 21)
            Me.label3.TabIndex = 4
            Me.label3.Text = "Contacts Tab Sample"
            Me.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label3.TooltipText = ""
            Me.label3.UseMnemonic = False
            Me.label3.ZOrder = 0
            '
            'tabPage6
            '
            Me.tabPage6.BackColor = System.Drawing.Color.Silver
            Me.tabPage6.ClassName = ""
            Me.tabPage6.ClientID = Nothing
            Me.tabPage6.Closable = False
            Me.tabPage6.Controls.Add(Me.label4)
            Me.tabPage6.CustomFontFamilies = ""
            Me.tabPage6.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.tabPage6.Location = New System.Drawing.Point(4, 24)
            Me.tabPage6.Name = "tabPage6"
            Me.tabPage6.Size = New System.Drawing.Size(485, 283)
            Me.tabPage6.TabIndex = 5
            Me.tabPage6.Text = "Money"
            Me.tabPage6.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.tabPage6.TooltipText = ""
            Me.tabPage6.Visible = False
            Me.tabPage6.ZOrder = 0
            '
            'label4
            '
            Me.label4.BackColor = System.Drawing.Color.OrangeRed
            Me.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            Me.label4.ClassName = ""
            Me.label4.CustomFontFamilies = ""
            Me.label4.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label4.ForeColor = System.Drawing.Color.White
            Me.label4.Image = Nothing
            Me.label4.Location = New System.Drawing.Point(107, 131)
            Me.label4.Name = "label4"
            Me.label4.Opacity = 100
            Me.label4.Size = New System.Drawing.Size(271, 21)
            Me.label4.TabIndex = 4
            Me.label4.Text = "Money Tab Sample"
            Me.label4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.label4.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label4.TooltipText = ""
            Me.label4.UseMnemonic = False
            Me.label4.ZOrder = 0
            '
            'tabPage8
            '
            Me.tabPage8.ClassName = ""
            Me.tabPage8.ClientID = Nothing
            Me.tabPage8.Closable = True
            Me.tabPage8.Controls.Add(Me.label5)
            Me.tabPage8.CustomFontFamilies = ""
            Me.tabPage8.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.tabPage8.Location = New System.Drawing.Point(4, 24)
            Me.tabPage8.Name = "tabPage8"
            Me.tabPage8.Size = New System.Drawing.Size(485, 283)
            Me.tabPage8.TabIndex = 7
            Me.tabPage8.Text = "More"
            Me.tabPage8.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.tabPage8.TooltipText = ""
            Me.tabPage8.Visible = False
            Me.tabPage8.ZOrder = 0
            '
            'label5
            '
            Me.label5.BackColor = System.Drawing.Color.Brown
            Me.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            Me.label5.ClassName = ""
            Me.label5.CustomFontFamilies = ""
            Me.label5.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label5.ForeColor = System.Drawing.Color.White
            Me.label5.Image = Nothing
            Me.label5.Location = New System.Drawing.Point(107, 131)
            Me.label5.Name = "label5"
            Me.label5.Opacity = 100
            Me.label5.Size = New System.Drawing.Size(271, 21)
            Me.label5.TabIndex = 5
            Me.label5.Text = "Other Tab with Default BackgroundColor"
            Me.label5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.label5.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label5.TooltipText = ""
            Me.label5.UseMnemonic = False
            Me.label5.ZOrder = 0
            '
            'comboBox1
            '
            Me.comboBox1.ClassName = ""
            Me.comboBox1.CustomFontFamilies = ""
            Me.comboBox1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.comboBox1.Items.AddRange(New Object() {"Customers", "Contacts", "Money", "More"})
            Me.comboBox1.Location = New System.Drawing.Point(514, 90)
            Me.comboBox1.MinSelectedIndex = -1
            Me.comboBox1.Name = "comboBox1"
            Me.comboBox1.Opacity = 100
            Me.comboBox1.Size = New System.Drawing.Size(171, 23)
            Me.comboBox1.TabIndex = 1
            Me.comboBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.comboBox1.TooltipText = ""
            Me.comboBox1.UpdateTextBySelection = Nothing
            Me.comboBox1.ValidationMessage = "An action is required"
            Me.comboBox1.Visible = False
            Me.comboBox1.ZOrder = 0
            '
            'imageList1
            '
            Me.imageList1.ImageStream = CType(resources.GetObject("imageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
            Me.imageList1.Tag = "TabsDemo"
            Me.imageList1.TransparentColor = System.Drawing.Color.Transparent
            Me.imageList1.Images.SetKeyName(0, "Customers.png")
            Me.imageList1.Images.SetKeyName(1, "Contacts.png")
            Me.imageList1.Images.SetKeyName(2, "Money.png")
            Me.imageList1.Images.SetKeyName(3, "more.png")
            '
            'label1
            '
            Me.label1.BackColor = System.Drawing.Color.Gold
            Me.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(511, 38)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 100
            Me.label1.Size = New System.Drawing.Size(174, 48)
            Me.label1.TabIndex = 2
            Me.label1.Text = "You can also use ISelect controls for tab index selection management"
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.Visible = False
            Me.label1.ZOrder = 0
            '
            'jButton1
            '
            Me.jButton1.ApplicationWideResource = True
            Me.jButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton1.BackgroundImagePosition = ""
            Me.jButton1.BackgroundImageQuality = CType(80, Short)
            Me.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton1.ClassName = ""
            Me.jButton1.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton1.CustomFontFamilies = ""
            Me.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton1.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton1.Icon = Nothing
            Me.jButton1.IconURL = ""
            Me.jButton1.Image = Nothing
            Me.jButton1.ImageLocation = ""
            Me.jButton1.Location = New System.Drawing.Point(511, 12)
            Me.jButton1.Name = "jButton1"
            Me.jButton1.Opacity = 100
            Me.jButton1.PreventMultipleClicks = True
            Me.jButton1.Size = New System.Drawing.Size(174, 23)
            Me.jButton1.TabIndex = 0
            Me.jButton1.Text = "Hide Headers"
            Me.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton1.TooltipText = ""
            Me.jButton1.UseVisualStyleBackColor = False
            Me.jButton1.ValidationFailedMessage = "Validation failed!"
            Me.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton1.VerticalGradient = True
            Me.jButton1.ZOrder = 0
            '
            'TabsTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(703, 333)
            Me.Controls.Add(Me.jButton1)
            Me.Controls.Add(Me.label1)
            Me.Controls.Add(Me.comboBox1)
            Me.Controls.Add(Me.tabControl1)
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "TabsTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "Tabs Demo"
            Me.tabControl1.ResumeLayout(False)
            Me.tabPage2.ResumeLayout(False)
            Me.tabPage4.ResumeLayout(False)
            Me.tabPage6.ResumeLayout(False)
            Me.tabPage8.ResumeLayout(False)
            Me.ResumeLayout(False)

        End Sub

		#End Region

        Friend WithEvents tabControl1 As VisualJS.Web.Forms.TabControl
		Private tabPage2 As VisualJS.Web.Forms.TabPage
		Public tabPage4 As VisualJS.Web.Forms.TabPage
		Private tabPage6 As VisualJS.Web.Forms.TabPage
		Private imageList1 As System.Windows.Forms.ImageList
		Private comboBox1 As VisualJS.Web.Forms.ComboBox
		Private label1 As VisualJS.Web.Forms.Label
        Friend WithEvents jButton1 As VisualJS.Web.Forms.JButton
		Private label2 As VisualJS.Web.Forms.Label
		Private label3 As VisualJS.Web.Forms.Label
		Private label4 As VisualJS.Web.Forms.Label
        Friend WithEvents tabPage8 As VisualJS.Web.Forms.TabPage
		Private label5 As VisualJS.Web.Forms.Label
	End Class
End Namespace 
