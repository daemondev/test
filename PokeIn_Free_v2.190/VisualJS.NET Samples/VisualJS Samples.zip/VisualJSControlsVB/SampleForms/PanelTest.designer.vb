
Namespace SampleForms
	Partial Class PanelTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PanelTest))
            Me.panel1 = New VisualJS.Web.Forms.Panel()
            Me.panel4 = New VisualJS.Web.Forms.Panel()
            Me.label5 = New VisualJS.Web.Forms.Label()
            Me.label4 = New VisualJS.Web.Forms.Label()
            Me.panel3 = New VisualJS.Web.Forms.Panel()
            Me.label3 = New VisualJS.Web.Forms.Label()
            Me.panel2 = New VisualJS.Web.Forms.Panel()
            Me.label2 = New VisualJS.Web.Forms.Label()
            Me.label1 = New VisualJS.Web.Forms.Label()
            Me.panel1.SuspendLayout()
            Me.panel4.SuspendLayout()
            Me.panel3.SuspendLayout()
            Me.panel2.SuspendLayout()
            Me.SuspendLayout()
            '
            'panel1
            '
            Me.panel1.ApplicationWideResource = True
            Me.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.panel1.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.panel1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(176, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
            Me.panel1.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
            Me.panel1.BackgroundImagePosition = ""
            Me.panel1.BackgroundImageQuality = CType(80, Short)
            Me.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.panel1.BorderColor = System.Drawing.Color.Black
            Me.panel1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid
            Me.panel1.ClassName = ""
            Me.panel1.ClientID = Nothing
            Me.panel1.Controls.Add(Me.panel4)
            Me.panel1.Controls.Add(Me.label4)
            Me.panel1.Controls.Add(Me.panel3)
            Me.panel1.Controls.Add(Me.panel2)
            Me.panel1.Controls.Add(Me.label1)
            Me.panel1.CustomFontFamilies = ""
            Me.panel1.Dock = System.Windows.Forms.DockStyle.Fill
            Me.panel1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.panel1.HTML = ""
            Me.panel1.ImageLocation = ""
            Me.panel1.Location = New System.Drawing.Point(0, 0)
            Me.panel1.Name = "panel1"
            Me.panel1.Opacity = 100
            Me.panel1.Size = New System.Drawing.Size(860, 476)
            Me.panel1.TabIndex = 0
            Me.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.panel1.TooltipText = ""
            Me.panel1.VerticalGradient = True
            Me.panel1.ZOrder = 0
            '
            'panel4
            '
            Me.panel4.ApplicationWideResource = True
            Me.panel4.AutoGrowShrink = VisualJS.Service.GrowShrink.ByWidth
            Me.panel4.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.panel4.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.panel4.BackColor = System.Drawing.Color.Transparent
            Me.panel4.BackColorEnd = System.Drawing.Color.Transparent
            Me.panel4.BackgroundImagePosition = ""
            Me.panel4.BackgroundImageQuality = CType(80, Short)
            Me.panel4.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.panel4.BorderColor = System.Drawing.Color.OrangeRed
            Me.panel4.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Dashed
            Me.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            Me.panel4.ClassName = ""
            Me.panel4.ClientID = Nothing
            Me.panel4.Controls.Add(Me.label5)
            Me.panel4.CustomFontFamilies = ""
            Me.panel4.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.panel4.ForeColor = System.Drawing.Color.Yellow
            Me.panel4.HTML = "<p style='margin:10px;'>This is the <strong>HTML</html> content inside the Panel " & _
        "control</p>"
            Me.panel4.ImageLocation = ""
            Me.panel4.Location = New System.Drawing.Point(0, 75)
            Me.panel4.Name = "panel4"
            Me.panel4.Opacity = 100
            Me.panel4.Size = New System.Drawing.Size(860, 122)
            Me.panel4.TabIndex = 4
            Me.panel4.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.panel4.TooltipText = ""
            Me.panel4.VerticalGradient = True
            Me.panel4.ZOrder = 0
            '
            'label5
            '
            Me.label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.label5.BackColor = System.Drawing.Color.Transparent
            Me.label5.ClassName = ""
            Me.label5.CustomFontFamilies = ""
            Me.label5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label5.ForeColor = System.Drawing.Color.White
            Me.label5.Image = Nothing
            Me.label5.Location = New System.Drawing.Point(689, 11)
            Me.label5.Name = "label5"
            Me.label5.Opacity = 90
            Me.label5.Size = New System.Drawing.Size(158, 69)
            Me.label5.TabIndex = 3
            Me.label5.Text = "AutoGrowShrink by Width, HTML Content Support, Transparent Background, Dashed Ora" & _
        "nge Border"
            Me.label5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
            Me.label5.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label5.TooltipText = ""
            Me.label5.UseMnemonic = False
            Me.label5.ZOrder = 0
            '
            'label4
            '
            Me.label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.label4.BackColor = System.Drawing.Color.Transparent
            Me.label4.ClassName = ""
            Me.label4.CustomFontFamilies = ""
            Me.label4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label4.ForeColor = System.Drawing.Color.White
            Me.label4.Image = Nothing
            Me.label4.Location = New System.Drawing.Point(604, 9)
            Me.label4.Name = "label4"
            Me.label4.Opacity = 90
            Me.label4.Size = New System.Drawing.Size(140, 36)
            Me.label4.TabIndex = 3
            Me.label4.Text = "Min Form Width:  550, Min Form Height: 400"
            Me.label4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label4.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label4.TooltipText = ""
            Me.label4.UseMnemonic = False
            Me.label4.ZOrder = 0
            '
            'panel3
            '
            Me.panel3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
            Me.panel3.ApplicationWideResource = True
            Me.panel3.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.panel3.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.panel3.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.panel3.BackColor = System.Drawing.Color.Black
            Me.panel3.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(102, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(102, Byte), Integer))
            Me.panel3.BackgroundImagePosition = ""
            Me.panel3.BackgroundImageQuality = CType(80, Short)
            Me.panel3.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.panel3.BorderColor = System.Drawing.Color.Black
            Me.panel3.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid
            Me.panel3.ClassName = ""
            Me.panel3.ClientID = Nothing
            Me.panel3.Controls.Add(Me.label3)
            Me.panel3.CustomFontFamilies = ""
            Me.panel3.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.panel3.HTML = ""
            Me.panel3.ImageLocation = ""
            Me.panel3.Location = New System.Drawing.Point(12, 230)
            Me.panel3.Name = "panel3"
            Me.panel3.Opacity = 20
            Me.panel3.Size = New System.Drawing.Size(241, 229)
            Me.panel3.TabIndex = 2
            Me.panel3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.panel3.TooltipText = ""
            Me.panel3.VerticalGradient = True
            Me.panel3.ZOrder = 0
            '
            'label3
            '
            Me.label3.BackColor = System.Drawing.Color.Transparent
            Me.label3.ClassName = ""
            Me.label3.CustomFontFamilies = ""
            Me.label3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label3.ForeColor = System.Drawing.Color.White
            Me.label3.Image = Nothing
            Me.label3.Location = New System.Drawing.Point(12, 13)
            Me.label3.Name = "label3"
            Me.label3.Opacity = 90
            Me.label3.Size = New System.Drawing.Size(106, 67)
            Me.label3.TabIndex = 2
            Me.label3.Text = "Opacity 20%, Gradient, Anchored to bottom left"
            Me.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label3.TooltipText = ""
            Me.label3.UseMnemonic = False
            Me.label3.ZOrder = 0
            '
            'panel2
            '
            Me.panel2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.panel2.ApplicationWideResource = True
            Me.panel2.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.panel2.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.panel2.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.panel2.BackColor = System.Drawing.Color.Black
            Me.panel2.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(102, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(102, Byte), Integer))
            Me.panel2.BackgroundImagePosition = ""
            Me.panel2.BackgroundImageQuality = CType(80, Short)
            Me.panel2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.panel2.BorderColor = System.Drawing.Color.Black
            Me.panel2.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid
            Me.panel2.ClassName = ""
            Me.panel2.ClientID = Nothing
            Me.panel2.Controls.Add(Me.label2)
            Me.panel2.CustomFontFamilies = ""
            Me.panel2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.panel2.HTML = ""
            Me.panel2.ImageLocation = ""
            Me.panel2.Location = New System.Drawing.Point(607, 230)
            Me.panel2.Name = "panel2"
            Me.panel2.Opacity = 70
            Me.panel2.Size = New System.Drawing.Size(241, 229)
            Me.panel2.TabIndex = 1
            Me.panel2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.panel2.TooltipText = ""
            Me.panel2.VerticalGradient = True
            Me.panel2.ZOrder = 0
            '
            'label2
            '
            Me.label2.BackColor = System.Drawing.Color.Transparent
            Me.label2.ClassName = ""
            Me.label2.CustomFontFamilies = ""
            Me.label2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label2.ForeColor = System.Drawing.Color.White
            Me.label2.Image = Nothing
            Me.label2.Location = New System.Drawing.Point(12, 13)
            Me.label2.Name = "label2"
            Me.label2.Opacity = 90
            Me.label2.Size = New System.Drawing.Size(106, 67)
            Me.label2.TabIndex = 2
            Me.label2.Text = "Opacity 70%, Gradient, Anchored to bottom right"
            Me.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label2.TooltipText = ""
            Me.label2.UseMnemonic = False
            Me.label2.ZOrder = 0
            '
            'label1
            '
            Me.label1.BackColor = System.Drawing.Color.Transparent
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label1.ForeColor = System.Drawing.Color.White
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(12, 9)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 90
            Me.label1.Size = New System.Drawing.Size(241, 36)
            Me.label1.TabIndex = 0
            Me.label1.Text = "Base Panel is Docked in Fill Mode with Gradient Background Color"
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.ZOrder = 0
            '
            'PanelTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(176, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
            Me.ClientSize = New System.Drawing.Size(860, 476)
            Me.Controls.Add(Me.panel1)
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.Name = "PanelTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "Panel Demo"
            Me.panel1.ResumeLayout(False)
            Me.panel4.ResumeLayout(False)
            Me.panel3.ResumeLayout(False)
            Me.panel2.ResumeLayout(False)
            Me.ResumeLayout(False)

        End Sub

		#End Region

		Private panel1 As VisualJS.Web.Forms.Panel
		Private label1 As VisualJS.Web.Forms.Label
		Private panel3 As VisualJS.Web.Forms.Panel
		Private label3 As VisualJS.Web.Forms.Label
		Private panel2 As VisualJS.Web.Forms.Panel
		Private label2 As VisualJS.Web.Forms.Label
		Private label4 As VisualJS.Web.Forms.Label
		Private panel4 As VisualJS.Web.Forms.Panel
		Private label5 As VisualJS.Web.Forms.Label
	End Class
End Namespace 
