
Namespace SampleForms
	Partial Class FeedBoxTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FeedBoxTest))
            Me.label1 = New VisualJS.Web.Forms.Label()
            Me.label2 = New VisualJS.Web.Forms.Label()
            Me.feedBox2 = New VisualJS.Web.Forms.FeedBox()
            Me.feedBox1 = New VisualJS.Web.Forms.FeedBox()
            CType(Me.feedBox2, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.feedBox1, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.SuspendLayout()
            '
            'label1
            '
            Me.label1.AutoSize = True
            Me.label1.BackColor = System.Drawing.Color.Transparent
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label1.ForeColor = System.Drawing.Color.LightSkyBlue
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(12, 9)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 100
            Me.label1.Size = New System.Drawing.Size(119, 15)
            Me.label1.TabIndex = 1
            Me.label1.Text = "Target External URL"
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.ZOrder = 0
            '
            'label2
            '
            Me.label2.AutoSize = True
            Me.label2.BackColor = System.Drawing.Color.Transparent
            Me.label2.ClassName = ""
            Me.label2.CustomFontFamilies = ""
            Me.label2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label2.ForeColor = System.Drawing.Color.LightSkyBlue
            Me.label2.Image = Nothing
            Me.label2.Location = New System.Drawing.Point(222, 9)
            Me.label2.Name = "label2"
            Me.label2.Opacity = 100
            Me.label2.Size = New System.Drawing.Size(146, 15)
            Me.label2.TabIndex = 3
            Me.label2.Text = "Target Server Side Event"
            Me.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label2.TooltipText = ""
            Me.label2.UseMnemonic = False
            Me.label2.ZOrder = 0
            '
            'feedBox2
            '
            Me.feedBox2.ApplicationWideResource = True
            Me.feedBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(144, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(16, Byte), Integer))
            Me.feedBox2.ClassName = ""
            Me.feedBox2.Cursor = System.Windows.Forms.Cursors.Hand
            Me.feedBox2.ErrorImage = CType(resources.GetObject("feedBox2.ErrorImage"), System.Drawing.Image)
            Me.feedBox2.ForeColor = System.Drawing.Color.White
            Me.feedBox2.Image = Global.VisualJSControlsVB.My.Resources.Resources.ios5
            Me.feedBox2.ImageQuality = CType(80, Short)
            Me.feedBox2.ImageText = "Target IOS Devices"
            Me.feedBox2.InitialImage = CType(resources.GetObject("feedBox2.InitialImage"), System.Drawing.Image)
            Me.feedBox2.Location = New System.Drawing.Point(225, 27)
            Me.feedBox2.Name = "feedBox2"
            Me.feedBox2.Opacity = 100
            Me.feedBox2.Size = New System.Drawing.Size(190, 200)
            Me.feedBox2.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal
            Me.feedBox2.TabIndex = 2
            Me.feedBox2.TabStop = False
            Me.feedBox2.Target = VisualJS.Web.Forms.FeedBox.URLOpen.NewWindow
            Me.feedBox2.TargetURL = ""
            Me.feedBox2.Text = "VisualJS.NET IOS Support"
            Me.feedBox2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.feedBox2.TooltipText = ""
            Me.feedBox2.ZOrder = 0
            '
            'feedBox1
            '
            Me.feedBox1.ApplicationWideResource = True
            Me.feedBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(144, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(16, Byte), Integer))
            Me.feedBox1.ClassName = ""
            Me.feedBox1.ErrorImage = CType(resources.GetObject("feedBox1.ErrorImage"), System.Drawing.Image)
            Me.feedBox1.ForeColor = System.Drawing.Color.White
            Me.feedBox1.Image = Global.VisualJSControlsVB.My.Resources.Resources.android_logo
            Me.feedBox1.ImageQuality = CType(80, Short)
            Me.feedBox1.ImageText = "Target Android Devices"
            Me.feedBox1.InitialImage = CType(resources.GetObject("feedBox1.InitialImage"), System.Drawing.Image)
            Me.feedBox1.Location = New System.Drawing.Point(15, 27)
            Me.feedBox1.Name = "feedBox1"
            Me.feedBox1.Opacity = 100
            Me.feedBox1.Size = New System.Drawing.Size(190, 200)
            Me.feedBox1.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal
            Me.feedBox1.TabIndex = 0
            Me.feedBox1.TabStop = False
            Me.feedBox1.Target = VisualJS.Web.Forms.FeedBox.URLOpen.NewWindow
            Me.feedBox1.TargetURL = "http://www.visualjs.net"
            Me.feedBox1.Text = "VisualJS.NET Android Support"
            Me.feedBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.feedBox1.TooltipText = ""
            Me.feedBox1.ZOrder = 0
            '
            'FeedBoxTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.BackColor = System.Drawing.Color.Black
            Me.ClientSize = New System.Drawing.Size(437, 243)
            Me.Controls.Add(Me.label2)
            Me.Controls.Add(Me.feedBox2)
            Me.Controls.Add(Me.label1)
            Me.Controls.Add(Me.feedBox1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "FeedBoxTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "FeedBox Demo"
            CType(Me.feedBox2, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.feedBox1, System.ComponentModel.ISupportInitialize).EndInit()
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

		#End Region

        Friend WithEvents feedBox1 As VisualJS.Web.Forms.FeedBox
		Private label1 As VisualJS.Web.Forms.Label
		Private label2 As VisualJS.Web.Forms.Label
        Friend WithEvents feedBox2 As VisualJS.Web.Forms.FeedBox
	End Class
End Namespace 
