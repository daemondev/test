﻿Namespace VisualJSControlsVB.SampleForms
    <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
    Partial Class CustomControl
        Inherits VisualJS.Web.Forms.Form

        'Form overrides dispose to clean up the component list.
        <System.Diagnostics.DebuggerNonUserCode()> _
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            Try
                If disposing AndAlso components IsNot Nothing Then
                    components.Dispose()
                End If
            Finally
                MyBase.Dispose(disposing)
            End Try
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            Me.MyCustomControl1 = New VisualJSControlsVB.MyCustomControl()
            Me.SuspendLayout()
            '
            'MyCustomControl1
            '
            Me.MyCustomControl1.ApplicationWideResource = True
            Me.MyCustomControl1.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.MyCustomControl1.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.MyCustomControl1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.MyCustomControl1.BackColor = System.Drawing.Color.Transparent
            Me.MyCustomControl1.BackColorEnd = System.Drawing.Color.Transparent
            Me.MyCustomControl1.BackgroundImagePosition = ""
            Me.MyCustomControl1.BackgroundImageQuality = CType(80, Short)
            Me.MyCustomControl1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.MyCustomControl1.BorderColor = System.Drawing.Color.Black
            Me.MyCustomControl1.BorderLineStyle = VisualJS.Web.Forms.UserControl.ClientBorderStyle.Solid
            Me.MyCustomControl1.ClassName = ""
            Me.MyCustomControl1.ClientID = Nothing
            Me.MyCustomControl1.CustomFontFamilies = ""
            Me.MyCustomControl1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.MyCustomControl1.HTML = ""
            Me.MyCustomControl1.ImageLocation = ""
            Me.MyCustomControl1.Location = New System.Drawing.Point(60, 41)
            Me.MyCustomControl1.Name = "MyCustomControl1"
            Me.MyCustomControl1.Opacity = 100
            Me.MyCustomControl1.Size = New System.Drawing.Size(254, 41)
            Me.MyCustomControl1.TabIndex = 0
            Me.MyCustomControl1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.MyCustomControl1.TooltipText = ""
            Me.MyCustomControl1.VerticalGradient = True
            Me.MyCustomControl1.ZOrder = 0
            '
            'CustomControl
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(389, 136)
            Me.Controls.Add(Me.MyCustomControl1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "CustomControl"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "CustomControl"
            Me.ResumeLayout(False)

        End Sub
        Friend WithEvents MyCustomControl1 As MyCustomControl

    End Class
End Namespace