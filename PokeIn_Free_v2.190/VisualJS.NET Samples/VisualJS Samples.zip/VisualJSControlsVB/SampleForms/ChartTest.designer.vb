
Namespace SampleForms
	Partial Class ChartTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ChartTest))
            Me.pnlChart1 = New VisualJS.Web.Forms.Panel()
            Me.label1 = New VisualJS.Web.Forms.Label()
            Me.label2 = New VisualJS.Web.Forms.Label()
            Me.pnlChart2 = New VisualJS.Web.Forms.Panel()
            Me.label3 = New VisualJS.Web.Forms.Label()
            Me.SuspendLayout()
            '
            'pnlChart1
            '
            Me.pnlChart1.ApplicationWideResource = True
            Me.pnlChart1.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.pnlChart1.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.pnlChart1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.pnlChart1.BackColor = System.Drawing.Color.White
            Me.pnlChart1.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(238, Byte), Integer))
            Me.pnlChart1.BackgroundImagePosition = ""
            Me.pnlChart1.BackgroundImageQuality = CType(80, Short)
            Me.pnlChart1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.pnlChart1.BorderColor = System.Drawing.Color.Black
            Me.pnlChart1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid
            Me.pnlChart1.ClassName = ""
            Me.pnlChart1.ClientID = Nothing
            Me.pnlChart1.CustomFontFamilies = ""
            Me.pnlChart1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.pnlChart1.HTML = ""
            Me.pnlChart1.ImageLocation = ""
            Me.pnlChart1.Location = New System.Drawing.Point(12, 28)
            Me.pnlChart1.Name = "pnlChart1"
            Me.pnlChart1.Opacity = 100
            Me.pnlChart1.Size = New System.Drawing.Size(366, 241)
            Me.pnlChart1.TabIndex = 0
            Me.pnlChart1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.pnlChart1.TooltipText = ""
            Me.pnlChart1.VerticalGradient = True
            Me.pnlChart1.ZOrder = 0
            '
            'label1
            '
            Me.label1.AutoSize = True
            Me.label1.BackColor = System.Drawing.Color.Transparent
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label1.ForeColor = System.Drawing.Color.Black
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(9, 10)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 100
            Me.label1.Size = New System.Drawing.Size(197, 15)
            Me.label1.TabIndex = 1
            Me.label1.Text = "Full interactive Line && Bar Chart."
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.ZOrder = 0
            '
            'label2
            '
            Me.label2.AutoSize = True
            Me.label2.BackColor = System.Drawing.Color.Transparent
            Me.label2.ClassName = ""
            Me.label2.CustomFontFamilies = ""
            Me.label2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label2.ForeColor = System.Drawing.Color.Black
            Me.label2.Image = Nothing
            Me.label2.Location = New System.Drawing.Point(396, 10)
            Me.label2.Name = "label2"
            Me.label2.Opacity = 100
            Me.label2.Size = New System.Drawing.Size(250, 15)
            Me.label2.TabIndex = 3
            Me.label2.Text = "Pie Chart (Click one of the pie areas below)"
            Me.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label2.TooltipText = ""
            Me.label2.UseMnemonic = False
            Me.label2.ZOrder = 0
            '
            'pnlChart2
            '
            Me.pnlChart2.ApplicationWideResource = True
            Me.pnlChart2.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.pnlChart2.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.pnlChart2.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.pnlChart2.BackColor = System.Drawing.Color.White
            Me.pnlChart2.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(238, Byte), Integer))
            Me.pnlChart2.BackgroundImagePosition = ""
            Me.pnlChart2.BackgroundImageQuality = CType(80, Short)
            Me.pnlChart2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.pnlChart2.BorderColor = System.Drawing.Color.Black
            Me.pnlChart2.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid
            Me.pnlChart2.ClassName = ""
            Me.pnlChart2.ClientID = Nothing
            Me.pnlChart2.CustomFontFamilies = ""
            Me.pnlChart2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.pnlChart2.HTML = ""
            Me.pnlChart2.ImageLocation = ""
            Me.pnlChart2.Location = New System.Drawing.Point(399, 28)
            Me.pnlChart2.Name = "pnlChart2"
            Me.pnlChart2.Opacity = 100
            Me.pnlChart2.Size = New System.Drawing.Size(366, 241)
            Me.pnlChart2.TabIndex = 2
            Me.pnlChart2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.pnlChart2.TooltipText = ""
            Me.pnlChart2.VerticalGradient = True
            Me.pnlChart2.ZOrder = 0
            '
            'label3
            '
            Me.label3.AutoSize = True
            Me.label3.BackColor = System.Drawing.Color.Transparent
            Me.label3.ClassName = ""
            Me.label3.CustomFontFamilies = ""
            Me.label3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label3.ForeColor = System.Drawing.Color.Black
            Me.label3.Image = Nothing
            Me.label3.Location = New System.Drawing.Point(12, 280)
            Me.label3.Name = "label3"
            Me.label3.Opacity = 100
            Me.label3.Size = New System.Drawing.Size(334, 15)
            Me.label3.TabIndex = 4
            Me.label3.Text = "Column, Doughnut Charts. Flow Support. User Interaction. "
            Me.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label3.TooltipText = ""
            Me.label3.UseMnemonic = False
            Me.label3.ZOrder = 0
            '
            'ChartTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.BackColor = System.Drawing.Color.White
            Me.ClientSize = New System.Drawing.Size(781, 304)
            Me.Controls.Add(Me.label3)
            Me.Controls.Add(Me.label2)
            Me.Controls.Add(Me.pnlChart2)
            Me.Controls.Add(Me.label1)
            Me.Controls.Add(Me.pnlChart1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "ChartTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "Chart Demo"
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

		#End Region

		Private pnlChart1 As VisualJS.Web.Forms.Panel
		Private label1 As VisualJS.Web.Forms.Label
		Private label2 As VisualJS.Web.Forms.Label
        Friend WithEvents pnlChart2 As VisualJS.Web.Forms.Panel
		Private label3 As VisualJS.Web.Forms.Label
	End Class
End Namespace 
