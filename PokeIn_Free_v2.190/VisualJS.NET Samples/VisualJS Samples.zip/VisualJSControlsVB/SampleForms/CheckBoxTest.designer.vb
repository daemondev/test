
Namespace SampleForms
	Partial Class CheckBoxTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CheckBoxTest))
            Me.checkBox1 = New VisualJS.Web.Forms.CheckBox()
            Me.label1 = New VisualJS.Web.Forms.Label()
            Me.checkBox2 = New VisualJS.Web.Forms.CheckBox()
            Me.checkBox3 = New VisualJS.Web.Forms.CheckBox()
            Me.checkBox4 = New VisualJS.Web.Forms.CheckBox()
            Me.maskedTextBox1 = New VisualJS.Web.Forms.MaskedTextBox()
            Me.label2 = New VisualJS.Web.Forms.Label()
            Me.SuspendLayout()
            '
            'checkBox1
            '
            Me.checkBox1.BackColor = System.Drawing.Color.Transparent
            Me.checkBox1.ClassName = ""
            Me.checkBox1.CustomFontFamilies = ""
            Me.checkBox1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.checkBox1.Image = Nothing
            Me.checkBox1.Location = New System.Drawing.Point(15, 36)
            Me.checkBox1.MustBeCheckedBeforeSubmit = False
            Me.checkBox1.Name = "checkBox1"
            Me.checkBox1.Opacity = 100
            Me.checkBox1.Size = New System.Drawing.Size(170, 23)
            Me.checkBox1.TabIndex = 8
            Me.checkBox1.Tag = "200000"
            Me.checkBox1.Text = "Sport Car [USD 200.000]"
            Me.checkBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.checkBox1.TooltipText = ""
            Me.checkBox1.UseMnemonic = False
            Me.checkBox1.UseVisualStyleBackColor = False
            Me.checkBox1.ValidationMessage = "An action is required"
            Me.checkBox1.ZOrder = 0
            '
            'label1
            '
            Me.label1.AutoSize = True
            Me.label1.BackColor = System.Drawing.Color.Transparent
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(12, 9)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 100
            Me.label1.Size = New System.Drawing.Size(286, 15)
            Me.label1.TabIndex = 1
            Me.label1.Text = "Please check the below things you are going to buy"
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.ZOrder = 0
            '
            'checkBox2
            '
            Me.checkBox2.BackColor = System.Drawing.Color.Transparent
            Me.checkBox2.ClassName = ""
            Me.checkBox2.CustomFontFamilies = ""
            Me.checkBox2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.checkBox2.Image = Nothing
            Me.checkBox2.Location = New System.Drawing.Point(15, 61)
            Me.checkBox2.MustBeCheckedBeforeSubmit = False
            Me.checkBox2.Name = "checkBox2"
            Me.checkBox2.Opacity = 100
            Me.checkBox2.Size = New System.Drawing.Size(161, 23)
            Me.checkBox2.TabIndex = 3
            Me.checkBox2.Tag = "400000"
            Me.checkBox2.Text = "House [USD 400.000]"
            Me.checkBox2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.checkBox2.TooltipText = ""
            Me.checkBox2.UseMnemonic = False
            Me.checkBox2.UseVisualStyleBackColor = False
            Me.checkBox2.ValidationMessage = "An action is required"
            Me.checkBox2.ZOrder = 0
            '
            'checkBox3
            '
            Me.checkBox3.AutoSize = True
            Me.checkBox3.BackColor = System.Drawing.Color.Transparent
            Me.checkBox3.ClassName = ""
            Me.checkBox3.CustomFontFamilies = ""
            Me.checkBox3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.checkBox3.Image = Nothing
            Me.checkBox3.Location = New System.Drawing.Point(15, 90)
            Me.checkBox3.MustBeCheckedBeforeSubmit = False
            Me.checkBox3.Name = "checkBox3"
            Me.checkBox3.Opacity = 100
            Me.checkBox3.Size = New System.Drawing.Size(117, 19)
            Me.checkBox3.TabIndex = 4
            Me.checkBox3.Tag = "500"
            Me.checkBox3.Text = "QPAD [USD 500]"
            Me.checkBox3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.checkBox3.TooltipText = ""
            Me.checkBox3.UseMnemonic = False
            Me.checkBox3.UseVisualStyleBackColor = False
            Me.checkBox3.ValidationMessage = "An action is required"
            Me.checkBox3.ZOrder = 0
            '
            'checkBox4
            '
            Me.checkBox4.BackColor = System.Drawing.Color.Transparent
            Me.checkBox4.ClassName = ""
            Me.checkBox4.CustomFontFamilies = ""
            Me.checkBox4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.checkBox4.Image = Nothing
            Me.checkBox4.Location = New System.Drawing.Point(15, 115)
            Me.checkBox4.MustBeCheckedBeforeSubmit = False
            Me.checkBox4.Name = "checkBox4"
            Me.checkBox4.Opacity = 100
            Me.checkBox4.Size = New System.Drawing.Size(161, 23)
            Me.checkBox4.TabIndex = 5
            Me.checkBox4.Tag = "500"
            Me.checkBox4.Text = "MBOX 360 [USD 500]"
            Me.checkBox4.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.checkBox4.TooltipText = ""
            Me.checkBox4.UseMnemonic = False
            Me.checkBox4.UseVisualStyleBackColor = False
            Me.checkBox4.ValidationMessage = "An action is required"
            Me.checkBox4.ZOrder = 0
            '
            'maskedTextBox1
            '
            Me.maskedTextBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.maskedTextBox1.CheckForEmail = False
            Me.maskedTextBox1.ClassName = ""
            Me.maskedTextBox1.CustomFontFamilies = ""
            Me.maskedTextBox1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.maskedTextBox1.Location = New System.Drawing.Point(191, 119)
            Me.maskedTextBox1.MinLength = -1
            Me.maskedTextBox1.Name = "maskedTextBox1"
            Me.maskedTextBox1.Opacity = 100
            Me.maskedTextBox1.PreventSQLInjection = False
            Me.maskedTextBox1.ReadOnly = True
            Me.maskedTextBox1.RegexCheck = ""
            Me.maskedTextBox1.Size = New System.Drawing.Size(120, 21)
            Me.maskedTextBox1.TabIndex = 6
            Me.maskedTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
            Me.maskedTextBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.maskedTextBox1.TooltipText = ""
            Me.maskedTextBox1.ValidationMessage = "An action is required"
            Me.maskedTextBox1.ZOrder = 0
            '
            'label2
            '
            Me.label2.BackColor = System.Drawing.Color.Transparent
            Me.label2.ClassName = ""
            Me.label2.CustomFontFamilies = ""
            Me.label2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label2.ForeColor = System.Drawing.Color.Maroon
            Me.label2.Image = Nothing
            Me.label2.Location = New System.Drawing.Point(188, 98)
            Me.label2.Name = "label2"
            Me.label2.Opacity = 100
            Me.label2.Size = New System.Drawing.Size(81, 15)
            Me.label2.TabIndex = 7
            Me.label2.Text = "Total"
            Me.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label2.TooltipText = ""
            Me.label2.UseMnemonic = False
            Me.label2.ZOrder = 0
            '
            'CheckBoxTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(336, 161)
            Me.Controls.Add(Me.label2)
            Me.Controls.Add(Me.maskedTextBox1)
            Me.Controls.Add(Me.checkBox4)
            Me.Controls.Add(Me.checkBox3)
            Me.Controls.Add(Me.checkBox2)
            Me.Controls.Add(Me.label1)
            Me.Controls.Add(Me.checkBox1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "CheckBoxTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "CheckBox Demo"
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

		#End Region

        Friend WithEvents checkBox1 As VisualJS.Web.Forms.CheckBox
		Private label1 As VisualJS.Web.Forms.Label
        Friend WithEvents checkBox2 As VisualJS.Web.Forms.CheckBox
        Friend WithEvents checkBox3 As VisualJS.Web.Forms.CheckBox
        Friend WithEvents checkBox4 As VisualJS.Web.Forms.CheckBox
		Private maskedTextBox1 As VisualJS.Web.Forms.MaskedTextBox
		Private label2 As VisualJS.Web.Forms.Label
	End Class
End Namespace
