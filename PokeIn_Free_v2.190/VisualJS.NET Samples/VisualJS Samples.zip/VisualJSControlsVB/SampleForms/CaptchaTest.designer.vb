
Namespace SampleForms
	Partial Class CaptchaTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CaptchaTest))
            Me.textBox1 = New VisualJS.Web.Forms.TextBox()
            Me.captchaBox1 = New VisualJS.Web.Forms.CaptchaBox()
            Me.jButton1 = New VisualJS.Web.Forms.JButton()
            CType(Me.captchaBox1, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.SuspendLayout()
            '
            'textBox1
            '
            Me.textBox1.CheckForEmail = False
            Me.textBox1.ClassName = ""
            Me.textBox1.CustomFontFamilies = ""
            Me.textBox1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.textBox1.Location = New System.Drawing.Point(12, 139)
            Me.textBox1.MaxLength = 65535
            Me.textBox1.MinLength = 6
            Me.textBox1.Name = "textBox1"
            Me.textBox1.Opacity = 100
            Me.textBox1.PreventSQLInjection = False
            Me.textBox1.RegexCheck = ""
            Me.textBox1.Size = New System.Drawing.Size(184, 21)
            Me.textBox1.TabIndex = 1
            Me.textBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.textBox1.TooltipText = "Enter Captcha Text Here"
            Me.textBox1.ValidationMessage = "Please enter captcha text here"
            Me.textBox1.ZOrder = 0
            '
            'captchaBox1
            '
            Me.captchaBox1.BackColor = System.Drawing.Color.Black
            Me.captchaBox1.ClassName = ""
            Me.captchaBox1.ErrorImage = CType(resources.GetObject("captchaBox1.ErrorImage"), System.Drawing.Image)
            Me.captchaBox1.Image = Nothing
            Me.captchaBox1.InitialImage = CType(resources.GetObject("captchaBox1.InitialImage"), System.Drawing.Image)
            Me.captchaBox1.Location = New System.Drawing.Point(12, 12)
            Me.captchaBox1.Name = "captchaBox1"
            Me.captchaBox1.Opacity = 100
            Me.captchaBox1.Size = New System.Drawing.Size(184, 121)
            Me.captchaBox1.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.Normal
            Me.captchaBox1.TabIndex = 0
            Me.captchaBox1.TabStop = False
            Me.captchaBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.captchaBox1.TooltipText = ""
            Me.captchaBox1.ZOrder = 0
            '
            'jButton1
            '
            Me.jButton1.ApplicationWideResource = True
            Me.jButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton1.BackgroundImagePosition = ""
            Me.jButton1.BackgroundImageQuality = CType(80, Short)
            Me.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton1.ClassName = ""
            Me.jButton1.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton1.CustomFontFamilies = ""
            Me.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton1.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton1.Icon = Nothing
            Me.jButton1.IconURL = ""
            Me.jButton1.Image = Nothing
            Me.jButton1.ImageLocation = ""
            Me.jButton1.Location = New System.Drawing.Point(12, 166)
            Me.jButton1.Name = "jButton1"
            Me.jButton1.Opacity = 100
            Me.jButton1.PreventMultipleClicks = True
            Me.jButton1.Size = New System.Drawing.Size(184, 23)
            Me.jButton1.TabIndex = 0
            Me.jButton1.Text = "Submit"
            Me.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton1.TooltipText = ""
            Me.jButton1.UseVisualStyleBackColor = False
            Me.jButton1.ValidationFailedMessage = "Enter Captcha Text"
            Me.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnForm
            Me.jButton1.VerticalGradient = True
            Me.jButton1.ZOrder = 0
            '
            'CaptchaTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(209, 203)
            Me.Controls.Add(Me.jButton1)
            Me.Controls.Add(Me.textBox1)
            Me.Controls.Add(Me.captchaBox1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "CaptchaTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "Captcha Demo"
            CType(Me.captchaBox1, System.ComponentModel.ISupportInitialize).EndInit()
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

		#End Region

		Private captchaBox1 As VisualJS.Web.Forms.CaptchaBox
		Private textBox1 As VisualJS.Web.Forms.TextBox
        Friend WithEvents jButton1 As VisualJS.Web.Forms.JButton
	End Class
End Namespace
