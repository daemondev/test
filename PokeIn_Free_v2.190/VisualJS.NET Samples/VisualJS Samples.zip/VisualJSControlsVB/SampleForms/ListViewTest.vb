
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports VisualJS
Imports VisualJS.Web.Forms
Imports System.Linq
Imports System.Text

Namespace SampleForms
	Public Partial Class ListViewTest
        Inherits VisualJS.Web.Forms.Form

#Region "Constructors"
        Public Sub New()
            InitializeComponent()
            AfterInitialization()
        End Sub

        'Use the below constructor if you create the instance of this Form object other than the active Thread
        'otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        Public Sub New(clientId As String)
            MyBase.New(clientId)
            InitializeComponent()
            AfterInitialization()
        End Sub
#End Region

        Private Sub AfterInitialization()
            listView1.Columns.Add("Column 1", 100, System.Windows.Forms.HorizontalAlignment.Left)
            listView1.Columns.Add("Column 2", 115, System.Windows.Forms.HorizontalAlignment.Left)
            listView1.Columns.Add("Column 3", 115, System.Windows.Forms.HorizontalAlignment.Left)
            listView1.Columns.Add("Column 4", 115, System.Windows.Forms.HorizontalAlignment.Left)
        End Sub

        Private Sub jButton1_Click(sender As Object, e As EventArgs) Handles jButton1.Click
            If listView1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None Then
                jButton1.Text = "Hide Headers"
                listView1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Clickable
            Else
                jButton1.Text = "Show Headers"
                listView1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
            End If
        End Sub

        Private Sub jButton4_Click(sender As Object, e As EventArgs) Handles jButton4.Click
            If listView1.CheckBoxes Then
                jButton4.Text = "Show CheckBoxes"
            Else
                jButton4.Text = "Hide CheckBoxes"
            End If
            listView1.CheckBoxes = Not listView1.CheckBoxes
        End Sub

        Private Sub jButton3_Click(sender As Object, e As EventArgs) Handles jButton3.Click
            n = 0
            listView1.Items.Clear()
        End Sub

        Private n As Integer = 0
        Private Sub jButton2_Click(sender As Object, e As EventArgs) Handles jButton2.Click
            If listView1.Items.Count >= 5000 Then
                MessageBox.Show("We limit this DEMO to 5.000 Rows", Me)
                Return
            End If
            Dim items As ListView.ListViewItem() = New ListView.ListViewItem(99) {}
            For i As Integer = 0 To 99
                items(i) = New ListView.ListViewItem("Item " + n.ToString())
                items(i).SubItems.Add("Sub Item 1 - " + n.ToString())
                items(i).SubItems.Add("Sub Item 2 - " + n.ToString())
                items(i).SubItems.Add("Sub Item 3 - " + n.ToString())
                items(i).SubItems(0).IconIndex = n Mod 7
                n += 1
            Next
            listView1.Items.AddRange(items)
        End Sub

        Private Sub listView1_OnCellValueUpdated(sender As Object, rowIndex As Integer, columnIndex As Integer, value As String) Handles listView1.OnCellValueUpdated
            listView1.Items(rowIndex).BackColor = Color.YellowGreen
        End Sub
	End Class
End Namespace 
