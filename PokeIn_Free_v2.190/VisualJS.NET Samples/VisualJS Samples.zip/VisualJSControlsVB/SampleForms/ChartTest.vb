

Imports VisualJS.Charts
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports VisualJS
Imports VisualJS.Web.Forms
Imports System.Linq
Imports System.Text
Namespace SampleForms

	Public Partial Class ChartTest
		Inherits VisualJS.Web.Forms.Form

		#Region "Constructors"
		Public Sub New()
			InitializeComponent()
			AfterInitialization()
		End Sub

		'Use the below constructor if you create the instance of this Form object other than the active Thread
		'otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
		Public Sub New(clientId As String)
			MyBase.New(clientId)
			InitializeComponent()
			AfterInitialization()
		End Sub
		#End Region

		'Use below method for the tasks after the initialization of the Form
		Private Sub AfterInitialization()
			DrawChart1()
			DrawChart2()
		End Sub

		Private chart1 As Chart, chart2 As Chart
		Private Sub DrawChart1()
			chart1 = New Chart(pnlChart1)
			Dim cs As Chart = chart1
			cs("Series1").Items.Add(New ChartData(1, 1))
			cs("Series1").Items.Add(New ChartData(2, 2))
			cs("Series1").Items.Add(New ChartData(3, 3))
			cs("Series1")(SerieType.Bar).Show = True
			cs("Series1")(SerieType.Bar).BarWidth = 0.4F
			cs("Series1")(SerieType.Point).Show = True

			cs("Series2").Items.Add(New ChartData(1, 1.4))
			cs("Series2").Items.Add(New ChartData(2, 2.1))
			cs("Series2").Items.Add(New ChartData(3, 4))
			cs.XAxis.FormatterFunction = "function(v){return '$ ' + v;}"

			cs("Series2")(SerieType.Line).Show = True
			cs("Series2")(SerieType.Point).Show = True
			cs("Series2").Label = "Series2"
			cs("Series2").LineColor = Color.Orange

			cs.BackgroundColor = Color.White
			cs.BackgroundColorEnd = Color.YellowGreen
			cs.Zoom = True
			cs.Navigation = True

			cs.Draw()
		End Sub

		Private Sub DrawChart2()
			chart2 = New Chart(pnlChart2)
			Dim cs As Chart = chart2
			cs("Series2").Items.Add(New ChartData(100, "Apple"))
			cs("Series2").Items.Add(New ChartData(60, "Orange"))
			cs("Series2").Items.Add(New ChartData(140, "Pineapple"))
			cs("Series2")(SerieType.Pie).PieLabelFormatter = "function(label, value, percent){ return label+'<br/>'+Math.round(percent)+'%';} "
			cs("Series2")(SerieType.Pie).Show = True
			cs.BackgroundColor = Color.White
			cs.BackgroundColorEnd = Color.Blue
			cs.ShowLegends = False
			cs.Draw()
		End Sub

        Private Sub pnlChart2_MouseDown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles pnlChart2.MouseDown
            Dim sname As String = chart2.GetClickedSerieName()
            Dim index As Integer = chart2.GetClickedPointIndex()
            MessageBox.Show("You have clicked <font color='blue'>" + sname + "</font>, <font color='red'>" + chart2(sname).Items(index).PieLabel + "</font>", Me)
        End Sub
	End Class
End Namespace
