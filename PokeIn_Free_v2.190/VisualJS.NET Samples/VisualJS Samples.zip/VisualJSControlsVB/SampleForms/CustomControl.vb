﻿Imports System
Imports System.Collections.Generic
Imports VisualJS.Web.Forms
Imports System.Drawing

Namespace VisualJSControlsVB.SampleForms
    Public Class CustomControl

#Region "Constructors"
        Public Sub New()
            ' This call is required by the designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.
        End Sub

        'Use the below constructor if you create the instance of this Form object other than the active Thread
        'otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        Public Sub New(clientId As String)
            MyBase.New(clientId)

            ' This call is required by the designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.

        End Sub
#End Region

        'Use below method for the tasks after the initialization of the Form
        Sub AfterInitialization()

        End Sub

    End Class
End Namespace