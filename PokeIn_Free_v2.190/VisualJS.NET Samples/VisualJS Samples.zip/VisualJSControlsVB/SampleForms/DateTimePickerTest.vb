
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports VisualJS
Imports VisualJS.Web.Forms
Imports System.Linq
Imports System.Text

Namespace SampleForms
	Public Partial Class DateTimePickerTest
		Inherits VisualJS.Web.Forms.Form
		Public Sub New()
			InitializeComponent()
			StartUp()
		End Sub

		'Use the below constructor if you create the instance of this Form object other than the active Thread
		'otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
		Public Sub New(clientId As String)
			MyBase.New(clientId)
			InitializeComponent()
			StartUp()
		End Sub

        Private Sub StartUp() Handles Me.Load
            dateTimePicker1.Value = DateTime.Now
        End Sub

        Private Sub jButton1_Click(sender As Object, e As EventArgs) Handles jButton1.Click
            lblLongDate.Text = dateTimePicker1.Value.ToLongDateString()
        End Sub

        Private Sub dateTimePicker1_TextChanged_1(sender As System.Object, e As System.EventArgs) Handles dtTurkish.TextChanged, dtGerman.TextChanged, dtChinese.TextChanged, dtArabic.TextChanged, dateTimePicker1.TextChanged
            Dim s As DateTimePicker = DirectCast(sender, DateTimePicker)
            dateTimePicker1.Value = s.Value
            dtChinese.Value = s.Value
            dtGerman.Value = s.Value
            dtTurkish.Value = s.Value
            dtArabic.Value = s.Value
        End Sub
    End Class
End Namespace 
