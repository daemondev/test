
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports VisualJS
Imports VisualJS.Web.Forms
Imports System.Linq
Imports System.Text

Namespace SampleForms
    Partial Public Class Buttons
        Inherits VisualJS.Web.Forms.Form
        Public Sub New()
            InitializeComponent()
        End Sub

        'Use the below constructor if you create the instance of this Form object other than the active Thread
        'otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
        Public Sub New(clientId As String)
            MyBase.New(clientId)
            InitializeComponent()
        End Sub

        Private Sub button2_Click(sender As System.Object, e As System.EventArgs) Handles button2.Click
            MessageBox.Show("Validation Passed", Me)
        End Sub
    End Class
End Namespace
