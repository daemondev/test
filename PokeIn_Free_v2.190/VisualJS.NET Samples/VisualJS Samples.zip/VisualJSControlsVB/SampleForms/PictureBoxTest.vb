
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports VisualJS
Imports VisualJS.Web.Forms
Imports System.Linq
Imports System.Text

Namespace SampleForms
	Public Partial Class PictureBoxTest
		Inherits VisualJS.Web.Forms.Form

		#Region "Constructors"
		Public Sub New()
			InitializeComponent()
			AfterInitialization()
		End Sub

		'Use the below constructor if you create the instance of this Form object other than the active Thread
		'otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
		Public Sub New(clientId As String)
			MyBase.New(clientId)
			InitializeComponent()
			AfterInitialization()
		End Sub
		#End Region

		'Use below method for the tasks after the initialization of the Form
		Private Sub AfterInitialization()
			Me.Height = 230
		End Sub

		Private mored As Boolean = False
		Private oldLocation As Integer = 0
        Private Sub jButton1_Click(sender As Object, e As EventArgs) Handles jButton1.Click
            If mored Then
                jButton1.Text = "More Sample.."
                mored = False
                Me.Height = 230
                Me.Top = oldLocation
            Else
                jButton1.Text = "Less Sample.."
                mored = True
                Me.Height = 520
                oldLocation = Me.Top
                Me.Top = 100
            End If
        End Sub

        Private Sub jButton2_Click(sender As Object, e As EventArgs) Handles jButton2.Click
            Dim bmp As New Bitmap(pictureBox7.Width, pictureBox7.Height)
            Dim grp As Graphics = Graphics.FromImage(bmp)
            grp.FillRectangle(New SolidBrush(clrBack.Color), 0, 0, pictureBox7.Width, pictureBox7.Height)
            grp.DrawString(txtImage.Text, Me.Font, New SolidBrush(clrText.Color), 15, 15)
            grp.Flush()
            grp.Save()
            pictureBox7.Image = bmp
        End Sub
	End Class
End Namespace
