

Imports PokeIn.Comet
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports VisualJS
Imports VisualJS.Web.Forms
Imports System.Linq
Imports System.Text
Namespace SampleForms

	Public Partial Class UploadTest
		Inherits VisualJS.Web.Forms.Form

		#Region "Constructors"
		Public Sub New()
			InitializeComponent()
			AfterInitialization()
		End Sub

		'Use the below constructor if you create the instance of this Form object other than the active Thread
		'otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
		Public Sub New(clientId As String)
			MyBase.New(clientId)
			InitializeComponent()
			AfterInitialization()
		End Sub
		#End Region

		'Use below method for the tasks after the initialization of the Form
		Private Sub AfterInitialization()

		End Sub

		Friend Shared demoLock As New Object()
        Private Sub uploadFile1_OnUpload(ByRef file As PokeIn.Comet.HttpFile) Handles uploadFile1.OnUpload
            If file.ContentLength > 1024 * 1024 Then
                MessageBox.Show("For this demo, max allowed file size is 1mb", Me)
                Return
            End If
            'keep image component's output from multiple concurrent updates
            SyncLock demoLock
                file.SaveAs(Page.ApplicationPath + "//App_Data/" + file.FileName)
                ResourceManager.AddReplaceResource(Page.ApplicationPath + "//App_Data/" + file.FileName, "uploadFile", ResourceType.Image, Nothing)
                pictureBox1.ImageLocation = ResourceManager.GetResourceURL("uploadFile", ResourceType.Image)
            End SyncLock
        End Sub

        Private Sub jButton1_Click(sender As Object, e As EventArgs) Handles jButton1.Click
            uploadFile1.Start()
        End Sub
	End Class
End Namespace

'=======================================================
'Service provided by Telerik (www.telerik.com)
'Conversion powered by NRefactory.
'Twitter: @telerik, @toddanglin
'Facebook: facebook.com/telerik
'=======================================================
