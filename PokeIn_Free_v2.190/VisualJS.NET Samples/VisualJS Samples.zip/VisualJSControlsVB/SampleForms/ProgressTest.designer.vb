
Namespace SampleForms
	Partial Class ProgressTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ProgressTest))
            Me.progressBar1 = New VisualJS.Web.Forms.ProgressBar()
            Me.jButton1 = New VisualJS.Web.Forms.JButton()
            Me.borderStyle = New VisualJS.Web.Forms.ComboBox()
            Me.borderColor = New VisualJS.Web.Forms.ColorPicker()
            Me.cbackColor = New VisualJS.Web.Forms.ColorPicker()
            Me.label1 = New VisualJS.Web.Forms.Label()
            Me.label2 = New VisualJS.Web.Forms.Label()
            Me.label3 = New VisualJS.Web.Forms.Label()
            Me.ColorPicker1 = New VisualJS.Web.Forms.ColorPicker()
            Me.SuspendLayout()
            '
            'progressBar1
            '
            Me.progressBar1.BarColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(221, Byte), Integer))
            Me.progressBar1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(221, Byte), Integer), CType(CType(0, Byte), Integer))
            Me.progressBar1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Dashed
            Me.progressBar1.ClassName = ""
            Me.progressBar1.CustomFontFamilies = ""
            Me.progressBar1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.progressBar1.ForeColor = System.Drawing.Color.Black
            Me.progressBar1.Location = New System.Drawing.Point(12, 12)
            Me.progressBar1.Name = "progressBar1"
            Me.progressBar1.Opacity = 100
            Me.progressBar1.Size = New System.Drawing.Size(496, 43)
            Me.progressBar1.TabIndex = 0
            Me.progressBar1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.progressBar1.TooltipText = ""
            Me.progressBar1.ZOrder = 0
            '
            'jButton1
            '
            Me.jButton1.ApplicationWideResource = True
            Me.jButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton1.BackgroundImagePosition = ""
            Me.jButton1.BackgroundImageQuality = CType(80, Short)
            Me.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton1.ClassName = ""
            Me.jButton1.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton1.CustomFontFamilies = ""
            Me.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton1.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton1.Icon = Nothing
            Me.jButton1.IconURL = ""
            Me.jButton1.Image = Nothing
            Me.jButton1.ImageLocation = ""
            Me.jButton1.Location = New System.Drawing.Point(383, 85)
            Me.jButton1.Name = "jButton1"
            Me.jButton1.Opacity = 100
            Me.jButton1.PreventMultipleClicks = True
            Me.jButton1.Size = New System.Drawing.Size(125, 23)
            Me.jButton1.TabIndex = 7
            Me.jButton1.Text = "Start Process"
            Me.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton1.TooltipText = ""
            Me.jButton1.UseVisualStyleBackColor = False
            Me.jButton1.ValidationFailedMessage = "Validation failed!"
            Me.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton1.VerticalGradient = True
            Me.jButton1.ZOrder = 0
            '
            'borderStyle
            '
            Me.borderStyle.ClassName = ""
            Me.borderStyle.CustomFontFamilies = ""
            Me.borderStyle.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.borderStyle.Items.AddRange(New Object() {"Solid", "Dotted", "Dashed", "Double"})
            Me.borderStyle.Location = New System.Drawing.Point(14, 87)
            Me.borderStyle.MinSelectedIndex = -1
            Me.borderStyle.Name = "borderStyle"
            Me.borderStyle.Opacity = 100
            Me.borderStyle.Size = New System.Drawing.Size(121, 23)
            Me.borderStyle.TabIndex = 1
            Me.borderStyle.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.borderStyle.TooltipText = ""
            Me.borderStyle.UpdateTextBySelection = Nothing
            Me.borderStyle.ValidationMessage = "An action is required"
            Me.borderStyle.ZOrder = 0
            '
            'borderColor
            '
            Me.borderColor.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.borderColor.CheckForEmail = False
            Me.borderColor.ClassName = ""
            Me.borderColor.Color = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(221, Byte), Integer), CType(CType(0, Byte), Integer))
            Me.borderColor.ColorInputValidation = True
            Me.borderColor.CustomFontFamilies = ""
            Me.borderColor.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.borderColor.Location = New System.Drawing.Point(150, 87)
            Me.borderColor.Mask = "#??????"
            Me.borderColor.MinLength = -1
            Me.borderColor.Name = "borderColor"
            Me.borderColor.Opacity = 100
            Me.borderColor.PreventSQLInjection = False
            Me.borderColor.RegexCheck = "^#?([a-f]|[A-F]|[0-9]){3}(([a-f]|[A-F]|[0-9]){3})?$"
            Me.borderColor.Size = New System.Drawing.Size(100, 21)
            Me.borderColor.TabIndex = 2
            Me.borderColor.Text = "00DD00"
            Me.borderColor.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.borderColor.TooltipText = ""
            Me.borderColor.ValidationMessage = "An action is required"
            Me.borderColor.ZOrder = 0
            '
            'cbackColor
            '
            Me.cbackColor.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.cbackColor.CheckForEmail = False
            Me.cbackColor.ClassName = ""
            Me.cbackColor.Color = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(153, Byte), Integer))
            Me.cbackColor.ColorInputValidation = True
            Me.cbackColor.CustomFontFamilies = ""
            Me.cbackColor.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.cbackColor.Location = New System.Drawing.Point(256, 87)
            Me.cbackColor.Mask = "#??????"
            Me.cbackColor.MinLength = -1
            Me.cbackColor.Name = "cbackColor"
            Me.cbackColor.Opacity = 100
            Me.cbackColor.PreventSQLInjection = False
            Me.cbackColor.RegexCheck = "^#?([a-f]|[A-F]|[0-9]){3}(([a-f]|[A-F]|[0-9]){3})?$"
            Me.cbackColor.Size = New System.Drawing.Size(100, 21)
            Me.cbackColor.TabIndex = 3
            Me.cbackColor.Text = "006699"
            Me.cbackColor.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.cbackColor.TooltipText = ""
            Me.cbackColor.ValidationMessage = "An action is required"
            Me.cbackColor.ZOrder = 0
            '
            'label1
            '
            Me.label1.AutoSize = True
            Me.label1.BackColor = System.Drawing.Color.Transparent
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(12, 69)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 100
            Me.label1.Size = New System.Drawing.Size(73, 15)
            Me.label1.TabIndex = 4
            Me.label1.Text = "Border Style"
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.ZOrder = 0
            '
            'label2
            '
            Me.label2.AutoSize = True
            Me.label2.BackColor = System.Drawing.Color.Transparent
            Me.label2.ClassName = ""
            Me.label2.CustomFontFamilies = ""
            Me.label2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label2.Image = Nothing
            Me.label2.Location = New System.Drawing.Point(147, 69)
            Me.label2.Name = "label2"
            Me.label2.Opacity = 100
            Me.label2.Size = New System.Drawing.Size(77, 15)
            Me.label2.TabIndex = 5
            Me.label2.Text = "Border Color"
            Me.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label2.TooltipText = ""
            Me.label2.UseMnemonic = False
            Me.label2.ZOrder = 0
            '
            'label3
            '
            Me.label3.AutoSize = True
            Me.label3.BackColor = System.Drawing.Color.Transparent
            Me.label3.ClassName = ""
            Me.label3.CustomFontFamilies = ""
            Me.label3.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label3.Image = Nothing
            Me.label3.Location = New System.Drawing.Point(253, 69)
            Me.label3.Name = "label3"
            Me.label3.Opacity = 100
            Me.label3.Size = New System.Drawing.Size(37, 15)
            Me.label3.TabIndex = 6
            Me.label3.Text = "Color"
            Me.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label3.TooltipText = ""
            Me.label3.UseMnemonic = False
            Me.label3.ZOrder = 0
            '
            'ColorPicker1
            '
            Me.ColorPicker1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.ColorPicker1.CheckForEmail = False
            Me.ColorPicker1.ClassName = ""
            Me.ColorPicker1.Color = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(221, Byte), Integer))
            Me.ColorPicker1.ColorInputValidation = True
            Me.ColorPicker1.CustomFontFamilies = ""
            Me.ColorPicker1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.ColorPicker1.Location = New System.Drawing.Point(256, 87)
            Me.ColorPicker1.Mask = "#??????"
            Me.ColorPicker1.MinLength = -1
            Me.ColorPicker1.Name = "ColorPicker1"
            Me.ColorPicker1.Opacity = 100
            Me.ColorPicker1.PreventSQLInjection = False
            Me.ColorPicker1.RegexCheck = "^#?([a-f]|[A-F]|[0-9]){3}(([a-f]|[A-F]|[0-9]){3})?$"
            Me.ColorPicker1.Size = New System.Drawing.Size(100, 21)
            Me.ColorPicker1.TabIndex = 8
            Me.ColorPicker1.Text = "0000DD"
            Me.ColorPicker1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.ColorPicker1.TooltipText = ""
            Me.ColorPicker1.ValidationMessage = "An action is required"
            Me.ColorPicker1.ZOrder = 0
            '
            'ProgressTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(527, 118)
            Me.Controls.Add(Me.ColorPicker1)
            Me.Controls.Add(Me.label3)
            Me.Controls.Add(Me.label2)
            Me.Controls.Add(Me.label1)
            Me.Controls.Add(Me.borderColor)
            Me.Controls.Add(Me.borderStyle)
            Me.Controls.Add(Me.jButton1)
            Me.Controls.Add(Me.progressBar1)
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "ProgressTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "ProgressBar Demo"
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

		#End Region

		Private progressBar1 As VisualJS.Web.Forms.ProgressBar
        Friend WithEvents jButton1 As VisualJS.Web.Forms.JButton
        Friend WithEvents borderStyle As VisualJS.Web.Forms.ComboBox
        Friend WithEvents borderColor As VisualJS.Web.Forms.ColorPicker
        Friend WithEvents cbackColor As VisualJS.Web.Forms.ColorPicker
		Private label1 As VisualJS.Web.Forms.Label
		Private label2 As VisualJS.Web.Forms.Label
        Private label3 As VisualJS.Web.Forms.Label
        Friend WithEvents ColorPicker1 As VisualJS.Web.Forms.ColorPicker
	End Class
End Namespace 
