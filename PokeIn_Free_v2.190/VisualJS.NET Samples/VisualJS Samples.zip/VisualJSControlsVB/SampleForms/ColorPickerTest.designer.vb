
Namespace SampleForms
	Partial Class ColorPickerTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ColorPickerTest))
            Me.colorPicker1 = New VisualJS.Web.Forms.ColorPicker()
            Me.label1 = New VisualJS.Web.Forms.Label()
            Me.label2 = New VisualJS.Web.Forms.Label()
            Me.colorPicker2 = New VisualJS.Web.Forms.ColorPicker()
            Me.panel1 = New VisualJS.Web.Forms.Panel()
            Me.checkBox1 = New VisualJS.Web.Forms.CheckBox()
            Me.SuspendLayout()
            '
            'colorPicker1
            '
            Me.colorPicker1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.colorPicker1.CheckForEmail = False
            Me.colorPicker1.ClassName = ""
            Me.colorPicker1.Color = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
            Me.colorPicker1.ColorInputValidation = True
            Me.colorPicker1.CustomFontFamilies = ""
            Me.colorPicker1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.colorPicker1.Location = New System.Drawing.Point(91, 12)
            Me.colorPicker1.Mask = "#??????"
            Me.colorPicker1.MinLength = -1
            Me.colorPicker1.Name = "colorPicker1"
            Me.colorPicker1.Opacity = 100
            Me.colorPicker1.PreventSQLInjection = False
            Me.colorPicker1.RegexCheck = "^#?([a-f]|[A-F]|[0-9]){3}(([a-f]|[A-F]|[0-9]){3})?$"
            Me.colorPicker1.Size = New System.Drawing.Size(93, 21)
            Me.colorPicker1.TabIndex = 7
            Me.colorPicker1.Text = "000000"
            Me.colorPicker1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.colorPicker1.TooltipText = ""
            Me.colorPicker1.ValidationMessage = "An action is required"
            Me.colorPicker1.ZOrder = 0
            '
            'label1
            '
            Me.label1.AutoSize = True
            Me.label1.BackColor = System.Drawing.Color.Transparent
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(11, 15)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 100
            Me.label1.Size = New System.Drawing.Size(65, 15)
            Me.label1.TabIndex = 1
            Me.label1.Text = "Start Color"
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.ZOrder = 0
            '
            'label2
            '
            Me.label2.AutoSize = True
            Me.label2.BackColor = System.Drawing.Color.Transparent
            Me.label2.ClassName = ""
            Me.label2.CustomFontFamilies = ""
            Me.label2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label2.Image = Nothing
            Me.label2.Location = New System.Drawing.Point(11, 42)
            Me.label2.Name = "label2"
            Me.label2.Opacity = 100
            Me.label2.Size = New System.Drawing.Size(62, 15)
            Me.label2.TabIndex = 3
            Me.label2.Text = "End Color"
            Me.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label2.TooltipText = ""
            Me.label2.UseMnemonic = False
            Me.label2.ZOrder = 0
            '
            'colorPicker2
            '
            Me.colorPicker2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.colorPicker2.CheckForEmail = False
            Me.colorPicker2.ClassName = ""
            Me.colorPicker2.Color = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
            Me.colorPicker2.ColorInputValidation = True
            Me.colorPicker2.CustomFontFamilies = ""
            Me.colorPicker2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.colorPicker2.Location = New System.Drawing.Point(91, 39)
            Me.colorPicker2.Mask = "#??????"
            Me.colorPicker2.MinLength = -1
            Me.colorPicker2.Name = "colorPicker2"
            Me.colorPicker2.Opacity = 100
            Me.colorPicker2.PreventSQLInjection = False
            Me.colorPicker2.RegexCheck = "^#?([a-f]|[A-F]|[0-9]){3}(([a-f]|[A-F]|[0-9]){3})?$"
            Me.colorPicker2.Size = New System.Drawing.Size(93, 21)
            Me.colorPicker2.TabIndex = 4
            Me.colorPicker2.Text = "FF0000"
            Me.colorPicker2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.colorPicker2.TooltipText = ""
            Me.colorPicker2.ValidationMessage = "An action is required"
            Me.colorPicker2.ZOrder = 0
            '
            'panel1
            '
            Me.panel1.ApplicationWideResource = True
            Me.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.panel1.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.panel1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.panel1.BackColor = System.Drawing.Color.Black
            Me.panel1.BackColorEnd = System.Drawing.Color.Red
            Me.panel1.BackgroundImagePosition = ""
            Me.panel1.BackgroundImageQuality = CType(80, Short)
            Me.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.panel1.BorderColor = System.Drawing.Color.Black
            Me.panel1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid
            Me.panel1.ClassName = ""
            Me.panel1.ClientID = Nothing
            Me.panel1.CustomFontFamilies = ""
            Me.panel1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.panel1.HTML = ""
            Me.panel1.ImageLocation = ""
            Me.panel1.Location = New System.Drawing.Point(14, 91)
            Me.panel1.Name = "panel1"
            Me.panel1.Opacity = 100
            Me.panel1.Size = New System.Drawing.Size(170, 101)
            Me.panel1.TabIndex = 5
            Me.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.panel1.TooltipText = ""
            Me.panel1.VerticalGradient = True
            Me.panel1.ZOrder = 0
            '
            'checkBox1
            '
            Me.checkBox1.AutoSize = True
            Me.checkBox1.BackColor = System.Drawing.Color.Transparent
            Me.checkBox1.Checked = True
            Me.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked
            Me.checkBox1.ClassName = ""
            Me.checkBox1.CustomFontFamilies = ""
            Me.checkBox1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.checkBox1.Image = Nothing
            Me.checkBox1.Location = New System.Drawing.Point(14, 66)
            Me.checkBox1.MustBeCheckedBeforeSubmit = False
            Me.checkBox1.Name = "checkBox1"
            Me.checkBox1.Opacity = 100
            Me.checkBox1.Size = New System.Drawing.Size(115, 19)
            Me.checkBox1.TabIndex = 6
            Me.checkBox1.Text = "Vertical Gradient"
            Me.checkBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.checkBox1.TooltipText = ""
            Me.checkBox1.UseMnemonic = False
            Me.checkBox1.UseVisualStyleBackColor = False
            Me.checkBox1.ValidationMessage = "An action is required"
            Me.checkBox1.ZOrder = 0
            '
            'ColorPickerTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(200, 210)
            Me.Controls.Add(Me.checkBox1)
            Me.Controls.Add(Me.panel1)
            Me.Controls.Add(Me.label2)
            Me.Controls.Add(Me.colorPicker2)
            Me.Controls.Add(Me.label1)
            Me.Controls.Add(Me.colorPicker1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "ColorPickerTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "ColorPicker Demo"
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

		#End Region

        Friend WithEvents colorPicker1 As VisualJS.Web.Forms.ColorPicker
		Private label1 As VisualJS.Web.Forms.Label
		Private label2 As VisualJS.Web.Forms.Label
        Friend WithEvents colorPicker2 As VisualJS.Web.Forms.ColorPicker
		Private panel1 As VisualJS.Web.Forms.Panel
        Friend WithEvents checkBox1 As VisualJS.Web.Forms.CheckBox
	End Class
End Namespace
