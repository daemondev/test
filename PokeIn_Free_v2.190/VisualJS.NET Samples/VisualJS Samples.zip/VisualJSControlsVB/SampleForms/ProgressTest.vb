

Imports System.Threading
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports VisualJS
Imports VisualJS.Web.Forms
Imports System.Linq
Imports System.Text
Namespace SampleForms

	Public Partial Class ProgressTest
		Inherits VisualJS.Web.Forms.Form

		#Region "Constructors"
		Public Sub New()
			InitializeComponent()
			AfterInitialization()
		End Sub

		'Use the below constructor if you create the instance of this Form object other than the active Thread
		'otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
		Public Sub New(clientId As String)
			MyBase.New(clientId)
			InitializeComponent()
			AfterInitialization()
		End Sub
		#End Region

		'Use below method for the tasks after the initialization of the Form
		Private Sub AfterInitialization()

		End Sub

        Private Sub jButton1_Click(sender As Object, e As EventArgs) Handles jButton1.Click
            jButton1.Enabled = False
            jButton1.Text = "Processing.."
            Me.FormClosableByUser = False
            borderColor.Enabled = False
            borderStyle.Enabled = False
            ColorPicker1.Enabled = False
            progressBar1.Value = 0
            Thread.Sleep(1000)
            'Fake Wait
            For i As Integer = 1 To 99 Step 4
                progressBar1.Value = i
                'Fake Wait
                Thread.Sleep(500)
            Next
            progressBar1.Value = 100
            MessageBox.Show("Done!", Me)
            jButton1.Enabled = True
            jButton1.Text = "Start Process"
            Me.FormClosableByUser = True
            borderColor.Enabled = True
            borderStyle.Enabled = True
            ColorPicker1.Enabled = True
        End Sub

        Private Sub borderStyle_SelectedIndexChanged(sender As Object, e As EventArgs) Handles borderStyle.SelectedIndexChanged
            progressBar1.BorderLineStyle = DirectCast(borderStyle.SelectedIndex, Panel.ClientBorderStyle)
        End Sub

        Private Sub borderColor_TextChanged(sender As Object, e As EventArgs) Handles borderColor.TextChanged
            progressBar1.BorderColor = borderColor.Color
        End Sub 

        Private Sub ColorPicker1_TextChanged(sender As System.Object, e As System.EventArgs) Handles ColorPicker1.TextChanged
            progressBar1.BarColor = ColorPicker1.Color
        End Sub
    End Class
End Namespace 