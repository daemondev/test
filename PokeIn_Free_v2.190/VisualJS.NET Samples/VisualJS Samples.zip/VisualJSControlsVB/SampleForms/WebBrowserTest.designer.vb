
Namespace SampleForms
	Partial Class WebBrowserTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(WebBrowserTest))
            Me.webBrowser1 = New VisualJS.Web.Forms.WebBrowser()
            Me.panel1 = New VisualJS.Web.Forms.Panel()
            Me.label1 = New VisualJS.Web.Forms.Label()
            Me.panel1.SuspendLayout()
            Me.SuspendLayout()
            '
            'webBrowser1
            '
            Me.webBrowser1.BackColor = System.Drawing.Color.White
            Me.webBrowser1.ClassName = ""
            Me.webBrowser1.Dock = System.Windows.Forms.DockStyle.Fill
            Me.webBrowser1.Enabled = False
            Me.webBrowser1.Location = New System.Drawing.Point(0, 0)
            Me.webBrowser1.Name = "webBrowser1"
            Me.webBrowser1.Opacity = 100
            Me.webBrowser1.ScrollBarsEnabled = False
            Me.webBrowser1.Size = New System.Drawing.Size(815, 454)
            Me.webBrowser1.TabIndex = 0
            Me.webBrowser1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.webBrowser1.TooltipText = ""
            Me.webBrowser1.URL = "http://www.pokein.com"
            Me.webBrowser1.ZOrder = 0
            '
            'panel1
            '
            Me.panel1.ApplicationWideResource = True
            Me.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.panel1.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.panel1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(153, Byte), Integer))
            Me.panel1.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(238, Byte), Integer))
            Me.panel1.BackgroundImagePosition = ""
            Me.panel1.BackgroundImageQuality = CType(80, Short)
            Me.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.panel1.BorderColor = System.Drawing.Color.Black
            Me.panel1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid
            Me.panel1.ClassName = ""
            Me.panel1.ClientID = Nothing
            Me.panel1.Controls.Add(Me.label1)
            Me.panel1.CustomFontFamilies = ""
            Me.panel1.Dock = System.Windows.Forms.DockStyle.Bottom
            Me.panel1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.panel1.HTML = ""
            Me.panel1.ImageLocation = ""
            Me.panel1.Location = New System.Drawing.Point(0, 418)
            Me.panel1.Name = "panel1"
            Me.panel1.Opacity = 80
            Me.panel1.Size = New System.Drawing.Size(815, 36)
            Me.panel1.TabIndex = 1
            Me.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.panel1.TooltipText = ""
            Me.panel1.VerticalGradient = True
            Me.panel1.ZOrder = 0
            '
            'label1
            '
            Me.label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.label1.AutoSize = True
            Me.label1.BackColor = System.Drawing.Color.Transparent
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label1.ForeColor = System.Drawing.Color.Gold
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(589, 12)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 100
            Me.label1.Size = New System.Drawing.Size(214, 15)
            Me.label1.TabIndex = 0
            Me.label1.Text = "Docked Panel & Left Anchored Label"
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.ZOrder = 0
            '
            'WebBrowserTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(815, 454)
            Me.Controls.Add(Me.panel1)
            Me.Controls.Add(Me.webBrowser1)
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.Name = "WebBrowserTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "WebBrowser Demo"
            Me.panel1.ResumeLayout(False)
            Me.panel1.PerformLayout()
            Me.ResumeLayout(False)

        End Sub

		#End Region

		Private webBrowser1 As VisualJS.Web.Forms.WebBrowser
		Private panel1 As VisualJS.Web.Forms.Panel
		Private label1 As VisualJS.Web.Forms.Label
	End Class
End Namespace 
