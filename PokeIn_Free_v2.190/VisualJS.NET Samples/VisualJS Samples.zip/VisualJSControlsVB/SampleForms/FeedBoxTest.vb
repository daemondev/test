
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports VisualJS
Imports VisualJS.Web.Forms
Imports System.Linq
Imports System.Text

Namespace SampleForms
	Public Partial Class FeedBoxTest
		Inherits VisualJS.Web.Forms.Form
		Public Sub New()
			InitializeComponent()
		End Sub

		'Use the below constructor if you create the instance of this Form object other than the active Thread
		'otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
		Public Sub New(clientId As String)
			MyBase.New(clientId)
			InitializeComponent()
		End Sub

        Private Sub feedBox2_MouseDown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles feedBox2.MouseDown
            MessageBox.Show("Server side received your click", Me)
        End Sub
	End Class
End Namespace 
