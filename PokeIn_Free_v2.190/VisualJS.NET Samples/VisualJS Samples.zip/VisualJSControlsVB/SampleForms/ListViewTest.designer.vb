
Namespace SampleForms
	Partial Class ListViewTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Me.components = New System.ComponentModel.Container()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ListViewTest))
            Me.listView1 = New VisualJS.Web.Forms.ListView()
            Me.imageList1 = New System.Windows.Forms.ImageList(Me.components)
            Me.jButton1 = New VisualJS.Web.Forms.JButton()
            Me.jButton2 = New VisualJS.Web.Forms.JButton()
            Me.jButton3 = New VisualJS.Web.Forms.JButton()
            Me.jButton4 = New VisualJS.Web.Forms.JButton()
            Me.SuspendLayout()
            '
            'listView1
            '
            Me.listView1.CellsEditable = True
            Me.listView1.ClassName = ""
            Me.listView1.CustomFontFamilies = ""
            Me.listView1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.listView1.FullRowSelect = True
            Me.listView1.GridLines = True
            Me.listView1.Groups = False
            Me.listView1.HideSelection = False
            Me.listView1.LabelWrap = False
            Me.listView1.LineColor = System.Drawing.Color.White
            Me.listView1.Location = New System.Drawing.Point(12, 12)
            Me.listView1.Name = "listView1"
            Me.listView1.SelectedFontColor = System.Drawing.Color.White
            Me.listView1.SelectedLineColor = System.Drawing.Color.Silver
            Me.listView1.ShowGroups = False
            Me.listView1.Size = New System.Drawing.Size(518, 270)
            Me.listView1.SmallImageList = Me.imageList1
            Me.listView1.Sorting = System.Windows.Forms.SortOrder.Ascending
            Me.listView1.TabIndex = 0
            Me.listView1.TileSize = New System.Drawing.Size(0, 0)
            Me.listView1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.listView1.TooltipText = ""
            Me.listView1.UseCompatibleStateImageBehavior = False
            Me.listView1.View = System.Windows.Forms.View.Details
            Me.listView1.ZOrder = 0
            '
            'imageList1
            '
            Me.imageList1.ImageStream = CType(resources.GetObject("imageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
            Me.imageList1.Tag = "ListViewIcons"
            Me.imageList1.TransparentColor = System.Drawing.Color.Transparent
            Me.imageList1.Images.SetKeyName(0, "android.png")
            Me.imageList1.Images.SetKeyName(1, "apple.png")
            Me.imageList1.Images.SetKeyName(2, "Chrome.png")
            Me.imageList1.Images.SetKeyName(3, "Firefox.png")
            Me.imageList1.Images.SetKeyName(4, "IE.png")
            Me.imageList1.Images.SetKeyName(5, "Opera.png")
            Me.imageList1.Images.SetKeyName(6, "Safari.png")
            '
            'jButton1
            '
            Me.jButton1.ApplicationWideResource = True
            Me.jButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton1.BackgroundImagePosition = ""
            Me.jButton1.BackgroundImageQuality = CType(80, Short)
            Me.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton1.ClassName = ""
            Me.jButton1.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton1.CustomFontFamilies = ""
            Me.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton1.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton1.Icon = Nothing
            Me.jButton1.IconURL = ""
            Me.jButton1.Image = Nothing
            Me.jButton1.ImageLocation = ""
            Me.jButton1.Location = New System.Drawing.Point(536, 12)
            Me.jButton1.Name = "jButton1"
            Me.jButton1.Opacity = 100
            Me.jButton1.PreventMultipleClicks = True
            Me.jButton1.Size = New System.Drawing.Size(122, 23)
            Me.jButton1.TabIndex = 3
            Me.jButton1.Text = "Hide Headers"
            Me.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton1.TooltipText = ""
            Me.jButton1.UseVisualStyleBackColor = False
            Me.jButton1.ValidationFailedMessage = "Validation failed!"
            Me.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton1.VerticalGradient = True
            Me.jButton1.ZOrder = 0
            '
            'jButton2
            '
            Me.jButton2.ApplicationWideResource = True
            Me.jButton2.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton2.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton2.BackgroundImagePosition = ""
            Me.jButton2.BackgroundImageQuality = CType(80, Short)
            Me.jButton2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton2.ClassName = ""
            Me.jButton2.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton2.CustomFontFamilies = ""
            Me.jButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton2.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton2.Icon = Nothing
            Me.jButton2.IconURL = ""
            Me.jButton2.Image = Nothing
            Me.jButton2.ImageLocation = ""
            Me.jButton2.Location = New System.Drawing.Point(536, 41)
            Me.jButton2.Name = "jButton2"
            Me.jButton2.Opacity = 100
            Me.jButton2.PreventMultipleClicks = True
            Me.jButton2.Size = New System.Drawing.Size(122, 23)
            Me.jButton2.TabIndex = 2
            Me.jButton2.Text = "Add 100 Rows"
            Me.jButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton2.TooltipText = ""
            Me.jButton2.UseVisualStyleBackColor = False
            Me.jButton2.ValidationFailedMessage = "Validation failed!"
            Me.jButton2.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton2.VerticalGradient = True
            Me.jButton2.ZOrder = 0
            '
            'jButton3
            '
            Me.jButton3.ApplicationWideResource = True
            Me.jButton3.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton3.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton3.BackgroundImagePosition = ""
            Me.jButton3.BackgroundImageQuality = CType(80, Short)
            Me.jButton3.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton3.ClassName = ""
            Me.jButton3.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton3.CustomFontFamilies = ""
            Me.jButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton3.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton3.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton3.Icon = Nothing
            Me.jButton3.IconURL = ""
            Me.jButton3.Image = Nothing
            Me.jButton3.ImageLocation = ""
            Me.jButton3.Location = New System.Drawing.Point(536, 70)
            Me.jButton3.Name = "jButton3"
            Me.jButton3.Opacity = 100
            Me.jButton3.PreventMultipleClicks = True
            Me.jButton3.Size = New System.Drawing.Size(122, 23)
            Me.jButton3.TabIndex = 1
            Me.jButton3.Text = "Clear Rows"
            Me.jButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton3.TooltipText = ""
            Me.jButton3.UseVisualStyleBackColor = False
            Me.jButton3.ValidationFailedMessage = "Validation failed!"
            Me.jButton3.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton3.VerticalGradient = True
            Me.jButton3.ZOrder = 0
            '
            'jButton4
            '
            Me.jButton4.ApplicationWideResource = True
            Me.jButton4.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton4.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton4.BackgroundImagePosition = ""
            Me.jButton4.BackgroundImageQuality = CType(80, Short)
            Me.jButton4.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton4.ClassName = ""
            Me.jButton4.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton4.CustomFontFamilies = ""
            Me.jButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton4.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton4.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton4.Icon = Nothing
            Me.jButton4.IconURL = ""
            Me.jButton4.Image = Nothing
            Me.jButton4.ImageLocation = ""
            Me.jButton4.Location = New System.Drawing.Point(536, 99)
            Me.jButton4.Name = "jButton4"
            Me.jButton4.Opacity = 100
            Me.jButton4.PreventMultipleClicks = True
            Me.jButton4.Size = New System.Drawing.Size(122, 23)
            Me.jButton4.TabIndex = 0
            Me.jButton4.Text = "Show CheckBoxes"
            Me.jButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton4.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton4.TooltipText = ""
            Me.jButton4.UseVisualStyleBackColor = False
            Me.jButton4.ValidationFailedMessage = "Validation failed!"
            Me.jButton4.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton4.VerticalGradient = True
            Me.jButton4.ZOrder = 0
            '
            'ListViewTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(666, 295)
            Me.Controls.Add(Me.jButton4)
            Me.Controls.Add(Me.jButton3)
            Me.Controls.Add(Me.jButton2)
            Me.Controls.Add(Me.jButton1)
            Me.Controls.Add(Me.listView1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "ListViewTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "ListView Demo"
            Me.ResumeLayout(False)

        End Sub

		#End Region

        Friend WithEvents listView1 As VisualJS.Web.Forms.ListView
        Friend WithEvents jButton1 As VisualJS.Web.Forms.JButton
        Friend WithEvents jButton2 As VisualJS.Web.Forms.JButton
        Friend WithEvents jButton3 As VisualJS.Web.Forms.JButton
        Friend WithEvents jButton4 As VisualJS.Web.Forms.JButton
		Private imageList1 As System.Windows.Forms.ImageList
	End Class
End Namespace
