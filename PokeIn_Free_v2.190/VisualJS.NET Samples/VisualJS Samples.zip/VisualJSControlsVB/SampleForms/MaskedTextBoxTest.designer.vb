
Namespace SampleForms
	Partial Class MaskedTextBoxTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MaskedTextBoxTest))
            Me.maskedTextBox1 = New VisualJS.Web.Forms.MaskedTextBox()
            Me.label1 = New VisualJS.Web.Forms.Label()
            Me.label3 = New VisualJS.Web.Forms.Label()
            Me.maskedTextBox3 = New VisualJS.Web.Forms.MaskedTextBox()
            Me.label2 = New VisualJS.Web.Forms.Label()
            Me.maskedTextBox2 = New VisualJS.Web.Forms.MaskedTextBox()
            Me.jButton1 = New VisualJS.Web.Forms.JButton()
            Me.label4 = New VisualJS.Web.Forms.Label()
            Me.maskedTextBox4 = New VisualJS.Web.Forms.MaskedTextBox()
            Me.SuspendLayout()
            '
            'maskedTextBox1
            '
            Me.maskedTextBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.maskedTextBox1.CheckForEmail = False
            Me.maskedTextBox1.ClassName = ""
            Me.maskedTextBox1.CustomFontFamilies = ""
            Me.maskedTextBox1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.maskedTextBox1.Location = New System.Drawing.Point(12, 29)
            Me.maskedTextBox1.Mask = "0000-0000-0000-0000"
            Me.maskedTextBox1.MinLength = 16
            Me.maskedTextBox1.Name = "maskedTextBox1"
            Me.maskedTextBox1.Opacity = 100
            Me.maskedTextBox1.PreventSQLInjection = False
            Me.maskedTextBox1.RegexCheck = ""
            Me.maskedTextBox1.Size = New System.Drawing.Size(174, 21)
            Me.maskedTextBox1.TabIndex = 2
            Me.maskedTextBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.maskedTextBox1.TooltipText = ""
            Me.maskedTextBox1.ValidationMessage = "Enter Credit Card Number"
            Me.maskedTextBox1.ZOrder = 0
            '
            'label1
            '
            Me.label1.AutoSize = True
            Me.label1.BackColor = System.Drawing.Color.Transparent
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(12, 11)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 100
            Me.label1.Size = New System.Drawing.Size(118, 15)
            Me.label1.TabIndex = 1
            Me.label1.Text = "Credit Card Number"
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.ZOrder = 0
            '
            'label3
            '
            Me.label3.AutoSize = True
            Me.label3.BackColor = System.Drawing.Color.Transparent
            Me.label3.ClassName = ""
            Me.label3.CustomFontFamilies = ""
            Me.label3.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label3.Image = Nothing
            Me.label3.Location = New System.Drawing.Point(12, 57)
            Me.label3.Name = "label3"
            Me.label3.Opacity = 100
            Me.label3.Size = New System.Drawing.Size(43, 15)
            Me.label3.TabIndex = 5
            Me.label3.Text = "Phone"
            Me.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label3.TooltipText = ""
            Me.label3.UseMnemonic = False
            Me.label3.ZOrder = 0
            '
            'maskedTextBox3
            '
            Me.maskedTextBox3.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.maskedTextBox3.CheckForEmail = False
            Me.maskedTextBox3.ClassName = ""
            Me.maskedTextBox3.CustomFontFamilies = ""
            Me.maskedTextBox3.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.maskedTextBox3.Location = New System.Drawing.Point(12, 75)
            Me.maskedTextBox3.Mask = "+(00) 00000000000"
            Me.maskedTextBox3.MinLength = 12
            Me.maskedTextBox3.Name = "maskedTextBox3"
            Me.maskedTextBox3.Opacity = 100
            Me.maskedTextBox3.PreventSQLInjection = False
            Me.maskedTextBox3.RegexCheck = ""
            Me.maskedTextBox3.Size = New System.Drawing.Size(174, 21)
            Me.maskedTextBox3.TabIndex = 3
            Me.maskedTextBox3.Text = "00"
            Me.maskedTextBox3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.maskedTextBox3.TooltipText = ""
            Me.maskedTextBox3.ValidationMessage = "Enter Your Phone Number (12 Number)"
            Me.maskedTextBox3.ZOrder = 0
            '
            'label2
            '
            Me.label2.AutoSize = True
            Me.label2.BackColor = System.Drawing.Color.Transparent
            Me.label2.ClassName = ""
            Me.label2.CustomFontFamilies = ""
            Me.label2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label2.Image = Nothing
            Me.label2.Location = New System.Drawing.Point(9, 107)
            Me.label2.Name = "label2"
            Me.label2.Opacity = 100
            Me.label2.Size = New System.Drawing.Size(63, 15)
            Me.label2.TabIndex = 8
            Me.label2.Text = "Password"
            Me.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label2.TooltipText = ""
            Me.label2.UseMnemonic = False
            Me.label2.ZOrder = 0
            '
            'maskedTextBox2
            '
            Me.maskedTextBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.maskedTextBox2.CheckForEmail = False
            Me.maskedTextBox2.ClassName = ""
            Me.maskedTextBox2.CustomFontFamilies = ""
            Me.maskedTextBox2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.maskedTextBox2.Location = New System.Drawing.Point(12, 125)
            Me.maskedTextBox2.MinLength = 5
            Me.maskedTextBox2.Name = "maskedTextBox2"
            Me.maskedTextBox2.Opacity = 100
            Me.maskedTextBox2.PasswordMode = True
            Me.maskedTextBox2.PreventSQLInjection = False
            Me.maskedTextBox2.RegexCheck = ""
            Me.maskedTextBox2.Size = New System.Drawing.Size(174, 21)
            Me.maskedTextBox2.TabIndex = 4
            Me.maskedTextBox2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.maskedTextBox2.TooltipText = ""
            Me.maskedTextBox2.ValidationMessage = "Min 5 Chars"
            Me.maskedTextBox2.ZOrder = 0
            '
            'jButton1
            '
            Me.jButton1.ApplicationWideResource = True
            Me.jButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton1.BackgroundImagePosition = ""
            Me.jButton1.BackgroundImageQuality = CType(80, Short)
            Me.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton1.ClassName = ""
            Me.jButton1.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton1.CustomFontFamilies = ""
            Me.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton1.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton1.Icon = Nothing
            Me.jButton1.IconURL = ""
            Me.jButton1.Image = Nothing
            Me.jButton1.ImageLocation = ""
            Me.jButton1.Location = New System.Drawing.Point(96, 205)
            Me.jButton1.Name = "jButton1"
            Me.jButton1.Opacity = 100
            Me.jButton1.PreventMultipleClicks = True
            Me.jButton1.Size = New System.Drawing.Size(90, 23)
            Me.jButton1.TabIndex = 12
            Me.jButton1.Text = "Submit"
            Me.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton1.TooltipText = ""
            Me.jButton1.UseVisualStyleBackColor = False
            Me.jButton1.ValidationFailedMessage = "Validation failed!"
            Me.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnForm
            Me.jButton1.VerticalGradient = True
            Me.jButton1.ZOrder = 0
            '
            'label4
            '
            Me.label4.AutoSize = True
            Me.label4.BackColor = System.Drawing.Color.Transparent
            Me.label4.ClassName = ""
            Me.label4.CustomFontFamilies = ""
            Me.label4.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label4.Image = Nothing
            Me.label4.Location = New System.Drawing.Point(12, 152)
            Me.label4.Name = "label4"
            Me.label4.Opacity = 100
            Me.label4.Size = New System.Drawing.Size(66, 15)
            Me.label4.TabIndex = 11
            Me.label4.Text = "IP Address"
            Me.label4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label4.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label4.TooltipText = ""
            Me.label4.UseMnemonic = False
            Me.label4.ZOrder = 0
            '
            'maskedTextBox4
            '
            Me.maskedTextBox4.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.maskedTextBox4.CheckForEmail = False
            Me.maskedTextBox4.ClassName = ""
            Me.maskedTextBox4.CustomFontFamilies = ""
            Me.maskedTextBox4.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.maskedTextBox4.Location = New System.Drawing.Point(12, 170)
            Me.maskedTextBox4.MinLength = -1
            Me.maskedTextBox4.Name = "maskedTextBox4"
            Me.maskedTextBox4.Opacity = 100
            Me.maskedTextBox4.PreventSQLInjection = False
            Me.maskedTextBox4.RegexCheck = "^((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){3}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|" & _
        "[0-9]{1,2})$"
            Me.maskedTextBox4.Size = New System.Drawing.Size(174, 21)
            Me.maskedTextBox4.TabIndex = 5
            Me.maskedTextBox4.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.maskedTextBox4.TooltipText = "Checks the input using Regex Validation feature"
            Me.maskedTextBox4.ValidationMessage = "Enter an IP address"
            Me.maskedTextBox4.ZOrder = 0
            '
            'MaskedTextBoxTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(198, 240)
            Me.Controls.Add(Me.label4)
            Me.Controls.Add(Me.maskedTextBox4)
            Me.Controls.Add(Me.jButton1)
            Me.Controls.Add(Me.label2)
            Me.Controls.Add(Me.maskedTextBox2)
            Me.Controls.Add(Me.label3)
            Me.Controls.Add(Me.maskedTextBox3)
            Me.Controls.Add(Me.label1)
            Me.Controls.Add(Me.maskedTextBox1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "MaskedTextBoxTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "MaskedTextBox Demo"
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

		#End Region

		Private maskedTextBox1 As VisualJS.Web.Forms.MaskedTextBox
		Private label1 As VisualJS.Web.Forms.Label
		Private label3 As VisualJS.Web.Forms.Label
		Private maskedTextBox3 As VisualJS.Web.Forms.MaskedTextBox
		Private label2 As VisualJS.Web.Forms.Label
		Private maskedTextBox2 As VisualJS.Web.Forms.MaskedTextBox
        Friend WithEvents jButton1 As VisualJS.Web.Forms.JButton
		Private label4 As VisualJS.Web.Forms.Label
		Private maskedTextBox4 As VisualJS.Web.Forms.MaskedTextBox
	End Class
End Namespace