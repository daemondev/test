
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports VisualJS
Imports VisualJS.Web.Forms
Imports System.Linq
Imports System.Text

Namespace SampleForms
	Public Partial Class TextboxTest
		Inherits VisualJS.Web.Forms.Form

		#Region "Constructors"
		Public Sub New()
			InitializeComponent()
			AfterInitialization()
		End Sub

		'Use the below constructor if you create the instance of this Form object other than the active Thread
		'otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
		Public Sub New(clientId As String)
			MyBase.New(clientId)
			InitializeComponent()
			AfterInitialization()
		End Sub
		#End Region

		'Use below method for the tasks after the initialization of the Form
		Private Sub AfterInitialization()

		End Sub

		Friend Shared colors As String() = {"red", "orange", "black", "white", "green", "blue", _
			"yellow", "maroon", "whitesmoke", "gray", "dimgray", "silvergray", _
			"lightblue", "skyblue", "forestgreen", "gold"}

		Friend prevValue As String = ""
        Private Sub textBox2_OnSuggestion(value As String) Handles textBox2.OnSuggestion
            If value = prevValue Then
                Return
            End If

            prevValue = value

            Dim vals As String() = value.ToLower().Replace(","c, " "c).Split(" "c)
            Dim suggestions As New Dictionary(Of String, String)()
            'value, color
            For Each val As String In vals
                If val = "" Then
                    Continue For
                End If
                For Each s As String In colors
                    If s.Contains(val) Then
                        If suggestions.ContainsKey(s) Then
                        Else
                            suggestions.Add(s, "black")
                        End If
                    End If
                Next
            Next

            textBox2.UpdateSuggestion(suggestions)
        End Sub

        Private Sub jButton1_Click(sender As Object, e As EventArgs) Handles jButton1.Click
            MessageBox.Show("You entered : " + textBox1.Text, Me)
        End Sub

        Private Sub jButton2_Click(sender As Object, e As EventArgs) Handles jButton2.Click
            MessageBox.Show("Input passed the SQLInjection Validation test", Me)
        End Sub
	End Class
End Namespace