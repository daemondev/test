
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports VisualJS
Imports VisualJS.Web.Forms
Imports System.Linq
Imports System.Text

Namespace SampleForms
	Public Partial Class RadioButtonTest
		Inherits VisualJS.Web.Forms.Form

		#Region "Constructors"
		Public Sub New()
			InitializeComponent()
			AfterInitialization()
		End Sub

		'Use the below constructor if you create the instance of this Form object other than the active Thread
		'otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
		Public Sub New(clientId As String)
			MyBase.New(clientId)
			InitializeComponent()
			AfterInitialization()
		End Sub
		#End Region

		'Use below method for the tasks after the initialization of the Form
		Private Sub AfterInitialization()

		End Sub  

        Private Sub rdRed_CheckedChanged_1(sender As System.Object, e As System.EventArgs) Handles rdRed.CheckedChanged, rdGreen.CheckedChanged, rdBlue.CheckedChanged
            Dim s As RadioButton = DirectCast(sender, RadioButton)
            Select Case s.Text
                Case "Red"
                    Me.pnlColor.BackColor = Color.Red
                    Exit Select
                Case "Green"
                    Me.pnlColor.BackColor = Color.Green
                    Exit Select
                Case "Blue"
                    Me.pnlColor.BackColor = Color.Blue
                    Exit Select
            End Select
        End Sub

        Private Sub radioButton3_CheckedChanged_1(sender As System.Object, e As System.EventArgs) Handles radioButton3.CheckedChanged, radioButton2.CheckedChanged, radioButton1.CheckedChanged
            Dim s As RadioButton = DirectCast(sender, RadioButton)
            Select Case s.Text
                Case "Orange"
                    Me.pnlColor2.BackColor = Color.Orange
                    Exit Select
                Case "Brown"
                    Me.pnlColor2.BackColor = Color.Brown
                    Exit Select
                Case "Olive"
                    Me.pnlColor2.BackColor = Color.Olive
                    Exit Select
            End Select
        End Sub
    End Class
End Namespace 