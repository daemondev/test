
Namespace SampleForms
	Partial Class DateTimePickerTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(DateTimePickerTest))
            Me.dateTimePicker1 = New VisualJS.Web.Forms.DateTimePicker()
            Me.dtChinese = New VisualJS.Web.Forms.DateTimePicker()
            Me.label1 = New VisualJS.Web.Forms.Label()
            Me.label2 = New VisualJS.Web.Forms.Label()
            Me.dtTurkish = New VisualJS.Web.Forms.DateTimePicker()
            Me.label3 = New VisualJS.Web.Forms.Label()
            Me.dtGerman = New VisualJS.Web.Forms.DateTimePicker()
            Me.lblArabic = New VisualJS.Web.Forms.Label()
            Me.dtArabic = New VisualJS.Web.Forms.DateTimePicker()
            Me.label4 = New VisualJS.Web.Forms.Label()
            Me.label5 = New VisualJS.Web.Forms.Label()
            Me.label6 = New VisualJS.Web.Forms.Label()
            Me.panel1 = New VisualJS.Web.Forms.Panel()
            Me.jButton1 = New VisualJS.Web.Forms.JButton()
            Me.lblLongDate = New VisualJS.Web.Forms.Label()
            Me.panel1.SuspendLayout()
            Me.SuspendLayout()
            '
            'dateTimePicker1
            '
            Me.dateTimePicker1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.dateTimePicker1.CheckForEmail = False
            Me.dateTimePicker1.ClassName = ""
            Me.dateTimePicker1.CustomFontFamilies = ""
            Me.dateTimePicker1.CustomFormat = "MM/dd/yyyy"
            Me.dateTimePicker1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.dateTimePicker1.Localize = VisualJS.Kernel.Localization.EnglishUS
            Me.dateTimePicker1.Location = New System.Drawing.Point(12, 29)
            Me.dateTimePicker1.Mask = "99/99/9999"
            Me.dateTimePicker1.MaxDate = New Date(9999, 12, 31, 23, 59, 59, 999)
            Me.dateTimePicker1.MinDate = New Date(CType(0, Long))
            Me.dateTimePicker1.MinLength = -1
            Me.dateTimePicker1.Name = "dateTimePicker1"
            Me.dateTimePicker1.Opacity = 100
            Me.dateTimePicker1.PreventSQLInjection = False
            Me.dateTimePicker1.RegexCheck = ""
            Me.dateTimePicker1.Size = New System.Drawing.Size(150, 21)
            Me.dateTimePicker1.TabIndex = 14
            Me.dateTimePicker1.Text = "02/26/2012"
            Me.dateTimePicker1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.dateTimePicker1.TooltipText = ""
            Me.dateTimePicker1.ValidationMessage = "An action is required"
            Me.dateTimePicker1.Value = New Date(2012, 2, 26, 0, 0, 0, 0)
            Me.dateTimePicker1.ZOrder = 0
            '
            'dtChinese
            '
            Me.dtChinese.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.dtChinese.CheckForEmail = False
            Me.dtChinese.ClassName = ""
            Me.dtChinese.CustomFontFamilies = ""
            Me.dtChinese.CustomFormat = "MM/dd/yyyy"
            Me.dtChinese.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.dtChinese.Localize = VisualJS.Kernel.Localization.Chinese
            Me.dtChinese.Location = New System.Drawing.Point(12, 75)
            Me.dtChinese.Mask = "99/99/9999"
            Me.dtChinese.MaxDate = New Date(9999, 12, 31, 23, 59, 59, 999)
            Me.dtChinese.MinDate = New Date(CType(0, Long))
            Me.dtChinese.MinLength = -1
            Me.dtChinese.Name = "dtChinese"
            Me.dtChinese.Opacity = 100
            Me.dtChinese.PreventSQLInjection = False
            Me.dtChinese.RegexCheck = ""
            Me.dtChinese.Size = New System.Drawing.Size(150, 21)
            Me.dtChinese.TabIndex = 2
            Me.dtChinese.Text = "02/26/2012"
            Me.dtChinese.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.dtChinese.TooltipText = ""
            Me.dtChinese.ValidationMessage = "An action is required"
            Me.dtChinese.Value = New Date(2012, 2, 26, 0, 0, 0, 0)
            Me.dtChinese.ZOrder = 0
            '
            'label1
            '
            Me.label1.AutoSize = True
            Me.label1.BackColor = System.Drawing.Color.Transparent
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(9, 57)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 100
            Me.label1.Size = New System.Drawing.Size(54, 15)
            Me.label1.TabIndex = 3
            Me.label1.Text = "Chinese"
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.ZOrder = 0
            '
            'label2
            '
            Me.label2.AutoSize = True
            Me.label2.BackColor = System.Drawing.Color.Transparent
            Me.label2.ClassName = ""
            Me.label2.CustomFontFamilies = ""
            Me.label2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label2.Image = Nothing
            Me.label2.Location = New System.Drawing.Point(9, 108)
            Me.label2.Name = "label2"
            Me.label2.Opacity = 100
            Me.label2.Size = New System.Drawing.Size(48, 15)
            Me.label2.TabIndex = 5
            Me.label2.Text = "Turkish"
            Me.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label2.TooltipText = ""
            Me.label2.UseMnemonic = False
            Me.label2.ZOrder = 0
            '
            'dtTurkish
            '
            Me.dtTurkish.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.dtTurkish.CheckForEmail = False
            Me.dtTurkish.ClassName = ""
            Me.dtTurkish.CustomFontFamilies = ""
            Me.dtTurkish.CustomFormat = "MM/dd/yyyy"
            Me.dtTurkish.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.dtTurkish.Localize = VisualJS.Kernel.Localization.Turkish
            Me.dtTurkish.Location = New System.Drawing.Point(12, 126)
            Me.dtTurkish.Mask = "99/99/9999"
            Me.dtTurkish.MaxDate = New Date(9999, 12, 31, 23, 59, 59, 999)
            Me.dtTurkish.MinDate = New Date(CType(0, Long))
            Me.dtTurkish.MinLength = -1
            Me.dtTurkish.Name = "dtTurkish"
            Me.dtTurkish.Opacity = 100
            Me.dtTurkish.PreventSQLInjection = False
            Me.dtTurkish.RegexCheck = ""
            Me.dtTurkish.Size = New System.Drawing.Size(150, 21)
            Me.dtTurkish.TabIndex = 4
            Me.dtTurkish.Text = "02/26/2012"
            Me.dtTurkish.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.dtTurkish.TooltipText = ""
            Me.dtTurkish.ValidationMessage = "An action is required"
            Me.dtTurkish.Value = New Date(2012, 2, 26, 20, 11, 3, 800)
            Me.dtTurkish.ZOrder = 0
            '
            'label3
            '
            Me.label3.AutoSize = True
            Me.label3.BackColor = System.Drawing.Color.Transparent
            Me.label3.ClassName = ""
            Me.label3.CustomFontFamilies = ""
            Me.label3.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label3.Image = Nothing
            Me.label3.Location = New System.Drawing.Point(9, 162)
            Me.label3.Name = "label3"
            Me.label3.Opacity = 100
            Me.label3.Size = New System.Drawing.Size(52, 15)
            Me.label3.TabIndex = 7
            Me.label3.Text = "German"
            Me.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label3.TooltipText = ""
            Me.label3.UseMnemonic = False
            Me.label3.ZOrder = 0
            '
            'dtGerman
            '
            Me.dtGerman.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.dtGerman.CheckForEmail = False
            Me.dtGerman.ClassName = ""
            Me.dtGerman.CustomFontFamilies = ""
            Me.dtGerman.CustomFormat = "MM/dd/yyyy"
            Me.dtGerman.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.dtGerman.Localize = VisualJS.Kernel.Localization.German
            Me.dtGerman.Location = New System.Drawing.Point(12, 180)
            Me.dtGerman.Mask = "99/99/9999"
            Me.dtGerman.MaxDate = New Date(9999, 12, 31, 23, 59, 59, 999)
            Me.dtGerman.MinDate = New Date(CType(0, Long))
            Me.dtGerman.MinLength = -1
            Me.dtGerman.Name = "dtGerman"
            Me.dtGerman.Opacity = 100
            Me.dtGerman.PreventSQLInjection = False
            Me.dtGerman.RegexCheck = ""
            Me.dtGerman.Size = New System.Drawing.Size(150, 21)
            Me.dtGerman.TabIndex = 6
            Me.dtGerman.Text = "02/26/2012"
            Me.dtGerman.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.dtGerman.TooltipText = ""
            Me.dtGerman.ValidationMessage = "An action is required"
            Me.dtGerman.Value = New Date(2012, 2, 26, 20, 11, 3, 800)
            Me.dtGerman.ZOrder = 0
            '
            'lblArabic
            '
            Me.lblArabic.AutoSize = True
            Me.lblArabic.BackColor = System.Drawing.Color.Transparent
            Me.lblArabic.ClassName = ""
            Me.lblArabic.CustomFontFamilies = ""
            Me.lblArabic.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.lblArabic.Image = Nothing
            Me.lblArabic.Location = New System.Drawing.Point(9, 210)
            Me.lblArabic.Name = "lblArabic"
            Me.lblArabic.Opacity = 100
            Me.lblArabic.Size = New System.Drawing.Size(41, 15)
            Me.lblArabic.TabIndex = 9
            Me.lblArabic.Text = "Arabic"
            Me.lblArabic.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.lblArabic.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.lblArabic.TooltipText = ""
            Me.lblArabic.UseMnemonic = False
            Me.lblArabic.ZOrder = 0
            '
            'dtArabic
            '
            Me.dtArabic.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.dtArabic.CheckForEmail = False
            Me.dtArabic.ClassName = ""
            Me.dtArabic.CustomFontFamilies = ""
            Me.dtArabic.CustomFormat = "MM/dd/yyyy"
            Me.dtArabic.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.dtArabic.Localize = VisualJS.Kernel.Localization.Arabic
            Me.dtArabic.Location = New System.Drawing.Point(12, 228)
            Me.dtArabic.Mask = "99/99/9999"
            Me.dtArabic.MaxDate = New Date(9999, 12, 31, 23, 59, 59, 999)
            Me.dtArabic.MinDate = New Date(CType(0, Long))
            Me.dtArabic.MinLength = -1
            Me.dtArabic.Name = "dtArabic"
            Me.dtArabic.Opacity = 100
            Me.dtArabic.PreventSQLInjection = False
            Me.dtArabic.RegexCheck = ""
            Me.dtArabic.Size = New System.Drawing.Size(150, 21)
            Me.dtArabic.TabIndex = 8
            Me.dtArabic.Text = "02/26/2012"
            Me.dtArabic.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.dtArabic.TooltipText = ""
            Me.dtArabic.ValidationMessage = "An action is required"
            Me.dtArabic.Value = New Date(2012, 2, 26, 20, 11, 3, 800)
            Me.dtArabic.ZOrder = 0
            '
            'label4
            '
            Me.label4.AutoSize = True
            Me.label4.BackColor = System.Drawing.Color.Transparent
            Me.label4.ClassName = ""
            Me.label4.CustomFontFamilies = ""
            Me.label4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label4.Image = Nothing
            Me.label4.Location = New System.Drawing.Point(70, 39)
            Me.label4.Name = "label4"
            Me.label4.Opacity = 100
            Me.label4.Size = New System.Drawing.Size(342, 15)
            Me.label4.TabIndex = 10
            Me.label4.Text = "This sample shows DateTimePicker from JQuery UI Library"
            Me.label4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label4.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label4.TooltipText = ""
            Me.label4.UseMnemonic = False
            Me.label4.ZOrder = 0
            '
            'label5
            '
            Me.label5.AutoSize = True
            Me.label5.BackColor = System.Drawing.Color.Transparent
            Me.label5.ClassName = ""
            Me.label5.CustomFontFamilies = ""
            Me.label5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label5.ForeColor = System.Drawing.Color.Yellow
            Me.label5.Image = Nothing
            Me.label5.Location = New System.Drawing.Point(17, 15)
            Me.label5.Name = "label5"
            Me.label5.Opacity = 100
            Me.label5.Size = New System.Drawing.Size(395, 15)
            Me.label5.TabIndex = 11
            Me.label5.Text = "VisualJS.NET's extensibility allows 3rd party custom JS components"
            Me.label5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label5.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label5.TooltipText = ""
            Me.label5.UseMnemonic = False
            Me.label5.ZOrder = 0
            '
            'label6
            '
            Me.label6.AutoSize = True
            Me.label6.BackColor = System.Drawing.Color.Transparent
            Me.label6.ClassName = ""
            Me.label6.CustomFontFamilies = ""
            Me.label6.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label6.Image = Nothing
            Me.label6.Location = New System.Drawing.Point(12, 9)
            Me.label6.Name = "label6"
            Me.label6.Opacity = 100
            Me.label6.Size = New System.Drawing.Size(66, 15)
            Me.label6.TabIndex = 12
            Me.label6.Text = "EnglishUS"
            Me.label6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label6.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label6.TooltipText = ""
            Me.label6.UseMnemonic = False
            Me.label6.ZOrder = 0
            '
            'panel1
            '
            Me.panel1.ApplicationWideResource = True
            Me.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.panel1.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.panel1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(153, Byte), Integer))
            Me.panel1.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
            Me.panel1.BackgroundImagePosition = ""
            Me.panel1.BackgroundImageQuality = CType(80, Short)
            Me.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.panel1.BorderColor = System.Drawing.Color.Black
            Me.panel1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid
            Me.panel1.ClassName = ""
            Me.panel1.ClientID = Nothing
            Me.panel1.Controls.Add(Me.label5)
            Me.panel1.Controls.Add(Me.label4)
            Me.panel1.CustomFontFamilies = ""
            Me.panel1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.panel1.HTML = ""
            Me.panel1.ImageLocation = ""
            Me.panel1.Location = New System.Drawing.Point(185, 29)
            Me.panel1.Name = "panel1"
            Me.panel1.Opacity = 60
            Me.panel1.Size = New System.Drawing.Size(433, 69)
            Me.panel1.TabIndex = 13
            Me.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.panel1.TooltipText = ""
            Me.panel1.VerticalGradient = True
            Me.panel1.ZOrder = 0
            '
            'jButton1
            '
            Me.jButton1.ApplicationWideResource = True
            Me.jButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton1.BackgroundImagePosition = ""
            Me.jButton1.BackgroundImageQuality = CType(80, Short)
            Me.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton1.ClassName = ""
            Me.jButton1.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton1.CustomFontFamilies = ""
            Me.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton1.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton1.Icon = Nothing
            Me.jButton1.IconURL = ""
            Me.jButton1.Image = Nothing
            Me.jButton1.ImageLocation = ""
            Me.jButton1.Location = New System.Drawing.Point(185, 172)
            Me.jButton1.Name = "jButton1"
            Me.jButton1.Opacity = 100
            Me.jButton1.PreventMultipleClicks = True
            Me.jButton1.Size = New System.Drawing.Size(149, 36)
            Me.jButton1.TabIndex = 17
            Me.jButton1.Text = "Get Long Date String"
            Me.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton1.TooltipText = ""
            Me.jButton1.UseVisualStyleBackColor = False
            Me.jButton1.ValidationFailedMessage = "Validation failed!"
            Me.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.jButton1.VerticalGradient = True
            Me.jButton1.ZOrder = 0
            '
            'lblLongDate
            '
            Me.lblLongDate.AutoSize = True
            Me.lblLongDate.BackColor = System.Drawing.Color.Transparent
            Me.lblLongDate.ClassName = ""
            Me.lblLongDate.CustomFontFamilies = ""
            Me.lblLongDate.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.lblLongDate.Image = Nothing
            Me.lblLongDate.Location = New System.Drawing.Point(345, 183)
            Me.lblLongDate.Name = "lblLongDate"
            Me.lblLongDate.Opacity = 100
            Me.lblLongDate.Size = New System.Drawing.Size(16, 15)
            Me.lblLongDate.TabIndex = 16
            Me.lblLongDate.Text = "..."
            Me.lblLongDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.lblLongDate.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.lblLongDate.TooltipText = ""
            Me.lblLongDate.UseMnemonic = False
            Me.lblLongDate.ZOrder = 0
            '
            'DateTimePickerTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(630, 270)
            Me.Controls.Add(Me.lblLongDate)
            Me.Controls.Add(Me.jButton1)
            Me.Controls.Add(Me.panel1)
            Me.Controls.Add(Me.label6)
            Me.Controls.Add(Me.lblArabic)
            Me.Controls.Add(Me.dtArabic)
            Me.Controls.Add(Me.label3)
            Me.Controls.Add(Me.dtGerman)
            Me.Controls.Add(Me.label2)
            Me.Controls.Add(Me.dtTurkish)
            Me.Controls.Add(Me.label1)
            Me.Controls.Add(Me.dtChinese)
            Me.Controls.Add(Me.dateTimePicker1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "DateTimePickerTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "DateTimePicker Demo"
            Me.panel1.ResumeLayout(False)
            Me.panel1.PerformLayout()
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

		#End Region

        Friend WithEvents dateTimePicker1 As VisualJS.Web.Forms.DateTimePicker
        Friend WithEvents dtChinese As VisualJS.Web.Forms.DateTimePicker
		Private label1 As VisualJS.Web.Forms.Label
		Private label2 As VisualJS.Web.Forms.Label
        Friend WithEvents dtTurkish As VisualJS.Web.Forms.DateTimePicker
		Private label3 As VisualJS.Web.Forms.Label
        Friend WithEvents dtGerman As VisualJS.Web.Forms.DateTimePicker
		Private lblArabic As VisualJS.Web.Forms.Label
        Friend WithEvents dtArabic As VisualJS.Web.Forms.DateTimePicker
		Private label4 As VisualJS.Web.Forms.Label
		Private label5 As VisualJS.Web.Forms.Label
		Private label6 As VisualJS.Web.Forms.Label
		Private panel1 As VisualJS.Web.Forms.Panel
        Friend WithEvents jButton1 As VisualJS.Web.Forms.JButton
		Private lblLongDate As VisualJS.Web.Forms.Label
	End Class
End Namespace 
