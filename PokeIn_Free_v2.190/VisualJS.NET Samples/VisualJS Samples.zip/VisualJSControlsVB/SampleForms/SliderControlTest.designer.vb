
Namespace SampleForms
	Partial Class SliderControlTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SliderControlTest))
            Me.slider1 = New VisualJS.Web.Forms.SliderControl()
            Me.SuspendLayout()
            '
            'slider1
            '
            Me.slider1.ApplicationWideResource = True
            Me.slider1.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.slider1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.slider1.BackColor = System.Drawing.Color.GreenYellow
            Me.slider1.BackgroundImagePosition = ""
            Me.slider1.BackgroundImageQuality = CType(80, Short)
            Me.slider1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.slider1.BoxCols = 5
            Me.slider1.BoxRows = 5
            Me.slider1.ClassName = ""
            Me.slider1.CustomFontFamilies = ""
            Me.slider1.DirectNav = True
            Me.slider1.DirectNavHide = True
            Me.slider1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.slider1.ImageLocation = ""
            Me.slider1.Location = New System.Drawing.Point(12, 12)
            Me.slider1.Name = "slider1"
            Me.slider1.PauseTime = 4000
            Me.slider1.ReadOnly = False
            Me.slider1.Size = New System.Drawing.Size(873, 301)
            Me.slider1.Slices = 5
            Me.slider1.StartSlide = 0
            Me.slider1.TabIndex = 0
            Me.slider1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.slider1.TooltipText = ""
            Me.slider1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.slider1.ZOrder = 0
            '
            'SliderControlTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.BackColor = System.Drawing.Color.Black
            Me.ClientSize = New System.Drawing.Size(900, 324)
            Me.Controls.Add(Me.slider1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "SliderControlTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "SliderControl Demo"
            Me.ResumeLayout(False)

        End Sub

		#End Region

		Private slider1 As VisualJS.Web.Forms.SliderControl
	End Class
End Namespace 
