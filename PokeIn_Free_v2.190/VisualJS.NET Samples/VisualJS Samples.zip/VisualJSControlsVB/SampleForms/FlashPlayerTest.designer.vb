
Namespace SampleForms
	Partial Class FlashPlayerTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FlashPlayerTest))
            Me.flashPlayer1 = New VisualJS.Web.Forms.FlashPlayer()
            Me.SuspendLayout()
            '
            'flashPlayer1
            '
            Me.flashPlayer1.AutoPlay = False
            Me.flashPlayer1.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.flashPlayer1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.flashPlayer1.BackColor = System.Drawing.Color.Black
            Me.flashPlayer1.ClassName = ""
            Me.flashPlayer1.Dock = System.Windows.Forms.DockStyle.Fill
            Me.flashPlayer1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.flashPlayer1.Location = New System.Drawing.Point(0, 0)
            Me.flashPlayer1.Name = "flashPlayer1"
            Me.flashPlayer1.Opacity = 100
            Me.flashPlayer1.Size = New System.Drawing.Size(626, 306)
            Me.flashPlayer1.SWF = "http://www.youtube.com/v/flj-919bKMU?version=3&amp;hl=en_US&amp;rel=0"
            Me.flashPlayer1.TabIndex = 0
            Me.flashPlayer1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.flashPlayer1.TooltipText = ""
            Me.flashPlayer1.ZOrder = 0
            '
            'FlashPlayerTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(626, 306)
            Me.Controls.Add(Me.flashPlayer1)
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MinimizeBox = False
            Me.Name = "FlashPlayerTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "FlashPlayer Demo"
            Me.ResumeLayout(False)

        End Sub

		#End Region

		Private flashPlayer1 As VisualJS.Web.Forms.FlashPlayer
	End Class
End Namespace 
