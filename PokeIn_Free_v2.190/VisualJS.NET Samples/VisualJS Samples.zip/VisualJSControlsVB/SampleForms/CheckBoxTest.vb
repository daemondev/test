
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports VisualJS
Imports VisualJS.Web.Forms
Imports System.Linq
Imports System.Text

Namespace SampleForms
	Public Partial Class CheckBoxTest
		Inherits VisualJS.Web.Forms.Form
		Public Sub New()
			InitializeComponent()
		End Sub

		'Use the below constructor if you create the instance of this Form object other than the active Thread
		'otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
		Public Sub New(clientId As String)
			MyBase.New(clientId)
			InitializeComponent()
		End Sub

		Private total As Double = 0 

        Private Sub checkBox1_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles checkBox4.CheckedChanged, checkBox3.CheckedChanged, checkBox2.CheckedChanged, checkBox1.CheckedChanged
            Dim chk As CheckBox = DirectCast(sender, CheckBox)
            If chk.Checked Then
                total += Convert.ToDouble(chk.Tag)
            Else
                total -= Convert.ToDouble(chk.Tag)
            End If

            maskedTextBox1.Text = "$ " + total.ToString("#,#")
        End Sub
    End Class
End Namespace
