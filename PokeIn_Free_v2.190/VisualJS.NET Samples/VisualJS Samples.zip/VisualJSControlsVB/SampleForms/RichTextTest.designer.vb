
Namespace SampleForms
	Partial Class RichTextTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(RichTextTest))
            Me.richTextBox1 = New VisualJS.Web.Forms.RichTextBox()
            Me.panel1 = New VisualJS.Web.Forms.Panel()
            Me.panel2 = New VisualJS.Web.Forms.Panel()
            Me.panel1.SuspendLayout()
            Me.SuspendLayout()
            '
            'richTextBox1
            '
            Me.richTextBox1.Buttons = "style,alignment,colors,insert,undoredo"
            Me.richTextBox1.CheckForEmail = False
            Me.richTextBox1.ClassName = ""
            Me.richTextBox1.CustomFontFamilies = ""
            Me.richTextBox1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.richTextBox1.Location = New System.Drawing.Point(12, 12)
            Me.richTextBox1.MaxLength = 65535
            Me.richTextBox1.MinLength = -1
            Me.richTextBox1.Multiline = True
            Me.richTextBox1.Name = "richTextBox1"
            Me.richTextBox1.Opacity = 100
            Me.richTextBox1.PreventSQLInjection = False
            Me.richTextBox1.RegexCheck = ""
            Me.richTextBox1.Size = New System.Drawing.Size(411, 236)
            Me.richTextBox1.TabIndex = 2
            Me.richTextBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.richTextBox1.TooltipText = ""
            Me.richTextBox1.ValidationMessage = "An action is required"
            Me.richTextBox1.ZOrder = 0
            '
            'panel1
            '
            Me.panel1.ApplicationWideResource = True
            Me.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.panel1.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.panel1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.panel1.BackColor = System.Drawing.Color.Transparent
            Me.panel1.BackColorEnd = System.Drawing.Color.Transparent
            Me.panel1.BackgroundImagePosition = ""
            Me.panel1.BackgroundImageQuality = CType(80, Short)
            Me.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.panel1.BorderColor = System.Drawing.Color.DimGray
            Me.panel1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid
            Me.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            Me.panel1.ClassName = ""
            Me.panel1.ClientID = Nothing
            Me.panel1.Controls.Add(Me.panel2)
            Me.panel1.CustomFontFamilies = ""
            Me.panel1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.panel1.HTML = ""
            Me.panel1.ImageLocation = ""
            Me.panel1.Location = New System.Drawing.Point(438, 12)
            Me.panel1.Name = "panel1"
            Me.panel1.Opacity = 100
            Me.panel1.Size = New System.Drawing.Size(374, 236)
            Me.panel1.TabIndex = 1
            Me.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.panel1.TooltipText = ""
            Me.panel1.VerticalGradient = True
            Me.panel1.ZOrder = 0
            '
            'panel2
            '
            Me.panel2.ApplicationWideResource = True
            Me.panel2.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.panel2.AutoScroll = True
            Me.panel2.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.panel2.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.panel2.BackColor = System.Drawing.Color.Transparent
            Me.panel2.BackColorEnd = System.Drawing.Color.Transparent
            Me.panel2.BackgroundImagePosition = ""
            Me.panel2.BackgroundImageQuality = CType(80, Short)
            Me.panel2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.panel2.BorderColor = System.Drawing.Color.Black
            Me.panel2.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid
            Me.panel2.ClassName = ""
            Me.panel2.ClientID = Nothing
            Me.panel2.CustomFontFamilies = ""
            Me.panel2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.panel2.HTML = "When the RichTextBox lost its focus, this component's HTML will be updated"
            Me.panel2.ImageLocation = ""
            Me.panel2.Location = New System.Drawing.Point(3, 3)
            Me.panel2.Name = "panel2"
            Me.panel2.Opacity = 100
            Me.panel2.Size = New System.Drawing.Size(366, 228)
            Me.panel2.TabIndex = 0
            Me.panel2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.panel2.TooltipText = ""
            Me.panel2.VerticalGradient = True
            Me.panel2.ZOrder = 0
            '
            'RichTextTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(824, 260)
            Me.Controls.Add(Me.panel1)
            Me.Controls.Add(Me.richTextBox1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "RichTextTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "RichTextBox Demo"
            Me.panel1.ResumeLayout(False)
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

		#End Region

        Friend WithEvents richTextBox1 As VisualJS.Web.Forms.RichTextBox
		Private panel1 As VisualJS.Web.Forms.Panel
		Private panel2 As VisualJS.Web.Forms.Panel
	End Class
End Namespace 
