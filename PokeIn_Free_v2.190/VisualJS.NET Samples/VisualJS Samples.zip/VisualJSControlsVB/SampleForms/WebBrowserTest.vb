
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports VisualJS
Imports VisualJS.Web.Forms
Imports System.Linq
Imports System.Text

Namespace SampleForms
	Public Partial Class WebBrowserTest
		Inherits VisualJS.Web.Forms.Form
		Public Sub New()
			InitializeComponent()
		End Sub

		'Use the below constructor if you create the instance of this Form object other than the active Thread
		'otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
		Public Sub New(clientId As String)
			MyBase.New(clientId)
			InitializeComponent()
		End Sub
	End Class
End Namespace 
