
Namespace SampleForms
	Partial Class TextboxTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(TextboxTest))
            Me.panel1 = New VisualJS.Web.Forms.Panel()
            Me.textBox1 = New VisualJS.Web.Forms.TextBox()
            Me.label1 = New VisualJS.Web.Forms.Label()
            Me.label2 = New VisualJS.Web.Forms.Label()
            Me.textBox2 = New VisualJS.Web.Forms.TextBox()
            Me.textBox3 = New VisualJS.Web.Forms.TextBox()
            Me.label3 = New VisualJS.Web.Forms.Label()
            Me.panel2 = New VisualJS.Web.Forms.Panel()
            Me.jButton1 = New VisualJS.Web.Forms.JButton()
            Me.panel3 = New VisualJS.Web.Forms.Panel()
            Me.jButton2 = New VisualJS.Web.Forms.JButton()
            Me.textBox4 = New VisualJS.Web.Forms.TextBox()
            Me.label4 = New VisualJS.Web.Forms.Label()
            Me.label5 = New VisualJS.Web.Forms.Label()
            Me.panel1.SuspendLayout()
            Me.panel2.SuspendLayout()
            Me.panel3.SuspendLayout()
            Me.SuspendLayout()
            '
            'panel1
            '
            Me.panel1.ApplicationWideResource = True
            Me.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.panel1.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.panel1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.panel1.BackColor = System.Drawing.Color.White
            Me.panel1.BackColorEnd = System.Drawing.Color.Transparent
            Me.panel1.BackgroundImagePosition = ""
            Me.panel1.BackgroundImageQuality = CType(80, Short)
            Me.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.panel1.BorderColor = System.Drawing.Color.Black
            Me.panel1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Dashed
            Me.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            Me.panel1.ClassName = ""
            Me.panel1.ClientID = Nothing
            Me.panel1.Controls.Add(Me.textBox1)
            Me.panel1.CustomFontFamilies = ""
            Me.panel1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.panel1.HTML = ""
            Me.panel1.ImageLocation = ""
            Me.panel1.Location = New System.Drawing.Point(7, 22)
            Me.panel1.Name = "panel1"
            Me.panel1.Opacity = 100
            Me.panel1.Size = New System.Drawing.Size(281, 29)
            Me.panel1.TabIndex = 0
            Me.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.panel1.TooltipText = ""
            Me.panel1.VerticalGradient = True
            Me.panel1.ZOrder = 0
            '
            'textBox1
            '
            Me.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
            Me.textBox1.CheckForEmail = False
            Me.textBox1.ClassName = ""
            Me.textBox1.CustomFontFamilies = ""
            Me.textBox1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.textBox1.Location = New System.Drawing.Point(3, 4)
            Me.textBox1.MaxLength = 65535
            Me.textBox1.MinLength = 1
            Me.textBox1.Name = "textBox1"
            Me.textBox1.Opacity = 100
            Me.textBox1.PreventSQLInjection = False
            Me.textBox1.RegexCheck = ""
            Me.textBox1.Size = New System.Drawing.Size(273, 19)
            Me.textBox1.TabIndex = 1
            Me.textBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.textBox1.TooltipText = ""
            Me.textBox1.ValidationMessage = "Enter some text"
            Me.textBox1.ZOrder = 0
            '
            'label1
            '
            Me.label1.AutoSize = True
            Me.label1.BackColor = System.Drawing.Color.Transparent
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(4, 3)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 100
            Me.label1.Size = New System.Drawing.Size(215, 16)
            Me.label1.TabIndex = 1
            Me.label1.Text = "Textbox inside a bordered panel"
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.ZOrder = 0
            '
            'label2
            '
            Me.label2.AutoSize = True
            Me.label2.BackColor = System.Drawing.Color.Transparent
            Me.label2.ClassName = ""
            Me.label2.CustomFontFamilies = ""
            Me.label2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label2.Image = Nothing
            Me.label2.Location = New System.Drawing.Point(15, 87)
            Me.label2.Name = "label2"
            Me.label2.Opacity = 100
            Me.label2.Size = New System.Drawing.Size(352, 16)
            Me.label2.TabIndex = 2
            Me.label2.Text = "AutoComplete for known <font color=red>colors<font>"
            Me.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label2.TooltipText = ""
            Me.label2.UseMnemonic = False
            Me.label2.ZOrder = 0
            '
            'textBox2
            '
            Me.textBox2.CheckForEmail = False
            Me.textBox2.ClassName = ""
            Me.textBox2.CustomFontFamilies = ""
            Me.textBox2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.textBox2.Location = New System.Drawing.Point(22, 106)
            Me.textBox2.MaxLength = 65535
            Me.textBox2.MinLength = -1
            Me.textBox2.Name = "textBox2"
            Me.textBox2.Opacity = 100
            Me.textBox2.PreventSQLInjection = False
            Me.textBox2.RegexCheck = ""
            Me.textBox2.Size = New System.Drawing.Size(273, 21)
            Me.textBox2.TabIndex = 3
            Me.textBox2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.textBox2.TooltipText = ""
            Me.textBox2.ValidationMessage = "An action is required"
            Me.textBox2.ZOrder = 0
            '
            'textBox3
            '
            Me.textBox3.CheckForEmail = False
            Me.textBox3.ClassName = ""
            Me.textBox3.CustomFontFamilies = ""
            Me.textBox3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.textBox3.Location = New System.Drawing.Point(11, 28)
            Me.textBox3.MaxLength = 65535
            Me.textBox3.MinLength = 1
            Me.textBox3.Name = "textBox3"
            Me.textBox3.Opacity = 100
            Me.textBox3.PreventSQLInjection = True
            Me.textBox3.RegexCheck = ""
            Me.textBox3.Size = New System.Drawing.Size(272, 26)
            Me.textBox3.TabIndex = 5
            Me.textBox3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.textBox3.TooltipText = ""
            Me.textBox3.ValidationMessage = "Enter some text"
            Me.textBox3.ZOrder = 0
            '
            'label3
            '
            Me.label3.AutoSize = True
            Me.label3.BackColor = System.Drawing.Color.Transparent
            Me.label3.ClassName = ""
            Me.label3.CustomFontFamilies = ""
            Me.label3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label3.Image = Nothing
            Me.label3.Location = New System.Drawing.Point(3, 9)
            Me.label3.Name = "label3"
            Me.label3.Opacity = 100
            Me.label3.Size = New System.Drawing.Size(153, 16)
            Me.label3.TabIndex = 4
            Me.label3.Text = "Prevents SQL Injection"
            Me.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label3.TooltipText = ""
            Me.label3.UseMnemonic = False
            Me.label3.ZOrder = 0
            '
            'panel2
            '
            Me.panel2.ApplicationWideResource = True
            Me.panel2.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.panel2.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.panel2.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.panel2.BackColor = System.Drawing.Color.Transparent
            Me.panel2.BackColorEnd = System.Drawing.Color.Transparent
            Me.panel2.BackgroundImagePosition = ""
            Me.panel2.BackgroundImageQuality = CType(80, Short)
            Me.panel2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.panel2.BorderColor = System.Drawing.Color.Black
            Me.panel2.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Dotted
            Me.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            Me.panel2.ClassName = ""
            Me.panel2.ClientID = Nothing
            Me.panel2.Controls.Add(Me.label1)
            Me.panel2.Controls.Add(Me.panel1)
            Me.panel2.Controls.Add(Me.jButton1)
            Me.panel2.CustomFontFamilies = ""
            Me.panel2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.panel2.HTML = ""
            Me.panel2.ImageLocation = ""
            Me.panel2.Location = New System.Drawing.Point(12, 12)
            Me.panel2.Name = "panel2"
            Me.panel2.Opacity = 100
            Me.panel2.Size = New System.Drawing.Size(409, 66)
            Me.panel2.TabIndex = 6
            Me.panel2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.panel2.TooltipText = ""
            Me.panel2.VerticalGradient = True
            Me.panel2.ZOrder = 0
            '
            'jButton1
            '
            Me.jButton1.ApplicationWideResource = True
            Me.jButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton1.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton1.BackgroundImagePosition = ""
            Me.jButton1.BackgroundImageQuality = CType(80, Short)
            Me.jButton1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton1.ClassName = ""
            Me.jButton1.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton1.CustomFontFamilies = ""
            Me.jButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton1.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton1.Icon = Global.VisualJSControlsVB.My.Resources.Resources.search
            Me.jButton1.IconURL = ""
            Me.jButton1.Image = Nothing
            Me.jButton1.ImageLocation = ""
            Me.jButton1.Location = New System.Drawing.Point(294, 22)
            Me.jButton1.Name = "jButton1"
            Me.jButton1.Opacity = 100
            Me.jButton1.PreventMultipleClicks = True
            Me.jButton1.Size = New System.Drawing.Size(102, 29)
            Me.jButton1.TabIndex = 2
            Me.jButton1.Text = "Search"
            Me.jButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton1.TooltipText = ""
            Me.jButton1.UseVisualStyleBackColor = False
            Me.jButton1.ValidationFailedMessage = "Validation failed!"
            Me.jButton1.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnParent
            Me.jButton1.VerticalGradient = True
            Me.jButton1.ZOrder = 0
            '
            'panel3
            '
            Me.panel3.ApplicationWideResource = True
            Me.panel3.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.panel3.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.panel3.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.panel3.BackColor = System.Drawing.Color.Transparent
            Me.panel3.BackColorEnd = System.Drawing.Color.Transparent
            Me.panel3.BackgroundImagePosition = ""
            Me.panel3.BackgroundImageQuality = CType(80, Short)
            Me.panel3.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.panel3.BorderColor = System.Drawing.Color.Black
            Me.panel3.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Dotted
            Me.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            Me.panel3.ClassName = ""
            Me.panel3.ClientID = Nothing
            Me.panel3.Controls.Add(Me.jButton2)
            Me.panel3.Controls.Add(Me.label3)
            Me.panel3.Controls.Add(Me.textBox3)
            Me.panel3.CustomFontFamilies = ""
            Me.panel3.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.panel3.HTML = ""
            Me.panel3.ImageLocation = ""
            Me.panel3.Location = New System.Drawing.Point(12, 137)
            Me.panel3.Name = "panel3"
            Me.panel3.Opacity = 100
            Me.panel3.Size = New System.Drawing.Size(409, 62)
            Me.panel3.TabIndex = 7
            Me.panel3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.panel3.TooltipText = ""
            Me.panel3.VerticalGradient = True
            Me.panel3.ZOrder = 0
            '
            'jButton2
            '
            Me.jButton2.ApplicationWideResource = True
            Me.jButton2.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
            Me.jButton2.BackColorEnd = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(206, Byte), Integer))
            Me.jButton2.BackgroundImagePosition = ""
            Me.jButton2.BackgroundImageQuality = CType(80, Short)
            Me.jButton2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.jButton2.ClassName = ""
            Me.jButton2.Cursor = System.Windows.Forms.Cursors.Hand
            Me.jButton2.CustomFontFamilies = ""
            Me.jButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.jButton2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.jButton2.HoverColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
            Me.jButton2.Icon = Global.VisualJSControlsVB.My.Resources.Resources.search
            Me.jButton2.IconURL = ""
            Me.jButton2.Image = Nothing
            Me.jButton2.ImageLocation = ""
            Me.jButton2.Location = New System.Drawing.Point(294, 27)
            Me.jButton2.Name = "jButton2"
            Me.jButton2.Opacity = 100
            Me.jButton2.PreventMultipleClicks = True
            Me.jButton2.Size = New System.Drawing.Size(102, 29)
            Me.jButton2.TabIndex = 0
            Me.jButton2.Text = "Search"
            Me.jButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.jButton2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.jButton2.TooltipText = ""
            Me.jButton2.UseVisualStyleBackColor = False
            Me.jButton2.ValidationFailedMessage = "Validation failed!"
            Me.jButton2.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnParent
            Me.jButton2.VerticalGradient = True
            Me.jButton2.ZOrder = 0
            '
            'textBox4
            '
            Me.textBox4.CheckForEmail = False
            Me.textBox4.ClassName = ""
            Me.textBox4.CustomFontFamilies = ""
            Me.textBox4.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.textBox4.Location = New System.Drawing.Point(443, 35)
            Me.textBox4.MaxLength = 65535
            Me.textBox4.MinLength = -1
            Me.textBox4.Multiline = True
            Me.textBox4.Name = "textBox4"
            Me.textBox4.Opacity = 100
            Me.textBox4.PreventSQLInjection = False
            Me.textBox4.RegexCheck = ""
            Me.textBox4.Size = New System.Drawing.Size(273, 164)
            Me.textBox4.TabIndex = 9
            Me.textBox4.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.textBox4.TooltipText = ""
            Me.textBox4.ValidationMessage = "An action is required"
            Me.textBox4.ZOrder = 0
            '
            'label4
            '
            Me.label4.AutoSize = True
            Me.label4.BackColor = System.Drawing.Color.Transparent
            Me.label4.ClassName = ""
            Me.label4.CustomFontFamilies = ""
            Me.label4.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label4.Image = Nothing
            Me.label4.Location = New System.Drawing.Point(436, 16)
            Me.label4.Name = "label4"
            Me.label4.Opacity = 100
            Me.label4.Size = New System.Drawing.Size(123, 16)
            Me.label4.TabIndex = 8
            Me.label4.Text = "Supports Multiline"
            Me.label4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label4.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label4.TooltipText = ""
            Me.label4.UseMnemonic = False
            Me.label4.ZOrder = 0
            '
            'label5
            '
            Me.label5.BackColor = System.Drawing.Color.Transparent
            Me.label5.ClassName = ""
            Me.label5.CustomFontFamilies = ""
            Me.label5.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.label5.Image = Nothing
            Me.label5.Location = New System.Drawing.Point(12, 217)
            Me.label5.Name = "label5"
            Me.label5.Opacity = 100
            Me.label5.Size = New System.Drawing.Size(704, 16)
            Me.label5.TabIndex = 10
            Me.label5.Text = "And many useful features like <strong>EmailCheck</strong>, <strong>RegEx Validati" & _
        "on</strong>, <strong>Custom fonts, opacity, docking..</strong>"
            Me.label5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
            Me.label5.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label5.TooltipText = ""
            Me.label5.UseMnemonic = False
            Me.label5.ZOrder = 0
            '
            'TextboxTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.BackColor = System.Drawing.Color.White
            Me.ClientSize = New System.Drawing.Size(734, 247)
            Me.Controls.Add(Me.label5)
            Me.Controls.Add(Me.textBox4)
            Me.Controls.Add(Me.label4)
            Me.Controls.Add(Me.panel3)
            Me.Controls.Add(Me.panel2)
            Me.Controls.Add(Me.textBox2)
            Me.Controls.Add(Me.label2)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "TextboxTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "Textbox Demo"
            Me.panel1.ResumeLayout(False)
            Me.panel1.PerformLayout()
            Me.panel2.ResumeLayout(False)
            Me.panel2.PerformLayout()
            Me.panel3.ResumeLayout(False)
            Me.panel3.PerformLayout()
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

		#End Region

		Private panel1 As VisualJS.Web.Forms.Panel
		Private textBox1 As VisualJS.Web.Forms.TextBox
		Private label1 As VisualJS.Web.Forms.Label
		Friend WithEvents jButton1 As VisualJS.Web.Forms.JButton
		Private label2 As VisualJS.Web.Forms.Label
        Friend WithEvents textBox2 As VisualJS.Web.Forms.TextBox
		Private textBox3 As VisualJS.Web.Forms.TextBox
		Private label3 As VisualJS.Web.Forms.Label
		Private panel2 As VisualJS.Web.Forms.Panel
		Private panel3 As VisualJS.Web.Forms.Panel
		Friend WithEvents jButton2 As VisualJS.Web.Forms.JButton
		Private textBox4 As VisualJS.Web.Forms.TextBox
		Private label4 As VisualJS.Web.Forms.Label
		Private label5 As VisualJS.Web.Forms.Label
	End Class
End Namespace

'=======================================================
'Service provided by Telerik (www.telerik.com)
'Conversion powered by NRefactory.
'Twitter: @telerik, @toddanglin
'Facebook: facebook.com/telerik
'=======================================================
