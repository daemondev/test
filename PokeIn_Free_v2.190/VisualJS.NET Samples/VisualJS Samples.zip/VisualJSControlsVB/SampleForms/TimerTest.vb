
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports VisualJS
Imports VisualJS.Web.Forms
Imports System.Linq
Imports System.Text

Namespace SampleForms
	Public Partial Class TimerTest
		Inherits VisualJS.Web.Forms.Form

		#Region "Constructors"
		Public Sub New()
			InitializeComponent()
			AfterInitialization()
		End Sub

		'Use the below constructor if you create the instance of this Form object other than the active Thread
		'otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
		Public Sub New(clientId As String)
			MyBase.New(clientId)
			InitializeComponent()
			AfterInitialization()
		End Sub
		#End Region

		'Use below method for the tasks after the initialization of the Form
		Private Sub AfterInitialization()

		End Sub

        Private Sub TimerTest_Load(sender As Object, e As EventArgs) Handles Me.Load
            timer1.Enabled = True
        End Sub

        Private Sub timer1_Tick(sender As System.Object, e As System.EventArgs) Handles timer1.Tick
            label1.Text = DateTime.Now.Hour.ToString("D2") + ":" + DateTime.Now.Minute.ToString("D2") + ":" + DateTime.Now.Second.ToString("D2")
        End Sub
    End Class
End Namespace 
