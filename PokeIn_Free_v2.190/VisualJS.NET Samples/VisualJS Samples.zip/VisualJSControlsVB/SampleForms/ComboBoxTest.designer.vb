
Namespace SampleForms
	Partial Class ComboBoxTest
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ComboBoxTest))
            Me.comboBox1 = New VisualJS.Web.Forms.ComboBox()
            Me.label3 = New VisualJS.Web.Forms.Label()
            Me.button1 = New VisualJS.Web.Forms.Button()
            Me.button2 = New VisualJS.Web.Forms.Button()
            Me.button3 = New VisualJS.Web.Forms.Button()
            Me.maskedTextBox2 = New VisualJS.Web.Forms.MaskedTextBox()
            Me.label2 = New VisualJS.Web.Forms.Label()
            Me.pictureBox1 = New VisualJS.Web.Forms.PictureBox()
            Me.panel1 = New VisualJS.Web.Forms.Panel()
            Me.panel2 = New VisualJS.Web.Forms.Panel()
            Me.button4 = New VisualJS.Web.Forms.Button()
            Me.maskedTextBox1 = New VisualJS.Web.Forms.MaskedTextBox()
            Me.label1 = New VisualJS.Web.Forms.Label()
            CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.panel1.SuspendLayout()
            Me.panel2.SuspendLayout()
            Me.SuspendLayout()
            '
            'comboBox1
            '
            Me.comboBox1.ClassName = ""
            Me.comboBox1.CustomFontFamilies = ""
            Me.comboBox1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.comboBox1.Location = New System.Drawing.Point(12, 12)
            Me.comboBox1.MinSelectedIndex = -1
            Me.comboBox1.Name = "comboBox1"
            Me.comboBox1.Opacity = 100
            Me.comboBox1.Size = New System.Drawing.Size(176, 23)
            Me.comboBox1.TabIndex = 13
            Me.comboBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.comboBox1.TooltipText = ""
            Me.comboBox1.UpdateTextBySelection = Me.label3
            Me.comboBox1.ValidationMessage = "An action is required"
            Me.comboBox1.ZOrder = 0
            '
            'label3
            '
            Me.label3.AutoSize = True
            Me.label3.BackColor = System.Drawing.Color.Transparent
            Me.label3.ClassName = ""
            Me.label3.CustomFontFamilies = ""
            Me.label3.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label3.Image = Nothing
            Me.label3.Location = New System.Drawing.Point(12, 42)
            Me.label3.Name = "label3"
            Me.label3.Opacity = 100
            Me.label3.Size = New System.Drawing.Size(76, 15)
            Me.label3.TabIndex = 14
            Me.label3.Text = "IText Feature"
            Me.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label3.TooltipText = ""
            Me.label3.UseMnemonic = False
            Me.label3.ZOrder = 0
            '
            'button1
            '
            Me.button1.BackgroundImagePosition = ""
            Me.button1.BackgroundImageQuality = CType(80, Short)
            Me.button1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.button1.ClassName = ""
            Me.button1.Cursor = System.Windows.Forms.Cursors.Hand
            Me.button1.CustomFontFamilies = ""
            Me.button1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.button1.Image = Nothing
            Me.button1.Location = New System.Drawing.Point(211, 12)
            Me.button1.Name = "button1"
            Me.button1.Opacity = 100
            Me.button1.PreventMultipleClicks = True
            Me.button1.Size = New System.Drawing.Size(109, 23)
            Me.button1.TabIndex = 1
            Me.button1.Text = "Add Item"
            Me.button1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.button1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.button1.TooltipText = ""
            Me.button1.UseMnemonic = False
            Me.button1.UseVisualStyleBackColor = True
            Me.button1.ValidationFailedMessage = "Validation failed!"
            Me.button1.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.button1.ZOrder = 0
            '
            'button2
            '
            Me.button2.BackgroundImagePosition = ""
            Me.button2.BackgroundImageQuality = CType(80, Short)
            Me.button2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.button2.ClassName = ""
            Me.button2.Cursor = System.Windows.Forms.Cursors.Hand
            Me.button2.CustomFontFamilies = ""
            Me.button2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.button2.Image = Nothing
            Me.button2.Location = New System.Drawing.Point(3, 6)
            Me.button2.Name = "button2"
            Me.button2.Opacity = 100
            Me.button2.PreventMultipleClicks = True
            Me.button2.Size = New System.Drawing.Size(109, 23)
            Me.button2.TabIndex = 2
            Me.button2.Text = "Remove Item"
            Me.button2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.button2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.button2.TooltipText = ""
            Me.button2.UseMnemonic = False
            Me.button2.UseVisualStyleBackColor = True
            Me.button2.ValidationFailedMessage = "Enter the index you want to remove"
            Me.button2.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnParent
            Me.button2.ZOrder = 0
            '
            'button3
            '
            Me.button3.BackgroundImagePosition = ""
            Me.button3.BackgroundImageQuality = CType(80, Short)
            Me.button3.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.button3.ClassName = ""
            Me.button3.Cursor = System.Windows.Forms.Cursors.Hand
            Me.button3.CustomFontFamilies = ""
            Me.button3.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.button3.Image = Nothing
            Me.button3.Location = New System.Drawing.Point(211, 113)
            Me.button3.Name = "button3"
            Me.button3.Opacity = 100
            Me.button3.PreventMultipleClicks = True
            Me.button3.Size = New System.Drawing.Size(109, 23)
            Me.button3.TabIndex = 3
            Me.button3.Text = "Clear Items"
            Me.button3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.button3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.button3.TooltipText = ""
            Me.button3.UseMnemonic = False
            Me.button3.UseVisualStyleBackColor = True
            Me.button3.ValidationFailedMessage = "Validation failed!"
            Me.button3.ValidationsCheckMode = VisualJS.Service.CheckValidations.Never
            Me.button3.ZOrder = 0
            '
            'maskedTextBox2
            '
            Me.maskedTextBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.maskedTextBox2.CheckForEmail = False
            Me.maskedTextBox2.ClassName = ""
            Me.maskedTextBox2.CustomFontFamilies = ""
            Me.maskedTextBox2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.maskedTextBox2.Location = New System.Drawing.Point(118, 8)
            Me.maskedTextBox2.MinLength = -1
            Me.maskedTextBox2.Name = "maskedTextBox2"
            Me.maskedTextBox2.Opacity = 100
            Me.maskedTextBox2.PreventSQLInjection = False
            Me.maskedTextBox2.RegexCheck = ""
            Me.maskedTextBox2.Size = New System.Drawing.Size(70, 21)
            Me.maskedTextBox2.TabIndex = 7
            Me.maskedTextBox2.Text = "0"
            Me.maskedTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
            Me.maskedTextBox2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.maskedTextBox2.TooltipText = ""
            Me.maskedTextBox2.ValidationMessage = "Enter a number"
            Me.maskedTextBox2.ZOrder = 0
            '
            'label2
            '
            Me.label2.AutoSize = True
            Me.label2.BackColor = System.Drawing.Color.Transparent
            Me.label2.ClassName = ""
            Me.label2.CustomFontFamilies = ""
            Me.label2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label2.Image = Nothing
            Me.label2.Location = New System.Drawing.Point(194, 10)
            Me.label2.Name = "label2"
            Me.label2.Opacity = 100
            Me.label2.Size = New System.Drawing.Size(36, 15)
            Me.label2.TabIndex = 9
            Me.label2.Text = "index"
            Me.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label2.TooltipText = ""
            Me.label2.UseMnemonic = False
            Me.label2.ZOrder = 0
            '
            'pictureBox1
            '
            Me.pictureBox1.ApplicationWideResource = False
            Me.pictureBox1.BackColor = System.Drawing.Color.White
            Me.pictureBox1.ClassName = ""
            Me.pictureBox1.ErrorImage = CType(resources.GetObject("pictureBox1.ErrorImage"), System.Drawing.Image)
            Me.pictureBox1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.pictureBox1.Image = Nothing
            Me.pictureBox1.ImageLocation = ""
            Me.pictureBox1.ImageQuality = CType(90, Short)
            Me.pictureBox1.InitialImage = CType(resources.GetObject("pictureBox1.InitialImage"), System.Drawing.Image)
            Me.pictureBox1.Location = New System.Drawing.Point(12, 62)
            Me.pictureBox1.Name = "pictureBox1"
            Me.pictureBox1.Opacity = 100
            Me.pictureBox1.RenderingImageType = VisualJS.Web.Forms.PictureBox.ImageType.JPG
            Me.pictureBox1.Size = New System.Drawing.Size(176, 72)
            Me.pictureBox1.SizeMode = VisualJS.Web.Forms.PictureBox.ImageSize.StretchImage
            Me.pictureBox1.TabIndex = 10
            Me.pictureBox1.TabStop = False
            Me.pictureBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.pictureBox1.TooltipText = ""
            Me.pictureBox1.ZOrder = 0
            '
            'panel1
            '
            Me.panel1.ApplicationWideResource = True
            Me.panel1.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.panel1.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.panel1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.panel1.BackColor = System.Drawing.Color.Transparent
            Me.panel1.BackColorEnd = System.Drawing.Color.Transparent
            Me.panel1.BackgroundImagePosition = ""
            Me.panel1.BackgroundImageQuality = CType(80, Short)
            Me.panel1.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.panel1.BorderColor = System.Drawing.Color.Black
            Me.panel1.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid
            Me.panel1.ClassName = ""
            Me.panel1.ClientID = Nothing
            Me.panel1.Controls.Add(Me.button2)
            Me.panel1.Controls.Add(Me.maskedTextBox2)
            Me.panel1.Controls.Add(Me.label2)
            Me.panel1.CustomFontFamilies = ""
            Me.panel1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.panel1.HTML = ""
            Me.panel1.ImageLocation = ""
            Me.panel1.Location = New System.Drawing.Point(208, 73)
            Me.panel1.Name = "panel1"
            Me.panel1.Opacity = 100
            Me.panel1.Size = New System.Drawing.Size(239, 32)
            Me.panel1.TabIndex = 11
            Me.panel1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.panel1.TooltipText = ""
            Me.panel1.VerticalGradient = True
            Me.panel1.ZOrder = 0
            '
            'panel2
            '
            Me.panel2.ApplicationWideResource = True
            Me.panel2.AutoGrowShrink = VisualJS.Service.GrowShrink.None
            Me.panel2.AutoScrollMargin = New System.Drawing.Size(0, 0)
            Me.panel2.AutoScrollMinSize = New System.Drawing.Size(0, 0)
            Me.panel2.BackColor = System.Drawing.Color.Transparent
            Me.panel2.BackColorEnd = System.Drawing.Color.Transparent
            Me.panel2.BackgroundImagePosition = ""
            Me.panel2.BackgroundImageQuality = CType(80, Short)
            Me.panel2.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.panel2.BorderColor = System.Drawing.Color.Black
            Me.panel2.BorderLineStyle = VisualJS.Web.Forms.Panel.ClientBorderStyle.Solid
            Me.panel2.ClassName = ""
            Me.panel2.ClientID = Nothing
            Me.panel2.Controls.Add(Me.button4)
            Me.panel2.Controls.Add(Me.maskedTextBox1)
            Me.panel2.Controls.Add(Me.label1)
            Me.panel2.CustomFontFamilies = ""
            Me.panel2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.panel2.HTML = ""
            Me.panel2.ImageLocation = ""
            Me.panel2.Location = New System.Drawing.Point(208, 38)
            Me.panel2.Name = "panel2"
            Me.panel2.Opacity = 100
            Me.panel2.Size = New System.Drawing.Size(239, 32)
            Me.panel2.TabIndex = 12
            Me.panel2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.panel2.TooltipText = ""
            Me.panel2.VerticalGradient = True
            Me.panel2.ZOrder = 0
            '
            'button4
            '
            Me.button4.BackgroundImagePosition = ""
            Me.button4.BackgroundImageQuality = CType(80, Short)
            Me.button4.BackgroundImageRepeat = VisualJS.Service.ImageRepeatType.RepeatXY
            Me.button4.ClassName = ""
            Me.button4.Cursor = System.Windows.Forms.Cursors.Hand
            Me.button4.CustomFontFamilies = ""
            Me.button4.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.button4.Image = Nothing
            Me.button4.Location = New System.Drawing.Point(3, 6)
            Me.button4.Name = "button4"
            Me.button4.Opacity = 100
            Me.button4.PreventMultipleClicks = True
            Me.button4.Size = New System.Drawing.Size(109, 23)
            Me.button4.TabIndex = 2
            Me.button4.Text = "Insert Item"
            Me.button4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
            Me.button4.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.button4.TooltipText = ""
            Me.button4.UseMnemonic = False
            Me.button4.UseVisualStyleBackColor = True
            Me.button4.ValidationFailedMessage = "Enter the index you want to insert"
            Me.button4.ValidationsCheckMode = VisualJS.Service.CheckValidations.OnParent
            Me.button4.ZOrder = 0
            '
            'maskedTextBox1
            '
            Me.maskedTextBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
            Me.maskedTextBox1.CheckForEmail = False
            Me.maskedTextBox1.ClassName = ""
            Me.maskedTextBox1.CustomFontFamilies = ""
            Me.maskedTextBox1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.maskedTextBox1.Location = New System.Drawing.Point(118, 8)
            Me.maskedTextBox1.MinLength = -1
            Me.maskedTextBox1.Name = "maskedTextBox1"
            Me.maskedTextBox1.Opacity = 100
            Me.maskedTextBox1.PreventSQLInjection = False
            Me.maskedTextBox1.RegexCheck = ""
            Me.maskedTextBox1.Size = New System.Drawing.Size(70, 21)
            Me.maskedTextBox1.TabIndex = 7
            Me.maskedTextBox1.Text = "0"
            Me.maskedTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
            Me.maskedTextBox1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.maskedTextBox1.TooltipText = ""
            Me.maskedTextBox1.ValidationMessage = "Enter a number"
            Me.maskedTextBox1.ZOrder = 0
            '
            'label1
            '
            Me.label1.AutoSize = True
            Me.label1.BackColor = System.Drawing.Color.Transparent
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(194, 10)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 100
            Me.label1.Size = New System.Drawing.Size(36, 15)
            Me.label1.TabIndex = 9
            Me.label1.Text = "index"
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.ZOrder = 0
            '
            'ComboBoxTest
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(451, 148)
            Me.Controls.Add(Me.label3)
            Me.Controls.Add(Me.panel2)
            Me.Controls.Add(Me.panel1)
            Me.Controls.Add(Me.pictureBox1)
            Me.Controls.Add(Me.button3)
            Me.Controls.Add(Me.button1)
            Me.Controls.Add(Me.comboBox1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "ComboBoxTest"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "ComboBox Demo"
            CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
            Me.panel1.ResumeLayout(False)
            Me.panel1.PerformLayout()
            Me.panel2.ResumeLayout(False)
            Me.panel2.PerformLayout()
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

		#End Region

        Friend WithEvents comboBox1 As VisualJS.Web.Forms.ComboBox
        Friend WithEvents button1 As VisualJS.Web.Forms.Button
        Friend WithEvents button2 As VisualJS.Web.Forms.Button
        Friend WithEvents button3 As VisualJS.Web.Forms.Button
		Private maskedTextBox2 As VisualJS.Web.Forms.MaskedTextBox
		Private label2 As VisualJS.Web.Forms.Label
		Private pictureBox1 As VisualJS.Web.Forms.PictureBox
		Private panel1 As VisualJS.Web.Forms.Panel
		Private panel2 As VisualJS.Web.Forms.Panel
        Friend WithEvents button4 As VisualJS.Web.Forms.Button
		Private maskedTextBox1 As VisualJS.Web.Forms.MaskedTextBox
		Private label1 As VisualJS.Web.Forms.Label
		Private label3 As VisualJS.Web.Forms.Label
	End Class
End Namespace
