
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports VisualJS
Imports VisualJS.Web.Forms
Imports System.Linq
Imports System.Text

Namespace SampleForms
	Public Partial Class ComboBoxTest
		Inherits VisualJS.Web.Forms.Form
		Public Sub New()
			InitializeComponent()
		End Sub

		'Use the below constructor if you create the instance of this Form object other than the active Thread
		'otherwise you will receive "Cant locate the ClientID in active context. Consider using Form constructor with ClientID parameter" exception
		Public Sub New(clientId As String)
			MyBase.New(clientId)
			InitializeComponent()
		End Sub

		Private n As Long = 0

		'Add Item
        Private Sub button1_Click(sender As Object, e As EventArgs) Handles button1.Click
            comboBox1.Items.Add("Item " + n.ToString())
            n = n + 1
        End Sub

		'Insert Item
        Private Sub button4_Click(sender As Object, e As EventArgs) Handles button4.Click
            Dim number As Int32
            If Int32.TryParse(maskedTextBox1.Text, number) Then
                If number < comboBox1.Items.Count Then
                    comboBox1.Items.Insert(number, "Item " + n.ToString())
                    n = n + 1
                    Return
                End If
            End If

            MessageBox.Show("Error", "Enter a number within the range of combobox items", MessageBoxIcons.[Error], Me)
        End Sub

		'Remove Item
        Private Sub button2_Click(sender As Object, e As EventArgs) Handles button2.Click
            Dim number As Int32
            If Int32.TryParse(maskedTextBox2.Text, number) Then
                If number < comboBox1.Items.Count Then
                    comboBox1.Items.RemoveAt(number)
                    Return
                End If
            End If

            MessageBox.Show("Error", "Enter a number within the range of combobox items", MessageBoxIcons.[Error], Me)
        End Sub

		'Clear Items
        Private Sub button3_Click(sender As Object, e As EventArgs) Handles button3.Click
            comboBox1.Items.Clear()
        End Sub

		Private colors As Color() = New Color(3) {Color.Yellow, Color.Orange, Color.White, Color.Red}
		Private Sub UpdateDraw(texts As String())
			Dim bmp As New Bitmap(pictureBox1.Width, pictureBox1.Height)
			Dim grp As Graphics = Graphics.FromImage(bmp)
			For i As Integer = 0 To texts.Length - 1
				grp.DrawString(texts(i), Me.Font, New SolidBrush(colors(i Mod 4)), 15, 10 + (i * 20))
			Next
			grp.Flush()
			grp.Save()
			pictureBox1.Image = bmp
		End Sub

        Private Sub comboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboBox1.SelectedIndexChanged
            Dim list As String() = New String() {"Selected Index:" + comboBox1.SelectedIndex.ToString(), "Value:" + comboBox1.SelectedItem}
            UpdateDraw(list)
        End Sub
	End Class
End Namespace 
