
Namespace SampleForms
	Partial Class Labels
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name=""disposing"">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Labels))
            Me.label1 = New VisualJS.Web.Forms.Label()
            Me.label2 = New VisualJS.Web.Forms.Label()
            Me.label3 = New VisualJS.Web.Forms.Label()
            Me.label4 = New VisualJS.Web.Forms.Label()
            Me.label5 = New VisualJS.Web.Forms.Label()
            Me.label6 = New VisualJS.Web.Forms.Label()
            Me.linkLabel1 = New VisualJS.Web.Forms.LinkLabel()
            Me.linkLabel2 = New VisualJS.Web.Forms.LinkLabel()
            Me.linkLabel3 = New VisualJS.Web.Forms.LinkLabel()
            Me.linkLabel4 = New VisualJS.Web.Forms.LinkLabel()
            Me.linkLabel5 = New VisualJS.Web.Forms.LinkLabel()
            Me.SuspendLayout()
            '
            'label1
            '
            Me.label1.AutoSize = True
            Me.label1.BackColor = System.Drawing.Color.Transparent
            Me.label1.ClassName = ""
            Me.label1.CustomFontFamilies = ""
            Me.label1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label1.Image = Nothing
            Me.label1.Location = New System.Drawing.Point(12, 9)
            Me.label1.Name = "label1"
            Me.label1.Opacity = 100
            Me.label1.Size = New System.Drawing.Size(106, 15)
            Me.label1.TabIndex = 0
            Me.label1.Text = "Normal Text Label"
            Me.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label1.TooltipText = ""
            Me.label1.UseMnemonic = False
            Me.label1.ZOrder = 0
            '
            'label2
            '
            Me.label2.BackColor = System.Drawing.Color.Transparent
            Me.label2.ClassName = ""
            Me.label2.CustomFontFamilies = ""
            Me.label2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label2.Image = Nothing
            Me.label2.Location = New System.Drawing.Point(12, 33)
            Me.label2.Name = "label2"
            Me.label2.Opacity = 100
            Me.label2.Size = New System.Drawing.Size(184, 15)
            Me.label2.TabIndex = 1
            Me.label2.Text = "Normal Text Label with <font color='#b00000'>HTML</font>"
            Me.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label2.TooltipText = ""
            Me.label2.UseMnemonic = False
            Me.label2.ZOrder = 0
            '
            'label3
            '
            Me.label3.AutoSize = True
            Me.label3.BackColor = System.Drawing.Color.Transparent
            Me.label3.ClassName = ""
            Me.label3.CustomFontFamilies = "Tahoma,Verdana"
            Me.label3.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label3.Image = Nothing
            Me.label3.Location = New System.Drawing.Point(12, 57)
            Me.label3.Name = "label3"
            Me.label3.Opacity = 100
            Me.label3.Size = New System.Drawing.Size(256, 15)
            Me.label3.TabIndex = 2
            Me.label3.Text = "Normal Text Label with Custom Font Families"
            Me.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label3.TooltipText = ""
            Me.label3.UseMnemonic = False
            Me.label3.ZOrder = 0
            '
            'label4
            '
            Me.label4.AutoSize = True
            Me.label4.BackColor = System.Drawing.Color.Gold
            Me.label4.ClassName = ""
            Me.label4.CustomFontFamilies = ""
            Me.label4.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label4.Image = Nothing
            Me.label4.Location = New System.Drawing.Point(12, 81)
            Me.label4.Name = "label4"
            Me.label4.Opacity = 100
            Me.label4.Size = New System.Drawing.Size(233, 15)
            Me.label4.TabIndex = 3
            Me.label4.Text = "Normal Text Label with Background Color"
            Me.label4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label4.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label4.TooltipText = ""
            Me.label4.UseMnemonic = False
            Me.label4.ZOrder = 0
            '
            'label5
            '
            Me.label5.AutoSize = True
            Me.label5.BackColor = System.Drawing.Color.Gold
            Me.label5.ClassName = ""
            Me.label5.CustomFontFamilies = ""
            Me.label5.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label5.Image = Nothing
            Me.label5.Location = New System.Drawing.Point(12, 105)
            Me.label5.Name = "label5"
            Me.label5.Opacity = 70
            Me.label5.Size = New System.Drawing.Size(287, 15)
            Me.label5.TabIndex = 4
            Me.label5.Text = "Normal Text Label with Background Color & Opacity"
            Me.label5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label5.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label5.TooltipText = ""
            Me.label5.UseMnemonic = False
            Me.label5.ZOrder = 0
            '
            'label6
            '
            Me.label6.BackColor = System.Drawing.Color.Orange
            Me.label6.ClassName = ""
            Me.label6.CustomFontFamilies = ""
            Me.label6.Dock = System.Windows.Forms.DockStyle.Bottom
            Me.label6.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.label6.Image = Nothing
            Me.label6.Location = New System.Drawing.Point(0, 138)
            Me.label6.Name = "label6"
            Me.label6.Opacity = 100
            Me.label6.Size = New System.Drawing.Size(626, 18)
            Me.label6.TabIndex = 5
            Me.label6.Text = "Docked Text Label with Background Color"
            Me.label6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.label6.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.label6.TooltipText = ""
            Me.label6.UseMnemonic = False
            Me.label6.ZOrder = 0
            '
            'linkLabel1
            '
            Me.linkLabel1.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(176, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
            Me.linkLabel1.AutoSize = True
            Me.linkLabel1.BackColor = System.Drawing.Color.Transparent
            Me.linkLabel1.ClassName = ""
            Me.linkLabel1.Cursor = System.Windows.Forms.Cursors.Hand
            Me.linkLabel1.CustomFontFamilies = ""
            Me.linkLabel1.DisabledLinkColor = System.Drawing.SystemColors.InactiveCaptionText
            Me.linkLabel1.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.linkLabel1.HoverLinkColor = System.Drawing.Color.Orange
            Me.linkLabel1.Image = Nothing
            Me.linkLabel1.LinkArea = New System.Windows.Forms.LinkArea(0, 26)
            Me.linkLabel1.LinkColor = System.Drawing.Color.Blue
            Me.linkLabel1.Location = New System.Drawing.Point(394, 9)
            Me.linkLabel1.Name = "linkLabel1"
            Me.linkLabel1.Opacity = 100
            Me.linkLabel1.Size = New System.Drawing.Size(151, 15)
            Me.linkLabel1.TabIndex = 6
            Me.linkLabel1.TabStop = True
            Me.linkLabel1.Target = VisualJS.Web.Forms.LinkLabel.URLOpen.NewWindow
            Me.linkLabel1.TargetURL = "http://www.visualjs.net"
            Me.linkLabel1.Text = "Link Label with URL target"
            Me.linkLabel1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.linkLabel1.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.linkLabel1.TooltipText = ""
            Me.linkLabel1.UseMnemonic = False
            Me.linkLabel1.VisitedLinkColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
            Me.linkLabel1.ZOrder = 0
            '
            'linkLabel2
            '
            Me.linkLabel2.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(176, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
            Me.linkLabel2.AutoSize = True
            Me.linkLabel2.BackColor = System.Drawing.Color.Transparent
            Me.linkLabel2.ClassName = ""
            Me.linkLabel2.Cursor = System.Windows.Forms.Cursors.Hand
            Me.linkLabel2.CustomFontFamilies = ""
            Me.linkLabel2.DisabledLinkColor = System.Drawing.SystemColors.InactiveCaptionText
            Me.linkLabel2.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.linkLabel2.HoverLinkColor = System.Drawing.Color.Orange
            Me.linkLabel2.Image = Nothing
            Me.linkLabel2.LinkArea = New System.Windows.Forms.LinkArea(0, 34)
            Me.linkLabel2.LinkColor = System.Drawing.Color.OrangeRed
            Me.linkLabel2.Location = New System.Drawing.Point(394, 33)
            Me.linkLabel2.Name = "linkLabel2"
            Me.linkLabel2.Opacity = 100
            Me.linkLabel2.Size = New System.Drawing.Size(190, 15)
            Me.linkLabel2.TabIndex = 7
            Me.linkLabel2.TabStop = True
            Me.linkLabel2.Target = VisualJS.Web.Forms.LinkLabel.URLOpen.NewWindow
            Me.linkLabel2.TargetURL = ""
            Me.linkLabel2.Text = "Link Label with Server Click Event"
            Me.linkLabel2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.linkLabel2.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.linkLabel2.TooltipText = ""
            Me.linkLabel2.UseMnemonic = False
            Me.linkLabel2.VisitedLinkColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
            Me.linkLabel2.ZOrder = 0
            '
            'linkLabel3
            '
            Me.linkLabel3.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(176, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
            Me.linkLabel3.AutoSize = True
            Me.linkLabel3.BackColor = System.Drawing.Color.Transparent
            Me.linkLabel3.ClassName = ""
            Me.linkLabel3.Cursor = System.Windows.Forms.Cursors.Hand
            Me.linkLabel3.CustomFontFamilies = ""
            Me.linkLabel3.DisabledLinkColor = System.Drawing.SystemColors.InactiveCaptionText
            Me.linkLabel3.Enabled = False
            Me.linkLabel3.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.linkLabel3.HoverLinkColor = System.Drawing.Color.Orange
            Me.linkLabel3.Image = Nothing
            Me.linkLabel3.LinkArea = New System.Windows.Forms.LinkArea(0, 19)
            Me.linkLabel3.LinkColor = System.Drawing.Color.Blue
            Me.linkLabel3.Location = New System.Drawing.Point(394, 57)
            Me.linkLabel3.Name = "linkLabel3"
            Me.linkLabel3.Opacity = 100
            Me.linkLabel3.Size = New System.Drawing.Size(117, 15)
            Me.linkLabel3.TabIndex = 8
            Me.linkLabel3.TabStop = True
            Me.linkLabel3.Target = VisualJS.Web.Forms.LinkLabel.URLOpen.NewWindow
            Me.linkLabel3.TargetURL = ""
            Me.linkLabel3.Text = "Disabled Link Label"
            Me.linkLabel3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.linkLabel3.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.linkLabel3.TooltipText = ""
            Me.linkLabel3.UseMnemonic = False
            Me.linkLabel3.VisitedLinkColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
            Me.linkLabel3.ZOrder = 0
            '
            'linkLabel4
            '
            Me.linkLabel4.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(176, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
            Me.linkLabel4.AutoSize = True
            Me.linkLabel4.BackColor = System.Drawing.Color.Transparent
            Me.linkLabel4.ClassName = ""
            Me.linkLabel4.Cursor = System.Windows.Forms.Cursors.Hand
            Me.linkLabel4.CustomFontFamilies = ""
            Me.linkLabel4.DisabledLinkColor = System.Drawing.SystemColors.InactiveCaptionText
            Me.linkLabel4.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.linkLabel4.HoverLinkColor = System.Drawing.Color.Orange
            Me.linkLabel4.Image = Nothing
            Me.linkLabel4.LinkArea = New System.Windows.Forms.LinkArea(0, 20)
            Me.linkLabel4.LinkColor = System.Drawing.Color.Blue
            Me.linkLabel4.Location = New System.Drawing.Point(394, 81)
            Me.linkLabel4.Name = "linkLabel4"
            Me.linkLabel4.Opacity = 70
            Me.linkLabel4.Size = New System.Drawing.Size(118, 15)
            Me.linkLabel4.TabIndex = 9
            Me.linkLabel4.TabStop = True
            Me.linkLabel4.Target = VisualJS.Web.Forms.LinkLabel.URLOpen.NewWindow
            Me.linkLabel4.TargetURL = ""
            Me.linkLabel4.Text = "Link Label & Opacity"
            Me.linkLabel4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.linkLabel4.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.linkLabel4.TooltipText = ""
            Me.linkLabel4.UseMnemonic = False
            Me.linkLabel4.VisitedLinkColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
            Me.linkLabel4.ZOrder = 0
            '
            'linkLabel5
            '
            Me.linkLabel5.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(176, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
            Me.linkLabel5.AutoSize = True
            Me.linkLabel5.BackColor = System.Drawing.Color.GreenYellow
            Me.linkLabel5.ClassName = ""
            Me.linkLabel5.Cursor = System.Windows.Forms.Cursors.Hand
            Me.linkLabel5.CustomFontFamilies = ""
            Me.linkLabel5.DisabledLinkColor = System.Drawing.SystemColors.InactiveCaptionText
            Me.linkLabel5.Font = New System.Drawing.Font("Arial", 9.0!)
            Me.linkLabel5.HoverLinkColor = System.Drawing.Color.Orange
            Me.linkLabel5.Image = Nothing
            Me.linkLabel5.LinkArea = New System.Windows.Forms.LinkArea(0, 29)
            Me.linkLabel5.LinkColor = System.Drawing.Color.Blue
            Me.linkLabel5.Location = New System.Drawing.Point(394, 105)
            Me.linkLabel5.Name = "linkLabel5"
            Me.linkLabel5.Opacity = 100
            Me.linkLabel5.Size = New System.Drawing.Size(177, 15)
            Me.linkLabel5.TabIndex = 10
            Me.linkLabel5.TabStop = True
            Me.linkLabel5.Target = VisualJS.Web.Forms.LinkLabel.URLOpen.NewWindow
            Me.linkLabel5.TargetURL = ""
            Me.linkLabel5.Text = "Link Label & Background Color"
            Me.linkLabel5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
            Me.linkLabel5.TooltipDirection = VisualJS.Service.TooltipDirections.East
            Me.linkLabel5.TooltipText = ""
            Me.linkLabel5.UseMnemonic = False
            Me.linkLabel5.VisitedLinkColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(128, Byte), Integer))
            Me.linkLabel5.ZOrder = 0
            '
            'Labels
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(626, 156)
            Me.Controls.Add(Me.linkLabel5)
            Me.Controls.Add(Me.linkLabel4)
            Me.Controls.Add(Me.linkLabel3)
            Me.Controls.Add(Me.linkLabel2)
            Me.Controls.Add(Me.linkLabel1)
            Me.Controls.Add(Me.label6)
            Me.Controls.Add(Me.label5)
            Me.Controls.Add(Me.label4)
            Me.Controls.Add(Me.label3)
            Me.Controls.Add(Me.label2)
            Me.Controls.Add(Me.label1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "Labels"
            Me.StartPosition = VisualJS.Web.Forms.FormStartPosition.CenterScreen
            Me.Text = "Labels Demo"
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

		#End Region

		Private label1 As VisualJS.Web.Forms.Label
		Private label2 As VisualJS.Web.Forms.Label
		Private label3 As VisualJS.Web.Forms.Label
		Private label4 As VisualJS.Web.Forms.Label
		Private label5 As VisualJS.Web.Forms.Label
		Private label6 As VisualJS.Web.Forms.Label
		Private linkLabel1 As VisualJS.Web.Forms.LinkLabel
		Friend WithEvents linkLabel2 As VisualJS.Web.Forms.LinkLabel
		Private linkLabel3 As VisualJS.Web.Forms.LinkLabel
		Private linkLabel4 As VisualJS.Web.Forms.LinkLabel
		Private linkLabel5 As VisualJS.Web.Forms.LinkLabel
	End Class
End Namespace
